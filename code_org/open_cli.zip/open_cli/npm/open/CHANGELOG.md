# Changelog

Notable changes to `@bytedance/doudian-open-cli`. Command name: `doudian-open-cli`.

This project follows [Semantic Versioning](https://semver.org/).

## 1.0.1 - 2026-10-21

`init --output json` 返回的 `verification_url` 可直接打开，不再把查询参数里的 `&` 写成 `\u0026`。

## 1.0.0 - 2026-10-16

First stable public release.

Install with npm, then use `init` to sign in or store credentials, `auth` to check status or sign out, `api` to call Open Platform endpoints by path, and `skills` to read bundled Agent handbooks.

Requires Node.js 18+. Linux amd64/arm64, macOS Intel and Apple Silicon, Windows amd64.
