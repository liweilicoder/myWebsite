# doudian-open-cli

Chinese handbook: [README.zh-CN.md](./README.zh-CN.md).

Public CLI for Douyin Open Platform. The executable name is `doudian-open-cli`. Use `init` to authorize or store credentials locally, then call Open APIs by path with `api`. There is no per-API subcommand. Paths and fields follow the [Open Platform API docs](https://op.jinritemai.com/docs/api-docs).

This README covers install, login, flags, exit codes, output format, and upgrades. Flags on each command’s `--help` win if they differ.

## Environment

Requires **Node.js 18+**. Go is not required. After install, the launcher picks the binary for this machine.

| OS | Arch |
|---|---|
| Linux | AMD64, ARM64 |
| macOS | Intel (x64), Apple Silicon (ARM64) |
| Windows | AMD64 |

Any other combination fails with an explicit error.

## Install

```bash
npm install --global @bytedance/doudian-open-cli@latest
doudian-open-cli --version
doudian-open-cli --help
```

Check: `doudian-open-cli --version` prints one version line on stdout.

The executable name is `doudian-open-cli`. Installing another npm package that ships the same command will overwrite it.

## Upgrade

Installed copies do not auto-update. Reinstall latest:

```bash
npm install --global @bytedance/doudian-open-cli@latest
doudian-open-cli --version
```

## Commands

Default `--output json` (or explicit `-o json`). Success data on stdout; prompts and errors on stderr. Use `-o text` for a one-line human summary. `skills` is an exception; see below.

| Command | Purpose |
|---|---|
| `--help`, `-h` | Usage for that command. Works on the root command and on `init`, `auth`, `api`, `skills` |
| `version` / `--version` | Print version |
| `skills` | List bundled skills: `open` first, then business skills; each line `name<TAB>description` |
| `skills <name>` | Print that skill’s SKILL.md. Does not write to the local Agent directory. Ignores `--output json` |
| `init --kind authorized` | Merchant Device Flow. No app key/secret typed in. Interactive terminals start then poll until done |
| `init --kind authorized --no-wait` | Start auth and return `verification_url` immediately. Required for Agents. Repeating while the session is valid reuses it |
| `init --kind authorized --complete` | Exchange the local pending session; blocks until success or timeout |
| `init --kind generic --app-key --app-secret --access-token` | Developer credentials written locally |
| `auth status` | Read local Open credentials (kind, app_key, expiry). No remote call. Never prints token/secret |
| `auth logout` | Delete local Open credentials. Run this before switching app or kind |
| `api [GET\|POST] --path <path> --data <json>` | Call the Open gateway with current credentials. `--path` is required. METHOD defaults to POST. Only GET and POST. Both kinds send HMAC `sign` / `sign_method`; callers never add `sign` |
| `api … --dry-run` | Preview method, URL, query keys, and body. No HTTP. Hides token/secret/CLI audit headers |

Prefix every command below with `doudian-open-cli`.

## Login

You must initialize locally before calling APIs. Credentials stay on this machine. `kind` is `authorized` (merchant browser auth) or `generic` (developer `app_key` / `app_secret` / `access_token`). A second `init` fails if credentials already exist; `auth logout` then `init`.

### Status and logout

```bash
doudian-open-cli auth status --output json
doudian-open-cli auth logout --output json
```

- Signed in: `"authenticated":true`, plus `identity` (`kind`, `app_key`, `expires_at`, …). Exit code 0.
- Signed out: `"authenticated":false`. Exit code still 0.
- `auth logout` deletes local credentials. Success has `"authenticated":false`.

Sign in again if `authenticated` is false, `expires_at` has passed, or `api` returns `type` `auth`. Generic credentials without `--expires-at` are not expired locally; wait for the gateway then `init`.

### Merchant auth (human at a terminal)

One command starts auth, opens a browser, and waits:

```bash
doudian-open-cli init --kind authorized --output json
```

stderr prints `请在浏览器打开: <verification_url>`. After success, `auth status` has `kind` `authorized`.

### Merchant auth (Agent, two steps)

1. Start auth, return the URL immediately. Does not write credentials or open a browser:

```bash
doudian-open-cli init --kind authorized --no-wait --output json
```

Give the user `verification_url` from stdout unchanged (keep the query). stderr prints the same URL. Repeating `--no-wait` while the session is valid reuses it.

2. After the user finishes, the Agent exchanges the ticket (immediately, or after the user confirms):

```bash
doudian-open-cli init --kind authorized --complete --output json
```

With no pending session this fails and tells you to run `--no-wait` first. Do not ask the user to run `--complete`. Do not put `device_code`, tokens, or secrets in chat. `device_code` is not printed. Locally it is stored as a keychain-encrypted file, not plaintext `login-session.json`. `auth logout` removes that session and the saved credentials. It does not remove the master key from the system keychain.

### Developer credentials

All three flags are required. They stay local and must not appear in chat or logs:

```bash
doudian-open-cli init --kind generic --app-key "$APP_KEY" --app-secret "$APP_SECRET" --access-token "$ACCESS_TOKEN" --output json
```

Authorized credentials have no `app_secret`. The CLI still fills `sign` and `sign_method` the same way as generic (generic uses `app_secret`). Callers must not add `sign`.

## Output format

Root `-o` / `--output` is `json` (**default**) or `text`. Omitting it is the same as `--output json` for `init` / `auth` / `api`. Agents and scripts can parse the default json. Use `-o text` only for a short human summary.

Check the process exit code first, then parse the matching stream. Do not parse stderr as success JSON.

### json success (default)

stdout is exactly one JSON object, newline-terminated. `ok` is `true`. Prompts and the auth URL go to stderr.

On a successful `api`, `data` is only the gateway body’s `data` (for example `{"task_id":"..."}`), not the full gateway JSON. Gateway `log_id` appears as `meta.log_id`. For authorized `init --no-wait`, `meta.log_id` comes from the `device/start` response header `x-tt-logid`; `--complete` or a one-shot authorized `init` uses the last `device/token` response’s same header. Failures after a request was sent put that id on stderr as `log_id`.

Signed-in `auth status` fields: `ok`, `identity`, `data.authenticated`. `--dry-run` also has `dry_run: true`.

### identity

Present only on **json success** when this machine **already has Open credentials**. Empty fields are omitted. Current fields are the three below. Token / `app_secret` are never printed. `shop_id` / `shop_name` are not filled.

| Field | When |
|---|---|
| `kind` | `authorized` or `generic` |
| `app_key` | App key from credentials |
| `expires_at` | RFC3339. Omitted when credentials have no expiry. Authorized: from the token exchange. Generic: only if `init` passed `--expires-at` |

Present for: successful `init` that wrote credentials (generic, or authorized wait / `--complete`), signed-in `auth status`, successful `api`, `api --dry-run`.

Absent for: signed-out `auth status`, `auth logout`, `init --no-wait` (not signed in yet), failure stderr, `skills`, `-o text` (text success is only `ok dry_run=...`).

### json failure (default)

stdout is empty. stderr is one JSON object: `type`, `message`, and maybe `hint`, `log_id`, `code`. When the Open gateway returns its usual failure JSON, `body` is that JSON. The CLI **does not** print HTTP response headers or the remote page.

If `api` gets a response that is not that JSON (any HTTP status, for example 401 / 403 / 502 HTML or plain text), stderr is only the status line, for example:

```json
{"type":"api","message":"网关 HTTP 502 Bad Gateway"}
```

`message` is always `网关 HTTP ` plus the HTTP status line, same template for every status. Authorized `init` uses `授权 start 返回 HTTP 502` / `授权 token 返回 HTTP 502` (digits only, no reason phrase).

### text (explicit `-o text`)

Success stdout is one line `ok dry_run=true|false` and does **not** print `data` or `log_id`. Failure stderr is `type: message`, optionally a `hint` line, and the gateway body when that JSON was parsed. Do not parse business fields from text.

### `skills` exception

`skills` ignores `--output`. stdout is always plain text, not a JSON envelope. On failure stdout is empty.

token, `app_secret`, and `device_code` never appear on stdout or stderr.

## Exit codes

| Exit code | `type` | Meaning |
|---|---|---|
| 0 | — | Success |
| 1 | `api` | Gateway or business failure |
| 2 | `validation` | Invalid arguments |
| 3 | `auth` | Not signed in, credentials expired, or authorization failed. Follow `hint` and `init` again |
| 4 | `network` | Network error |
| 5 | `internal` | CLI internal error |

`auth status` still exits 0 when signed out.

## Commands and flags

Prefix with `doudian-open-cli`.

### Global

| Flag | Meaning |
|---|---|
| `-h`, `--help` | Print help and exit. Root, `init`, `auth`, `api`, `skills` |
| `-o`, `--output` | `json` (default) or `text`. Ignored by `skills` |
| `-v`, `--version` | Root only. Print version |
| `version` | Subcommand. Same as `--version`; one version line on stdout |

### skills

For Agents to read bundled docs. Does not write to disk.

```bash
doudian-open-cli skills
doudian-open-cli skills open_cli_skill
doudian-open-cli skills <business-name>
```

No args: list `open` first, then business skills. Each line `name<TAB>description`. Unknown name exits 2.

### init

No positional args.

| Flag | Meaning |
|---|---|
| `--kind` | `authorized` or `generic`. Required for a bare `init`. Optional with `--no-wait` or `--complete`; then defaults to `authorized` |
| `--no-wait` | Start auth and return `verification_url`, `user_code`, `expires_in`, `interval`, `hint`. Not with `--complete` or `--device-code`. Not for `generic` |
| `--complete` | Finish the local pending session and write credentials. Not for `generic` |
| `--device-code` | Optional. Must match the local pending session. Usually omit |
| `--app-key` | Required for generic |
| `--app-secret` | Required for generic |
| `--access-token` | Required for generic |
| `--expires-at` | Optional RFC3339. Generic only. Authorized expiry comes from the auth result |

### auth

`auth` alone does nothing. `status` / `logout` have no extra flags.

### api

```text
doudian-open-cli api [GET|POST] --path <path> --data <json> [--dry-run]
```

METHOD may be omitted (POST). `--path` is required and is not a positional path; it must start with `/`. A full URL is reduced to its path. Only GET and POST.

| Flag | Meaning |
|---|---|
| `--path` | Required. Open API path, or a URL whose path is used |
| `--data` | JSON object. Required for POST; optional for GET (`{}` if omitted). Inline, `@file`, or `@-` |
| `--dry-run` | Preview `http_method`, `path`, gateway `method`, `url`, `query_keys`, `body`. No HTTP. Fails if not signed in |

```bash
doudian-open-cli api POST --path '/product/detail' --data '{}' --dry-run --output json
doudian-open-cli api --path '/product/detail' --data '{"product_id":"..."}' --output json
doudian-open-cli api GET --path '/product/list' --data '{"page":1}' --output json
```

For writes, `--dry-run` first, confirm parameters with the user, then send the same request without `--dry-run`.

## Agent usage

1. `doudian-open-cli skills` — pick a skill from the descriptions.
2. `doudian-open-cli skills open_cli_skill` or `doudian-open-cli skills <business-name>` — print SKILL.md.
3. `doudian-open-cli auth status` — confirm login (default json); otherwise `init` as above.
4. `doudian-open-cli api … --dry-run` then send.

This package does not install skills into the local Agent directory.

## Limits and network

- No `+` shortcuts, `--appkey`, `api invoke`, or `auth login`
- Remote calls are HTTPS: auth and Open gateway `https://openapi-fxg.jinritemai.com`; API docs [https://op.jinritemai.com/docs/api-docs](https://op.jinritemai.com/docs/api-docs)

## Examples

Commands below omit `--output json` (it is the default). Add `-o text` for a short human line. Check the exit code first: `0` → parse stdout; non-zero → stdout is empty, parse stderr.

### skills

```bash
doudian-open-cli skills
doudian-open-cli skills open_cli_skill
doudian-open-cli skills doudian_aigc
doudian-open-cli skills doudian_aigc --ref create_video
```

No-arg stdout is plain text, `name<TAB>description` per line, ignoring `--output`.

### auth status (signed out, exit 0)

```bash
doudian-open-cli auth status
```

stdout:

```json
{"ok":true,"dry_run":false,"data":{"authenticated":false}}
```

### auth status (signed in, exit 0)

```json
{
  "ok": true,
  "dry_run": false,
  "identity": {
    "kind": "authorized",
    "app_key": "6845161900440045064",
    "expires_at": "2026-10-01T15:29:00+08:00"
  },
  "data": {"authenticated": true}
}
```

### Generic login

```bash
doudian-open-cli init --kind generic \
  --app-key "$APP_KEY" \
  --app-secret "$APP_SECRET" \
  --access-token "$ACCESS_TOKEN"
```

stdout looks like:

```json
{
  "ok": true,
  "dry_run": false,
  "identity": {"kind": "generic", "app_key": "6845161900440045064"},
  "data": {"kind": "generic", "authenticated": true}
}
```

Without `--expires-at` there is no `identity.expires_at`.

### Merchant auth (Agent, two steps)

```bash
doudian-open-cli init --kind authorized --no-wait
```

stdout includes `verification_url`, `user_code`, `expires_in`, `interval`, `hint`. Give `verification_url` to the user unchanged. After they finish:

```bash
doudian-open-cli init --kind authorized --complete
```

A human at a terminal can wait in one command: `doudian-open-cli init --kind authorized`.

A second `init` fails (exit 3) if credentials already exist; `auth logout` first.

### api preview (no HTTP)

```bash
doudian-open-cli api POST --path '/product/detail' --data '{}' --dry-run
```

stdout `data` has `http_method`, `path`, gateway `method`, `url`, `query_keys`, `body`. No token/secret.

```json
{
  "ok": true,
  "dry_run": true,
  "identity": {
    "kind": "authorized",
    "app_key": "6845161900440045064",
    "expires_at": "2026-10-01T15:29:00+08:00"
  },
  "data": {
    "http_method": "POST",
    "path": "/product/detail",
    "method": "product.detail",
    "url": "https://openapi-fxg.jinritemai.com/product/detail",
    "query_keys": ["access_token", "app_key", "method", "sign", "sign_method", "timestamp", "v"],
    "body": {}
  }
}
```

### api success (exit 0)

When the gateway `code` is `10000`, CLI puts gateway `data` in the envelope `data` and `log_id` in `meta.log_id`.

```bash
doudian-open-cli api POST --path '/contentAigc/createAIVideoTaskOpen' --data '{"...":"..."}'
```

stdout:

```json
{
  "ok": true,
  "dry_run": false,
  "identity": {
    "kind": "generic",
    "app_key": "7687517554562303517"
  },
  "data": {"task_id": "584875801346"},
  "meta": {"log_id": "20261010113423729861E2FDCC5D1FB32F"}
}
```

Reads and lists also come from `data`, for example:

```bash
doudian-open-cli api --path '/product/detail' --data '{"product_id":"..."}'
doudian-open-cli api GET --path '/product/list' --data '{"page":1}'
```

`--data` also accepts `@file` or `@-` (stdin).

### api gateway business failure (exit 1)

stdout empty. stderr:

```json
{
  "type": "api",
  "code": "dop.service-timeout-error",
  "message": "服务内部访问超时，请重试",
  "log_id": "2026092416541870A80A208A3767DE168F",
  "body": {
    "code": 20001,
    "msg": "内部服务超时",
    "sub_code": "dop.service-timeout-error",
    "sub_msg": "服务内部访问超时，请重试",
    "data": null,
    "log_id": "2026092416541870A80A208A3767DE168F"
  }
}
```

### token invalid (exit 3)

stderr has `type` `auth` and `hint`; follow the hint and `init` again:

```json
{
  "type": "auth",
  "code": "isv.access-token-no-existed",
  "message": "access_token不存在，请使用最新的access_token访问",
  "hint": "先运行 doudian-open-cli init",
  "log_id": "20260924163802231CAD329A205AFAF287",
  "body": {
    "code": 40003,
    "msg": "access_token不存在，请使用最新的access_token访问",
    "sub_code": "isv.access-token-no-existed",
    "sub_msg": "access_token不存在，请使用最新的access_token访问",
    "data": null,
    "log_id": "20260924163802231CAD329A205AFAF287"
  }
}
```

### invalid arguments (exit 2)

For example missing `--data`. stderr: `{"type":"validation","message":"--data 不能为空"}`

### HTTP failure that is not Open JSON (exit 1)

Any unsuccessful HTTP status whose body is not the Open JSON envelope: see “json failure” above. Do not look for response headers or the remote page on stderr.

### network timeout (exit 4)

Unreachable or the whole request exceeds the default 30s. This is **not** “the peer returned an HTTP status”. Timeout stderr looks like:

```json
{"type":"network","message":"Post \"https://openapi-fxg.jinritemai.com/auth/cli/device/start\": context deadline exceeded (Client.Timeout exceeded while awaiting headers)"}
```

### explicit text

```bash
doudian-open-cli -o text api --path '/product/detail' --data '{"product_id":"..."}'
```

Success stdout is only `ok dry_run=false`, with no `task_id` / `log_id`. Agents should not use this mode.
