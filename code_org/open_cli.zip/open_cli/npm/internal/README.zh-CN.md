# @ecom-open-cli/opencli

英文主文档：[README.md](./README.md)。

抖店开放平台**对内** CLI（`doudian-open-cli`）。这是对外能力的超集：含开放面 `init` / `auth` / `api` / `skills`，以及点将台配置命令 `djt`。

## npm 安装（推荐）

Node.js 18 及以上可从公司 npm registry 安装，无需 Go 环境。npm 包坐标暂保持 `@ecom-open-cli/opencli`，安装后唯一暴露的可执行命令为 `doudian-open-cli`。包内携带 Linux AMD64/ARM64、macOS Intel/Apple Silicon、Windows AMD64 二进制。点将台 `djt self skill` 只在 macOS/Linux 写入本机 Agent 目录：

```bash
npm install --global @ecom-open-cli/opencli --registry=https://bnpm.byted.org
doudian-open-cli --help
doudian-open-cli --version
doudian-open-cli djt version
```

已安装用户或 Agent 不会自动升级。要获取 BNPM 上最新 CLI 和随包发布的 Skill，执行：

```bash
npm install --global @ecom-open-cli/opencli@latest --registry=https://bnpm.byted.org
doudian-open-cli --version
doudian-open-cli djt self skill update --output json
```

如果点将台 Skill 尚未安装，使用 `doudian-open-cli djt self skill install --output json`；`update` 只更新本机已经存在的 Skill 目标。开放与业务 Skill 用 `doudian-open-cli skills` 列出、`doudian-open-cli skills <name>` 打印全文，不安装到本机。

`doudian-open-cli --version` 与 `doudian-open-cli djt version` 都只在 stdout 输出一行版本号。npm 多平台二进制显示 package 版本；未注入版本的源码构建默认显示 `dev`。

安装钩子会 best-effort 静默安装点将台 Skill，最长等待 30 秒；失败不会阻断 npm 安装。若使用 `--ignore-scripts`，或钩子提示失败，请显式执行：

```bash
doudian-open-cli djt self skill install --output json
```

## 源码测试与安装

拉取代码后，先在仓库根目录执行质量检查：

```bash
go test ./...
go test -race ./...
go vet ./...
go build ./cmd/doudian-open-cli-internal
```

`go build ./cmd/doudian-open-cli-internal` 会在当前目录生成对内二进制，可用 `./doudian-open-cli --help` 直接预览；它不会自动加入 `PATH`。要在任意目录直接输入 `doudian-open-cli`，执行：

```bash
go install ./cmd/doudian-open-cli-internal
export PATH="$(go env GOPATH)/bin:$PATH" # 未设置 GOBIN 时
doudian-open-cli --help
```

如设置了 `GOBIN`，请把该目录加入 `PATH`。因此不是“编译后一定能直接全局调用”：`go build` 适合本地验证，`go install` 才是本机安装。

## Agent 使用入口

本 CLI 参考 Lark CLI/bytedcli 的 Agent-first 思路，将运行时命令契约和操作流程随 npm 分发：

- `doudian-open-cli skills`：列出开放与业务 Skill；`skills open_cli_skill` / `skills <业务名>` 打印对应 `SKILL.md`，不写入本机。
- `skills/djt/`：Agent 可直接加载的点将台完整 Skill。`SKILL.md` 是入口 Hub；`api.md` 与 `spi.md` 同级分别承载 OpenAPI / SPI 完整 SOP；`scripts/` 提供离线树处理。整个目录是发布和内嵌镜像的唯一手工维护源。
- `skills/djt/scripts/apply_style_patches.py`：按现有 `path` 在本地修改完整 `requestInfo` 树（style，以及 `mustNeed` / `example` / `description`）。叶子打成内部变量/常量后，会把「子节点全是 2/3」的中间 struct 提升为 style=2，与网页 Split+Merge 一致。网页示例值和描述没有单独 CLI flag。
- `skills/djt/scripts/validate_style_tree.py`：基于 `doudian-open-cli djt api get` JSON 或显式内部变量名，在本地预检 style/path 约束（含未提升的 style=1 中间节点）。
- `skills/djt/api.md` **§3a/§3c**：嵌套内部变量/常量时父 struct 须与网页 Split+Merge 一致（style=2）；以及 **open_gw 不支持或弱支持** 的形态（如 map 内透传、嵌套 map、list of map 等）。配置 request 前必读。
- `skills/djt/scripts/json_to_spi_param_tree.py`：将 SPI 示例 JSON 转为 request/response 字段树，只做本地转换，不得联网。
- 分层命令：`doudian-open-cli <domain> <resource> <action>`；自动化调用默认使用 `--output json`。

`AGENTS.md` 仅用于仓库内开发和维护，不属于 npm 运行时依赖，也不会被打进发布包。维护者向 BNPM **发包**前须先 `bnpm login --auth-type=sso`（Lark 扫码），详见 `AGENTS.md` 的「npm 发布 SOP」。

可用内置命令把完整 Skill 目录安装到本机 Agent。canonical 目标 `~/.agents/skills/djt/` 始终可创建；Claude（`CLAUDE_CONFIG_DIR` 或 `~/.claude`）和 Codex（`CODEX_HOME` 或 `~/.codex`）仅在对应 Agent 根目录已存在时写入：

```bash
doudian-open-cli djt self skill install
doudian-open-cli --output json djt self skill status
doudian-open-cli djt self skill update
```

`install` 创建缺失项并同步旧版本，`update` 只更新已存在项，`status` 只读。环境变量指定的 Agent 根必须是绝对路径；命令会去重相同目标并拒绝符号链接或异常文件类型。多个目标独立处理，任一目标失败时仍输出全部目标结果并以非零状态退出。

Agent 无需由用户逐条教学。所有 DJT 请求固定连接 `https://djt.bytedance.net`；登录时仍需用户在浏览器完成公司 SSO/授权，Agent 应把登录过程 stderr 中的授权 URL 和用户代码展示给用户。

### npm 安装与 DJT 登录时序

```mermaid
sequenceDiagram
    autonumber
    actor User as 用户
    participant Agent as 全新 Agent
    participant NPM as npm / BNPM
    participant Hook as doudian-open-cli postinstall
    participant DJT as DJT 服务
    participant Browser as 浏览器 / 公司 SSO

    User->>Agent: 要求安装 doudian-open-cli
    Agent->>NPM: npm install --global @ecom-open-cli/opencli --registry=https://bnpm.byted.org
    NPM-->>Agent: launcher + 平台二进制 + skills/djt
    NPM->>Hook: 执行 postinstall
    Hook->>Hook: doudian-open-cli djt self skill install --output json
    Hook-->>Agent: 安装 djt Skill 到 Agent Skill 目录
    Note over Hook,Agent: postinstall 为 best-effort，失败或 30 秒超时不阻断 npm 安装

    User->>Agent: 要求执行 DJT 操作
    Agent->>Agent: 加载 djt Skill
    Agent->>Agent: doudian-open-cli djt auth status --output json

    alt 已登录
        Agent->>DJT: 继续执行 API、PSM 或业务域命令
    else 未登录或凭据过期
        Agent->>DJT: auth login start --output json
        DJT-->>Agent: authorization URL + user code + expires_at
        Agent-->>User: 原样展示 URL 和用户代码，请用户授权
        User->>Browser: 打开 URL并完成公司 SSO
        Browser->>DJT: 授权 Device Code
        User->>Agent: 已完成授权
        Agent->>DJT: auth login complete --output json
        DJT-->>Agent: Token 与当前用户身份
        Agent->>Agent: 安全保存本地凭据并继续原操作
    end
```

> Agent 使用两段式登录：先运行 `doudian-open-cli djt auth login start --output json`，立即把返回的授权 URL 和用户代码展示给用户；用户完成授权后，再运行 `doudian-open-cli djt auth login complete --output json`。待完成会话会安全保存在本地，因此不依赖前台命令跨对话轮次持续运行。若安装时使用了 `--ignore-scripts` 或 postinstall 失败，请执行 `doudian-open-cli djt self skill install --output json`，并让 Agent 重新加载 Skill。

## 使用示例

### 1. 登录

Agent 跨对话授权：

```bash
doudian-open-cli djt auth login start --output json
# 用户完成浏览器授权后
doudian-open-cli djt auth login complete --output json
```

`start` 会立即返回授权 URL、用户代码和过期时间，并保存可恢复的短期登录会话；`complete` 使用同一会话换取并保存正式凭据。会话有效期间不要重复执行 `start`。

人工终端也可继续使用兼容的一步式登录：

```bash
doudian-open-cli djt auth login
```

该命令会保持前台运行直至浏览器授权完成，不适合 Agent 跨对话轮次等待。

### 2. 查看状态

```bash
doudian-open-cli djt auth status
doudian-open-cli --output json djt auth status
```

### 3. 查看身份

```bash
doudian-open-cli djt auth whoami
```

### 4. 查询 BAM 元数据、业务域并确认 init 清单

`api init` 必须显式提供 `PSM`、`methodName` 和 `bamVersionId`。DJT CLI 不维护 PSM、BAM 方法或版本列表；Agent 应优先使用运行环境已有的 BAM Skill，否则使用 `bytedcli` 的只读 JSON 查询能力：

```bash
bytedcli --json bam psm search '<PSM 或服务关键词>'
bytedcli --json bam method list --psm '<PSM>' --name '<方法名或路径>' --count 20
bytedcli --json bam version list '<PSM>'
```

`psm search` 和 `version list` 不支持 `--count`。Agent 应通过方法结果确认 `name` / `rpc_method`，并结合方法的 `version` / `latest_version` 与版本列表中的分支、提交和时间确定候选。不能猜测 PSM，不能跨分支机械选择最大版本；存在多个合理候选时必须展示给用户选择。BAM Skill/bytedcli 只负责发现元数据，点将台写操作仍全部通过 `doudian-open-cli djt` 完成。

业务域来自当前环境动态表，禁止硬编码枚举。执行 init 前必须先查询：

```bash
doudian-open-cli djt biz-domain list --output json
```

JSON 固定输出 `{code,message,data}` envelope，`data` 保留 `total`、`domainInfoList`、`ownerdomainInfoList`；每个业务域至少包含 `domainId`、`domainName`、`suffixList`。text 模式逐行显示 `id`、`name`、`prefix` 和当前用户是否 `available`。

Agent 必须把动态列表和以下确认清单展示给用户，并等待用户明确答复：新建/重绑、PSM、methodName、bamVersionId、interfaceName（省略会生成测试路径）、bizDomainId、ownerList（省略为当前用户）、skipAuth、desc、sceneDesc、interfaceCateId。禁止 Agent 自行选择默认测试域或伪造确认。

### 5. 配置点将台接口

以下五个命令是正式 Agent Interface 入口；建议始终添加 `--output json`：

```bash
# 三个 selector 必须且只能选一个：--interface-id / --interface-name / --interface-name-like
doudian-open-cli djt api get --interface-id 2846 --output json

# init 没有 dry-run；获得用户明确确认后，两道本地门禁必须同时传入
doudian-open-cli djt api init \
  --psm your.psm.name \
  --method-name TestTemplateInterface \
  --bam-version-id 1.0.340 \
  --biz-domain-id 8 \
  --confirmed-by-user --apply --output json
```

`--biz-domain-id` 必须显式传入且大于 0，CLI 不再静默默认到业务域 15。必须先执行 `doudian-open-cli djt biz-domain list --output json`，把动态结果和确认清单展示给用户，获得明确答复后再 init。`--confirmed-by-user` 只是本地语义门禁，不会进入 HTTP 请求体；它与既有 `--apply` 缺一不可。

`init` 直接落库；新建或重绑时，即使 BAM 绑定/解析失败，已创建的草稿也不会回滚。确认清单中 `interfaceName` 省略会生成测试路径，`ownerList` 省略为当前用户。此双门禁和确认 SOP 只约束 `init`，不扩展到 `save`、`doc` 或 `advance-step`。

```bash
# save 默认 dry-run；显式预览后，使用同一 payload 改为 --apply
doudian-open-cli djt api save \
  --interface-id 2846 --modify-version-id 42 \
  --sections request --request-info @request.json \
  --dry-run --output json
doudian-open-cli djt api save \
  --interface-id 2846 --modify-version-id 42 \
  --sections request --request-info @request.json \
  --apply --output json

# doc 调用即落库，没有 --dry-run，必须显式 --apply
doudian-open-cli djt api doc \
  --interface-id 2846 --modify-version-id 43 \
  --desc '查询订单' --scene-desc '商家查询单笔订单' \
  --apply --output json

# advance-step 也必须先 dry-run 检查，再使用当前版本 apply
doudian-open-cli djt api advance-step \
  --interface-id 2846 --modify-version-id 44 \
  --step request --dry-run --output json
doudian-open-cli djt api advance-step \
  --interface-id 2846 --modify-version-id 44 \
  --step request --apply --output json

# submit-audit 必须同时提供非空 audit reason 与 Meego 地址
doudian-open-cli djt api advance-step \
  --interface-id 2846 --modify-version-id 48 \
  --step submit-audit --audit-reason '首次发布' \
  --audit-meego 'https://meego.bytedance.net/xxx' \
  --dry-run --output json
doudian-open-cli djt api advance-step \
  --interface-id 2846 --modify-version-id 48 \
  --step submit-audit --audit-reason '首次发布' \
  --audit-meego 'https://meego.bytedance.net/xxx' \
  --apply --output json
doudian-open-cli djt api get --interface-id 2846 --output json # 确认 statusV2=310 并取最新版本

# cancel-audit 将审核中状态撤回到文档编辑态，同样先 dry-run 再 apply
doudian-open-cli djt api advance-step \
  --interface-id 2846 --modify-version-id 49 \
  --step cancel-audit --dry-run --output json
doudian-open-cli djt api advance-step \
  --interface-id 2846 --modify-version-id 49 \
  --step cancel-audit --apply --output json
doudian-open-cli djt api get --interface-id 2846 --output json # 确认 statusV2=200
```

审核闭环固定为：submit-audit dry-run/apply → get 确认 statusV2=310 → cancel-audit dry-run/apply → get 确认 statusV2=200。禁止推进到 330+；审核通过后的发布只能由用户在网页完成。

`save` 和 `advance-step` 在不传模式参数时安全默认 `--dry-run`，且 `--dry-run` 与 `--apply` 互斥。必须检查 dry-run 响应中的 `preview`、`diff`、`errors`，确认后才执行 `--apply`。`init`、`doc` 没有 dry-run；`init` 缺少 `--confirmed-by-user --apply` 任一门禁时不会发请求，`doc` 缺少显式 `--apply` 时不会发请求；`doc` 成功后 `modifyVersionId` 可能改变，应重新 `get`。

### 5.1 配置 SPI 场景与接口

SPI 命令与 API 并列，写操作同样先 `--dry-run` 检查 `preview`/`errors`，再 `--apply`。最短路径：

```text
scene save --apply → interface：json_to_spi_param_tree.py → 补必填/加密/Map/Header
→ interface save --dry-run → 看 preview/errors → save --apply
（新建还要 biz-domain list + --confirmed-by-user）
→ get 记录 modifyVersionId
→ submit-review --dry-run → --apply
→ 网页审核（CLI 停止）
```

```bash
doudian-open-cli djt spi scene list --scene-name your --page 1 --page-size 20 --output json

doudian-open-cli djt spi interface list --name-like prefix --page 1 --page-size 20 --output json
doudian-open-cli djt spi interface list --scene-id 248 --name-like order --output json

doudian-open-cli djt spi scene save \
  --scene-name your_scene --scene-desc '场景描述' \
  --dry-run --output json
doudian-open-cli djt spi scene save \
  --scene-name your_scene --scene-desc '场景描述' \
  --apply --output json

doudian-open-cli djt biz-domain list --output json

python3 skills/djt/scripts/json_to_spi_param_tree.py \
  --kind request --in request-example.json --out request-info.json

doudian-open-cli djt spi interface save \
  --scene-id 1 --interface-name prefix/name --biz-domain-id 8 \
  --request-info @request-info.json --dry-run --output json
doudian-open-cli djt spi interface save \
  --scene-id 1 --interface-name prefix/name --biz-domain-id 8 \
  --request-info @request-info.json \
  --confirmed-by-user --apply --output json

doudian-open-cli djt spi interface get --interface-id 1 --output json
doudian-open-cli djt spi interface get --interface-name prefix/name --output json

doudian-open-cli djt spi scene access-app list --scene-id 248 --output json
doudian-open-cli djt spi scene access-app get --scene-id 248 --app-id 12345 --output json

doudian-open-cli djt spi interface submit-review \
  --interface-id 1 --modify-version-id 42 --reason '首次发布' \
  --meego 'https://meego.bytedance.net/xxx' --dry-run --output json
doudian-open-cli djt spi interface submit-review \
  --interface-id 1 --modify-version-id 42 --reason '首次发布' \
  --meego 'https://meego.bytedance.net/xxx' --apply --output json

doudian-open-cli djt spi scene access-app save --scene-id 1 --app-id 12345 --dry-run --output json
doudian-open-cli djt spi scene access-app enable --auth-id 99 --apply --output json  # save 后仍为未启用，需要可见时再 enable --apply
```

提审后到网页完成审核。可选：

```bash
doudian-open-cli djt spi scene sync-boe --scene-id 1 --app-ids '[12345]' --dry-run --output json
doudian-open-cli djt spi interface cancel-upgrade --interface-id 1 --dry-run --output json
doudian-open-cli djt biz-domain apply --domain-ids 8,15 --output json
```

完整 SOP 见 `skills/djt/spi.md`（与 `skills/djt/api.md` 同级）。

复杂数组参数支持统一 JSON source 语法，适用于 `--request-info`、`--response-info`、`--err-config-list`、`--style-patches`、`--owner-list` 和 `--auth-subject-ids`：

```bash
# inline
doudian-open-cli djt api save ... --request-info '[{"path":"shopId"}]' --dry-run
# @file（实际写法是 @ 后紧跟路径）
doudian-open-cli djt api save ... --request-info @request.json --dry-run
# @-：从 stdin 读取；同一命令最多使用一次
doudian-open-cli djt api save ... --request-info @- --dry-run < request.json
```

每个 JSON source 最大 8 MiB，必须恰好包含一个 JSON 文档且顶层为数组；传整棵 `requestInfo` / `responseInfo` 时是整区替换，不是增量 patch。Agent Interface 响应体最大 8 MiB，超限会安全失败且不回显响应原文。

所有请求固定连接 `https://djt.bytedance.net`，没有 base URL、任意 method/path/header 或 raw API 覆盖入口。`advance-step` 会先 `get` 检查版本和状态；`statusV2 >= 330` 时拒绝推进，审核通过后的发布只能在网页完成。

### 6. 退出

```bash
doudian-open-cli djt auth logout
```

### 输出预览与分流

text 模式面向终端，成功内容写 `stdout`：

```text
$ doudian-open-cli djt auth whoami
吴昊天 <user@example.com>
```

JSON 模式的最终结构化结果只写 `stdout`，登录过程提示写 `stderr`，便于脚本安全解析：

```text
$ doudian-open-cli -o json djt auth status >result.json 2>prompt.log
$ cat result.json
{"authenticated":true,"user":{"employee_id":"123","employee_name":"吴昊天","email":"user@example.com","head_url":"","user_type":1,"authority_list":["interface.read"]},"expires_at":"2026-08-06T12:00:00Z"}
```

Agent Interface 的 JSON 成功输出固定为恰好一个 `{"code":0,"message":"success","data":{}}` 文档并以换行结束；服务端 `data`（包括未知字段）保持 camelCase。成功 stdout 不混入摘要或日志；错误只由进程入口写一次 `stderr`，失败退出码为 `1`，失败 stdout 为空。调用方必须先检查退出码，不能把 stderr 当 JSON 解析。

命令错误由进程入口写 `stderr` 并以状态码 `1` 退出。text 输出会清理终端控制字符；任何输出和错误都不会包含当前 token。

## 安全说明

> **Demo 警示**：当前 token 保存在 `<os.UserConfigDir()>/doudian-open-cli/djt/credentials.json`，文件权限设置为 `0600`。
> 正式版本**必须**将 `CredentialStore` 的实现由明文文件替换为系统安全存储：
> - macOS: Keychain
> - Windows: Credential Manager
> - Linux: Secret Service (via dbus)

## 依赖说明

本 Demo 严格限制依赖，除 `github.com/spf13/cobra` 及其必要传递依赖外，仅使用 Go 标准库。

## API 测试

CLI 使用点将台内部测试应用执行与网页端一致的 BOE、PPE、PROD API 测试。`--params` 支持 inline JSON、`@file` 和 `@-`；`--lane` 是被测 API 泳道，与访问点将台 BFF 的隐藏 `--ppe-env` 含义不同。

`--auth-id`、`--auth-type` 在命令语法上可选，但必须遵循接口元数据：`skipAuth=false` 时二者必须同时传入，`skipAuth=true` 时二者可同时省略。服务端会在调用开放 API 网关前校验；需要授权却缺少主体时返回 `code=30030`，不会发起下游请求。不得根据 `authSubjectId=[0]` 推断免授权。

```bash
# 添加/刷新内部测试应用授权；店铺授权主体类型为 0
doudian-open-cli djt api test auth add \
  --env ppe \
  --auth-id 90419 \
  --auth-subject-biz-id 0

# PPE：需要授权的接口必须同时指定 auth-id 与 auth-type
doudian-open-cli djt api test ppe \
  --interface-name /test/zzhTestDDD \
  --lane ppe_djt_cli \
  --auth-id 90419 \
  --auth-type 0 \
  --params '{}'

# PPE：免授权接口同时省略 auth-id 与 auth-type
doudian-open-cli djt api test ppe \
  --interface-name /order/batchDecryptNoAuth \
  --lane ppe_djt_cli \
  --params @params.json

# PROD 必须显式确认；接口可能产生真实业务数据
doudian-open-cli djt api test prod \
  --interface-name /test/zzhTestDDD \
  --auth-id 90419 \
  --auth-type 0 \
  --params '{}' \
  --confirmed-by-user
```

自动化场景建议添加 `--output json`。CLI 不返回内部应用密钥或 access token；授权主体是否合法、店铺是否允许添加测试授权，均由点将台复用网页端规则校验。
