# Changelog

History before 0.3.16 is not recorded. Edit again before a public npmjs.com release.

## 0.3.20

JSON 输出里的 URL（含 `init` 的 `verification_url`、点将台 `data` 中的审核/文档链接）可直接打开，不再把查询参数里的 `&` 写成 `\u0026`。

## 0.3.19

All outbound HTTP requests send `X-Doudian-Open-Cli-Version` with the current CLI version.

## 0.3.18

Authorized and generic `api` calls both send HMAC `sign` / `sign_method`. Authorized uses the local fake token as the HMAC key (no `app_secret`).

## 0.3.17

Ship English `README.md`, `README.zh-CN.md`, `CHANGELOG.md`, and an empty `LICENSE` in the npm tarball.

## 0.3.16

Package contents as of the previous BNPM latest.
