# @ecom-open-cli/opencli

Chinese handbook (full internal SOP, including 点将台 / `djt`): [README.zh-CN.md](./README.zh-CN.md).

Internal CLI for Douyin Open Platform (`doudian-open-cli`). This is a superset of the public package: Open commands `init` / `auth` / `api` / `skills`, plus 点将台 `djt`.

Open-only usage matches [`@ecom-open-cli/doudian-open-cli`](https://bnpm.byted.org/-/web/detail/@ecom-open-cli/doudian-open-cli). Do not install both packages globally; the later install overwrites `doudian-open-cli`.

## Install

Node.js 18+. Package name stays `@ecom-open-cli/opencli`; the only executable is `doudian-open-cli`. The tarball includes Linux AMD64/ARM64, macOS Intel/Apple Silicon, and Windows AMD64 binaries. `djt self skill` writes the 点将台 skill on macOS/Linux only:

```bash
npm install --global @ecom-open-cli/opencli --registry=https://bnpm.byted.org
doudian-open-cli --help
doudian-open-cli --version
doudian-open-cli djt version
```

Installed copies do not auto-update. To get the latest CLI and bundled skills from BNPM:

```bash
npm install --global @ecom-open-cli/opencli@latest --registry=https://bnpm.byted.org
doudian-open-cli --version
doudian-open-cli djt self skill update --output json
```

If the 点将台 skill is not installed yet, run `doudian-open-cli djt self skill install --output json`. `update` only refreshes targets that already exist. Open and business skills are listed with `doudian-open-cli skills` and printed with `doudian-open-cli skills <name>`; they are not installed locally.

`doudian-open-cli --version` and `doudian-open-cli djt version` each print one version line on stdout.

postinstall best-effort installs the 点将台 skill (30s). Failure does not fail npm. With `--ignore-scripts`, or if the hook reports failure:

```bash
doudian-open-cli djt self skill install --output json
```

## Agent login (点将台)

Two-step login. Show the user the authorization URL and user code from `start`; after they finish SSO, run `complete`:

```bash
doudian-open-cli djt auth login start --output json
doudian-open-cli djt auth login complete --output json
```

Full command list, BAM, 业务域, SPI, PPE, and diagrams: [README.zh-CN.md](./README.zh-CN.md).

## LICENSE / changelog

This internal tarball currently ships an empty `LICENSE`. The public package `@bytedance/doudian-open-cli` includes the legal text. [CHANGELOG.md](./CHANGELOG.md) starts at the current version only.
