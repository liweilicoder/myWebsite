"""unittest 入口：复用 scripts/json_to_spi_param_tree.test.py 中的用例。"""

from __future__ import annotations

import importlib.util
import unittest
from pathlib import Path

_FLAT = Path(__file__).resolve().parent.parent / "json_to_spi_param_tree.test.py"


def load_tests(loader: unittest.TestLoader, tests: unittest.TestSuite, pattern: str) -> unittest.TestSuite:
    spec = importlib.util.spec_from_file_location("json_to_spi_param_tree_test_flat", _FLAT)
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot load {}".format(_FLAT))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return loader.loadTestsFromModule(module)
