import assert from 'node:assert/strict';
import { access, mkdtemp, mkdir, readFile, rm, writeFile } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import test from 'node:test';
import { fileURLToPath, pathToFileURL } from 'node:url';

const repo = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const scriptPath = path.join(repo, 'scripts/release-npm.mjs');

let releaseModule;
try {
  releaseModule = await import(pathToFileURL(scriptPath).href);
} catch {
  releaseModule = undefined;
}

const validState = {
  branch: 'main',
  status: '',
  localVersion: '0.2.14',
  publishedVersion: '0.2.13',
};

test('版本比较遵循 semver 预发布顺序', () => {
  assert.equal(releaseModule?.compareVersions?.('0.2.14', '0.2.13'), 1);
  assert.equal(releaseModule?.compareVersions?.('0.2.13', '0.2.13'), 0);
  assert.equal(releaseModule?.compareVersions?.('0.2.12', '0.2.13'), -1);
  assert.equal(releaseModule?.compareVersions?.('1.0.0-alpha.0', '0.2.21'), 1);
  assert.equal(releaseModule?.compareVersions?.('1.0.0-alpha.0', '1.0.0'), -1);
  assert.equal(releaseModule?.compareVersions?.('1.0.0-alpha.1', '1.0.0-alpha.0'), 1);
  assert.equal(releaseModule?.compareVersions?.('1.0.0-beta.0', '1.0.0-alpha.9'), 1);
  assert.equal(releaseModule?.compareVersions?.('1.0.0', '1.0.0-rc.0'), 1);
  assert.throws(() => releaseModule?.compareVersions?.('next', '0.2.13'), /版本格式/);
  assert.throws(() => releaseModule?.compareVersions?.('1.0.0-alpha', '1.0.0'), /版本格式/);
});

test('预发布版本默认打对应 dist-tag，禁止 latest', () => {
  assert.equal(releaseModule.resolveDistTag('1.0.0-alpha.0', { branch: 'main' }), 'alpha');
  assert.equal(releaseModule.resolveDistTag('1.0.0-beta.0', { branch: 'main' }), 'beta');
  assert.equal(releaseModule.resolveDistTag('1.0.0-rc.0', { branch: 'main' }), 'rc');
  assert.equal(releaseModule.resolveDistTag('1.0.0', { branch: 'main' }), 'latest');
  assert.equal(releaseModule.resolveDistTag('1.0.0', { branch: 'feat/x' }), 'beta');
  assert.equal(releaseModule.resolveDistTag('1.0.0-alpha.0', { tag: 'alpha', branch: 'main' }), 'alpha');
  assert.throws(() => releaseModule.resolveDistTag('1.0.0-alpha.0', { tag: 'latest', branch: 'main' }), /latest/);
  assert.throws(() => releaseModule.resolveDistTag('1.0.0-alpha.0', { tag: 'beta', branch: 'main' }), /alpha/);
});

test('发布状态要求 main、干净工作区和未发布的新版本', () => {
  assert.doesNotThrow(() => releaseModule?.validateReleaseState?.(validState));
  assert.throws(() => releaseModule?.validateReleaseState?.({ ...validState, branch: 'feat/test' }), /main/);
  assert.doesNotThrow(() => releaseModule?.validateReleaseState?.({ ...validState, branch: 'feat/test', allowDevBranch: true }));
  assert.throws(() => releaseModule?.validateReleaseState?.({ ...validState, status: ' M README.md' }), /工作区/);
  assert.throws(() => releaseModule?.validateReleaseState?.({ ...validState, localVersion: '0.2.13' }), /大于/);
  assert.doesNotThrow(() => releaseModule?.validateReleaseState?.({
    ...validState,
    localVersion: '0.1.0',
    publishedVersion: releaseModule.UNPUBLISHED_VERSION,
  }));
});

test('公开包名与目标 registry 随 --npmjs 切换', async () => {
  const { flavors } = await import(pathToFileURL(path.join(repo, 'scripts/npm-flavors.mjs')).href);
  assert.equal(releaseModule.publishedPackageName(flavors.open, { npmjs: true }), '@bytedance/doudian-open-cli');
  assert.equal(releaseModule.publishedPackageName(flavors.open, {}), '@ecom-open-cli/doudian-open-cli');
  assert.equal(releaseModule.targetRegistry({ npmjs: true }), 'https://registry.npmjs.org');
  assert.match(releaseModule.targetRegistry({}), /bnpm\.byted\.org/);
});

test('首次发包时把 BNPM 404 当成未发布', () => {
  assert.equal(
    releaseModule.readPublishedVersion('pkg', () => {
      const error = new Error('Command failed: npm view');
      error.stderr = 'npm error code E404\nnpm error 404 Not Found - GET https://bnpm.byted.org/pkg';
      throw error;
    }),
    '0.0.0',
  );
  assert.equal(
    releaseModule.readPublishedVersion('pkg', () => '["0.3.1","0.3.2","1.0.0-alpha.0"]\n'),
    '1.0.0-alpha.0',
  );
  assert.equal(releaseModule.highestPublishedVersion('"0.3.2"'), '0.3.2');
  assert.equal(releaseModule.highestPublishedVersion('["1.0.0-beta.0","1.0.0-alpha.9","0.9.9"]'), '1.0.0-beta.0');
  assert.throws(() => releaseModule.readPublishedVersion('pkg', () => {
    const error = new Error('Command failed: npm view');
    error.stderr = 'npm error code E403\nnpm error 403 Forbidden';
    throw error;
  }), /E403|Forbidden|Command failed/);
});

test('清理所有 npm 打包产物但保留其他文件', async () => {
  const tempRepo = await mkdtemp(path.join(os.tmpdir(), 'open-cli-release-'));
  try {
    await mkdir(path.join(tempRepo, 'binaries'));
    await writeFile(path.join(tempRepo, 'binaries', 'cli'), 'binary');
    await writeFile(path.join(tempRepo, 'first.tgz'), 'first');
    await writeFile(path.join(tempRepo, 'second.tgz'), 'second');
    await writeFile(path.join(tempRepo, 'keep.txt'), 'keep');
    await releaseModule.cleanArtifacts(tempRepo);
    await assert.rejects(access(path.join(tempRepo, 'binaries')));
    await assert.rejects(access(path.join(tempRepo, 'first.tgz')));
    await assert.rejects(access(path.join(tempRepo, 'second.tgz')));
    await assert.doesNotReject(access(path.join(tempRepo, 'keep.txt')));
  } finally {
    await rm(tempRepo, { recursive: true, force: true });
  }
});

test('发布脚本默认仅展示帮助，不会发布', () => {
  const result = spawnSync(process.execPath, [scriptPath, '--help'], {
    cwd: repo,
    encoding: 'utf8',
  });
  assert.equal(result.status, 0, result.stderr);
  assert.match(result.stdout, /npm run release:check/);
  assert.match(result.stdout, /npm run release:publish -- --yes/);
  assert.match(result.stdout, /--yes/);
  assert.match(result.stdout, /--allow-dev-branch/);
  assert.match(result.stdout, /--flavor/);
  assert.match(result.stdout, /--npmjs/);
  assert.match(result.stdout, /release:npmjs/);
  assert.match(result.stdout, /stage publish/);
});

test('AGENTS 包含 AI 维护者完整发布步骤', async () => {
  const agents = await readFile(path.join(repo, 'AGENTS.md'), 'utf8');
  for (const required of [
    'npm install -g @bytedance-dev/bnpm',
    'bnpm login --auth-type=sso',
    'npm login --auth-type=sso --registry=http://bnpm.byted.org --browser=false',
    'npx @bytedance-dev/bnpm@latest login --auth-type=sso --browser=false',
    'npm whoami --registry=http://bnpm.byted.org',
    'npm view @ecom-open-cli/opencli version --registry=https://bnpm.byted.org',
    'npm version patch --no-git-tag-version',
    'node scripts/sync-skill.mjs',
    'npm run release:check',
    'npm run release:publish -- --yes',
    'npm run release:npmjs',
    'docs/spec/npmjs-open-publish.md',
    'YYYY-MM-DD-',
    'docs/plans/',
    'npx npm@latest',
    'Staged Packages',
    '--allow-dev-branch',
    '--flavor=internal',
    'npm install --global @ecom-open-cli/opencli@latest --registry=https://bnpm.byted.org',
    'doudian-open-cli djt self skill update --output json',
  ]) {
    assert.match(agents, new RegExp(required.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')), `AGENTS 缺少 ${required}`);
  }
});

test('根 README 说明双产物，对内 README 说明如何更新 latest', async () => {
  const rootReadme = await readFile(path.join(repo, 'README.md'), 'utf8');
  const internalReadme = await readFile(path.join(repo, 'npm/internal/README.md'), 'utf8');
  assert.match(rootReadme, /npm install --global @bytedance\/doudian-open-cli@latest --registry=https:\/\/registry\.npmjs\.org/);
  assert.match(rootReadme, /npm install --global @ecom-open-cli\/doudian-open-cli@latest --registry=https:\/\/bnpm\.byted\.org/);
  assert.match(rootReadme, /npm install --global @ecom-open-cli\/opencli@latest --registry=https:\/\/bnpm\.byted\.org/);
  assert.match(rootReadme, /doudian-open-cli djt self skill update --output json/);
  assert.match(rootReadme, /npm run release:npmjs/);
  assert.match(rootReadme, /docs\/spec\/npmjs-open-publish\.md/);
  assert.match(internalReadme, /npm install --global @ecom-open-cli\/opencli@latest --registry=https:\/\/bnpm\.byted\.org/);
  assert.match(internalReadme, /doudian-open-cli djt self skill update --output json/);
});

test('package scripts 暴露检查和显式发布入口', async () => {
  const manifest = JSON.parse(await readFile(path.join(repo, 'package.json'), 'utf8'));
  assert.equal(manifest.scripts['release:check'], 'node scripts/release-npm.mjs --check');
  assert.equal(manifest.scripts['release:publish'], 'node scripts/release-npm.mjs --publish');
  assert.equal(manifest.scripts['release:npmjs'], 'node scripts/release-npmjs.mjs');
});

test('必须在 open_cli 仓库根执行发布脚本', () => {
  assert.doesNotThrow(() => releaseModule.assertReleaseCwd(repo));
  assert.throws(() => releaseModule.assertReleaseCwd(path.join(repo, 'npm/open')), /open_cli 仓库根/);
  assert.throws(() => releaseModule.assertReleaseCwd(os.tmpdir()), /package.json/);
});

test('公网发布走 npx npm@latest stage publish，并解析 stage id / 409', () => {
  assert.deepEqual(
    releaseModule.npmjsStagePublishArgs('/tmp/pkg.tgz', 'alpha'),
    ['-y', 'npm@latest', 'stage', 'publish', '/tmp/pkg.tgz', '--registry=https://registry.npmjs.org', '--tag', 'alpha', '--access', 'public'],
  );
  assert.equal(
    releaseModule.parseNpmjsStageId('Created staged package 222444f0-B653-4ac4-aa6b-33b5bfe17ff7\n'),
    '222444f0-b653-4ac4-aa6b-33b5bfe17ff7',
  );
  assert.equal(releaseModule.parseNpmjsStageId('ok'), null);
  assert.match(
    releaseModule.npmjsStageConflictMessage('npm error code E409\nnpm error Cannot stage previously published version'),
    /占用/,
  );
  assert.equal(releaseModule.npmjsStageConflictMessage('E403 Forbidden'), null);
  assert.doesNotThrow(() => releaseModule.assertGoVersionForNpmjs('go version go1.22.5 darwin/arm64'));
  assert.throws(() => releaseModule.assertGoVersionForNpmjs('go version go1.20.14 darwin/arm64'), /1\.22/);
});

test('公网包装脚本默认展示帮助且固定 flavor', () => {
  const wrapper = path.join(repo, 'scripts/release-npmjs.mjs');
  const result = spawnSync(process.execPath, [wrapper, '--help'], {
    cwd: repo,
    encoding: 'utf8',
  });
  assert.equal(result.status, 0, result.stderr);
  assert.match(result.stdout, /npm run release:npmjs -- --check/);
  assert.match(result.stdout, /npm run release:npmjs -- --publish --yes/);
  assert.match(result.stdout, /npmjs-open-publish/);
});
