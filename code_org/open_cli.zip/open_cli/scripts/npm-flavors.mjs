import { existsSync, readdirSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

export const repo = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
export const registry = 'https://bnpm.byted.org';

function skillDirs(root) {
  return readdirSync(root, { withFileTypes: true })
    .filter((entry) => entry.isDirectory() && existsSync(path.join(root, entry.name, 'SKILL.md')))
    .map((entry) => entry.name)
    .sort();
}

// skills/ 下每个带 SKILL.md 的目录都是 Skill。biz/ 只是抽屉，真正的 Skill 在它的下一层。
// 对外包含除 djt 以外的全部；对内再加 djt。不在这里手写名单。
function discoverSkills() {
  const root = path.join(repo, 'skills');
  const skills = [];
  for (const name of skillDirs(root)) {
    if (name === 'biz') continue;
    skills.push(name);
  }
  const biz = path.join(root, 'biz');
  if (existsSync(biz)) {
    for (const name of skillDirs(biz)) skills.push(path.join('biz', name));
  }
  return skills;
}

const discovered = discoverSkills();
const externalSkills = Object.freeze(discovered.filter((skill) => skill !== 'djt'));

export const flavors = Object.freeze({
  open: {
    id: 'open',
    name: '@bytedance/doudian-open-cli',
    bnpmName: '@ecom-open-cli/doudian-open-cli',
    cmd: './cmd/doudian-open-cli',
    skills: externalSkills,
  },
  internal: {
    id: 'internal',
    name: '@ecom-open-cli/opencli',
    cmd: './cmd/doudian-open-cli-internal',
    skills: Object.freeze([...externalSkills, 'djt']),
  },
});

export function skillInstallName(skillPath) {
  const name = path.basename(skillPath);
  if (!/^[a-z][a-z0-9_-]{0,40}$/.test(name)) {
    throw new Error(`Skill 安装名无效：${skillPath}`);
  }
  return name;
}

export function embedPlans() {
  const plans = [];
  const seen = new Set();
  for (const skill of flavors.open.skills) {
    const name = skillInstallName(skill);
    if (name === 'djt' || seen.has(name)) {
      throw new Error(`对外 Skill 安装名冲突：${name}`);
    }
    seen.add(name);
    plans.push({
      name,
      source: path.join(repo, 'skills', skill),
      target: path.join(repo, 'internal', 'open', 'skill', 'assets', name),
      assetsDir: path.join(repo, 'internal', 'open', 'skill', 'assets'),
    });
  }
  plans.push({
    name: 'djt',
    source: path.join(repo, 'skills', 'djt'),
    target: path.join(repo, 'internal', 'djt', 'skill', 'assets', 'djt'),
    assetsDir: path.join(repo, 'internal', 'djt', 'skill', 'assets'),
  });
  return plans;
}

export function flavorDir(id) {
  return path.join(repo, 'npm', id);
}

export function resolveFlavor(id) {
  const flavor = flavors[id];
  if (!flavor) {
    throw new Error(`未知 flavor：${id}，只支持 open 或 internal`);
  }
  return flavor;
}
