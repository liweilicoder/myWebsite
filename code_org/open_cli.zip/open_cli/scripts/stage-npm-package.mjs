import { execFileSync } from 'node:child_process';
import { chmod, copyFile, mkdir, rm } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

import { flavorDir, repo, resolveFlavor } from './npm-flavors.mjs';

export function listGitTracked(repoDir, source) {
  const rel = path.relative(repoDir, source);
  if (rel.startsWith('..') || path.isAbsolute(rel)) {
    throw new Error(`拒绝复制仓库外路径：${source}`);
  }
  const stdout = execFileSync('git', ['-C', repoDir, 'ls-files', '-z', '--', rel], {
    encoding: 'utf8',
  });
  return stdout.split('\0').filter(Boolean);
}

export async function copyGitTracked(repoDir, source, target) {
  const files = listGitTracked(repoDir, source);
  if (files.length === 0) {
    throw new Error(`没有受版本控制的文件：${path.relative(repoDir, source)}`);
  }
  const sourceAbs = path.resolve(source);
  for (const file of files) {
    const from = path.join(repoDir, file);
    const to = path.join(target, path.relative(sourceAbs, from));
    await mkdir(path.dirname(to), { recursive: true, mode: 0o755 });
    await copyFile(from, to);
  }
}

export async function stageFlavor(id) {
  const flavor = resolveFlavor(id);
  const dest = flavorDir(flavor.id);
  const copies = [
    [path.join(repo, 'bin'), path.join(dest, 'bin')],
  ];
  if (flavor.id === 'internal') {
    copies.push([path.join(repo, 'scripts', 'postinstall.cjs'), path.join(dest, 'scripts', 'postinstall.cjs')]);
  }
  for (const skill of flavor.skills) {
    copies.push([path.join(repo, 'skills', skill), path.join(dest, 'skills', skill)]);
  }

  await rm(path.join(dest, 'bin'), { recursive: true, force: true });
  await rm(path.join(dest, 'scripts'), { recursive: true, force: true });
  await rm(path.join(dest, 'skills'), { recursive: true, force: true });

  for (const [source, target] of copies) {
    await mkdir(path.dirname(target), { recursive: true, mode: 0o755 });
    await copyGitTracked(repo, source, target);
  }
  await chmod(path.join(dest, 'bin', 'doudian-open-cli.js'), 0o755);
}

if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
  stageFlavor(process.argv[2]).catch((error) => {
    process.stderr.write(`[stage-npm-package] ${error.message}\n`);
    process.exitCode = 1;
  });
}
