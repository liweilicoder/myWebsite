import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { access, mkdir, mkdtemp, rm, writeFile } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import test from 'node:test';

import { copyGitTracked } from './stage-npm-package.mjs';

test('stage 只复制 git 跟踪文件，忽略 .DS_Store', async () => {
  const dir = await mkdtemp(path.join(os.tmpdir(), 'stage-npm-'));
  try {
    const git = (args, opts = {}) => {
      const result = spawnSync('git', ['-c', 'commit.gpgsign=false', ...args], {
        cwd: dir,
        encoding: 'utf8',
        env: { ...process.env, GIT_CONFIG_NOSYSTEM: '1' },
        ...opts,
      });
      if (result.status !== 0) {
        throw new Error(result.stderr || result.stdout || `git ${args.join(' ')} failed`);
      }
      return result;
    };
    git(['init']);
    git(['config', 'user.email', 'stage@test']);
    git(['config', 'user.name', 'stage']);
    await mkdir(path.join(dir, 'skills/open'), { recursive: true });
    await writeFile(path.join(dir, 'skills/open/SKILL.md'), 'ok\n');
    await writeFile(path.join(dir, 'skills/open/.DS_Store'), 'nope\n');
    await writeFile(path.join(dir, '.gitignore'), '.DS_Store\n');
    git(['add', 'skills/open/SKILL.md', '.gitignore']);
    git(['commit', '-m', 'init'], { stdio: 'pipe' });

    const dest = path.join(dir, 'out/skills/open');
    await copyGitTracked(dir, path.join(dir, 'skills/open'), dest);
    await access(path.join(dest, 'SKILL.md'));
    await assert.rejects(() => access(path.join(dest, '.DS_Store')));
  } finally {
    await rm(dir, { recursive: true, force: true });
  }
});
