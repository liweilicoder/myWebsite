#!/usr/bin/env node
import { execFileSync } from 'node:child_process';
import { readdir, readFile } from 'node:fs/promises';
import path from 'node:path';
import process from 'node:process';
import { pathToFileURL } from 'node:url';

import { repo, resolveFlavor } from './npm-flavors.mjs';

const commonFiles = [
  'package/CHANGELOG.md',
  'package/LICENSE',
  'package/README.md',
  'package/README.zh-CN.md',
  'package/bin/launcher.cjs',
  'package/bin/doudian-open-cli.js',
  'package/binaries/doudian-open-cli-darwin-amd64',
  'package/binaries/doudian-open-cli-darwin-arm64',
  'package/binaries/doudian-open-cli-linux-amd64',
  'package/binaries/doudian-open-cli-linux-arm64',
  'package/binaries/doudian-open-cli-windows-amd64.exe',
  'package/package.json',
];

const executables = new Set([
  'package/bin/doudian-open-cli.js',
  'package/binaries/doudian-open-cli-darwin-amd64',
  'package/binaries/doudian-open-cli-darwin-arm64',
  'package/binaries/doudian-open-cli-linux-amd64',
  'package/binaries/doudian-open-cli-linux-arm64',
  'package/binaries/doudian-open-cli-windows-amd64.exe',
]);

async function collectFiles(root, relative = '') {
  const directory = path.join(root, relative);
  const entries = await readdir(directory, { withFileTypes: true });
  const files = [];
  for (const entry of entries.sort((left, right) => left.name.localeCompare(right.name))) {
    const child = path.join(relative, entry.name);
    if (entry.isDirectory()) files.push(...await collectFiles(root, child));
    else if (entry.isFile()) files.push(child.split(path.sep).join('/'));
  }
  return files;
}

export async function approvedFiles(flavorID) {
  const flavor = resolveFlavor(flavorID);
  const files = [...commonFiles];
  if (flavor.id === 'internal') files.push('package/scripts/postinstall.cjs');
  for (const skill of flavor.skills) {
    const names = await collectFiles(path.join(repo, 'skills', skill));
    for (const name of names) files.push(`package/skills/${skill}/${name}`);
  }
  return Object.freeze(files.sort());
}

export const APPROVED_FILES = await approvedFiles('internal');
export const OPEN_APPROVED_FILES = await approvedFiles('open');

export const OPEN_PACK_FORBIDDEN = Object.freeze([
  /bnpm/i,
  /byted\.org/i,
  /bytedance\.net/i,
  /code\.byted/i,
  /--use-ppe/,
  /--ppe-env/,
  /@ecom-open-cli\/opencli/,
  /内网/,
]);

function isOpenPackTextFile(name) {
  if (!name.startsWith('package/') || name.includes('/binaries/')) return false;
  return /\.(md|json|js|cjs|txt)$/.test(name) || /(^|\/)LICENSE$/.test(name);
}

export function assertOpenPublicSurface(entries) {
  for (const [name, entry] of entries) {
    if (!isOpenPackTextFile(name)) continue;
    const text = Buffer.from(entry.content ?? '').toString('utf8');
    for (const pattern of OPEN_PACK_FORBIDDEN) {
      if (pattern.test(text)) {
        throw new Error(`对外包 ${name} 含内部标识 ${pattern}`);
      }
    }
  }
}

export function validatePackage(entries, sourceSkillFiles, expectedFiles = APPROVED_FILES) {
  const actual = [...entries.keys()].sort();
  const expected = [...expectedFiles].sort();
  if (JSON.stringify(actual) !== JSON.stringify(expected)) {
    throw new Error(`tarball 文件清单不符合 allowlist\n期望: ${expected.join(', ')}\n实际: ${actual.join(', ')}`);
  }
  for (const name of executables) {
    if ((entries.get(name).mode & 0o111) !== 0o111) throw new Error(`${name} 缺少可执行权限`);
    if (entries.get(name).mode !== 0o755) throw new Error(`${name} 权限不是 0755`);
  }
  for (const name of expected.filter((candidate) => !executables.has(candidate))) {
    if (entries.get(name).mode !== 0o644) throw new Error(`${name} 权限不是 0644`);
  }
  for (const [name, source] of sourceSkillFiles) {
    const packaged = entries.get(name)?.content;
    if (!packaged || !Buffer.from(packaged).equals(Buffer.from(source))) {
      throw new Error(`tarball Skill 文件字节与唯一源不一致: ${name}`);
    }
  }
  if (expected.some((name) => name.startsWith('package/skills/djt/')) === false) {
    for (const name of actual) {
      if (name.includes('skills/djt') || name.includes('internal/djt')) {
        throw new Error(`对外包不得包含点将台路径: ${name}`);
      }
    }
    assertOpenPublicSurface(entries);
  }
}

function modeFromTarPermissions(permissions) {
  let mode = 0;
  for (const [index, bit] of [[1, 0o400], [2, 0o200], [3, 0o100], [4, 0o040], [5, 0o020], [6, 0o010], [7, 0o004], [8, 0o002], [9, 0o001]]) {
    if (permissions[index] !== '-') mode |= bit;
  }
  return mode;
}

export function readArchive(tarball) {
  const names = execFileSync('tar', ['-tzf', tarball], { encoding: 'utf8' })
    .split('\n').filter(Boolean).filter((name) => !name.endsWith('/'));
  const verbose = execFileSync('tar', ['-tvzf', tarball], { encoding: 'utf8' }).split('\n').filter(Boolean);
  const modes = new Map();
  for (const line of verbose) {
    const permissions = line.slice(0, 10);
    const name = names.find((candidate) => line.endsWith(candidate));
    if (name) modes.set(name, modeFromTarPermissions(permissions));
  }
  return new Map(names.map((name) => [name, {
    mode: modes.get(name) ?? 0,
    content: name.startsWith('package/skills/') || isOpenPackTextFile(name)
      ? execFileSync('tar', ['-xOzf', tarball, name], { encoding: null })
      : Buffer.alloc(0),
  }]));
}

export async function sourceSkillFiles(flavorID) {
  const files = new Map();
  for (const name of await approvedFiles(flavorID)) {
    if (!name.startsWith('package/skills/')) continue;
    files.set(name, await readFile(path.join(repo, name.slice('package/'.length))));
  }
  return files;
}

export async function verify(tarball, flavorID) {
  if (!tarball) throw new Error('用法：node scripts/verify-npm-package.mjs <tarball.tgz> --flavor=open|internal');
  const flavor = resolveFlavor(flavorID);
  const resolved = path.resolve(tarball);
  const expected = await approvedFiles(flavor.id);
  validatePackage(readArchive(resolved), await sourceSkillFiles(flavor.id), expected);
  process.stdout.write(`[verify-npm-package] 通过：${flavor.id} ${resolved}\n`);
}

function parseArgs(argv) {
  let tarball;
  let flavor;
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg === '--flavor') {
      flavor = argv[++i];
    } else if (arg.startsWith('--flavor=')) {
      flavor = arg.slice('--flavor='.length);
    } else if (!arg.startsWith('-')) {
      tarball = arg;
    } else {
      throw new Error(`未知参数：${arg}`);
    }
  }
  return { tarball, flavor };
}

if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
  const { tarball, flavor } = parseArgs(process.argv.slice(2));
  verify(tarball, flavor).catch((error) => {
    process.stderr.write(`[verify-npm-package] ${error.message}\n`);
    process.exitCode = 1;
  });
}
