import { chmod, mkdir, readFile, rm } from 'node:fs/promises';
import path from 'node:path';
import process from 'node:process';
import { spawn } from 'node:child_process';
import { pathToFileURL } from 'node:url';

import { flavorDir, resolveFlavor } from './npm-flavors.mjs';

export const targets = [
  { goos: 'darwin', goarch: 'amd64', name: 'doudian-open-cli-darwin-amd64' },
  { goos: 'darwin', goarch: 'arm64', name: 'doudian-open-cli-darwin-arm64' },
  { goos: 'linux', goarch: 'amd64', name: 'doudian-open-cli-linux-amd64' },
  { goos: 'linux', goarch: 'arm64', name: 'doudian-open-cli-linux-arm64' },
  { goos: 'windows', goarch: 'amd64', name: 'doudian-open-cli-windows-amd64.exe' },
];

const cliVersionSymbol = 'code.byted.org/temai/open_cli/internal/core/cli.BuildVersion';
const identityVersionSymbol = 'code.byted.org/temai/open_cli/internal/core/identity.BuildVersion';

export function buildArgs(version, output, flavor = 'open') {
  return ['build', '-trimpath', '-ldflags', `-X ${cliVersionSymbol}=${version} -X ${identityVersionSymbol}=${version}`, '-o', output, resolveFlavor(flavor).cmd];
}

export function cgoEnabled(goos) {
  return goos === 'darwin' ? '1' : '0';
}

function run(command, args, options) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, options);
    child.once('error', reject);
    child.once('exit', (code, signal) => {
      if (code === 0) resolve();
      else reject(new Error(`${command} 构建失败：${signal ? `signal ${signal}` : `exit ${code}`}`));
    });
  });
}

function parseFlavor(argv) {
  const prefix = '--flavor=';
  const equal = argv.find((arg) => arg.startsWith(prefix));
  if (equal) return equal.slice(prefix.length);
  const index = argv.indexOf('--flavor');
  if (index >= 0) {
    if (!argv[index + 1]) throw new Error('--flavor 缺少名称');
    return argv[index + 1];
  }
  return 'open';
}

export async function build(flavorID = 'open') {
  const flavor = resolveFlavor(flavorID);
  const dest = flavorDir(flavor.id);
  const manifest = JSON.parse(await readFile(path.join(dest, 'package.json'), 'utf8'));
  const outputDir = path.join(dest, 'binaries');
  await rm(outputDir, { recursive: true, force: true });
  await mkdir(outputDir, { recursive: true, mode: 0o755 });
  for (const target of targets) {
    const output = path.join(outputDir, target.name);
    await run('go', buildArgs(manifest.version, output, flavor.id), {
      cwd: path.resolve(dest, '..', '..'),
      stdio: 'inherit',
      shell: false,
      env: { ...process.env, CGO_ENABLED: cgoEnabled(target.goos), GOOS: target.goos, GOARCH: target.goarch },
    });
    await chmod(output, 0o755);
  }
}

if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
  build(parseFlavor(process.argv.slice(2))).catch((error) => {
    process.stderr.write(`[build-npm-binaries] ${error.message}\n`);
    process.exitCode = 1;
  });
}
