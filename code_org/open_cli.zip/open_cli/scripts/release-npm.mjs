import { execFileSync, spawnSync } from 'node:child_process';
import { readFileSync, readdirSync, rmSync } from 'node:fs';
import path from 'node:path';
import process from 'node:process';
import { fileURLToPath } from 'node:url';

import { flavorDir, flavors, registry, repo, resolveFlavor } from './npm-flavors.mjs';
import { stampOpenPackageForBnpm } from './stamp-open-bnpm.mjs';
import { stageFlavor } from './stage-npm-package.mjs';

export const UNPUBLISHED_VERSION = '0.0.0';
export const npmjsRegistry = 'https://registry.npmjs.org';

const VERSION_RE = /^(\d+)\.(\d+)\.(\d+)(?:-(alpha|beta|rc)\.(\d+))?$/;
const CHANNEL_RANK = { alpha: 0, beta: 1, rc: 2 };

export function parseNpmVersion(value) {
  const match = String(value).match(VERSION_RE);
  if (!match) {
    throw new Error(`版本格式必须为 x.y.z 或 x.y.z-alpha|beta|rc.N：${value}`);
  }
  return {
    major: Number(match[1]),
    minor: Number(match[2]),
    patch: Number(match[3]),
    channel: match[4] ?? null,
    n: match[4] ? Number(match[5]) : null,
  };
}

export function compareVersions(left, right) {
  const a = parseNpmVersion(left);
  const b = parseNpmVersion(right);
  for (const key of ['major', 'minor', 'patch']) {
    if (a[key] !== b[key]) {
      return a[key] > b[key] ? 1 : -1;
    }
  }
  if (!a.channel && !b.channel) return 0;
  if (!a.channel) return 1;
  if (!b.channel) return -1;
  if (a.channel !== b.channel) {
    return CHANNEL_RANK[a.channel] > CHANNEL_RANK[b.channel] ? 1 : -1;
  }
  if (a.n !== b.n) return a.n > b.n ? 1 : -1;
  return 0;
}

export function resolveDistTag(version, { tag, branch } = {}) {
  const parsed = parseNpmVersion(version);
  if (tag === 'latest' && parsed.channel) {
    throw new Error(`预发布版本 ${version} 不能打 latest，应使用 --tag ${parsed.channel}`);
  }
  if (tag) {
    if (parsed.channel && tag !== parsed.channel) {
      throw new Error(`预发布版本 ${version} 的 dist-tag 必须是 ${parsed.channel}，实际 ${tag}`);
    }
    return tag;
  }
  if (parsed.channel) return parsed.channel;
  return branch === 'main' ? 'latest' : 'beta';
}

export function isUnpublishedRegistryError(text) {
  return /\bE404\b|404 Not Found|could not be found|NOTFOUND/i.test(String(text));
}

export function highestPublishedVersion(stdout) {
  const text = String(stdout).trim();
  if (!text) return UNPUBLISHED_VERSION;
  const parsed = JSON.parse(text);
  const list = Array.isArray(parsed) ? parsed : [parsed];
  let max = UNPUBLISHED_VERSION;
  for (const item of list) {
    const version = String(item);
    try {
      if (compareVersions(version, max) > 0) max = version;
    } catch {
      // 忽略 registry 上不符合本仓库规范的历史标签
    }
  }
  return max;
}

export function publishedPackageName(flavor, options = {}) {
  if (options.npmjs) return flavor.name;
  return flavor.bnpmName ?? flavor.name;
}

export function targetRegistry(options = {}) {
  return options.npmjs ? npmjsRegistry : registry;
}

export function assertReleaseCwd(cwd, readText = (filePath) => readFileSync(filePath, 'utf8')) {
  const pkgPath = path.join(cwd, 'package.json');
  let name;
  try {
    name = JSON.parse(readText(pkgPath)).name;
  } catch {
    throw new Error(`必须在 open_cli 仓库根执行（当前目录没有可用的 package.json）：${cwd}`);
  }
  if (name !== 'open_cli') {
    throw new Error(`必须在 open_cli 仓库根执行，当前 package.json name 为 ${name}。cwd=${cwd}`);
  }
}

export function parseGoVersion(stdout) {
  const match = String(stdout).match(/go(\d+)\.(\d+)/);
  if (!match) {
    throw new Error(`无法解析 go version 输出：${stdout}`);
  }
  return { major: Number(match[1]), minor: Number(match[2]) };
}

export function assertGoVersionForNpmjs(stdout) {
  const parsed = parseGoVersion(stdout);
  if (parsed.major < 1 || (parsed.major === 1 && parsed.minor < 22)) {
    throw new Error(`发公网 npm 需要 Go 1.22+，当前 ${String(stdout).trim()}。可将 PATH/GOROOT 指向 go@1.22`);
  }
}

export function npmjsStagePublishArgs(tarball, distTag) {
  return ['-y', 'npm@latest', 'stage', 'publish', tarball, `--registry=${npmjsRegistry}`, '--tag', distTag, '--access', 'public'];
}

export function parseNpmjsStageId(text) {
  const match = String(text).match(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i);
  return match ? match[0].toLowerCase() : null;
}

export function npmjsStageConflictMessage(text) {
  if (/E409|previously published|Cannot stage/i.test(String(text))) {
    return '该版本已在 npmjs 占用（占位、暂存或已发布）。升 npm/open/package.json 的 version 后再发，不要重复 stage 同一号。详见 docs/spec/npmjs-open-publish.md';
  }
  return null;
}

export function readPublishedVersion(packageName, exec = execFileSync, npmRegistry = registry) {
  try {
    const stdout = exec('npm', ['view', packageName, 'versions', '--json', `--registry=${npmRegistry}`], {
      cwd: repo,
      encoding: 'utf8',
      stdio: ['ignore', 'pipe', 'pipe'],
    });
    return highestPublishedVersion(stdout);
  } catch (error) {
    const text = `${error.stdout || ''}\n${error.stderr || ''}\n${error.message || ''}`;
    if (isUnpublishedRegistryError(text)) {
      return UNPUBLISHED_VERSION;
    }
    throw error;
  }
}

export function validateReleaseState({ branch, status, localVersion, publishedVersion, allowDevBranch = false }) {
  if (branch !== 'main' && !allowDevBranch) {
    throw new Error(`npm 默认只能从 main 分支发布，当前分支：${branch}；开发分支请显式传入 --allow-dev-branch`);
  }
  if (status.trim()) {
    throw new Error('npm 发布要求 Git 工作区干净，请先提交或清理改动');
  }
  if (compareVersions(localVersion, publishedVersion) <= 0) {
    throw new Error(`本地版本 ${localVersion} 必须大于已发布版本 ${publishedVersion}`);
  }
}

function run(command, args, options = {}) {
  return execFileSync(command, args, {
    cwd: options.cwd ?? repo,
    encoding: 'utf8',
    stdio: options.capture ? ['ignore', 'pipe', 'inherit'] : 'inherit',
  });
}

function capture(command, args, cwd = repo) {
  return run(command, args, { capture: true, cwd }).trim();
}

function usage() {
  console.log(`npm 发布工具（默认不会发布）

检查发布条件并完成构建、打包和包内容校验：
  npm run release:check -- --flavor=internal
  npm run release:check -- --flavor=open

显式发布已校验的新版本：
  npm run release:publish -- --yes --flavor=internal

开发分支预发布（不污染 latest；无预发布号时默认 beta tag）：
  npm run release:publish -- --yes --flavor=internal --allow-dev-branch

可选参数：
  --flavor <open|internal>   必填
  --allow-dev-branch         允许非 main 分支发布
  --tag <name>               指定 npm dist-tag。x.y.z-alpha|beta|rc.N 默认打对应 tag，禁止 latest
  --npmjs                    仅对外包：保持公网名，发到 npmjs；真实发布走 npx npm@latest stage publish

公网请用 npm run release:npmjs（固定 --flavor=open --npmjs）。细则：docs/spec/npmjs-open-publish.md

发布要求：必须在 open_cli 仓库根、Git 工作区干净、本地版本高于目标 registry 已发布版本，并已登录对应 registry。
对内发布仍会构建并扫描对外产物。发布结束后会删除 flavor 构建产物。
仓库根不能 npm pack / npm publish。`);
}

function parsePackFilename(output) {
  const result = JSON.parse(output);
  if (!Array.isArray(result) || result.length !== 1 || !result[0]?.filename) {
    throw new Error('npm pack 未返回唯一 tarball 文件名');
  }
  return result[0].filename;
}

export function cleanArtifacts(root = repo) {
  rmSync(path.join(root, 'binaries'), { recursive: true, force: true });
  for (const name of readdirSync(root)) {
    if (name.endsWith('.tgz')) rmSync(path.join(root, name), { force: true });
  }
  for (const id of Object.keys(flavors)) {
    const dest = path.join(root, 'npm', id);
    rmSync(path.join(dest, 'bin'), { recursive: true, force: true });
    rmSync(path.join(dest, 'binaries'), { recursive: true, force: true });
    rmSync(path.join(dest, 'skills'), { recursive: true, force: true });
    rmSync(path.join(dest, 'scripts'), { recursive: true, force: true });
    try {
      for (const name of readdirSync(dest)) {
        if (name.endsWith('.tgz')) rmSync(path.join(dest, name), { force: true });
      }
    } catch {
      // flavor 目录在单元测试夹具里可能不存在
    }
  }
}

function parseOptions(argv) {
  const options = { allowDevBranch: false, tag: undefined, flavor: undefined, npmjs: false };
  for (let index = 0; index < argv.length; index += 1) {
    const arg = argv[index];
    if (arg === '--allow-dev-branch') {
      options.allowDevBranch = true;
    } else if (arg === '--npmjs') {
      options.npmjs = true;
    } else if (arg === '--flavor') {
      options.flavor = argv[++index];
      if (!options.flavor) throw new Error('--flavor 缺少名称');
    } else if (arg.startsWith('--flavor=')) {
      options.flavor = arg.slice('--flavor='.length);
    } else if (arg === '--tag') {
      const value = argv[++index];
      if (!value) throw new Error('--tag 缺少名称');
      options.tag = value;
    } else if (!['--check', '--publish', '--yes', '--help'].includes(arg)) {
      throw new Error(`未知参数：${arg}`);
    }
  }
  return options;
}

function preflight(options, flavor) {
  assertReleaseCwd(process.cwd());
  const major = Number(process.versions.node.split('.')[0]);
  if (major < 18) {
    throw new Error(`Node.js 版本必须 >=18，当前为 ${process.versions.node}`);
  }
  if (options.npmjs) {
    assertGoVersionForNpmjs(capture('go', ['version']));
  }
  const manifest = JSON.parse(readFileSync(path.join(flavorDir(flavor.id), 'package.json'), 'utf8'));
  const branch = capture('git', ['branch', '--show-current']);
  const status = capture('git', ['status', '--short']);
  const publishedName = publishedPackageName(flavor, options);
  const destRegistry = targetRegistry(options);
  const publishedVersion = readPublishedVersion(publishedName, execFileSync, destRegistry);
  validateReleaseState({ branch, status, localVersion: manifest.version, publishedVersion, allowDevBranch: options.allowDevBranch });
  const distTag = resolveDistTag(manifest.version, { tag: options.tag, branch });
  run('npm', ['whoami', `--registry=${destRegistry}`]);
  const fromLabel = publishedVersion === UNPUBLISHED_VERSION ? 'unpublished' : publishedVersion;
  console.log(`发布前检查通过：${publishedName} ${fromLabel} -> ${manifest.version}（registry ${destRegistry}，分支 ${branch}，dist-tag ${distTag}）`);
  return { distTag, version: manifest.version, publishedName, destRegistry };
}

async function packFlavor(flavor, options = {}) {
  await stageFlavor(flavor.id);
  if (flavor.id === 'open' && !options.npmjs) {
    stampOpenPackageForBnpm(flavorDir(flavor.id));
  }
  run('node', ['scripts/build-npm-binaries.mjs', '--flavor', flavor.id]);
  const dest = flavorDir(flavor.id);
  const output = capture('npm', ['pack', '--json', '--ignore-scripts'], dest);
  const tarballName = parsePackFilename(output);
  const tarball = path.join(dest, tarballName);
  run('node', ['scripts/verify-npm-package.mjs', tarball, '--flavor', flavor.id]);
  return tarball;
}

async function buildAndPack(flavor, options = {}) {
  run('node', ['scripts/sync-skill.mjs', '--check']);
  run('go', ['test', './...']);
  run('node', ['--test']);
  run('go', ['test', '-race', './...']);
  run('go', ['vet', './...']);
  run('go', ['build', './cmd/doudian-open-cli']);
  run('go', ['build', './cmd/doudian-open-cli-internal']);
  const openTarball = await packFlavor(resolveFlavor('open'), options);
  if (flavor.id === 'open') return openTarball;
  return packFlavor(flavor, options);
}

async function main() {
  const argv = process.argv.slice(2);
  if (argv.length === 0 || argv.includes('--help')) {
    usage();
    return;
  }
  const options = parseOptions(argv);
  const check = argv.includes('--check');
  const publish = argv.includes('--publish');
  if (check === publish) {
    throw new Error('只支持 --check，或 --publish --yes');
  }
  if (publish && !argv.includes('--yes')) {
    throw new Error('真实发布必须显式传入 --yes');
  }
  if (!options.flavor) {
    throw new Error('必须指定 --flavor=open 或 --flavor=internal');
  }
  const flavor = resolveFlavor(options.flavor);
  if (options.npmjs && flavor.id !== 'open') {
    throw new Error('--npmjs 只适用于 --flavor=open');
  }
  let tarball;
  try {
    const { distTag, publishedName, destRegistry } = preflight(options, flavor);
    tarball = await buildAndPack(flavor, options);
    if (publish) {
      if (options.npmjs) {
        const staged = spawnSync('npx', npmjsStagePublishArgs(tarball, distTag), {
          cwd: repo,
          encoding: 'utf8',
        });
        const combined = `${staged.stdout || ''}\n${staged.stderr || ''}`;
        if (staged.status !== 0) {
          throw new Error(npmjsStageConflictMessage(combined) ?? (staged.stderr || staged.stdout || `npx npm stage publish 退出 ${staged.status}`));
        }
        const stageId = parseNpmjsStageId(combined);
        console.log(`已提交 npmjs 暂存：${publishedName} dist-tag ${distTag}（registry ${destRegistry}）`);
        if (stageId) console.log(`stage id: ${stageId}`);
        console.log('这还不是可安装状态。打开 https://www.npmjs.com/settings/~/#staged-packages 等 Validating 结束后 Approve + 2FA。');
        console.log('完整步骤：docs/spec/npmjs-open-publish.md');
      } else {
        run('npm', ['publish', tarball, `--registry=${destRegistry}`, '--tag', distTag]);
        console.log(`发布完成：${publishedName}（dist-tag: ${distTag}，registry ${destRegistry}）`);
        if (distTag !== 'latest') {
          console.log(`安装：npm install --global ${publishedName}@${distTag} --registry=${destRegistry}`);
        }
      }
    } else {
      console.log(`发布检查完成：${tarball} 已通过校验，未执行上传（将使用 dist-tag ${distTag}）`);
    }
  } finally {
    cleanArtifacts();
  }
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  try {
    await main();
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    process.exitCode = 1;
  }
}
