const assert = require('node:assert/strict');
const { EventEmitter } = require('node:events');
const path = require('node:path');
const test = require('node:test');

const { runPostinstall } = require('./postinstall.cjs');

class Child extends EventEmitter {
  kill(signal) {
    this.signal = signal;
  }
}

function harness(overrides = {}) {
  const messages = [];
  const timers = [];
  const child = new Child();
  let invocation;
  const result = runPostinstall({
    platform: 'linux',
    arch: 'x64',
    launcher: path.resolve('/pkg/bin/doudian-open-cli.js'),
    stderr: { write: (message) => messages.push(message) },
    spawnImpl(command, args, options) {
      invocation = { command, args, options };
      return child;
    },
    setTimeoutImpl(callback, milliseconds) {
      timers.push({ callback, milliseconds });
      return timers.length;
    },
    clearTimeoutImpl() {},
    ...overrides,
  });
  return { result, messages, timers, child, invocation: () => invocation };
}

test('postinstall 用 Node 绝对路径静默启动 skill install，并设置 30 秒超时', () => {
  const h = harness();
  assert.deepEqual(h.invocation(), {
    command: process.execPath,
    args: [path.resolve('/pkg/bin/doudian-open-cli.js'), 'djt', 'self', 'skill', 'install', '--output', 'json'],
    options: { stdio: 'ignore', shell: false },
  });
  assert.equal(h.timers[0].milliseconds, 30_000);
  h.child.emit('exit', 0, null);
  assert.deepEqual(h.messages, []);
});

test('postinstall 失败只提示一行且 hook 不抛错', () => {
  const h = harness();
  h.child.emit('exit', 1, null);
  assert.equal(h.messages.length, 1);
  assert.match(h.messages[0], /^\[doudian-open-cli\] postinstall: .+\n$/);
});

test('postinstall 超时终止子进程并只提示一行', () => {
  const h = harness();
  h.timers[0].callback();
  assert.equal(h.child.signal, 'SIGKILL');
  assert.equal(h.messages.length, 1);
  h.child.emit('exit', null, 'SIGTERM');
  assert.equal(h.messages.length, 1);
});

test('postinstall 对未知平台 best-effort 成功并提示', () => {
  const h = harness({ platform: 'linux', arch: 'ia32' });
  assert.equal(h.invocation(), undefined);
  assert.equal(h.messages.length, 1);
  assert.match(h.messages[0], /不支持的平台/);
});
