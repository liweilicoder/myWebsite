'use strict';

const path = require('node:path');
const { spawn } = require('node:child_process');
const { binaryName } = require('../bin/launcher.cjs');

function runPostinstall({
  platform = process.platform,
  arch = process.arch,
  launcher = path.resolve(__dirname, '..', 'bin', 'doudian-open-cli.js'),
  stderr = process.stderr,
  spawnImpl = spawn,
  setTimeoutImpl = setTimeout,
  clearTimeoutImpl = clearTimeout,
} = {}) {
  let reported = false;
  const report = (message) => {
    if (reported) return;
    reported = true;
    stderr.write(`[doudian-open-cli] postinstall: ${message}\n`);
  };

  try {
    binaryName(platform, arch);
  } catch (error) {
    report(error.message);
    return undefined;
  }

  let child;
  try {
    child = spawnImpl(
      process.execPath,
      [launcher, 'djt', 'self', 'skill', 'install', '--output', 'json'],
      { stdio: 'ignore', shell: false },
    );
  } catch (error) {
    report(`Skill 安装启动失败：${error.message}`);
    return undefined;
  }

  const timer = setTimeoutImpl(() => {
    report('Skill 安装超过 30 秒，已终止');
    child.kill('SIGKILL');
  }, 30_000);
  timer?.unref?.();
  const finish = (message) => {
    clearTimeoutImpl(timer);
    if (message) report(message);
  };
  child.once('error', (error) => finish(`Skill 安装启动失败：${error.message}`));
  child.once('exit', (code, signal) => {
    if (code === 0 && !signal) finish();
    else finish(`Skill 安装失败（${signal ? `signal ${signal}` : `exit ${code}`}），可稍后运行 doudian-open-cli djt self skill install`);
  });
  return child;
}

if (require.main === module) runPostinstall();

module.exports = { runPostinstall };
