import assert from 'node:assert/strict';
import { readFile, stat } from 'node:fs/promises';
import path from 'node:path';
import test from 'node:test';
import { fileURLToPath } from 'node:url';

import { flavors } from './npm-flavors.mjs';
import { APPROVED_FILES, OPEN_APPROVED_FILES, assertOpenPublicSurface, validatePackage } from './verify-npm-package.mjs';

const repo = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const readText = relativePath => readFile(path.join(repo, relativePath), 'utf8');
const skill = await readFile(path.join(repo, 'skills/djt/SKILL.md'));
const apiSkill = await readFile(path.join(repo, 'skills/djt/api.md'));
const spiSkill = await readFile(path.join(repo, 'skills/djt/spi.md'));
const skillFiles = new Map([
  ['package/skills/djt/.skillignore', await readFile(path.join(repo, 'skills/djt/.skillignore'))],
  ['package/skills/djt/README.md', await readFile(path.join(repo, 'skills/djt/README.md'))],
  ['package/skills/djt/SKILL.md', skill],
  ['package/skills/djt/api.md', apiSkill],
  ['package/skills/djt/spi.md', spiSkill],
  ['package/skills/djt/scripts/apply_style_patches.py', await readFile(path.join(repo, 'skills/djt/scripts/apply_style_patches.py'))],
  ['package/skills/djt/scripts/validate_style_tree.py', await readFile(path.join(repo, 'skills/djt/scripts/validate_style_tree.py'))],
  ['package/skills/djt/scripts/request_style.py', await readFile(path.join(repo, 'skills/djt/scripts/request_style.py'))],
  ['package/skills/djt/scripts/json_to_spi_param_tree.py', await readFile(path.join(repo, 'skills/djt/scripts/json_to_spi_param_tree.py'))],
]);
const skillText = skill.toString('utf8');
const apiText = apiSkill.toString('utf8');
const spiText = spiSkill.toString('utf8');
const skillBundleText = `${skillText}\n${apiText}\n${spiText}`;
const readme = await readText('npm/internal/README.zh-CN.md');
const internalReadmeEn = await readText('npm/internal/README.md');
const rootReadme = await readText('README.md');
const openReadme = await readText('npm/open/README.md');
const openReadmeZh = await readText('npm/open/README.zh-CN.md');
const openSkill = await readText('skills/open_cli_skill/SKILL.md');
const openChangelog = await readText('npm/open/CHANGELOG.md');
const agents = await readText('AGENTS.md');
const rootManifest = JSON.parse(await readText('package.json'));
const openManifest = JSON.parse(await readText('npm/open/package.json'));
const internalManifest = JSON.parse(await readText('npm/internal/package.json'));
const escapeRegExp = value => value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

function assertContainsAll(text, required, label) {
  for (const value of required) {
    assert.match(text, new RegExp(escapeRegExp(value)), `${label} 缺少 ${value}`);
  }
}

test('仓库根 package.json 为 private 且拒绝 pack', () => {
  assert.equal(rootManifest.private, true);
  assert.equal(rootManifest.scripts.prepack, 'node scripts/guard-root-pack.mjs');
  assert.equal(rootManifest.scripts['release:check'], 'node scripts/release-npm.mjs --check');
  assert.equal(rootManifest.scripts['release:publish'], 'node scripts/release-npm.mjs --publish');
  assert.equal(rootManifest.scripts['release:npmjs'], 'node scripts/release-npmjs.mjs');
});

test('双 flavor npm manifest 固定包名、registry、Node 版本和零运行时依赖', () => {
  assert.equal(openManifest.name, '@bytedance/doudian-open-cli');
  assert.equal(flavors.open.bnpmName, '@ecom-open-cli/doudian-open-cli');
  assert.equal(openManifest.version, '1.0.1');
  assert.equal(openManifest.publishConfig, undefined);
  assert.equal(openManifest.engines.node, '>=18');
  assert.deepEqual(openManifest.dependencies ?? {}, {});
  assert.equal(openManifest.bin['doudian-open-cli'], 'bin/doudian-open-cli.js');
  assert.deepEqual(openManifest.files, ['bin/', 'binaries/', 'skills/', 'README.md', 'README.zh-CN.md', 'CHANGELOG.md', 'LICENSE']);
  assert.equal(openManifest.scripts?.postinstall, undefined);
  assert.deepEqual([...flavors.internal.skills], [...flavors.open.skills, 'djt']);
  assert.ok(flavors.open.skills.includes('open_cli_skill'));
  assert.ok(!flavors.open.skills.includes('djt'));
  assert.ok(!flavors.open.skills.includes('biz'));
  for (const skill of flavors.open.skills) {
    if (skill === 'open_cli_skill') continue;
    assert.match(skill, /^biz\/[a-z][a-z0-9_-]{0,40}$/);
  }

  assert.equal(internalManifest.name, '@ecom-open-cli/opencli');
  assert.equal(internalManifest.version, '0.3.20');
  assert.equal(internalManifest.publishConfig.registry, 'https://bnpm.byted.org');
  assert.equal(internalManifest.engines.node, '>=18');
  assert.deepEqual(internalManifest.dependencies ?? {}, {});
  assert.equal(internalManifest.bin['doudian-open-cli'], 'bin/doudian-open-cli.js');
  assert.deepEqual(internalManifest.files, ['bin/', 'binaries/', 'scripts/postinstall.cjs', 'skills/', 'README.md', 'README.zh-CN.md', 'CHANGELOG.md', 'LICENSE']);
  assert.equal(internalManifest.scripts.postinstall, 'node scripts/postinstall.cjs');
});

test('Skill 源文件权限固定为 0644', async () => {
  for (const name of skillFiles.keys()) {
    const relative = name.slice('package/'.length);
    const info = await stat(path.join(repo, relative));
    assert.equal(info.mode & 0o777, 0o644, relative);
  }
});

test('README、AGENTS 与 npm Skill 锁定 Agent Interface 文档契约', () => {
  const commands = [
    'doudian-open-cli djt api get',
    'doudian-open-cli djt api init',
    'doudian-open-cli djt api save',
    'doudian-open-cli djt api doc',
    'doudian-open-cli djt api advance-step',
    'doudian-open-cli djt api test ppe',
    'doudian-open-cli djt api test auth add',
  ];
  const sharedContract = [
    ...commands,
    'doudian-open-cli --version', 'doudian-open-cli djt version',
    '--dry-run', '--apply', '--audit-meego', '@file', '@-',
    'submit-audit dry-run/apply', 'get 确认 statusV2=310',
    'cancel-audit dry-run/apply', 'get 确认 statusV2=200',
    '禁止推进到 330+',
    'https://djt.bytedance.net', '330',
    'doudian-open-cli djt biz-domain list --output json',
    '--confirmed-by-user --apply',
    '禁止 Agent 自行选择默认测试域或伪造确认',
    'bytedcli --json bam psm search',
    'bytedcli --json bam method list',
    'bytedcli --json bam version list',
    'DJT CLI 不维护 PSM、BAM 方法或版本列表',
  ];
  const loginContract = [
    'doudian-open-cli djt auth login',
    '授权 URL',
    '用户代码',
  ];
  const internalPPEContract = [
    'doudian-open-cli djt auth login --use-ppe --ppe-env ppe_djt_cli',
    'Start、Token、GetLoginUser',
    '不能单独设置，必须同时启用 PPE',
  ];
  const spiContract = [
    'doudian-open-cli djt spi scene list',
    'doudian-open-cli djt spi scene save',
    'doudian-open-cli djt spi scene sync-boe',
    'doudian-open-cli djt spi interface save',
    'doudian-open-cli djt spi interface submit-review',
    'doudian-open-cli djt spi interface cancel-upgrade',
    'scripts/json_to_spi_param_tree.py',
    '只做本地', '不得联网',
    '提审后到网页完成审核',
    'scene save --apply',
    'interface save --dry-run',
    'submit-review --dry-run',
    'modifyVersionId',
    'access-app save',
    'enable --apply',
    '补必填/加密/Map/Header',
    'biz-domain apply',
  ];
  assertContainsAll(readme, [
    ...sharedContract, ...loginContract, ...spiContract,
    'skills/djt/api.md', 'skills/djt/spi.md',
    'skills/djt/scripts/apply_style_patches.py',
    'skills/djt/scripts/validate_style_tree.py',
    'skills/djt/scripts/json_to_spi_param_tree.py',
    '本地', 'doudian-open-cli djt',
  ], '对内 README');
  assertContainsAll(skillText, [
    ...sharedContract.slice(0, 5),
    'doudian-open-cli djt api test',
    'doudian-open-cli --version', 'doudian-open-cli djt version',
    '--dry-run', '--apply',
    'https://djt.bytedance.net',
    'doudian-open-cli djt biz-domain list --output json',
    'doudian-open-cli djt biz-domain apply',
    'api.md', 'spi.md',
    ...loginContract,
    'doudian-open-cli djt spi scene list',
    'interface list|get|save|submit-review|cancel-upgrade',
    'inline', 'stdout', 'stderr',
    'preview', 'diff', 'errors',
  ], 'Skill Hub');
  assertContainsAll(apiText, [
    ...commands,
    'bytedcli --json bam psm search',
    'bytedcli --json bam method list',
    'bytedcli --json bam version list',
    '禁止 Agent 自行选择默认测试域或伪造 `--confirmed-by-user`',
    '--confirmed-by-user --apply',
    'submit-audit dry-run/apply', 'get 确认 statusV2=310',
    'cancel-audit dry-run/apply', 'get 确认 statusV2=200',
    '禁止推进到 330+',
    'scripts/apply_style_patches.py', 'scripts/validate_style_tree.py',
    '--in', '--patches', '--out', '--get-json', '--strict',
    'fromBam', 'modifyVersionId', 'statusV2', 'configPhase', 'nextStep',
    '对外开放入参', '内部变量', '内部常量',
    'ArgType', '1/2/3/4/5/6/7/8/9/11/99', 'reservedInnerVarNames',
    '8000037', 'errcode', '110', 'cancel-audit', '200',
    '@request.json',
  ], 'api.md');
  assertContainsAll(spiText, [
    'doudian-open-cli djt spi scene list',
    'doudian-open-cli djt spi scene sync-boe',
    'doudian-open-cli djt spi scene access-app list',
    'doudian-open-cli djt spi interface save',
    'doudian-open-cli djt spi interface submit-review',
    'doudian-open-cli djt spi interface cancel-upgrade',
    'scripts/json_to_spi_param_tree.py',
    'scene save --apply',
    'interface save --dry-run',
    'submit-review --dry-run',
    'modifyVersionId',
    'access-app save',
    'enable --apply',
    '补必填/加密/Map/Header',
    '禁止改名',
    '--use-ppe --ppe-env',
    'config', 'doc',
  ], 'spi.md');
  assertContainsAll(agents, [
    ...internalPPEContract,
    'doudian-open-cli djt spi scene list|get|save|sync-boe',
    'scene access-app list|get|save|enable',
    'interface list|get|save|submit-review|cancel-upgrade',
    'scripts/json_to_spi_param_tree.py',
    'scene save --apply',
    'interface save --dry-run',
    'submit-review --dry-run',
    'modifyVersionId',
    'access-app save',
    'enable --apply',
    'biz-domain apply',
    'api.md` 与 `spi.md',
    'skills/djt/spi.md',
    'internal/jsoninput', 'AgentService', 'AgentInterfaceClient', 'Transport',
    'AgentSPIService', 'AgentSPIClient', 'djt spi',
    'json.RawMessage', '8 MiB', 'cmd/doudian-open-cli/main.go',
    '--biz-domain-id > 0',
    'node --test scripts/npm-package.test.mjs',
    'skills/djt/scripts/json_to_spi_param_tree.py',
    'cmd/doudian-open-cli-internal',
    '--flavor=internal',
    'npm/open',
    'npm/internal',
    '对外 CHANGELOG 只写用户可感知的能力',
  ], 'AGENTS');
  assertContainsAll(rootReadme, [
    '@ecom-open-cli/opencli',
    '@ecom-open-cli/doudian-open-cli',
    '@bytedance/doudian-open-cli',
    'npm/internal/README.md',
    'npm/open/README.md',
    'cmd/doudian-open-cli-internal',
  ], '根 README');
  for (const forbidden of [
    'djt_cli_agent_spi', 'SaveSpiTemplateInterface', 'modify_version', 'kitex', 'CAS',
  ]) {
    assert.doesNotMatch(skillBundleText, new RegExp(escapeRegExp(forbidden)), `Skill 不应包含内部实现名 ${forbidden}`);
  }
  for (const forbidden of [
    'saveTemplateInfo',
    'getTemplateDetail',
    'interfaceStatusFlow',
    'open_admin_web',
    'cmp.ecom.open_admin',
    '源码开发', 'go install', '过渡期', 'feat/dev', '/tmp/', 'commit',
  ]) {
    assert.doesNotMatch(skillBundleText, new RegExp(escapeRegExp(forbidden)), `最终 Skill 不应包含 ${forbidden}`);
  }
  for (const forbidden of [
    'open_admin_web', 'cmp.ecom.open_admin',
  ]) {
    assert.doesNotMatch(readme, new RegExp(escapeRegExp(forbidden)), `对内 README 不应包含 ${forbidden}`);
  }
  assert.doesNotMatch(skillBundleText, /不需要 Python 脚本/);
});

test('对外 README 与 open Skill 不得出现点将台命令或 PPE 教程', () => {
  for (const [label, text] of [['open README', openReadme], ['open README zh', openReadmeZh], ['open Skill', openSkill]]) {
    assert.match(text, /init --kind/);
    assert.doesNotMatch(text, /doudian-open-cli djt/);
    assert.doesNotMatch(text, /djt\.bytedance\.net/);
    assert.doesNotMatch(text, /--use-ppe/);
    assert.doesNotMatch(text, /--ppe-env/);
  }
});

test('对外打包源不得出现内部 registry、PPE 或对内包名', async () => {
  const entries = new Map();
  for (const rel of ['npm/open/README.md', 'npm/open/README.zh-CN.md', 'npm/open/CHANGELOG.md', 'npm/open/LICENSE', 'npm/open/package.json']) {
    entries.set(`package/${path.basename(rel)}`, { content: await readText(rel) });
  }
  for (const name of OPEN_APPROVED_FILES) {
    if (!name.startsWith('package/skills/')) continue;
    if (!/\.(md|json|txt)$/.test(name)) continue;
    entries.set(name, { content: await readFile(path.join(repo, name.slice('package/'.length))) });
  }
  assert.doesNotThrow(() => assertOpenPublicSurface(entries));
  assert.throws(
    () => assertOpenPublicSurface(new Map([['package/README.md', { content: 'https://bnpm.byted.org' }]])),
    /内部标识/,
  );
});

test('对外 CHANGELOG 只写用户可感知能力，不写内部设计', () => {
  assert.match(openChangelog, /^## 1\.0\.0 /m);
  assert.doesNotMatch(openChangelog, /^## \d+\.\d+\.\d+-(alpha|beta|rc)\./m);
  for (const leak of [
    'X-Doudian-Open-Cli', 'X-Cli-Source', 'HMAC', 'fake token', 'open_gw',
    'sign_method', 'DOUBAO_SANDBOX', 'identity.Apply',
  ]) {
    assert.doesNotMatch(openChangelog, new RegExp(escapeRegExp(leak)), `CHANGELOG 不应出现 ${leak}`);
  }
});

test('对外 README 是可上传的 CLI 接入手册', () => {
  for (const heading of ['## Install', '## Upgrade', '## Commands', '## Login', '## Output format', '## Exit codes', '## Commands and flags', '## Examples']) {
    assert.match(openReadme, new RegExp(heading), `English handbook missing ${heading}`);
  }
  assert.match(openReadme, /Chinese handbook: \[README\.zh-CN\.md\]/);
  assert.match(openReadme, /npm install --global @bytedance\/doudian-open-cli/);
  assert.doesNotMatch(openReadme, /--registry=/);
  assert.match(openReadme, /json` \(\*\*default\*\*\)/);
  assert.match(openReadme, /auth status/);
  assert.match(openReadme, /"authenticated": true/);
  assert.match(openReadme, /"task_id": "584875801346"/);
  assert.match(openReadme, /https:\/\/op\.jinritemai\.com\/docs\/api-docs/);
  assert.match(openReadme, /exit 0|Exit codes/);
  for (const heading of ['## 安装', '## 升级', '## 命令', '## 登录', '## 输出格式', '## 退出码', '## 命令与参数', '## 示例']) {
    assert.match(openReadmeZh, new RegExp(heading), `中文手册缺少 ${heading}`);
  }
  assert.match(openReadmeZh, /json`（\*\*默认\*\*）/);
  assert.match(internalReadmeEn, /Chinese handbook/);
});

test('tarball allowlist 必须按 flavor 精确', () => {
  assert.ok(APPROVED_FILES.includes('package/skills/djt/SKILL.md'));
  assert.ok(APPROVED_FILES.includes('package/skills/open_cli_skill/SKILL.md'));
  assert.ok(OPEN_APPROVED_FILES.includes('package/skills/open_cli_skill/SKILL.md'));
  for (const extra of ['package/README.zh-CN.md', 'package/CHANGELOG.md', 'package/LICENSE']) {
    assert.ok(OPEN_APPROVED_FILES.includes(extra), extra);
    assert.ok(APPROVED_FILES.includes(extra), extra);
  }
  assert.ok(OPEN_APPROVED_FILES.includes('package/binaries/doudian-open-cli-windows-amd64.exe'));
  assert.ok(!OPEN_APPROVED_FILES.some(name => name.includes('skills/djt')));
  assert.ok(!OPEN_APPROVED_FILES.some(name => name.includes('postinstall')));
  assert.ok(APPROVED_FILES.includes('package/scripts/postinstall.cjs'));
  const entries = new Map(APPROVED_FILES.map((name) => [name, {
    mode: name.includes('/binaries/') || name.endsWith('/doudian-open-cli.js') ? 0o755 : 0o644,
    content: skillFiles.get(name) ?? Buffer.from('x'),
  }]));
  assert.doesNotThrow(() => validatePackage(entries, skillFiles, APPROVED_FILES));

  entries.set('package/source.go', { mode: 0o644, content: Buffer.from('bad') });
  assert.throws(() => validatePackage(entries, skillFiles, APPROVED_FILES), /文件清单/);
  entries.delete('package/source.go');
  entries.get('package/binaries/doudian-open-cli-linux-amd64').mode = 0o644;
  assert.throws(() => validatePackage(entries, skillFiles, APPROVED_FILES), /可执行权限/);
  entries.get('package/binaries/doudian-open-cli-linux-amd64').mode = 0o755;
  entries.get('package/package.json').mode = 0o755;
  assert.throws(() => validatePackage(entries, skillFiles, APPROVED_FILES), /权限/);
  entries.get('package/package.json').mode = 0o644;
  entries.get('package/skills/djt/scripts/validate_style_tree.py').content = Buffer.from('stale');
  assert.throws(() => validatePackage(entries, skillFiles, APPROVED_FILES), /Skill 文件字节/);
});

test('Agent Skill 使用可恢复登录且不重复授权', async () => {
  const skillText = await readFile(path.join(repo, 'skills/djt/SKILL.md'), 'utf8');
  const internalReadme = await readFile(path.join(repo, 'npm/internal/README.zh-CN.md'), 'utf8');
  for (const content of [skillText, internalReadme]) {
    assert.match(content, /doudian-open-cli djt auth login start --output json/);
    assert.match(content, /doudian-open-cli djt auth login complete --output json/);
  }
  assert.match(skillText, /不需要.*开始授权/);
  assert.match(skillText, /不得重复创建登录会话/);
});
