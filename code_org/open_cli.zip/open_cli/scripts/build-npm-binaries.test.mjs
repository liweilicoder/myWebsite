import assert from 'node:assert/strict';
import test from 'node:test';

import { buildArgs, cgoEnabled, targets } from './build-npm-binaries.mjs';

const cliVersionSymbol = 'code.byted.org/temai/open_cli/internal/core/cli.BuildVersion';
const identityVersionSymbol = 'code.byted.org/temai/open_cli/internal/core/identity.BuildVersion';

test('构建脚本生成五平台二进制，仅 darwin 开启 CGO', () => {
  assert.deepEqual(targets, [
    { goos: 'darwin', goarch: 'amd64', name: 'doudian-open-cli-darwin-amd64' },
    { goos: 'darwin', goarch: 'arm64', name: 'doudian-open-cli-darwin-arm64' },
    { goos: 'linux', goarch: 'amd64', name: 'doudian-open-cli-linux-amd64' },
    { goos: 'linux', goarch: 'arm64', name: 'doudian-open-cli-linux-arm64' },
    { goos: 'windows', goarch: 'amd64', name: 'doudian-open-cli-windows-amd64.exe' },
  ]);
  assert.equal(cgoEnabled('darwin'), '1');
  assert.equal(cgoEnabled('linux'), '0');
  assert.equal(cgoEnabled('windows'), '0');
});

test('构建参数通过 ldflags 注入 npm package 版本', () => {
  assert.deepEqual(buildArgs('0.2.3', '/tmp/doudian-open-cli', 'open'), [
    'build',
    '-trimpath',
    '-ldflags',
    `-X ${cliVersionSymbol}=0.2.3 -X ${identityVersionSymbol}=0.2.3`,
    '-o',
    '/tmp/doudian-open-cli',
    './cmd/doudian-open-cli',
  ]);
  assert.deepEqual(buildArgs('0.3.3', '/tmp/doudian-open-cli', 'internal')[6], './cmd/doudian-open-cli-internal');
});
