import { spawn } from 'node:child_process';
import path from 'node:path';
import process from 'node:process';
import { fileURLToPath } from 'node:url';

const repo = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const inner = path.join(repo, 'scripts/release-npm.mjs');

function usage() {
  console.log(`公网 npmjs 发布（@bytedance/doudian-open-cli）

必须在 open_cli 仓库根执行。细则：docs/spec/npmjs-open-publish.md

  npm run release:npmjs -- --check
  npm run release:npmjs -- --publish --yes

本包装固定 --flavor=open --npmjs，真实发布走 npx npm@latest stage publish，不改 BNPM 名。`);
}

const argv = process.argv.slice(2);
if (argv.length === 0 || argv.includes('--help')) {
  usage();
  process.exit(0);
}

const child = spawn(process.execPath, [inner, ...argv, '--flavor=open', '--npmjs'], {
  cwd: repo,
  stdio: 'inherit',
});
child.on('exit', (code, signal) => {
  if (signal) {
    process.kill(process.pid, signal);
    return;
  }
  process.exit(code ?? 1);
});
