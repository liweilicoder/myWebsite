#!/usr/bin/env node
process.stderr.write('仓库根不能 npm pack / npm publish。请使用 npm/open 或 npm/internal，或 scripts/release-npm.mjs --flavor=open|internal。\n');
process.exit(1);
