#!/usr/bin/env python3
"""Golden tests for json_to_spi_param_tree (script lives under skills/djt)."""

from __future__ import annotations

import importlib.util
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent
SCRIPT = REPO / "skills" / "djt" / "scripts" / "json_to_spi_param_tree.py"
TESTDATA = Path(__file__).resolve().parent / "testdata" / "spi_json_parse"


def load_module():
    spec = importlib.util.spec_from_file_location("json_to_spi_param_tree", SCRIPT)
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot load {}".format(SCRIPT))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def run_cli(*args: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [sys.executable, str(SCRIPT), *args],
        capture_output=True,
        text=True,
        cwd=REPO,
    )


class JsonToSpiParamTreeTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.mod = load_module()

    def test_request_golden(self) -> None:
        with open(TESTDATA / "input_basic.json", encoding="utf-8") as handle:
            payload = json.load(handle)
        with open(TESTDATA / "output_request.json", encoding="utf-8") as handle:
            expected = json.load(handle)
        actual = self.mod.convert(payload, "request")
        self.assertEqual(actual, expected)

    def test_web_request_form_fixture_matches_request_golden(self) -> None:
        with open(TESTDATA / "output_request.json", encoding="utf-8") as handle:
            expected = json.load(handle)
        with open(TESTDATA / "web_request_form_equivalent.json", encoding="utf-8") as handle:
            actual = json.load(handle)
        self.assertEqual(actual, expected)

    def test_response_golden(self) -> None:
        with open(TESTDATA / "input_basic.json", encoding="utf-8") as handle:
            payload = json.load(handle)
        with open(TESTDATA / "output_response.json", encoding="utf-8") as handle:
            expected = json.load(handle)
        actual = self.mod.convert(payload, "response")
        self.assertEqual(actual, expected)

    def test_null_exits_one(self) -> None:
        with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False) as handle:
            json.dump({"field": None}, handle)
            path = handle.name
        result = run_cli("--kind", "request", "--in", path, "--out", path + ".out")
        self.assertEqual(result.returncode, 1)
        self.assertIn("null", result.stderr.lower())

    def test_top_level_array_rejected(self) -> None:
        with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False) as handle:
            json.dump([1, 2], handle)
            path = handle.name
        result = run_cli("--kind", "request", "--in", path, "--out", path + ".out")
        self.assertEqual(result.returncode, 1)

    def test_cli_writes_output(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            inp = Path(tmp) / "in.json"
            out = Path(tmp) / "out.json"
            inp.write_text((TESTDATA / "input_basic.json").read_text(encoding="utf-8"), encoding="utf-8")
            result = run_cli("--kind", "request", "--in", str(inp), "--out", str(out))
            self.assertEqual(result.returncode, 0, result.stderr)
            with open(TESTDATA / "output_request.json", encoding="utf-8") as handle:
                expected = json.load(handle)
            with open(out, encoding="utf-8") as handle:
                actual = json.load(handle)
            self.assertEqual(actual, expected)

    def test_help_local_only(self) -> None:
        result = run_cli("--help")
        self.assertEqual(result.returncode, 0)
        help_text = result.stdout
        self.assertIn("不联网", help_text)
        self.assertNotIn("SaveSpi", help_text)
        self.assertNotIn("djt_cli_agent_spi", help_text)


if __name__ == "__main__":
    unittest.main()
