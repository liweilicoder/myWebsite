import assert from 'node:assert/strict';
import { mkdtemp, mkdir, readFile, writeFile } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import test from 'node:test';

import { flavors } from './npm-flavors.mjs';
import { stampOpenPackageForBnpm } from './stamp-open-bnpm.mjs';

test('发 BNPM 时打包把公网包名改成内网坐标，不改仓库源文件', async () => {
  const dir = await mkdtemp(path.join(os.tmpdir(), 'open-bnpm-'));
  await mkdir(dir, { recursive: true });
  const from = flavors.open.name;
  const to = flavors.open.bnpmName;
  await writeFile(path.join(dir, 'package.json'), JSON.stringify({ name: from, version: '1.0.0-alpha.0' }));
  await writeFile(path.join(dir, 'README.md'), `npm install --global ${from}\n`);
  await writeFile(path.join(dir, 'README.zh-CN.md'), `安装 ${from}\n`);
  stampOpenPackageForBnpm(dir);
  const manifest = JSON.parse(await readFile(path.join(dir, 'package.json'), 'utf8'));
  assert.equal(manifest.name, to);
  assert.match(await readFile(path.join(dir, 'README.md'), 'utf8'), new RegExp(to.replace('/', '\\/')));
  assert.doesNotMatch(await readFile(path.join(dir, 'README.md'), 'utf8'), /@bytedance\/doudian-open-cli/);
  assert.match(await readFile(path.join(dir, 'README.zh-CN.md'), 'utf8'), new RegExp(to.replace('/', '\\/')));
});
