#!/usr/bin/env node
import { chmod, lstat, mkdir, readFile, readdir, rename, rm, writeFile } from 'node:fs/promises';
import path from 'node:path';
import process from 'node:process';

import { embedPlans } from './npm-flavors.mjs';

function parseArgs(argv) {
  const options = { check: false, source: undefined, target: undefined, name: undefined };
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg === '--check') {
      options.check = true;
    } else if (arg === '--source' || arg === '--target' || arg === '--name') {
      if (!argv[i + 1]) throw new Error(`${arg} 缺少路径`);
      options[arg.slice(2)] = arg === '--name' ? argv[++i] : path.resolve(argv[++i]);
    } else {
      throw new Error(`未知参数：${arg}`);
    }
  }
  return options;
}

function validateSkill(content) {
  const text = content.toString('utf8');
  const frontmatter = text.match(/^---\r?\n([\s\S]*?)\r?\n---(?:\r?\n|$)/)?.[1];
  const nameLine = frontmatter?.split(/\r?\n/).find((line) => line.startsWith('name:'));
  const name = nameLine?.slice('name:'.length).trim();
  if (!name || name.trim() !== name || /[\t\r\n]/.test(name)) {
    throw new Error('Skill frontmatter 必须包含非空单行 name');
  }
}

async function collect(root, relative = '') {
  const directory = path.join(root, relative);
  const entries = await readdir(directory, { withFileTypes: true });
  const files = [];
  for (const entry of entries.sort((left, right) => left.name.localeCompare(right.name))) {
    const child = path.join(relative, entry.name);
    if (entry.isDirectory()) {
      files.push(...await collect(root, child));
    } else if (entry.isFile()) {
      files.push(child);
    } else {
      throw new Error(`Skill 目录包含不支持的文件类型：${child}`);
    }
  }
  return files;
}

async function readTree(root) {
  const names = await collect(root);
  const entries = new Map();
  for (const name of names) entries.set(name, await readFile(path.join(root, name)));
  return entries;
}

async function targetTree(root) {
  try {
    const info = await lstat(root);
    if (!info.isDirectory() || info.isSymbolicLink()) throw new Error('embed 镜像必须是普通目录');
    return await readTree(root);
  } catch (error) {
    if (error.code === 'ENOENT') return null;
    throw error;
  }
}

function treesEqual(source, target) {
  if (!target || source.size !== target.size) return false;
  for (const [name, content] of source) {
    if (!target.get(name)?.equals(content)) return false;
  }
  return true;
}

async function writeTree(root, entries) {
  await mkdir(root, { recursive: false, mode: 0o755 });
  await chmod(root, 0o755);
  for (const [name, content] of entries) {
    const destination = path.join(root, name);
    await mkdir(path.dirname(destination), { recursive: true, mode: 0o755 });
    await writeFile(destination, content, { mode: 0o644, flag: 'wx' });
    await chmod(destination, 0o644);
  }
}

async function replaceTree(target, entries) {
  const parent = path.dirname(target);
  const temporary = path.join(parent, `.${path.basename(target)}.tmp-${process.pid}-${Date.now()}`);
  const backup = path.join(parent, `.${path.basename(target)}.old-${process.pid}-${Date.now()}`);
  await mkdir(parent, { recursive: true, mode: 0o755 });
  let movedOld = false;
  try {
    await writeTree(temporary, entries);
    try {
      await rename(target, backup);
      movedOld = true;
    } catch (error) {
      if (error.code !== 'ENOENT') throw error;
    }
    try {
      await rename(temporary, target);
    } catch (error) {
      if (movedOld) await rename(backup, target);
      throw error;
    }
    if (movedOld) await rm(backup, { recursive: true, force: true });
  } finally {
    await rm(temporary, { recursive: true, force: true });
    await rm(backup, { recursive: true, force: true });
  }
}

async function syncOne({ source, target, name, check }) {
  const sourceInfo = await lstat(source);
  if (!sourceInfo.isDirectory() || sourceInfo.isSymbolicLink()) throw new Error('Skill 唯一源必须是普通目录');
  const tree = await readTree(source);
  const skill = tree.get('SKILL.md');
  if (!skill) throw new Error('Skill 唯一源缺少 SKILL.md');
  validateSkill(skill);

  const existing = await targetTree(target);
  if (treesEqual(tree, existing)) return;
  if (check) throw new Error(`Skill 唯一源与 embed 镜像不同步：${name}`);
  await replaceTree(target, tree);
}

async function sync(options) {
  if (options.source || options.target) {
    if (!options.source || !options.target) {
      throw new Error('--source 与 --target 必须同时提供');
    }
    const name = options.name || path.basename(options.source);
    await syncOne({ source: options.source, target: options.target, name, check: options.check });
    return;
  }
  const plans = embedPlans();
  for (const plan of plans) {
    await syncOne({ ...plan, check: options.check });
  }
  if (options.check) {
    const groups = new Map();
    for (const plan of plans) {
      const names = groups.get(plan.assetsDir) ?? new Set();
      names.add(plan.name);
      groups.set(plan.assetsDir, names);
    }
    for (const [assetsDir, names] of groups) {
      const entries = await readdir(assetsDir, { withFileTypes: true });
      for (const entry of entries) {
        if (entry.isDirectory() && !names.has(entry.name)) {
          throw new Error(`embed 镜像含未出现在 skills 源目录中的 Skill：${entry.name}`);
        }
      }
    }
  }
}

try {
  await sync(parseArgs(process.argv.slice(2)));
} catch (error) {
  process.stderr.write(`[sync-skill] ${error.message}\n`);
  process.exitCode = 1;
}
