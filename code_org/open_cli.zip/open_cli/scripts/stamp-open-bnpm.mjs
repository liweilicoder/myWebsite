import { readFileSync, writeFileSync } from 'node:fs';
import path from 'node:path';

import { flavors } from './npm-flavors.mjs';

export function stampOpenPackageForBnpm(packageDir) {
  const from = flavors.open.name;
  const to = flavors.open.bnpmName;
  if (!to || from === to) {
    throw new Error('仓库公网包名与 BNPM 包名必须不同');
  }
  const manifestPath = path.join(packageDir, 'package.json');
  const manifest = JSON.parse(readFileSync(manifestPath, 'utf8'));
  if (manifest.name !== from) {
    throw new Error(`预期仓库包名为 ${from}，实际 ${manifest.name}`);
  }
  manifest.name = to;
  writeFileSync(manifestPath, `${JSON.stringify(manifest, null, 2)}\n`);
  for (const file of ['README.md', 'README.zh-CN.md']) {
    const target = path.join(packageDir, file);
    const text = readFileSync(target, 'utf8');
    writeFileSync(target, text.split(from).join(to));
  }
}
