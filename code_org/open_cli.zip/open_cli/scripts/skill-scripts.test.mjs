import assert from 'node:assert/strict';
import { mkdtemp, readFile, writeFile } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import test from 'node:test';

const repo = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const scriptsDir = path.join(repo, 'skills', 'djt', 'scripts');
const applyScript = path.join(scriptsDir, 'apply_style_patches.py');
const validateScript = path.join(scriptsDir, 'validate_style_tree.py');
const requestStyleScript = path.join(scriptsDir, 'request_style.py');
const python = process.env.PYTHON ?? 'python3';

async function writeJSON(file, value) {
  await writeFile(file, `${JSON.stringify(value, null, 2)}\n`);
}

function run(script, args) {
  return spawnSync(python, [script, ...args], { encoding: 'utf8', timeout: 10_000 });
}

test('apply_style_patches 按嵌套 path 修改完整树且不改变输入文件', async () => {
  const root = await mkdtemp(path.join(os.tmpdir(), 'opencli-skill-script-'));
  const input = path.join(root, 'request.json');
  const patches = path.join(root, 'patches.json');
  const output = path.join(root, 'patched.json');
  const tree = [{
    path: 'testCase', toName: 'testCase', style: 1, children: [
      { path: 'testCase.scene', toName: 'scene', style: 1, mustNeed: true },
    ],
  }];
  await writeJSON(input, tree);
  await writeJSON(patches, [{
    path: 'testCase.scene', style: 3, constantValue: 'order_query', mustNeed: false,
    example: 'ignored-by-service-but-valid-locally', description: '固定业务场景',
  }]);

  const result = run(applyScript, ['--in', input, '--patches', patches, '--out', output]);
  assert.equal(result.status, 0, result.stderr);
  const actual = JSON.parse(await readFile(output, 'utf8'));
  assert.deepEqual(actual[0].children[0], {
    path: 'testCase.scene', toName: 'scene', style: 3, mustNeed: false,
    constantValue: 'order_query', example: 'ignored-by-service-but-valid-locally', description: '固定业务场景',
  });
  assert.equal(actual[0].style, 2);
  assert.deepEqual(JSON.parse(await readFile(input, 'utf8')), tree);
  assert.match(result.stderr, /patched 1 path/);
});

test('apply_style_patches 遇到未知 path 时失败且不生成输出', async () => {
  const root = await mkdtemp(path.join(os.tmpdir(), 'opencli-skill-script-'));
  const input = path.join(root, 'request.json');
  const patches = path.join(root, 'patches.json');
  const output = path.join(root, 'patched.json');
  await writeJSON(input, [{ path: 'known', children: [] }]);
  await writeJSON(patches, [{ path: 'unknown', style: 2 }]);

  const result = run(applyScript, ['--in', input, '--patches', patches, '--out', output]);
  assert.notEqual(result.status, 0);
  assert.match(result.stderr, /unknown/);
  await assert.rejects(readFile(output), { code: 'ENOENT' });
});

test('validate_style_tree strict 拒绝新接口对外参数与内部变量冲突', async () => {
  const root = await mkdtemp(path.join(os.tmpdir(), 'opencli-skill-script-'));
  const input = path.join(root, 'request.json');
  const getJSON = path.join(root, 'get.json');
  await writeJSON(input, [{ path: 'shopId', toName: 'shopId', requestName: 'SHOP_ID', style: 1 }]);
  await writeJSON(getJSON, { data: { current: { reservedInnerVarNames: ['shop_id'], isOldInterface: false } } });

  const result = run(validateScript, ['--in', input, '--get-json', getJSON, '--strict']);
  assert.equal(result.status, 1, result.stderr);
  assert.match(result.stdout, /与内部变量.*冲突/);
});

test('validate_style_tree 接受显式内部变量参数下的合法嵌套树', async () => {
  const root = await mkdtemp(path.join(os.tmpdir(), 'opencli-skill-script-'));
  const input = path.join(root, 'request.json');
  await writeJSON(input, [{
    path: 'testCase', toName: 'testCase', requestName: 'test_case', type: 5, style: 2,
    children: [
      { path: 'testCase.shopId', toName: 'shopId', requestName: 'shop_id', style: 2, mustNeed: false },
      { path: 'testCase.scene', toName: 'scene', style: 3, constantValue: 'query', description: '场景' },
    ],
  }]);

  const result = run(validateScript, ['--in', input, '--inner-var-names', 'shop_id,user_id', '--strict']);
  assert.equal(result.status, 0, `${result.stdout}\n${result.stderr}`);
  assert.match(result.stdout, /OK/);
});

test('apply_style_patches 提升全内部变量/常量子树的中间节点为 style=2', async () => {
  const root = await mkdtemp(path.join(os.tmpdir(), 'opencli-skill-script-'));
  const input = path.join(root, 'request.json');
  const patches = path.join(root, 'patches.json');
  const output = path.join(root, 'patched.json');
  await writeJSON(input, [{
    path: 'account', toName: 'account', requestName: 'account', type: 5, style: 1,
    children: [
      { path: 'account.shopId', toName: 'shopId', requestName: 'shop_id', type: 1, style: 1 },
    ],
  }]);
  await writeJSON(patches, [{ path: 'account.shopId', style: 2, requestName: 'shop_id', mustNeed: false }]);

  const result = run(applyScript, ['--in', input, '--patches', patches, '--out', output]);
  assert.equal(result.status, 0, result.stderr);
  const actual = JSON.parse(await readFile(output, 'utf8'));
  assert.equal(actual[0].style, 2);
  assert.equal(actual[0].children[0].style, 2);
});

test('validate_style_tree 拒绝未提升的 style=1 中间节点', async () => {
  const root = await mkdtemp(path.join(os.tmpdir(), 'opencli-skill-script-'));
  const input = path.join(root, 'request.json');
  await writeJSON(input, [{
    path: 'account', toName: 'account', requestName: 'account', type: 5, style: 1,
    children: [
      { path: 'account.shopId', toName: 'shopId', requestName: 'shop_id', style: 2 },
    ],
  }]);

  const result = run(validateScript, ['--in', input, '--inner-var-names', 'shop_id', '--strict']);
  assert.equal(result.status, 1, result.stdout);
  assert.match(result.stdout, /中间节点 path=account style=1/);
});

test('两个本地脚本兼容 Python 3.8 语法且不包含网络依赖', async () => {
  for (const script of [applyScript, validateScript, requestStyleScript]) {
    const source = await readFile(script, 'utf8');
    assert.doesNotMatch(source, /\b(?:urllib|requests|http\.client|socket)\b|https?:\/\//);
    const syntax = spawnSync(python, ['-c', 'import ast,sys; ast.parse(open(sys.argv[1], encoding="utf-8").read(), feature_version=(3, 8))', script], { encoding: 'utf8' });
    assert.equal(syntax.status, 0, syntax.stderr);
  }
  for (const script of [applyScript, validateScript]) {
    const help = run(script, ['--help']);
    assert.equal(help.status, 0, help.stderr);
  }
});
