import assert from 'node:assert/strict';
import { mkdtemp, mkdir, readFile, readdir, writeFile } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import test from 'node:test';

const repo = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const script = path.join(repo, 'scripts', 'sync-skill.mjs');

function run(args, cwd = os.tmpdir()) {
  return spawnSync(process.execPath, [script, ...args], { cwd, encoding: 'utf8' });
}

async function files(root, prefix = '') {
  const output = [];
  for (const entry of await readdir(path.join(root, prefix), { withFileTypes: true })) {
    const relative = path.join(prefix, entry.name);
    if (entry.isDirectory()) output.push(...await files(root, relative));
    else if (entry.isFile()) output.push(relative.split(path.sep).join('/'));
    else throw new Error(`unexpected entry: ${relative}`);
  }
  return output.sort();
}

async function assertTreesEqual(source, target) {
  const expected = await files(source);
  assert.deepEqual(await files(target), expected);
  for (const relative of expected) {
    assert.deepEqual(await readFile(path.join(target, relative)), await readFile(path.join(source, relative)), relative);
  }
}

test('同步工具不依赖当前目录且 check 校验仓库完整镜像', () => {
  const result = run(['--check']);
  assert.equal(result.status, 0, result.stderr);
  assert.equal(result.stdout, '');
});

test('同步工具递归复制完整目录、保持字节并删除镜像过期文件', async () => {
  const root = await mkdtemp(path.join(os.tmpdir(), 'opencli-skill-sync-'));
  const source = path.join(root, 'source');
  const target = path.join(root, 'asset');
  await mkdir(path.join(source, 'scripts'), { recursive: true });
  await mkdir(path.join(target, 'old'), { recursive: true });
  await writeFile(path.join(source, 'SKILL.md'), Buffer.from('---\nname: djt\n---\n原始字节\n'));
  await writeFile(path.join(source, '.skillignore'), '*.pyc\n');
  await writeFile(path.join(source, 'scripts', 'tool.py'), Buffer.from('#!/usr/bin/env python3\n'));
  await writeFile(path.join(target, 'SKILL.md'), 'stale');
  await writeFile(path.join(target, 'old', 'removed.txt'), 'remove me');

  const mismatch = run(['--check', '--source', source, '--target', target, '--name', 'djt']);
  assert.notEqual(mismatch.status, 0);
  assert.match(mismatch.stderr, /不同步/);

  const synced = run(['--source', source, '--target', target, '--name', 'djt']);
  assert.equal(synced.status, 0, synced.stderr);
  await assertTreesEqual(source, target);
  assert.equal(run(['--check', '--source', source, '--target', target, '--name', 'djt']).status, 0);
});

test('同步工具允许 frontmatter name 作为显示名独立于源目录', async () => {
  const root = await mkdtemp(path.join(os.tmpdir(), 'opencli-skill-sync-'));
  const source = path.join(root, 'source');
  const target = path.join(root, 'asset');
  await mkdir(source);
  await writeFile(path.join(source, 'SKILL.md'), '---\nname: 抖店AI视频创作\n---\n');
  const result = run(['--source', source, '--target', target]);
  assert.equal(result.status, 0, result.stderr);
  assert.equal(run(['--check', '--source', source, '--target', target]).status, 0);
});

 test('同步工具拒绝缺少 frontmatter name', async () => {
  const root = await mkdtemp(path.join(os.tmpdir(), 'opencli-skill-sync-'));
  const source = path.join(root, 'source');
  const target = path.join(root, 'asset');
  await mkdir(source);
  await writeFile(path.join(source, 'SKILL.md'), '---\ndescription: x\n---\n');
  const result = run(['--source', source, '--target', target]);
  assert.notEqual(result.status, 0);
  assert.match(result.stderr, /非空单行 name/);
});
