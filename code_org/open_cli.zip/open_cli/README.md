# doudian-open-cli

同一仓库产出两套命令名相同的 CLI：`doudian-open-cli`。

| 产物 | npm 包 | 入口 | 能力 |
|---|---|---|---|
| 对外 | 公网 [`@bytedance/doudian-open-cli`](npm/open/README.md)；BNPM `@ecom-open-cli/doudian-open-cli` | `cmd/doudian-open-cli` | 开放调用（`init`、`auth status|logout`、`api`） |
| 对内 | [`@ecom-open-cli/opencli`](npm/internal/README.md) | `cmd/doudian-open-cli-internal` | 对外超集，另含点将台 `djt` |

仓库根 `package.json` 为 `private`，不能 `npm pack` / `npm publish`。必须在 **`open_cli` 仓库根**执行 `npm run`。BNPM 发布必须指定 flavor：

```bash
npm run release:check -- --flavor=internal
npm run release:check -- --flavor=open
```

发公网 npmjs（`@bytedance/doudian-open-cli`）用 `npm run release:npmjs`，可执行 SOP：[`docs/spec/npmjs-open-publish.md`](docs/spec/npmjs-open-publish.md)。维护约定见 [`AGENTS.md`](AGENTS.md)。

## 环境

npm 安装需要 **Node.js 18+**（`engines.node: >=18`），无需 Go。安装后启动器按本机系统选出包内二进制。

| 平台 | 架构 |
|---|---|
| Linux | AMD64、ARM64 |
| macOS | Intel（x64）、Apple Silicon（ARM64） |
| Windows | AMD64 |

其余组合会明确失败，不要用 Windows ARM 或 32 位。`init` / `auth` / `api` / `skills` 在上表均可运行。点将台 `djt self skill` 只在 macOS / Linux 写入本机 Agent 目录。

## 安装

两套包命令名都是 `doudian-open-cli`，全局安装会互相覆盖，按用途只装其中一个。

**对外 · 公网 npmjs**（商家 / 外部 Agent）：

```bash
npm install --global @bytedance/doudian-open-cli@latest --registry=https://registry.npmjs.org
doudian-open-cli --version
doudian-open-cli --help
doudian-open-cli skills
```

本机默认 registry 若是 BNPM，必须带 `--registry=https://registry.npmjs.org`。

**对外 · 公司 BNPM**（内部验收，打包名不同）：

```bash
npm install --global @ecom-open-cli/doudian-open-cli@latest --registry=https://bnpm.byted.org
doudian-open-cli --help
doudian-open-cli skills
```

**对内**（点将台配置，含对外全部命令）：

```bash
npm install --global @ecom-open-cli/opencli@latest --registry=https://bnpm.byted.org
doudian-open-cli --help
doudian-open-cli skills
doudian-open-cli djt version
doudian-open-cli djt self skill install --output json
```

已安装用户不会自动升级。再跑同一条 `npm install --global …@latest` 即可拉到最新。对内更新点将台 Skill 另加：

```bash
doudian-open-cli djt self skill update --output json
```

对外包说明见 [`npm/open/README.md`](npm/open/README.md)。点将台操作见 [`npm/internal/README.md`](npm/internal/README.md) 与 `skills/djt/`。开发与设计文档见 [docs/README.md](docs/README.md)。

## 命令

两套二进制的命令名都是 `doudian-open-cli`。对内包包含下面全部对外命令，并额外挂 `djt`。根上的 `auth` / `api` 是商家开放调用；`djt auth` / `djt api` 是点将台配置，凭据和接口都不通用。

默认 `--output json`（也可显式 `-o json`；人眼可读加 `-o text`）。成功数据在 stdout，过程提示和错误在 stderr。

本地开放凭据和待完成 `device_code` 用钥匙串主密钥加密后落盘，不留明文 `credentials.json` / `login-session.json`。macOS 只把 32 字节主密钥放进登录钥匙串，库与飞书相同（`go-keyring` v0.2.8，调用 `/usr/bin/security`）。`DOUBAO_SANDBOX_TYPE=SaaS` 才是云电脑：明文文件、`device/start` 发送 `mode=cloud`，且不访问系统钥匙串。细节见 [钥匙串与云电脑](docs/spec/open-cli-keychain-sandbox.md)。

### 对外（两边都有）

| 命令 | 作用 |
|---|---|
| `version` / `--version` | 打印版本号 |
| `skills` | 列出内嵌 Skill：`open` 在前，随后是 `skills/biz` 下的业务；每行 `名称<TAB>description` |
| `skills <name>` | 打印指定 Skill 的 SKILL.md 原文。不写入本机 Agent 目录，不受 `--output json` 影响 |
| `init --kind authorized` | 商家授权型登录：第一方 Device Flow，不录入 ak/sk。人工终端发起后阻塞轮询 |
| `init --kind authorized --no-wait` | 只发起授权并立刻返回 `verification_url`；Agent 必用。有效会话内重复执行会复用，不重新发码 |
| `init --kind authorized --complete` | 用本机待完成会话兑票，阻塞到成功或超时 |
| `init --kind generic --app-key --app-secret --access-token` | 通用型：把开发者自己的 ak/sk/token 写入本地凭据 |
| `auth status` | 只读本地开放凭据（类型、app_key、过期、店铺），不打远端，不打印 token / secret |
| `auth logout` | 删除本地开放凭据和待完成会话。不删除系统钥匙串里的主密钥。换应用或换类型前先执行 |
| `api [GET\|POST] --path <path> --data <json>` | 按当前凭据调用开放网关。`--path` 必填，省略 METHOD 时为 POST，只支持 GET / POST。两种身份都带 HMAC `sign`；授权型 query 放 fake token |
| `api … --dry-run` | 只预览方法、URL、query 键和 body，不发 HTTP，不展示 token / secret / CLI 审计头 |

`--use-ppe` / `--ppe-env` 在对外 `--help` 里隐藏，对外文档不写联调教程。

### 仅对内（`djt`）

点将台员工登录、业务域、OpenAPI 配置、SPI、内部测试调用。请求固定打 `https://djt.bytedance.net`。根命令 `--use-ppe` / `--ppe-env` 只在对内 `--help` 可见，用于把点将台请求打到指定泳道。

| 命令 | 作用 |
|---|---|
| `djt version` | 打印版本号（与根 `version` 相同） |
| `djt self skill install\|status\|update` | 只管理点将台 Skill，写入本机 Agent 目录。对外 CLI 没有对应命令 |
| `djt auth login` | 一步式登录，适合可持续前台运行的人工终端 |
| `djt auth login start` | 创建可跨对话完成的登录会话；Agent 必用，向用户展示 `verification_url` 和 `user_code` |
| `djt auth login complete` | 完成最近一次登录会话 |
| `djt auth status` | 只读本地点将台登录状态，不验证远端会话 |
| `djt auth whoami` | 只读本地缓存身份，不发远端请求 |
| `djt auth logout` | 退出点将台登录 |
| `djt biz-domain list` | 列出当前环境业务域及当前用户可用域 |
| `djt biz-domain apply --domain-ids` | 申请业务域权限；无 dry-run，调用即提交 |
| `djt api get` | 查询接口配置，或按条件模糊搜索 |
| `djt api init` | 从 BAM 初始化接口。直接落库，须先 `biz-domain list`，并向用户确认后同时传 `--confirmed-by-user --apply` |
| `djt api save` | 保存接口配置。默认 dry-run，`--apply` 才落库 |
| `djt api doc` | 保存接口文档。必须显式 `--apply` |
| `djt api advance-step` | 预览或推进接口配置步骤。默认 dry-run；审核通过后的发布只能走网页 |
| `djt api test boe\|ppe\|prod` | 用点将台内部测试应用在对应环境调用 API。`prod` 必须 `--confirmed-by-user` |
| `djt api test auth add` | 给内部测试应用添加或刷新授权主体 |
| `djt spi scene list\|get` | 列出或查询 SPI 场景 |
| `djt spi scene save` | 保存 SPI 场景。默认 dry-run |
| `djt spi scene sync-boe` | 同步 SPI 场景的 BOE 应用。默认 dry-run |
| `djt spi scene access-app list\|get` | 列出或查询场景接入应用；`get` 含接口实现详情 |
| `djt spi scene access-app save` | 保存接入应用。默认 dry-run；保存后仍未启用 |
| `djt spi scene access-app enable` | 启用接入应用。默认 dry-run |
| `djt spi interface list\|get` | 搜索或查询 SPI 接口 |
| `djt spi interface save` | 创建或更新 SPI 接口。默认 dry-run；新建还要 `--confirmed-by-user` |
| `djt spi interface submit-review` | 提交接口审核。默认 dry-run；提审后到网页完成审核 |
| `djt spi interface cancel-upgrade` | 撤销升级草稿。默认 dry-run，仅草稿态可撤销 |

## 仓库目录

本树是仓库目录的唯一维护处。增删改目录、包或下列关键文件时，必须在同一变更里更新本节。描述只写职责。

```text
open_cli/
├── README.md
│     仓库说明：同一命令名、两套安装包、各自用途；本目录树
├── AGENTS.md
│     开发约定、两套发布 SOP、门禁
├── go.mod / go.sum
│     单一 Go module
├── package.json
│     private；只编排测试/构建/发布，根目录不能 npm publish
│
├── cmd/                              只有 main 与入口级门禁，不放业务命令
│   ├── doudian-open-cli/             对外进程入口。只装配 core + open
│   │   ├── main.go
│   │   ├── main_test.go              对外 --help 不含 djt / 隐藏 PPE
│   │   ├── import_guard_test.go      go list -deps 不得出现 internal/djt
│   │   └── leak_test.go              对外二进制字符串黑名单
│   └── doudian-open-cli-internal/    对内进程入口。装配 core + open + djt
│       └── main.go
│
├── internal/
│   ├── core/                         两边共用，按对外标准改；禁止引用 open / djt
│   │   ├── output/                   text / json 信封打印
│   │   ├── errs/                     结构化错误：type / code / message / hint / log_id
│   │   ├── jsoninput/                inline、@file、@- 有界 JSON
│   │   ├── sanitize/                 终端输出脱敏
│   │   ├── urlpolicy/                绝对 URL、same-origin 校验
│   │   ├── browser/                  打开系统浏览器
│   │   ├── ppe/                      联调头白名单（x-use-ppe / x-tt-env）
│   │   ├── httpx/                    禁止 redirect、限制响应体的 HTTP 客户端
│   │   ├── httpmock/                 单测 HTTP Registry：stub + Verify，无真网关
│   │   ├── factory/                  惰性依赖注入；TestFactory 可替换 HTTP/凭据/IO
│   │   ├── credstore/                0600 JSON 凭据文件，schema 由调用方定
│   │   ├── identity/                 请求头 From / Source / Version；豆包 Agent 名
│   │   ├── keychain/                 主密钥与密文。macOS 经 go-keyring 调 security；Linux 文件；Windows DPAPI
│   │   ├── skill/                    对内把点将台 Skill 原子安装到 Agent 目录
│   │   └── cli/                      Build(factory, Register…)；根命令 --output、version、PPE
│   │       ├── root.go
│   │       ├── version.go
│   │       └── self.go
│   │
│   ├── open/                         开放平台面；禁止依赖 djt
│   │   ├── config/                   网关 Base URL、会话 start/poll、CLI 审计头名
│   │   ├── auth/                     凭据与待完成会话（本地钥匙串密文 / 云电脑明文）、start 的 mode、status、logout
│   │   ├── invoke/                   唯一发开放网关的端口；path → 网关、签名、dry-run、Send
│   │   ├── cli/                      init / auth / api / skills 的 Cobra（Register / RegisterWith）
│   │   └── skill/                    对外 Skill embed（open_cli_skill + skills/biz 下各业务）
│   │       └── assets/               每个 Skill 一个子目录，与手工源字节一致
│   │           ├── doudian_aigc/
│   │           └── open_cli_skill/
│   │
│   └── djt/                          点将台配置面；禁止被 open 依赖
│       ├── auth/                     员工 Device Flow、whoami、点将台凭据
│       ├── *.go                      点将台 HTTP、OpenAPI/SPI Agent、业务域、API 测试
│       ├── cli/                      djt 子树：auth / api / spi / biz-domain / self skill
│       └── skill/                    点将台 Skill 的 embed 镜像（与 skills/djt 字节一致）
│           └── assets/djt/
│
├── skills/                           Agent Skill 唯一手工维护源
│   ├── open_cli_skill/               对外：授权与 api 的 SOP；不写 djt、不写 PPE
│   ├── djt/                          对内：点将台 OpenAPI / SPI 配置 SOP 与离线脚本
│   └── biz/                          业务 Skill 抽屉；README 不是 Skill。子目录随 skills 命令列出
│       └── doudian_aigc/             商家 AI 成片、任务与积分查询
│           ├── SKILL.md              场景路由与共通规则
│           ├── references/           权限校验、创建成片、任务及积分查询流程
│           └── scripts/              Bash 成片任务轮询脚本
│
├── bin/                              npm 启动器，两套包共用，不含业务
│   ├── doudian-open-cli.js           bin 入口，转调 launcher
│   ├── launcher.cjs                  spawn 包内对应平台二进制
│   ├── launcher.test.cjs
│   └── .npmignore
│
├── scripts/                          构建、Skill 同步、打包校验、发布
│   ├── npm-flavors.mjs               两套 flavor 的包名 / 入口；Skill 按目录自动发现
│   ├── stage-npm-package.mjs         把 bin / binaries / skills 拷入 npm/<flavor>
│   ├── guard-root-pack.mjs           拒绝仓库根 npm pack / publish
│   ├── build-npm-binaries.mjs        按 flavor 交叉编译两个 main，写入对应 npm 目录
│   ├── build-npm-binaries.test.mjs
│   ├── sync-skill.mjs                将 skills/open_cli_skill、skills/biz/*、skills/djt 同步到 embed
│   ├── sync-skill.test.mjs
│   ├── postinstall.cjs               对内包：best-effort 安装点将台 Skill
│   ├── postinstall.test.cjs
│   ├── verify-npm-package.mjs        校验 tarball 与该 flavor 的文件 allowlist
│   ├── npm-package.test.mjs          两套包的 pack 契约测试
│   ├── release-npm.mjs               --flavor=open|internal 发布到 BNPM
│   ├── release-npm.test.mjs
│   ├── skill-scripts.test.mjs        点将台 Skill 配套脚本测试
│   ├── json_to_spi_param_tree.test.py
│   ├── json_to_spi_param_tree/
│   └── testdata/spi_json_parse/      SPI JSON 转参数树的样例
│
├── npm/                              npm pack / publish 的包根
│   ├── open/                         对外包 @bytedance/doudian-open-cli（发 BNPM 时改名）
│   │   ├── package.json              对外二进制；打包 skills/ 下除 djt 外的全部 Skill
│   │   ├── README.md                 英文主文档；禁止出现 djt
│   │   ├── README.zh-CN.md           中文手册
│   │   ├── CHANGELOG.md              对外用户可见能力；不写请求头、验签、预发布内部记录
│   │   └── LICENSE                   版权与抖店用户协议、开放平台协议链接
│   └── internal/                     对内包 @ecom-open-cli/opencli
│       ├── package.json              对内二进制；打包 skills/ 下的全部 Skill，含 djt
│       ├── README.md                 英文主文档
│       ├── README.zh-CN.md           中文超集用法
│       ├── CHANGELOG.md
│       └── LICENSE
│
└── docs/
    ├── README.md                     文档目录。细节在下面的文件里
    ├── open_cli_open_onepage.md      对外 CLI 建设（命令面、Factory、信封、开平契约）
    ├── open_cli_djt_onepage.md       点将台全景
    ├── spec/
    │   ├── dual-flavor-cli.md        双产物隔离、打包、文档分层
    │   ├── npmjs-open-publish.md       对外包发公网 npmjs 可执行 SOP
    │   ├── npm-skill-distribution.md   生产地址、npm 与 Skill 分发
    │   ├── cli-output.md             成功信封、失败错误、退出码
    │   ├── skill-layout.md           对外 Skill 目录、skills catalog/read、业务约束
    │   ├── open-cli-auth-invoke.md   授权型 Device Flow 与通用型签名
    │   ├── open-cli-keychain-sandbox.md  本地主密钥、密文会话、mode 与沙箱头
    │   ├── agent-interface.md
    │   ├── djt-cli-demo.md
    │   ├── djt-cli-spi-agent.md
    │   └── djt-fixed-baseurl-and-psm.md
```

构建生成、不进 Git：`npm/<flavor>/bin/`、`npm/<flavor>/binaries/`、`npm/<flavor>/skills/`、`*.tgz`。`bin/` 源码只维护一份，prepack 拷入对应 flavor。

## 源码

```bash
go test ./...
go test -race ./...
go vet ./...
go build ./cmd/doudian-open-cli
go build ./cmd/doudian-open-cli-internal
```

开发约定见 [`AGENTS.md`](AGENTS.md)。隔离设计见 [`docs/spec/dual-flavor-cli.md`](docs/spec/dual-flavor-cli.md)。
