# 业务 Skill 怎么写

本文件给编写 `skills/biz/<业务>/` 的人看。它不是 Skill，不会出现在 `doudian-open-cli skills` 列表里，也不会打进 npm。Agent 用的通用 CLI 说明只有 `skills/open_cli_skill/SKILL.md`，用 `doudian-open-cli skills open_cli_skill` 阅读。

`doudian-open-cli skills` **依赖**下面这些约定：查找键是目录名，目录行是 `description`，全文是根上那份 `SKILL.md`。写错任意一条，Agent 就匹配不到或 `skills <业务名>` 会报未知 Skill。规格见 `docs/spec/skill-layout.md`。

## Agent 怎么用

```text
doudian-open-cli skills                 # 先看目录：open 在前，然后是各业务
doudian-open-cli skills open_cli_skill  # CLI 用法（登录、api、禁止事项）
doudian-open-cli skills <业务名>                 # 打印 SKILL.md
doudian-open-cli skills <业务名> --ref <name>      # 打印 references/<name>.md
doudian-open-cli skills <业务名> --script <name>   # 打印 scripts/<name>.sh 或 .py
```

不要假设业务 Skill 已经安装到 `~/.agents`。对外 CLI 不会往本机写 Skill 文件。

## 分工

| 写在哪                        | 写什么                                                                                     |
| -------------------------- | --------------------------------------------------------------------------------------- |
| `skills/open_cli_skill`    | 登录、两种身份、`auth status` / `logout`、`api` 的 METHOD / `--data` / `--dry-run`、退出码和禁止泄露 token |
| 已发布接口文档                    | 字段、类型、是否必填、错误码。文档随接口发布更新，例如内容投稿：<https://op.jinritemai.com/docs/api-docs/1568/7145>     |
| `skills/biz/<业务>/SKILL.md` | 这个业务要调用哪些 path、参数怎么组、多个接口的先后顺序、哪一步必须先问用户                                                |

业务 Skill 不要再写一遍授权，也不要再写一遍「`api` 怎么调用」的通用规则。登录失败或凭据过期时停下来即可，通用规则在 `skills open_cli_skill`。

## frontmatter（给 `skills` 目录用）

```yaml
---
name: content-aigc
description: >-
  内容投稿：组稿、上传素材、按顺序调开放接口发稿。
  当用户提到内容投稿、图文发稿、视频发稿、内容素材上传时使用。
---
```

- 目录名是稳定查找键，匹配 `^[a-z][a-z0-9_-]{0,40}$`；`name` 是非空单行展示名，可使用中文，并可用于查找。不能叫 `open`、`open_cli_skill`、`djt`、`biz`。
- `description` 会出现在 `doudian-open-cli skills` 的第二列（`名称` 和 `description` 用制表符分隔）。必须非空；解析后不能含制表符或换行。folded `>-` 的多行会被拼成一行，这是推荐写法：先写做什么，再写何时使用。

## 业务 Skill 里应该有的

- 任务目标和完成标准
- 接口 path，以及 `--data` 里业务字段怎么填。字段含义用一句话指向官方文档，不要把文档整页抄进来
- 多个接口的组合顺序，以及上一步的返回值怎么填进下一步
- 会改线上数据时，写明先向用户展示关键参数并等待同意，然后再发请求

调用形式只保留业务本身需要的那一行，例如：

```bash
doudian-open-cli api POST --path '/your/path' --data '{"field":"..."}' --output json
```

path 必须通过 `--path` 提供；path 和字段名以该接口的已发布文档为准。不要在 Skill 里发明文档里没有的字段。

## 不要写

下面这些子串一旦出现在 `skills/biz/<业务>/` 的**任意文件**里，`go test ./internal/open/skill` 会失败（与 `internal/open/skill/biz.go` 中的列表一致）：

- `init --kind`、`--no-wait`、`--complete`、`--device-code`、`verification_url`、`device_code`
- `auth status`、`auth logout`、`--app-key`、`--app-secret`、`--access-token`
- `--dry-run`、`sign_method`、`签名算法`
- `doudian-open-cli djt`、`djt.bytedance.net`、`--use-ppe`、`--ppe-env`、`点将台`、`PPE`

## 目录

```text
skills/biz/<业务>/
├── SKILL.md                 必需。frontmatter 的 name 是展示名
├── references/<name>.md     可选。用 skills <业务> --ref <name> 打印
└── scripts/<name>.sh|py     可选。用 skills <业务> --script <name> 打印
```

根上不能再放别的文件。`references` 和 `scripts` 只允许一层，不能再套目录，也不能再放 `SKILL.md`。

## 交到仓库之后

1. 把目录放进 `skills/biz/<业务>/`。
2. `go test ./internal/open/skill` 必须通过（布局、frontmatter、禁词、catalog）。
3. `node scripts/sync-skill.mjs`，提交生成的 `internal/open/skill/assets/<业务>/`。
4. 不必改打包名单或 `skills` 命令入口。对外包和对内包都会带上它；`doudian-open-cli skills` 会出现一行 `<业务名><TAB><description>`，`doudian-open-cli skills <业务名>` 打印这份 `SKILL.md`。
