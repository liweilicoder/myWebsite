module code.byted.org/temai/open_cli

go 1.21

require (
	github.com/spf13/cobra v1.9.1
	github.com/spf13/pflag v1.0.6
	github.com/zalando/go-keyring v0.2.8
	golang.org/x/sys v0.30.0
)

require (
	github.com/danieljoos/wincred v1.2.3 // indirect
	github.com/godbus/dbus/v5 v5.2.2 // indirect
	github.com/inconshreveable/mousetrap v1.1.0 // indirect
)
