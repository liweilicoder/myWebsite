# 对外 CLI 建设onepage

**状态：** 已落地 init 双身份与 api 发送  
**日期：** 2026-09-20  
**仓库：** `open_cli`  
**范围：** 仅对外开放面（`internal/open` + 为此服务的 `internal/core`）。点将台业务不在本文扩展；若 core 契约变化，由 `internal/djt` **适配**，不以点将台习惯约束 core。

隔离与双产物见 `docs/spec/dual-flavor-cli.md`。CLI 授权与调用以 `docs/spec/open-cli-auth-invoke.md` 为准；服务端 Device Flow 以 `open_auth/docs/spec/2026-09-21-cli-pending-two-schemes.md` 为准。

## 1. 目标

对外包 `@bytedance/doudian-open-cli` 成为商家 / Agent 调用抖店开放平台的 CLI（SDK 式入口）。

第一期产品只做 **Lark 意义上的第一层：带鉴权的原始 API 调用**，外加必须同时具备的地基（依赖注入、输出信封、dry-run、登录态、短 Skill）。不做元数据生成命令树，不做 `+` 快捷编排。

命令面已锁定：path 模式，默认 POST，仅支持 GET/POST。见第 4 节。

## 2. 原则

1. **core 按对外标准设计。** 共享包没有「对内特例」。点将台继续用 core，差异在 `internal/djt` 适配层。
2. **Cobra 只表达意图。** 运行时依赖必须走 **Factory**，实现必须参考 Lark CLI 的 `cmdutil.Factory`（惰性初始化、凭据优先、测试可替换字段）。不在命令里 new HTTP、刷 token、拼签名。
3. **stdout 只放数据，stderr 只放诊断。** token / secret 不得出现在任何输出里。
4. **`+` 留给以后的 shortcut。** 第一期命令语法不得使用 `+<domain>`。
5. **初始化一次，后续调用带身份。** `api` 不接受 `--appkey`；换应用或换类型走 `auth logout` 再 `init`。
6. **第一期可发现、可预览、可失败恢复。** 有 help/schema 挂载点、invoke 有 dry-run、错误有 type + hint。

## 3. 第一期做 / 不做

**做：** `init`（authorized / generic）、`auth status` / `auth logout`、原始 API 调用（含签名发送）、`--dry-run`、结构化错误、`skills` catalog/read（`skills/open` 与 `skills/biz`）、对外 README。  
**不做：** `auth login` / `auth reset-sk`、refresh token、service 动态命令树、shortcut、远程元数据 overlay、Keychain、把 Skill 安装到本机目录、SPI 回调、任意 `--header`。本仓库不实现 `open_gw` skip-sign 与豆包换票服务。运行时支持 Windows AMD64。

授权页、网关、限流、计费仍由开平服务承担。CLI 消费契约：会话 start/poll 与网关签名见第 9 节与 `docs/spec/open-cli-auth-invoke.md`。

## 4. 对外命令面（已锁定）

```text
doudian-open-cli [--output text|json]

  version

  init --kind authorized|generic [--no-wait | --complete]

  auth logout | status

  api [GET|POST] --path <path> --data <json> [--dry-run]

  skills [name]
```

`--use-ppe` / `--ppe-env` 根上可解析，对外 `--help` 隐藏。禁止 `djt`、`+<shortcut>`、`service`。`doctor` / `schema` / `completion` 第一期不做。

### 4.1 `api`：`--path` 必填，默认 POST，仅 GET/POST

```text
doudian-open-cli api --path '/product/detail' --data '{"product_id":"1"}'
doudian-open-cli api POST --path '/product/detail' --data @body.json --dry-run
doudian-open-cli api GET --path '/product/list' --data '{"page":1}'
```

- 省略 METHOD 时为 **POST**。
- path 必须通过 `--path` 提供，不接受位置参数；旧的 `api /path` 与 `api POST /path` 语法不兼容。
- METHOD 只允许 **GET**、**POST**（大小写不敏感，内部规范成大写）。PUT/PATCH/DELETE 直接校验失败。
- path 必须以 `/` 开头；若用户粘贴了完整 URL，剥掉 host。
- `--data` 走 `jsoninput`（inline / `@file` / `@-`）；必须支持 `--dry-run`。
- 默认使用登录态。**禁止** `api invoke`、`--method`、`--appkey`、`+<domain>`。身份只来自 `init` 写入的凭据；换应用必须先 `logout` 再 `init`。
- path → 网关 method 的映射（如 `/product/detail` → `product.detail`）只发生在 `open/invoke`，命令面不暴露 method 名。

短资源命令（`product detail --product-id`）留给以后的元数据层。

## 5. 六条地基与仓库改动范围

隔离完成时：`internal/open` 几乎只有 Skill 占位；`internal/core` 有输出打印、httpx、PPE、根命令、Skill 安装器。下文表格是当时的落点。当前仓库已具备 Factory、凭据、`init` / `auth` / `api` / `skills`；Skill 形态以 `docs/spec/skill-layout.md` 为准，不再按域拆 `product.md`。

### 5.1 Factory（必须对齐 Lark CLI）

参考实现：`larksuite/cli` 的 `internal/cmdutil/factory.go`、`factory_default.go`。这是对外 CLI 的硬约束，不是可选项。点将台现有 `Dependencies` 一次性 new 全套依赖，要收成「用 Factory」，不能再作为对外样板。

**要对齐的：**

| Lark | 我们 |
|---|---|
| `Factory` 持有 `IOStreams` + 惰性 `func() (T, error)` | `internal/core/factory` 同样结构 |
| `sync.OnceValues` 首次使用才创建并缓存 | `--version` / `skills` 不得触发 HTTP、不得读开放凭据 |
| 顺序：HTTP（无凭据）→ Credential → Config 由凭据派生 → API Client | 同样四段；没有飞书 SDK，最后一段是开放网关 Client |
| 单测替换 Factory 字段，不打真网关 | 开放命令单测必须能注入 fake HTTP / fake creds / 假 stdout |
| 命令只拿 `*Factory` | `internal/open/cli` 的 Cobra `RunE` 禁止 `httpx.NewClient()`、禁止直接 `os.Open` 凭据文件 |

**不要照搬的：**

- Keychain / 飞书 `--as user|bot` / Lark SDK Client（第一期仍文件凭据，身份是商家登录态）
- 允许 redirect 再剥跨 host 头：我们 **继续禁止自动 redirect**（比 Lark 更严），Factory 的 HTTP 仍走 `internal/core/httpx`

**装配：**

| 动作 | 路径 |
|---|---|
| 新增 | `internal/core/factory/` |
| 新增 | `internal/open/cli/`（只调 Factory） |
| 改 | `cmd/doudian-open-cli/main.go`：`factory.NewDefault` 后挂开放命令 |
| 改 | `cmd/doudian-open-cli-internal/main.go`：同一 Factory 上加挂开放命令 + djt |
| 适配 | `internal/djt/cli` 的 `Dependencies` 改为从 Factory 取 HTTP/IO/输出，删除 `newProductionDependencies` 里直接 `httpx.NewClient()` |

验收：对外 `version` 的测试断言 Factory 的 HTTP/凭据函数未被调用；`api` dry-run 单测只替换 `HttpClient`，无真实网络。

### 5.2 stdout 信封 + 可恢复错误

| 动作 | 路径 |
|---|---|
| 改/扩 | `internal/core/output/`：成功信封（data、meta.log_id、dry_run、identity 摘要）；失败不写业务 stdout |
| 新增 | `internal/core/errs/`：`type` / `code` / `message` / `hint` / `log_id`（auth、permission、validation、rate_limit、network、api） |
| 适配 | `internal/djt/` 的错误打印改为走 core 信封或薄适配，不再各自 `fmt` 一套；**点将台业务字段不变** |
| 测 | `internal/core/output/*_test.go`、`internal/core/errs/*_test.go`；泄漏测试继续禁止 token |

### 5.3 `api` 调用带 `--dry-run`

| 动作 | 路径 |
|---|---|
| 新增 | `internal/open/invoke/`：组请求、签名（协议补齐后）、真正发送、dry-run 只输出预览 |
| 新增 | `internal/core` 可抽公共 dry-run flag 绑定（可选）；点将台已有 dry-run 的命令不必推翻 |
| 文档 | `skills/open_cli_skill/`、`npm/open/README.md` |

dry-run 成功时仍是标准信封，`dry_run=true`，`data` 含将发出的 method 或 path、身份摘要、body 摘要；无远端副作用。

### 5.4 登录一次，调用带身份

| 动作 | 路径 |
|---|---|
| 新增 | `internal/core/credstore/`：0600 JSON、拒绝未知字段；schema 由调用方提供（搬家规格里有、代码里还没有） |
| 新增 | `internal/open/auth/`：商家 login/logout/status/reset-sk；写 `{UserConfigDir}/doudian-open-cli/open/` |
| 适配 | `internal/djt/auth/store.go` 改为基于 `credstore`（路径仍是 `.../djt/`） |
| 不改 | 两套凭据文件继续分离；商家 schema 不得复用员工 Device Flow 结构 |

### 5.5 Skill：catalog / read，业务另放

对外不把 Skill 安装到本机。Agent 先 `doudian-open-cli skills` 看目录（`name<TAB>description`），再 `skills open_cli_skill` 或 `skills <业务名>` 拉全文。业务步骤不写进 `skills/open_cli_skill/SKILL.md`，放进 `skills/biz/<业务>/`。约束与校验见 `docs/spec/skill-layout.md`。

| 动作 | 路径 |
|---|---|
| 改 | `skills/open_cli_skill/SKILL.md`：auth + 原始 API 调用范式、错误恢复、禁止事项、`skills` 用法 |
| 新增 | `skills/biz/<业务>/SKILL.md`：该业务的 path、参数组合和顺序 |
| 同步 | `internal/open/skill/assets/<name>/` embed、`scripts/sync-skill.mjs`（自动发现，不必改白名单） |
| 改 | `npm/open/README.md`：真实用法；**禁止出现 djt** |

### 5.6 预留 `+`，第一期不用

无独立代码。只约束 `internal/open/cli` 的 Use 字符串和 Skill 示例。以后 shortcut 再占用 `+<domain>`。

### 5.7 可能顺手但非第一期必须

- `doctor`、`schema`：可在 `internal/open/cli` 留空命令或最小实现（只描述 `api` flags）。
- `internal/core/httpx/`：补响应上限；签名与业务 Header 留在 `open/invoke`。
- 不搬 Lark 的 jq / table / csv / 自更新 notice。json + text 足够。

### 5.8 开闭原则、可 mock、门禁（Lark 其余必须抄）

Factory 只是袋子。下面这些让「加第二层/第三层不用拆地基」，并且单测能当门禁。

**开闭：加能力时改扩展点，不改命令内部。**

| 扩展点 | 对齐 Lark | 我们落点 |
|---|---|---|
| 命令树装配 | `cmd.Build(opts...)` 纯函数，磁盘/网络不进 Build | `internal/core/cli`：`Build(factory, Register...)`；新命令 = 新 package 的 `Register(root, f)`，不改 `main` 里的业务 |
| HTTP 中间件 | `RoundTripper` 包装链（retry / 安全头） | `httpx` 允许外包一层（PPE、日志）；**新增包装不改 invoke** |
| 调网关只走一处 | shortcut/service 都经 APIClient | 只有 `internal/open/invoke` 发开放请求；以后 service/shortcut **调用 invoke，禁止自己打 HTTP** |
| 凭据端口 | `CredentialProvider` 可替换 | `credstore` + `open/auth` 接口；文件实现可被测试假实现替换 |
| 命令测试钩子 | `NewCmdApi(f, runF)` 可注入假 Run | 每个开放 Cobra 构造函数允许 `runF`，UT 不启动进程 |

**可 mock / UT：禁止测真实网关当默认。**

对齐 `cmdutil.TestFactory` + `internal/httpmock.Registry`：

- `internal/core/factory` 提供 `TestFactory(t)`：返回 factory、stdout/stderr buffer、HTTP stub registry
- stub 必须 `Verify`：多打、少打、打错 URL 都 fail
- 命令代码不得使用 `os.Stdout` / `os.Getenv` / `http.DefaultClient`，一律 Factory
- `httptest` 或 RoundTripper stub 二选一，推荐 Registry（Lark 同款），方便断言 Header（PPE、鉴权）且无端口
- 现有泄漏门禁保留：`go list -deps`、二进制字符串、npm allowlist；再加契约单测：信封字段、失败 stdout 为空、dry-run 零 HTTP

**退出码（开放命令，参考 Lark，细类靠 envelope.type）：**

| 码 | 含义 |
|---|---|
| 0 | 成功 |
| 1 | 远端 API / 通用失败 |
| 2 | 参数校验 |
| 3 | 未登录 / token 无效 |
| 4 | 网络 |
| 5 | 内部错误 |

点将台适配期间可仍用退出码 1，但打印应尽快走同一信封，避免 core 两套哲学。

**以后长层时不用改的：** Factory、信封、httpmock、invoke 端口、Build 注册表。第二层只是再 `Register` 一棵元数据命令；第三层只是 shortcut 调 invoke。

## 6. 依赖方向

```text
cmd/doudian-open-cli              →  core + open
cmd/doudian-open-cli-internal     →  core + open + djt
open                              →  core
djt                               →  core（适配新信封 / factory / credstore）
core                              →  标准库与 cobra
```

禁止：`open → djt`、`core → open`、`core → djt`。

对外二进制泄漏门禁不变（`go list -deps`、字符串黑名单、npm allowlist）。改 core 必须跑这组门禁，即使改动是为了 djt 适配。

## 7. 输出契约（对外）

成功 json（字段名可在实现前微调，语义锁定）：

```json
{
  "ok": true,
  "dry_run": false,
  "identity": {"app_key": "***", "shop_id": "..."},
  "data": {},
  "meta": {"log_id": "...", "duration_ms": 0}
}
```

失败：stdout 为空；stderr 一条结构化问题（text 或 json 随 `--output`）；退出码按第 5.8 节（校验=2，认证=3，网络=4，API=1）。至少含 `type`、`message`、`hint`，有则含 `log_id`。任意 HTTP 状态 / 非 JSON / 超时的具体文案以 [输出契约](spec/cli-output.md) 为准。

`identity` 中的密钥必须脱敏。点将台现有 `{code,message,data}` 通过 djt 适配映射到同一套打印，或暂时仅开放命令用新信封、djt 在适配完成前保持旧打印——**优先前者**，避免 core 里两套输出哲学长期并存。

## 8. 与 Lark 三层的关系

| Lark | 对外第一期 | 以后 |
|---|---|---|
| `api GET --path '/path'` | `api [GET|POST] --path '/path'`（默认 POST） | 保持为兜底层 |
| `service` 元数据命令 | 不做 | 开放文档/元数据就绪后再做 |
| `+` shortcut | 语法预留，不实现 | 场景型 Skill + 多接口编排 |

## 9. 开平契约

授权与调用的 CLI 面见 `docs/spec/open-cli-auth-invoke.md`。服务端 Device Flow / fake token 见 `open_auth/docs/spec/2026-09-21-cli-pending-two-schemes.md`。此处只保留实现已对齐的摘要。

### 9.1 身份：`init`

- **通用型** `--kind generic`：录入 `app_key` / `app_secret` / `access_token`（过期时间可选）。
- **授权型** `--kind authorized`：第一方 Device Flow。start body 带 `mode=local|cloud`。返回 `user_code`（进授权 URL）与 `device_code`（只留本机：本地为钥匙串密文，云电脑才是明文 `login-session.json`）；token 轮询标准错误码。成功写入 fake `access_token`、`app_key`、`expires_at`（来自服务端 `expires_time`）；**不落 sk**。生产 URL 只出现在 `internal/open/config/endpoints.go`。服务端 start 零落库、确认后才写 Redis/DB；CLI 不感知存储。存储与沙箱头见 [钥匙串与云电脑](spec/open-cli-keychain-sandbox.md)。
  Agent：`--no-wait` 展示 `verification_url`，再 `--complete` 兑票。不要把 `device_code` 打进对话。有效 pending 期间重复 `--no-wait` 必须复用。一步式阻塞 poll 仅给人工终端。

禁止 refresh token。已有凭据须先 `auth logout`。未初始化或过期：`type=auth`，hint 指向 `init`。

### 9.2 网关调用

标准流程见 [API 调用指南](https://op.jinritemai.com/docs/guide-docs/148/814)。`/product/detail` ↔ `method=product.detail`。

- `GET`/`POST` `https://openapi-fxg.jinritemai.com/{path}`
- query：`method`、`app_key`、`access_token`、`timestamp`、`v=2`、`sign`、`sign_method=hmac-sha256`（两种身份都带；授权型 HMAC 密钥为 fake token）
- body：规范化 JSON
- 所有对外 HTTP（含 Device Flow start/token）都带 `X-Cli-Source: doudian-open-cli`、`X-Doudian-Open-Cli-Version`（当前 CLI 版本）
- 业务 `api` 另带：`X-Doudian-Open-Cli-From`（默认 `cli`）、`X-Doudian-Open-Cli-Auth-Kind: authorized|generic`
- **仅授权型**另带 `X-Doudian-Open-Cli-Access-Token`；通用型不带
- `--dry-run` 打印方法、URL（无 query）、query 键、body；隐藏上述 CLI 头（含 Access-Token）；脱敏 token
- HTTP 任意状态、非 JSON、超时如何进 stderr：见 [输出契约](spec/cli-output.md) 第 5 节

网关 skip-sign 与豆包换票不在本仓库。

## 10. 验收（本规格落地后）

- 对外二进制有 `init`、`auth` 与原始 API 调用，无 `djt`，无 `+` 快捷命令。
- 未初始化调用 API：失败 type=auth，hint 指向 `init`。
- 初始化后无需每条命令传密钥；dry-run 不访问网关，且不展示 CLI 审计头。
- 失败 stdout 为空；输出无 token / secret。
- `skills/open_cli_skill/SKILL.md` 可指导 Agent 完成「init → dry-run → 调用」。
- `doudian-open-cli skills` 列出内嵌 Skill；`skills <name>` 打印对应全文，不写 `~/.agents`。
- 对内二进制仍能跑原 `djt` 命令；若 core 输出/凭据已切换，djt 测试全绿。

## 11. 文档

- 本文：`docs/open_cli_open_onepage.md`（对外建设的权威规格）
- 授权与调用设计：`docs/spec/open-cli-auth-invoke.md`
- 服务端最终方案：`open_auth/docs/spec/2026-09-21-cli-pending-two-schemes.md`
- 隔离：`docs/spec/dual-flavor-cli.md`
- Skill 目录与 `skills` 命令：`docs/spec/skill-layout.md`
- **仓库目录树**：根 `README.md`。落地本文时若增删 Go 包 / 目录，必须同步改 README，不要在 spec 里再维护一棵树。
- 点将台业务：`docs/spec/agent-interface.md` 等，不因本文改业务语义
