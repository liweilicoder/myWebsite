# 文档目录

开发与设计文档都在本目录。根 [README](../README.md) 只索引到这里。**行为以 `spec/` 为准**；实现过程以代码与测试为准，不在仓库里单独保留 plan 文档。

改命令、接口或对外行为时，更新本目录里对应的那一份，并改本页链接。不改变行为的改动不用改文档。

## Spec 命名约定

`docs/spec/` 下文件名使用 **kebab-case**，按主题命名，**不要** `YYYY-MM-DD-` 日期前缀：

| 前缀 / 模式 | 含义 | 示例 |
|---|---|---|
| `open-cli-*` | 对外 CLI（授权、钥匙串等） | `open-cli-auth-invoke.md` |
| `djt-*` | 点将台命令与 BFF 契约 | `djt-cli-spi-agent.md` |
| `skill-*` / `npm-*` | Skill 与 npm 分发 | `skill-layout.md` |
| 其它 | 横切能力 | `dual-flavor-cli.md`、`cli-output.md` |

新增 spec：先在本表选合适前缀，再在本页下方文档表登记一行。硬约束全文亦见根目录 [`AGENTS.md`](../AGENTS.md) 的 **Spec Coding**。

## 对外 CLI

| 文档 | 内容 |
|---|---|
| [对外全景](open_cli_open_onepage.md) | 授权、`api`、Skill 目录的总览 |
| [双产物隔离](spec/dual-flavor-cli.md) | 对外包与对内包怎么拆、怎么打包 |
| [授权与调用](spec/open-cli-auth-invoke.md) | 授权型 Device Flow 与通用型签名 |
| [钥匙串与云电脑](spec/open-cli-keychain-sandbox.md) | 本地主密钥、密文会话、`mode` 与沙箱头 |
| [输出契约](spec/cli-output.md) | 成功信封、失败错误、`type` 与退出码、任意 HTTP 状态如何映射到 stderr |
| [Skill 布局](spec/skill-layout.md) | `skills/open` 与 `skills/biz` 的目录和约束 |
| [Skill 分发](spec/npm-skill-distribution.md) | npm 包如何带上 Skill |
| [发公网 npmjs](spec/npmjs-open-publish.md) | 对外包 `@bytedance/doudian-open-cli` 的可执行发布 SOP（`npm run release:npmjs`） |

## 点将台

| 文档 | 内容 |
|---|---|
| [点将台全景](open_cli_djt_onepage.md) | `djt` 命令与调用链总览 |
| [Agent Interface](spec/agent-interface.md) | OpenAPI 配置命令与 HTTP 契约 |
| [SPI](spec/djt-cli-spi-agent.md) | SPI 场景与接口命令 |
| [固定地址](spec/djt-fixed-baseurl-and-psm.md) | 只打 `djt.bytedance.net`，不维护 PSM 列表 |
| [演示路径](spec/djt-cli-demo.md) | 从登录到配置的一条演示 |

实操步骤在 `skills/djt/`，不在本目录重复。
