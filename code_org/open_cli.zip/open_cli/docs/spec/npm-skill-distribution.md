# open_cli 生产默认地址与 npm/Skill 分发设计

**状态：** 已实施  

## 目标

Agent 无需源码和 Go 环境，通过 npm 安装后即可运行 `doudian-open-cli` 并获得点将台 Skill。生产调用默认使用 `https://djt.bytedance.net`。

## 生产 Base URL

登录按 `--base-url > OPENCLI_DJT_BASE_URL > config.json > https://djt.bytedance.net` 解析，所有值先 `TrimSpace`。一旦选择非空 flag/env，校验失败立即报错且不读低优先级来源。仅 flag/env 均空时读取配置；文件不存在，或合法对象的 `base_url` 缺失、为 null/空白时，返回经现有校验器校验的默认地址。文件存在但不可读、JSON 非法、有尾随内容、未知字段或非空 URL 非法时必须报错。已登录业务请求仍固定使用 credential Base URL，显式 flag/env 只校验同源。

## npm 包

对外包根为 `npm/open/`（仓库名 `@bytedance/doudian-open-cli`，发 BNPM 时打包改名为 `@ecom-open-cli/doudian-open-cli`），对内包根为 `npm/internal/`（`@ecom-open-cli/opencli`）。仓库根 `package.json` 为 `private: true`，不能 `npm pack` / `npm publish`。内部验收 registry 为 `https://bnpm.byted.org`；公网为 `https://registry.npmjs.org`。Node.js >=18，无 npm 运行时依赖。对外 tarball 的 README / `package.json` 不得出现 BNPM；BNPM 发布由 `release-npm.mjs` 传入 `--registry`。公网发版用 `npm run release:npmjs`（`stage publish`），步骤见 `docs/spec/npmjs-open-publish.md`。

`bin/doudian-open-cli.js` 使用 `spawn` 启动包内绝对路径二进制，参数为 `process.argv.slice(2)`、`stdio: inherit`、不启 shell、不通过 PATH 查找。支持映射 darwin x64/arm64、linux x64/arm64、win32 x64；其他平台明确失败。正常退出透传数值退出码；捕获并转发 SIGINT/SIGTERM，非 Windows 另转发 SIGHUP，子进程因信号退出时移除监听并向自身发送同一信号。spawn 失败非零退出，结束后清理监听。

发布由 `scripts/release-npm.mjs --flavor=open|internal` 编排：Skill 同步校验、Go/Node 测试、五平台 `go build -trimpath`。darwin 构建设 `CGO_ENABLED=1`，Linux 和 Windows 为 `CGO_ENABLED=0`。macOS 钥匙串不靠这次 CGO：访问走 `go-keyring` v0.2.8 调用的 `/usr/bin/security`。生成二进制不提交 Git。Node 测试覆盖平台映射、含空格/引号/Unicode 的 argv、stdio、正常/非零/signal 退出以及缺失二进制。

## Skill 分发

手工源按目录发现，不维护白名单：`skills/` 下每个带 `SKILL.md` 的目录都是 Skill；`skills/biz/` 只是抽屉，业务 Skill 在 `skills/biz/<业务>/`。目录 basename 是稳定 Bundle 键，frontmatter `name` 是展示名和首选查找名，CLI 也接受目录 basename 作为兼容名。对外 flavor 打包并 embed 除 `djt` 以外的全部；对内 flavor 再加 `djt`。目录、catalog/read 契约与业务禁词见 `docs/spec/skill-layout.md`。

Go embed：开放与业务都在 `internal/open/skill/assets/<name>/`，点将台在 `internal/djt/skill/assets/djt/`，均提交 Git。`node scripts/sync-skill.mjs` 按发现结果同步全部；`--check` 还拒绝 embed 里多出来的目录。`go generate`、发布均校验源与镜像字节一致。

对外 CLI 用 `doudian-open-cli skills` 列出内嵌 Skill，`doudian-open-cli skills <name>` 打印对应 `SKILL.md` 原文，不写入本机 Agent 目录，也没有 `self skill`。`open` 始终在列表第一项；业务行使用 frontmatter 展示名，旧目录名仍可作为查询别名。对内仅 `doudian-open-cli djt self skill install|status|update` 把点将台 Skill 安装到 Agent 目录（JSON 仍为单 skill 对象）。canonical 目标固定为 `~/.agents/skills/djt/`，允许创建。Claude 根取绝对的非空 `CLAUDE_CONFIG_DIR`，否则 `~/.claude`；Codex 同理取 `CODEX_HOME` 或 `~/.codex`。仅 Agent 根已存在且为目录时创建其 `skills/<name>`；相对或非法 env 路径作为目标错误，不回退；重复目标去重。

`install` 确保所有可发现目标为内置内容且文件 mode 为 `0644`：缺失 `installed`、内容与 mode 均相同 `skipped`、内容不同或 mode 非 `0644` 均为 `updated`。`update` 只更新已存在 Skill：内容与 mode 均相同 `skipped`、内容不同或 mode 非 `0644` 均为 `updated`，不创建缺失项。`status` 只读，内容相同且 mode 为 `0644` 时为 `current`，内容不同或 mode 非 `0644` 时为 `outdated`，其余状态为 `missing|error`。目标独立执行；任一错误使命令非零，同时保留其他目标结果。稳定 JSON 为：

```json
{"skill":"djt","targets":[{"agent":"universal","path":"/home/user/.agents/skills/djt/SKILL.md","status":"installed"}]}
```

JSON 中 `path` 仅在存在可验证的清理后绝对目标时输出；例如相对的 `CLAUDE_CONFIG_DIR`/`CODEX_HOME` 无法确定安全目标，错误项省略 `path`，不得输出空字符串。

路径必须是清理后的绝对路径。目录遍历逐级使用 `openat` + `O_NOFOLLOW` 获得受信父目录句柄；后续文件读取、临时文件创建、清理和 `renameat` 均相对该句柄执行，因此即使路径中的父目录并发被替换或改为 symlink，也不会写出已固定的受信目录。写入拒绝符号链接和异常文件类型；目录 0755、文件 0644；同目录不可预测临时文件经 Write/Chmod/Sync/Close 后 Rename，失败清理临时文件，不先删除旧文件。

npm `postinstall` 仅对内包存在，用 Node 绝对路径启动本包 `bin/doudian-open-cli.js djt self skill install --output json`，不用 shell/PATH，30 秒超时，stdout 静默；失败、超时、未知平台仅向 stderr 输出一条 `[doudian-open-cli] postinstall:` 提示，hook 自身始终 0。使用 `--ignore-scripts` 时用户显式运行 `doudian-open-cli djt self skill install`。测试使用临时 HOME，绝不写真实用户目录。对外包没有 postinstall。

## 安全和文档

不改变 Device Flow、认证 Header、credential origin 和权限策略。点将台 Skill 命令不接受任意目标路径，不接触凭据。运行时支持 Windows AMD64；点将台 Skill 安装仍仅 macOS/Linux。不远端下载二进制、不实现多 Skill 锁文件。同步更新 README、AGENTS.md 和 Skill：默认生产地址、npm 安装、`djt self skill` 及 `--output json`。

## 打包验收

从干净状态执行 `npm pack --json`，校验 tarball 文件清单与批准 allowlist 完全一致，包含 package.json、launcher、五个可执行二进制、Skill、英文 `README.md`、`README.zh-CN.md`、`CHANGELOG.md`、`LICENSE`（对内另含 postinstall），不含源码、测试、凭据、embed 镜像或临时文件；校验可执行 mode 和 Skill 字节。将 tgz 安装到隔离 prefix/HOME：先 `--ignore-scripts` 验证 host 二进制；对内再验证 `djt self skill` 与 postinstall；所有执行只使用 tgz 内容。
