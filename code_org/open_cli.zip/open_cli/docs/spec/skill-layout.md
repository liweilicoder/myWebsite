# Skill 目录：CLI 通用、业务分包与 `skills` 命令

**状态：** 已实施（目录、自动发现、catalog/read、业务校验、AIGC 后台等待任务摘要与紧凑参数模板）；Registry 拉取未实施
**仓库：** `open_cli`  
**长期方案：** [doudian-open-cli 统一 Skill 中心建设方案](https://bytedance.larkoffice.com/docx/NUCqdrE14o27eixQEgeckN6rnSG)  
**打包与点将台安装：** `docs/spec/npm-skill-distribution.md`

## 1. 一句话

CLI 和开放调用的用法只留在 `skills/open_cli_skill/`。业务 Skill 放进 `skills/biz/<业务>/`，每个业务一个子目录。`biz` 只是仓库里的抽屉，**不进** `doudian-open-cli skills` 的名称，也不出现在 Agent 查找键里。

对外 Agent **不把 Skill 写到本机目录**。发现与阅读都走同一条命令：

```text
doudian-open-cli skills              # 目录：open 在前，随后业务按名字排序；每行 name<TAB>description
doudian-open-cli skills open_cli_skill # 打印 skills/open_cli_skill/SKILL.md 原文
doudian-open-cli skills <业务名>      # 打印 skills/biz/<业务>/SKILL.md 原文
```

`skills` 的 stdout 是纯文本，不受 `--output json` 影响，失败时 stdout 为空、退出码 2。对内专用的点将台 Skill 不出现在这个列表里；点将台仍用 `djt self skill` 写入 `~/.agents/skills/djt/`。

长期仍走飞书文档里的中心化 Registry。本文把目录、发现方式和校验定下来，使手交目录和以后按 lock 拉取是同一种制品。

## 2. 现在实际发出去的是什么

不维护发布白名单。`scripts/npm-flavors.mjs` 扫描 `skills/`：每个带 `SKILL.md` 的目录都是 Skill；`skills/biz/` 本身不是 Skill，真正的业务 Skill 在它的下一层。对外包带上除 `djt` 以外的全部；对内包再加 `djt`。`skills/biz/README.md` 不是 Skill，不会打进包。

| | 手工源 | npm 路径 | 二进制 embed | Agent 怎么读 |
|---|---|---|---|---|
| 开放 CLI | `skills/open_cli_skill/` | `skills/open_cli_skill/` | `internal/open/skill/assets/open_cli_skill/` | `doudian-open-cli skills open_cli_skill` |
| 业务 | `skills/biz/<业务>/` | `skills/biz/<业务>/` | `internal/open/skill/assets/<业务>/` | `doudian-open-cli skills <业务>` |
| 点将台 | `skills/djt/` | 仅对内包 `skills/djt/` | `internal/djt/skill/assets/djt/` | `djt self skill` 安装到本机 |

embed 与手工源字节一致。新增 `skills/biz/<业务>/` 后运行 `node scripts/sync-skill.mjs`，提交生成的 embed。不必改 `npm-flavors.mjs`、`package.json` 或 `skills` 命令入口。

当前仓库内置 `doudian_aigc` 业务 Skill，catalog 包含 `open_cli_skill`、`content` 和 `抖店AI视频创作`，后者兼容目录名查找。后续业务目录仍按相同规则自动发现，不维护白名单。

`doudian_aigc` 包含创建成片、查询任务和查询积分三个场景，围绕查询成片权限、按名称搜索店铺商品、查询商家积分、查询当前商品成片配置选项、预校验成片任务参数、创建成片、查询成片任务列表七项业务接口组织流程。七项接口的 Path 统一使用 `/contentAIGC/` 前缀，文档示例与任务轮询脚本保持一致。成片参数限定在当前商品可用的枚举和定义内，创建前预校验并确认本次方案及积分消耗。 对外契约以点将台配置为准：权限接口为 `getAIVideoPermissionOpen`，预校验接口为 `previewAIVideoTaskOpen`；请求与响应使用 snake_case 业务字段，任务列表使用 `page` / `page_size` 分页并以 `has_more` 判断下一页，轮询使用 `task_ids` 请求和 `task_id` 匹配结果。

`doudian_aigc` 的七项接口分别提供展示预设，详细规则位于 `references/display_presets.md`。所有业务展示统一使用对话正文 Markdown，以标题、分组列表和表格组织内容；不生成 HTML、播放器或预览附件。参数选择、创建确认与翻页优先使用宿主原生交互提问工具，工具不可用时使用文字对话；选项依据当前上下文或接口结果，原有创建确认门禁不变。模拟演示同样逐阶段遵守选择和创建确认门禁，不将未给出的模拟配置、费用或链接伪装为接口结果。链接仅使用实际返回的有效地址，单任务成功结果统一使用“任务 ID / 视频标题 / 操作”三列横向表格，仅一条数据行，不显示状态列，播放和发布链接在操作单元格内并排。展示不改变 API 契约或创建确认门禁。

成片创建成功并取得 `task_id` 后，默认由宿主子 Agent 执行现有轮询脚本，主 Agent 持续等待子 Agent 的终态结果并在同一对话交付；不能把首次查询的初始化或生成中状态当成完成，也不能仅把后台任务句柄交给用户。轮询脚本必须沿用创建和首次查询时实际生效的 CLI 全局参数或等价环境变量，允许在任务 ID 后用 `--` 透传 CLI 全局参数，不在业务 Skill 中固化联调环境。子 Agent 不可用时由主 Agent 运行同一脚本并等待。用户明确只需提交、停止等待，或脚本返回终态、失败、超时时结束等待；不根据状态猜测生成耗时，不自动重复创建。

## 3. 目录

```text
skills/
├── open/                 CLI + 开放调用通用。一个 Skill，name=open
├── djt/                  仅对内。点将台配置，不进对外包，不放进 biz
└── biz/                  业务抽屉。本身不是 Skill，禁止放 SKILL.md
    ├── README.md         给业务方看的写法说明。不是 Skill
    ├── content/          商家短视频投稿与查询
    ├── doudian_aigc/     商家 AI 成片、任务与积分查询
    └── <biz>/            一个业务一个 Skill，目录名是稳定 Bundle 键
        ├── SKILL.md
        └── …             该业务自己的步骤、示例、离线脚本
```

通用 CLI Skill 使用 `skills/open_cli_skill`，不拆成两份。登录、两段式授权、组包、dry-run、输出契约只写在这里。业务 Skill 假设读者已经用 `skills open_cli_skill` 读过通用规则，不复制这套步骤。

## 4. 三类 Skill 各写什么

| | `skills/open_cli_skill` | `skills/djt` | `skills/biz/<biz>` |
|---|---|---|---|
| 读者 | 对外商家 / 豆包 Agent | 内部配置同学 | 该业务的 Agent |
| 写什么 | 命令怎么用、凭据怎么放、什么不许打印 | 点将台登录与 API/SPI 配置 SOP | 这个业务要完成什么、调哪些 `api` path、确认点和失败怎么恢复 |
| 谁维护 | CLI | 点将台 | 业务方；把目录交到本仓库即可随 CLI 发出 |
| 进哪套包 | 对外 + 对内 | 仅对内 | 对外 + 对内（自动发现，不必点名） |
| 版本 | 跟 CLI 发版 | 跟对内包发版 | 现在随 CLI 包走；以后先发 Registry，再被 CLI 快照选中 |

业务 Skill 里调用开放接口只写 `doudian-open-cli api …`。不写网关签名算法，不写 fake token 怎么解密，不教用户改 URL 里的 `user_code`。

## 5. 查找名与仓库路径分开

仓库用 `biz/` 把业务收在一起。`doudian-open-cli skills` 优先使用 frontmatter 展示名查找，同时保留**铺平后的目录 basename**作为兼容名称，不使用 `biz/<业务>` 路径：

```text
open
抖店AI视频创作
```

不会出现 `biz` 或 `biz/content-aigc`。`biz` 不是 namespace，也不进 frontmatter `name`。

每个业务目录是一个 Bundle，目录名是稳定 Bundle 键并等于 embed 子目录名；frontmatter `name` 是展示名称及首选查找名。CLI 同时接受目录名作为兼容别名。对外 CLI 不把这些 Bundle 安装到 `~/.agents`。对内仅 `djt self skill` 安装点将台 Bundle。

## 6. `skills` 命令依赖的契约

Agent 推荐顺序：先无参数拿目录，按 **description** 判断要不要读某一份，再 `skills <name>` 拉全文。不要一次把所有 `SKILL.md` 拼出来。

因此业务目录必须同时满足下面几条，否则 catalog 对不上、`skills <业务名>` 会以「未知 Skill」失败（退出码 2）：

| 依赖点 | 规则 | 若违反 |
|---|---|---|
| 查找键 | frontmatter `name` 是展示名称和首选 `skills` 参数；目录名与 embed 子目录名一致，并作为兼容查找名。展示名称非空、单行且全局唯一 | catalog 名称冲突或无法通过新旧名称读取 |
| 目录行 | `description` 解析后非空，且不含制表符、换行（folded YAML 会被拼成一行） | `skills` 输出的 `name<TAB>description` 错列，Agent 无法匹配 |
| 全文 | 业务目录根上必须有 `SKILL.md`；禁止再嵌套一份 `SKILL.md` | `skills <name>` 没有可打印的正文，或误把子目录当成另一个 Skill |
| 同步 | 手工源与 `internal/open/skill/assets/<目录名>/` 字节一致 | 二进制 catalog 缺这一条；提示先跑 `sync-skill` |
| 隔离 | 业务正文不得教登录 / dry-run / 点将台 / PPE | Agent 在业务 Skill 里走错命令面 |

`open_cli_skill` 同样要求非空、无制表符的 `description`，以及 frontmatter `name: open_cli_skill`。

## 7. 通用约束

业务子目录和 `skills/open_cli_skill` 都要满足对外文本禁令。`skills/djt` 继续按对内 Skill 的现有规则，不套用对外禁词。

### 7.1 身份

- 业务目录根上只有 `SKILL.md`。步骤放 `references/<name>.md`，脚本放 `scripts/<name>.sh|py`，不再嵌套目录。
- 目录名是稳定 Bundle 键：`^[a-z][a-z0-9_-]{0,40}$`。以小写字母开头，后续允许小写字母、数字、下划线和连字符，不用大写或点号。
- `skills/biz/SKILL.md` 禁止存在。`open`、`djt`、`biz` 不能当业务目录名。
- `SKILL.md` 必须以 frontmatter 开头，且含非空单行 `name` 与 `description`。业务 `name` 全局唯一，不得与保留名 `open`、`djt`、`biz` 冲突；可使用中文。
- 一个目录一个 Skill。章节用 `doudian-open-cli skills <目录名> --ref <name>` 或 `--script <name>` 读取，目录内相对链接保持有效。

### 7.2 对外文本

进对外包的 Skill（`open` 以及 `biz/<biz>`）正文、示例、脚本注释不得出现：

- `doudian-open-cli djt`、`djt.bytedance.net`
- `--use-ppe`、`--ppe-env`，以及 PPE 联调教程
- 真实或示例形态的 token、app_secret、Cookie、`device_code`
- 内部 PSM、仓库实现名（如 `open_admin`、`kitex`）

业务 Skill 可以写接口 path 和字段名。密钥与登录一律不写，留给 `skills open_cli_skill`；登录失败则停下。

### 7.3 体积与文件

- 预置进 npm 的单个业务 Skill 以文档和确定性离线脚本为主。大模型、二进制、低频资源不进 CLI 包，留给以后的按需下载。
- 不提交 `.DS_Store`、编辑器临时文件、凭据样例文件。
- 脚本只做本地转换或校验，不得在 Skill 文档里要求脚本去打网关或下载未固定版本。

### 7.4 和 CLI 的关系

- 业务方先读 `skills/biz/README.md`。业务 Skill 不写 `init`、`auth`、`--dry-run` 和签名。这些只在 `skills/open_cli_skill`。
- 字段与错误码指向已发布接口文档（随接口发布更新），Skill 只写 path、`--data` 怎么组、多个接口的顺序。
- 高风险调用（会改线上数据）必须在 Skill 里写明要用户确认。开放 `api` 今天没有单独的确认旗标，确认写在对话步骤里。

业务文件里一旦出现下列子串，仓库测试失败（完整列表与 `internal/open/skill/biz.go` 的 `bizForbiddenSubstrings` 一致）：

`init --kind`、`--no-wait`、`--complete`、`--device-code`、`verification_url`、`device_code`、`auth status`、`auth logout`、`--app-key`、`--app-secret`、`--access-token`、`--dry-run`、`sign_method`、`签名算法`、`doudian-open-cli djt`、`djt.bytedance.net`、`--use-ppe`、`--ppe-env`、`点将台`、`PPE`。

## 8. 校验

`go test ./internal/open/skill` 会跑：

- `TestBizSkillLayout`：`skills/biz` 根上只能有 `README.md`；每个业务子目录必须通过 `validateBizFiles`；内嵌 catalog 按展示名读取且 `SKILL.md` 与手工源字节一致。
- `TestValidateBizFiles`：用内存夹具覆盖缺文件、保留名、非法目录名、空显示名、空 description、description 含制表符、嵌套 `SKILL.md`、禁词。
- `TestDocumentsCatalogContract`：所有内嵌对外 Skill（含 `open`）的 catalog 名、frontmatter、description、展示名和目录别名 `Lookup` 一致；`open` 第一；不得出现 `djt`。

`skills/open_cli_skill` 另有 embed 字节对照，以及不得出现点将台 Origin / PPE 字样的测试。`node scripts/sync-skill.mjs --check` 校验手工源与 embed 一致，并拒绝 embed 里多出来的 Skill 目录。校验只读仓库，不访问网络。

失败即非零，报告路径和原因。规则对应第 6、7 节：

| 规则 | 条件 |
|---|---|
| `biz-root` | `skills/biz` 存在时，其直接子项只能是目录；根上没有 `SKILL.md`，只允许 `README.md` |
| `one-level` | 业务 Skill 的 `SKILL.md` 只出现在 `skills/biz/<biz>/SKILL.md` |
| `name` | 是非空单行显示名，全局唯一，且不等于 `open` / `djt` / `biz` |
| `frontmatter` | 包含有效 `name` 与非空且不含制表符/换行的 `description` |
| `open-flavor-text` | 对外 Skill 命中第 7.2 / 7.4 节禁词则失败 |
| `catalog` | 每个业务目录都能被 `Documents()` / `Lookup` 读到 |
| `embed-bytes` | 每个要发布的 Skill，手工源与对应 embed 字节一致 |

`skills/open_cli_skill` 继续跑现有 embed 对照和禁词测试。新的 `biz` 规则不要放进点将台 Skill 测试里。

## 9. 和长期 Registry 怎么接

飞书文档里已经确定、本文不改的部分：

- Skill 身份是稳定 `skill_id`；人读坐标是 `namespace/name@skill_version`。类目、接口只是弱引用，不进主键。
- CLI、Skill、API/SPI 分开发布。业务更新不强迫 CLI 发版。
- 两条出口：npm 预置快照保证冷启动；Skill API 负责在线搜索和更新。执行时用本地锁定版本，不静默切到 latest。
- CLI 构建只拉取 Registry 里已发布、签名有效、满足 CLI ABI 的精确版本，并写下 `embedded-skills.lock`（skill_id、版本、digest）。
- 本地优先级：用户 pin → 已安装 lock → npm 预置。只有 search / update 才访问线上。
- 预置包只收高频、官方、体积受控的 Skill。大文件走对象存储，不塞进业务 JSON，也不进 npm。

落到这个仓库时：

| 现在 | 以后 |
|---|---|
| 业务把 `skills/biz/<biz>/` 交到本仓库，自动随 CLI 包发出 | 同一目录形状从 Registry 制品检出到构建目录，不再手改 Git 里的业务正文 |
| 没有 `skill_id`，目录名作为稳定 Bundle 键 | `name` 作为 `skills <name>` 的展示及首选查找名，目录名保留兼容查询；`skill_id` 写在该 Skill 的 manifest 里 |
| `skills/open_cli_skill` 跟 CLI 源码一起发 | 继续留在本仓库。它是 CLI 制品，不是业务 Registry 里的一条 |
| `skills/djt` 只在对内包 | 保持。不进对外快照，也不进对外 Registry 渠道 |

第一期不做：Skill API、签名、CDN、Bundle（多 Skill 套件）、在线 `skill search|install`、从点将台生产 Skill。这些都在飞书文档的后续范围里。

## 10. 业务方怎么交一份 Skill

例如 AI 成片业务位于 `skills/biz/doudian_aigc/`，`SKILL.md` 的 `name: 抖店AI视频创作`，description 写清创建、任务与积分查询场景。通过第 6、7、8 节校验后，跑 `node scripts/sync-skill.mjs` 并提交 embed。Skill 里只描述该业务相关接口的调用步骤。授权和 `api` 通用规则仍由 `skills/open_cli_skill` 提供。

## 11. 明确不做

- 不把业务步骤写进 `skills/open_cli_skill/SKILL.md`
- 不把 `skills/djt` 放进 `skills/biz` 或对外包
- 不按接口一个 Skill 拆碎，除非业务方自己决定要多个子目录
- 不在本规格里实现 Registry、换票或网关
- 不把对外 / 业务 Skill 安装到 `~/.agents`
- 不改对内 `djt self skill install|status|update` 的目标根（`~/.agents/skills/djt/`）

## 12. AIGC 参数与展示验收（2026-10-09）

- 登录及成片权限校验通过后，缺少明确商品时使用展示预设中的固定一句话提示，不展示商品链接示例，仅提供用户已给出的名称和 ID 实值示例，允许商家任选一种输入。示例仅用于说明，不默认选用，不推定示例指向同一商品。字段格式由 Agent 内部校验，不在正常提问中展示“十进制正整数字符串”等技术术语；已有明确商品时复用，不重复询问。商家提供商品详情链接时自动解析 URL 查询参数 `id`，校验为十进制正整数字符串后原样作为 `product_id`，保留大整数精度，不要求再次填写或确认 ID。参数缺失、为空、非正整数或重复且值不一致时不猜测；仅链接无法确定 ID 时请商家补充商品 ID；仅有名称时先搜索店铺商品。此步只解析本地文本，不访问页面或新增接口调用。
- 仅当用户输入商品名称或名称片段、且没有明确商品 ID 时调用 `POST /contentAIGC/searchShopProductOpen`；此接口不是成片必经步骤。有效商品 ID、可提取 ID 的商品链接及上下文已明确选定的商品直接进入后续流程，即使同时附带名称也不搜索。名称搜索，以 `product_name` 传入商家实际名称或名称片段。读取 `data.products` 中的 `product_id`、`product_name`，最多四条且无分页；保留全部实际候选和返回顺序，使用原生 ask 单选，即使仅一条也等待商家确认，不自动选择。选定后复用真实 ID 和名称进入配置查询，不再索要 ID。空列表引导修改关键词或提供链接、ID；失败或响应异常如实报告，不视为空结果、不编造候选、不自动重试。接口配置已通过 DJT 查询核实（2891、版本 5、状态 110），尚未验证 PPE 或生产可调用性，不宣称上线。
- 查询配置前确认商品和目标；预校验与创建显式提交相同的 `params.target`，这是 Agent 流程约束，不改变 API 可选字段契约。
- 模型、分辨率、时长均由商家通过 ask 从本次配置选项中选择，不再提供默认或自定义分支。已明确且有效的选择复用，其余项均询问，三项齐全后才预校验并随创建提交；这是 Agent 流程约束，不改变 API 字段的可选性。范式仍可独立选择或省略。任一必选项缺少可用选项时暂停创建，不自行选首项或退回服务端默认值。
- 成片目标提问固定为“请选择本次短视频的成片目标：挂车成交 / 引流直播”，必须按宿主 ask 的实际 schema 在选项字段中传入“挂车成交”和“引流直播”两个可选项，分别映射 `target=0` 和 `target=1`；不得仅传提问文案、将选项只写入 display_message，或发起没有候选的自由输入问题。等待商家明确选择，不自动默认。调用前检查该问题的选项字段确实包含这两个候选，按工具实际 schema 设置单选；商品信息自由输入与成片目标单选分开提问，不复用自由输入问题。提问文案中的两个名称用于确保用户可读，不能代替工具选项字段。宿主不支持选项交互、ask 不可用或报错，或用户反馈未看到选项时，在正文提示“请选择成片目标：**挂车成交** / **引流直播**，回复名称即可”，等待文字选择，不重复发起同样的空选项问题。不假定工具调用成功就代表按钮已显示，也不声称已经检查无法观测的界面。已有明确目标时复用。成片目标在查询配置前选择，不单独输出展示内容；取得配置后，使用紧凑 Markdown 模板：基础参数用“参数 / 可选项”两列表格，模型、分辨率、时长各一行，候选用“ / ”分隔；范式独立用“范式 / 说明”两列表格，每个候选一行。保留全部候选、原顺序和真实说明，不将全部候选加粗。长单元格自然换行，不用 HTML。选择完成后展示一次“已选方案”引用块，仅展示已选值；明确不指定范式时注明自动选择。摘要不新增确认步骤或代替预校验后的费用确认；展示后仍通过 ask 选择。
- 范式有实际 `description` 时附简短说明，无说明则仅展示名称；保持本次 `paradigms` 顺序且不截断，不输出 JSON 数组、代码块或横向长行。ask 最多列前三个范式并加“自行输入”，合计不超过四项；少于三个时列全部范式。该截取仅用于展示，不代表推荐或预选。输入可选名称或 `paradigm_key`，只接受当前配置中的唯一匹配，歧义或无匹配时重新选择。宿主已内置自由输入入口时直接复用，不再重复添加“自行输入”按钮。
- 商品或目标变化后重新查询配置，仅复用仍有效的选择，重新预校验并确认方案与费用。
- 展示细节统一维护在展示预设中；参数、未通过权限项、积分、创建回执与任务结果均使用 Markdown。
- 轮询脚本兼容 macOS Bash 3.2；未传 CLI 全局参数时可正常查询，不因空数组与 `set -u` 报错。
- 权限检查项的 `permission_type` 为接口返回的字符串，不维护数字枚举或名称白名单；是否通过依据 `passed`，异常字段不得视为通过。全部通过时直接继续创建，不展示权限通过提示或通过项；仅展示 `passed=false` 的权限点、实际原因和获取权限的下一步。指引依据返回原因，不编造开通条件、入口或链接；原因未提供操作时，说明未返回具体获取方式，提示先获取或补齐相应权限，完成后重新校验。查询失败或结果无法判定时仅说明暂时无法确认权限，不冒充权限未通过。
- 宿主具备子 Agent 能力时，等待成片必须先委派再启动脚本；子 Agent 独占脚本及其后台输出等待，主 Agent 仅等待子 Agent 完成。仅确认无子 Agent 能力时允许主 Agent 执行；前台超时不构成降级理由。子 Agent 转后台后使用同一后台命令 ID 阻塞等待，不以句柄或中间状态交付。
- Skill 入口保留场景路由与共通门禁；委派职责、后台阻塞等待和结束条件分别在查询文档中集中描述，不再附重复委派模板。状态定义统一由查询文档维护，展示预设引用该定义并只描述排版；通用展示形式只规定一次，不保留 HTML 模板或渲染协议。
- 商家待确认内容先在对话正文使用 Markdown 展示，再通过 ask 确认或取消；ask 简短引用上方内容，不重复整份方案。创建确认正文包含商品 ID、目标、已选参数、本次消耗积分和当前余额；未指定范式时注明自动选择。工具不可用时在展示后通过文字等待明确答复，未确认不创建。
- 创建成功并取得 `task_id` 后，主 Agent 在委派或运行轮询脚本前，先在对话正文提示一次“任务生成中，预计等待时间 20–30 分钟。”，可与创建回执合并。此为固定等待提示，不依据查询状态计算剩余时间；轮询脚本每隔 30 秒查询一次，保留 30 分钟总等待上限。只提交任务或单次查询时不使用该等待提示，等待期间不重复发送。

- 委派工具确实成功、宿主结果确认子 Agent 已启动后，主 Agent 在正文补充一次任务摘要：已知真实商品名称与商品 ID、本次确认的成片目标、模型、分辨率、时长、本次实际指定的范式、创建返回的 `task_id`。仅复用本次已确认方案与实际返回，未知字段省略，不额外调用 API 补信息。随后说明“已启动后台进度查询，预计生成需要 20–30 分钟。你可以继续发送其他消息，完成或查询异常时我会通知你。”仅发出请求时不得宣称已启动；未指定范式不得猜测服务端选择。保留委派前简短等待提示、创建前确认、单脚本轮询、参数继承与原有阻塞等待机制；仅主 Agent 执行或只提交任务时不使用子 Agent 启动摘要。

- AIGC 的身份检查先于所有业务调用及信息收集。未登录、授权过期或认证错误时仅引导商家在线链接授权，不索要商品 ID、商品链接、成片目标或参数；已有信息保留，授权成功后再复用。不得索要 app key、secret、token 或让商家选择开发者凭据方式。授权链接获取失败时报告实际阻塞，不以收集业务信息或开发者凭据绕过。已有不兼容身份时不自动清除或覆盖。

- 成片成功交付只输出“任务 ID / 视频标题 / 操作”三列横向表格，仅一条数据行，不显示状态列；任务 ID 使用行内代码，标题加粗；播放、发布入口均加粗，置于同一个操作单元格，用“　·　”分隔。标题只取本任务明确返回或用户此前确认用于本视频的标题，不假定固定字段名、不推测、不额外请求；缺失时视频标题单元格显示“—”，保留三列表头。标题中的竖线和其他 Markdown 特殊字符按普通文本转义，换行转为空格。表格外不重复标题、成功提示或操作链接，不追加参数概览、积分和发布承诺。播放链接缺失时在操作单元格说明暂未取得播放地址，短视频发布入口使用 `short_video_publish_url`；广告素材发布入口仅在 `ad_material_publish_url` 非空且为有效 HTTP(S) 链接时展示，缺失、空串或仅空白时完全省略，不显示占位或权限提示。各发布链接独立判断，不自行拼接或推测。失败原因读取接口字段 `fail_reson`。主 Agent 整理子 Agent 的终态结果后仅交付一次。只使用真实 Markdown 链接，不主动创建 URL 卡片、附件或播放器；不承诺控制宿主自动链接预览。

- 成片参数首次展示时附提示：“如需自定义视频风格、模特等，可点击链接前往抖店生成 AI 视频。”其中“前往抖店生成 AI 视频”链接到 `https://fxg.jinritemai.com/ffa/content-tool/ai-generate-video?from=doubao`。此固定入口由用户指定，是接口返回链接规则的明确例外；每轮参数选择只展示一次，不改变当前配置与创建确认流程，不自动打开或创建任务。

- 成片任务明确返回生成失败（`status=9`），且本任务已确认的 `required_credits` 大于 0 时，在实际失败原因后补充“任务消耗积分已自动返还。”消耗为 0 或未知时不展示，不从余额变化或其他任务推算消耗。多任务列表逐任务判断，仅在满足条件的失败任务行展示。接口调用失败、查询超时、未查到任务、取消或未知状态不使用该文案；不推算返还积分数额，不自动重新创建。
