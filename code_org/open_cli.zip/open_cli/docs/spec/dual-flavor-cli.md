# doudian-open-cli 双产物隔离设计

**状态：** 第 1 步（隔离）已实施；第 3 步对外命令面已落地，见 `docs/open_cli_open_onepage.md` 与 `docs/spec/open-cli-auth-invoke.md`  
**仓库：** `open_cli`

## 1. 目标

同一仓库、同一命令名 `doudian-open-cli`，产出两套隔离安装包：

- **对外包**：商家 / Agent 调用开放平台 OpenAPI 的 SDK 式 CLI。第一期只提供授权与 `api`，随包分发开放 Skill。
- **对内包**：对外能力的超集，额外包含点将台配置命令与点将台 Skill。

对外二进制在编译期不得链接点将台代码、点将台 Skill、点将台 Origin。对内可以迭代更快；`internal/core` 与 `internal/open` 的每次改动按对外等级做测试和门禁。

## 2. 范围与实施顺序

本规格覆盖**双产物隔离、打包、文档分层与门禁**。仓库目录树只写在根 `README.md`。动手顺序固定为三步，不得跳步：

1. **隔离并迁移点将台**：按根 `README.md` 目录树与本文第 4 节依赖边界拆目录，把现有 `djt` 行为原样迁到对内入口；对外入口与 `internal/open`、`skills/open`、`npm/open` **只留空位**（可编译、可打包、不含点将台）。不实现商家授权和 `api`。
2. **详细设计对外流程**：`docs/spec/open_cli_open_spec.md`。未批准前不写开放域实现。
3. **实现对外能力**：按 `docs/spec/open_cli_open_spec.md` 实现。

第 1、2 步已完成；第 3 步对外命令面（`init` / `auth status|logout` / `api`）已落地，细节以 `open_cli_open_spec.md` 与 `open-cli-auth-invoke.md` 为准。下文第 1 步「不包含」只描述隔离里程碑当时的范围，不是当前仓库能力。

### 2.1 第 1 步包含

- 按域拆分目录与 Go 包，用 import 图保证对外二进制碰不到 `internal/djt`。
- 两个进程入口、两个 BNPM 包骨架、独立版本号。
- 对内 `djt` 子树行为与迁移前一致（员工授权、OpenAPI/SPI 配置、业务域、API 测试、`djt self skill`）。
- 点将台凭据迁到 `{UserConfigDir}/doudian-open-cli/djt/`（第 8 节）。
- PPE 收到根命令；对外 `--help` 隐藏，对内可见。
- 文档按第 15 节分层改写：根 README / AGENTS 覆盖两套产物；点将台用法不再假装是仓库唯一能力。
- 对外发布硬门禁（依赖扫描、二进制字符串、npm allowlist）。

### 2.2 第 1 步不包含

- 不实现、不假装已实现商家 `auth` / `api`（命令可以不注册，或 `--help` 不可见；禁止返回假成功）。
- 不实现商家授权页、开放网关、限流与计费。
- 不把包发到公网 npm。
- 不引入任意 `--header`。
- 当时不支持 Windows（现已支持 Windows AMD64 运行时；点将台 Skill 安装仍仅 macOS/Linux）。
- 不把 `internal/core` 抽成独立 Go module。
- 不在仓库根目录 `npm publish`。

第 7、10 节的开放命令面以当前对外规格为准；隔离文档不再把 `auth login` / `reset-sk` 当作已交付命令。

## 3. 产物与坐标

| | 对外 | 对内 |
|---|---|---|
| 进程入口 | `cmd/doudian-open-cli` | `cmd/doudian-open-cli-internal` |
| npm 包根 | `npm/open/` | `npm/internal/` |
| 包名 | `@bytedance/doudian-open-cli`（发 BNPM 时打包改名为 `@ecom-open-cli/doudian-open-cli`） | `@ecom-open-cli/opencli` |
| registry | BNPM：`release-npm.mjs --flavor=open`（打包改名）；公网：`npm run release:npmjs` 发 `registry.npmjs.org`。**tarball 内不写 `publishConfig.registry`** | `https://bnpm.byted.org` |
| 可执行名 | `doudian-open-cli` | `doudian-open-cli` |
| 二进制 | 只含 core + open | core + open + djt |
| Skill | `skills/open_cli_skill/` + `skills/biz/<业务>/` | 同左，另加 `skills/djt/` |
| 版本 | 独立 | 独立 |

仓库根 `package.json` 为 `private: true`，只编排脚本。必须在 **open_cli 仓库根**用发布脚本，不要在 `npm/<flavor>/` 下直接 `npm publish`。BNPM：`scripts/release-npm.mjs --flavor=open|internal`；公网 SOP：`docs/spec/npmjs-open-publish.md`。

## 4. 依赖与信任边界

单向依赖：

```text
cmd/doudian-open-cli            →  core + open
cmd/doudian-open-cli-internal   →  core + open + djt
open                            →  core
djt                             →  core
core                            →  标准库与 cobra 等基础设施
```

禁止：`open → djt`、`core → open`、`core → djt`、`djt → open`。对内超集只在对内 `main` 装配，点将台包不得调用开放域，开放域不得感知点将台。

保障等级：

- `internal/core`、`internal/open`、`skills/open`、`skills/biz`：对外等级。改动必须跑对外测试、泄漏扫描、对外包 allowlist。共享层不允许对内特例。
- `internal/djt`、`skills/djt`：对内等级。可以较快迭代，但合入仍须证明对外产物不含点将台。

## 5. 仓库目录

目录树**只维护在根 [`README.md`](../../README.md)**，本文不复制。增删改目录时改 README。

装配约束：

- `cmd/*` 只做装配。Cobra 实现分别在 `internal/core/cli`、`internal/open/cli`、`internal/djt/cli`。
- 对外二进制：`core` + `open`；PPE flag 可用但 `--help` 隐藏。
- 对内二进制：同一开放命令面，再挂 `djt` 子树；PPE 在帮助里可见。
- 构建产物不进 Git：`npm/<flavor>/bin/`、`npm/<flavor>/binaries/`、`npm/<flavor>/skills/`、`*.tgz`。

## 6. 共享层复用规则

可放进 `internal/core` 的：输出、结构化错误、JSON 输入、脱敏、通用 URL 校验、打开浏览器、PPE 白名单头、无协议的 HTTP 安全客户端、httpmock、Factory、凭据文件读写模式、可配置 Skill 安装器、根命令骨架。

不得放进 `internal/core` 的：

- 员工 Device Flow、点将台 Header、员工身份 schema、点将台 Origin。
- 商家授权协议、开放网关签名、`api` 的业务 DTO。
- 点将台 envelope、`AgentCurrent`、SPI/OpenAPI 配置状态机。
- Skill 内容与 `go:embed` 镜像（分属 `open/skill` 与 `djt/skill`）。
- 任意请求头注入。

`credstore` 只保证文件权限、单 JSON 文档、拒绝未知字段；开放凭据与点将台凭据使用不同路径和不同结构，互读必须失败。

## 7. 命令树

对外（对内超集中的开放面相同）：

```text
doudian-open-cli init [--kind authorized|generic]
doudian-open-cli auth status|logout
doudian-open-cli api [GET|POST] --path <path> --data ...
doudian-open-cli skills [name]
```

`api` 的 METHOD 可省略并默认 POST，path 必须通过 `--path` 提供。两套产物共享这一 breaking 命令面，不兼容旧的 path 位置参数。

对内额外：

```text
doudian-open-cli djt auth ...
doudian-open-cli djt api ...
doudian-open-cli djt spi ...
doudian-open-cli djt biz-domain ...
doudian-open-cli djt self skill ...
```

`auth` 与 `djt auth` 不是别名。前者商家开放授权，后者员工点将台 Device Flow。

对外 CLI 不把 Skill 安装到本机目录。`doudian-open-cli skills` 列出内嵌 Skill（`open` 在前，随后是 `skills/biz` 下的业务）；`doudian-open-cli skills <name>` 打印该 Skill 的 `SKILL.md` 原文，不受 `--output json` 影响。对内仅 `djt self skill install|status|update` 写入 Agent 目录，且只操作点将台 Skill，JSON 仍为单 skill 对象（与 `npm-skill-distribution.md` 兼容）。

对内 `postinstall` 调用 `djt self skill install --output json`；不解析 stdout 做业务分支，失败只打一条 stderr 提示且 hook 退出码为 0。对外包没有 postinstall。

第一期 `api` 为通用调用器（path 模式，默认 POST，仅 GET/POST），不为每个 OpenAPI 生成子命令。CLI 用法在 `skills/open`，业务步骤在 `skills/biz/<业务>/`，Agent 用 `doudian-open-cli skills` 发现后再按名称读取。禁止 `+<domain>`、`--method`。

对外 `--help`、对外 README、`skills/open`、`skills/biz` 不得出现 `djt` 子命令、点将台 Origin、PPE 教程。

## 8. 凭据

正式路径：

点将台仍是明文文件。开放面本地模式改为钥匙串主密钥加密后的文件，明文路径只留给云电脑（`DOUBAO_SANDBOX_TYPE=SaaS`）和尚未迁走的旧文件。细则见 [钥匙串与云电脑](open-cli-keychain-sandbox.md)。

```text
{UserConfigDir}/doudian-open-cli/open/credentials.json          # 仅云电脑，或本地迁移前的旧文件
{UserConfigDir}/doudian-open-cli/open/login-session.json       # 同上
~/Library/Application Support/doudian-open-cli/keychain/       # macOS 本地密文；Linux 在 ~/.local/share 下
{UserConfigDir}/doudian-open-cli/djt/credentials.json
{UserConfigDir}/doudian-open-cli/djt/login-session.json
```

点将台旧路径（对内启动时只读迁移，成功后删除旧文件，不得写入 `open/`）：

```text
{UserConfigDir}/opencli/credentials.json
{UserConfigDir}/opencli/login-session.json
```

若旧文件与新路径同时存在，以新路径为准，不覆盖，旧文件保留并在 stderr 提示一次。商家凭据 schema 由 `docs/spec/open_cli_open_spec.md` 定义。开放授权不落 refresh token。本期不做 `auth reset-sk`。`api` 不接受 `--appkey`；身份只来自登录态。

## 9. PPE

本文覆盖 `agent-interface.md` 中「PPE 挂在 `djt auth` / `djt api` / `djt spi` 父命令」的装配方式。重构后**只在根命令**注册 persistent flag，所有子命令（含 `init`、`auth status`、`api`、全部 `djt`）继承同一组值。`djt` 子树不再重复定义同名 flag。

允许的头仅：

- `x-use-ppe`
- `x-tt-env`

Flag 名：`--use-ppe`、`--ppe-env`（语义与现点将台一致：成对出现、环境名 allowlist）。

环境变量（flag 优先于 env）：

- 正式：`OPENCLI_USE_PPE`、`OPENCLI_PPE_ENV`
- 兼容：`OPENCLI_DJT_USE_PPE`、`OPENCLI_DJT_PPE_ENV` 仍可读；与正式变量同时出现时以正式变量为准

用于把请求打到 PPE 授权与 PPE 网关。对外二进制保留解析能力，flag 在 `--help` 中 Hidden；对外 Skill 与对外 README 不写。对内 `--help` 可见。禁止任意 `--header`。公网 npm 若需裁掉 PPE，另开规格，不在本期删除解析逻辑。

## 10. 开放调用与输出契约

### 10.1 CLI 命令面（已锁定）

权威细节以 `docs/spec/open_cli_open_spec.md` 第 4 节为准。`+<domain>` 留给以后的 shortcut，第一期命令语法不得使用。

| 命令 | 作用 |
|---|---|
| `init --kind authorized\|generic` | 授权型 Device Flow 或通用型录入凭据 |
| `auth status` | 当前登录身份（不打印 token / secret） |
| `auth logout` | 删除本地开放凭据 |
| `api [GET\|POST] --path <path> --data <json>` | 调用对应 OpenAPI；`--path` 必填，省略 METHOD 则为 POST |

`--data` 支持 inline / `@file` / `@-`。默认使用登录态；不提供 `--appkey`。

### 10.2 协议（另文，阻塞第 2 波实现）

下列内容不在本文展开，实施开放调用前必须有 `docs/spec/open_cli_open_spec.md`：

- 官方授权页 URL、回调/Device 类流程、CLI 如何拿到 token
- 开放网关 Base URL 与签名
- `open/credentials.json` 字段表
- `auth status` / `api` 成功 JSON 的业务字段
- 开放网关错误码到 CLI `code`/`message`/`log_id` 的映射

CLI 不实现授权页与网关。第 3 步流程骨架：

1. `init --kind authorized` 走第一方 Device Flow（或 `generic` 录入 ak/sk/token）。
2. 成功后写入 `open/credentials.json`。
3. `api` 使用登录态调用开放网关。
4. PPE 白名单头加在 HTTP 客户端上，不进入对外文档。

### 10.3 输出

输出与现有 Agent-first 一致，两边共用 `core/output`：

- `--output json`：成功时 stdout 恰好一份 JSON 并以换行结束；提示与授权 URL 走 stderr。
- 失败：stdout 为空，stderr 一条可读错误，退出码 `1`。
- token / secret 不得出现在 stdout、stderr 或错误回显。

开放网关业务错误映射为稳定字段（如 `code`、`message`、`log_id`）。不得复用点将台 `AgentFieldError` / `modifyVersionId`。`--data` 走 `jsoninput`（inline / `@file` / `@-`）。

## 11. npm 包内容

`bin/` 启动器：用 `spawn` 启动包内绝对路径二进制，`process.argv.slice(2)`，`stdio: inherit`，不启 shell，不经 PATH。平台映射 darwin/linux × amd64/arm64 以及 windows amd64；其余平台明确失败。透传退出码与 SIGINT/SIGTERM；非 Windows 另转发 SIGHUP。

| 字段 | 对外 `npm/open` | 对内 `npm/internal` |
|---|---|---|
| `files` | `bin/`、`binaries/`、`skills/`（`open` 与 `biz/<业务>`，无 `djt`）、`README.md`（英文主文档）、`README.zh-CN.md`、`CHANGELOG.md`、`LICENSE` | 另加 `scripts/postinstall.cjs`、`skills/djt/` |
| postinstall | 无 | 安装点将台 Skill，30s 超时，失败不阻断 npm |
| README | 英文主文档 + 中文 `README.zh-CN.md`；仅对外用法 | 英文主文档 + 中文超集用法（点将台细节在中文） |

对内 `postinstall` 用 Node 绝对路径调用本包 `bin/doudian-open-cli.js djt self skill install --output json`。`--ignore-scripts` 时需显式执行 `djt self skill install`。对外包不安装 Skill。

## 12. 测试与发布门禁

对外发布（以及任何改动 core / 对外入口的合入）必须：

1. `go test` / `go test -race` / `go vet` 覆盖 `internal/core`、`internal/open`、`internal/djt`、两个 `cmd` 入口。
2. `go list -deps ./cmd/doudian-open-cli` 不得出现 `internal/djt`。
3. 对外二进制字符串不得包含 `djt.bytedance.net`、`skills/djt`、`AgentSpi`、点将台 CLI Header 名等批准黑名单。
4. `skills/open` 与 `skills/biz/<业务>/` 与 `internal/open/skill/assets/<name>/` embed 字节一致；内容不得出现点将台 SOP 或 PPE 教程。业务目录还须满足 `docs/spec/skill-layout.md` 的 frontmatter / catalog / 禁词校验。
5. 从 `npm/open` pack 的 tarball 与对外 allowlist 精确一致，不得含 `skills/djt`、源码、测试、凭据、embed 源目录。
6. 隔离 prefix 安装 tgz：二进制可执行，对外 `skills` 向 stdout 打印目录或指定 `SKILL.md`，不写 `~/.agents`。

对内发布额外：

1. `internal/djt` 与对内入口测试通过。
2. 从 `npm/internal` pack 的 tarball 含 `skills/open`、`skills/biz/<业务>/`（若有）与 `skills/djt`。
3. 仍须构建并扫描**对外**产物（步骤 2–5），防止有人从 core/open 加回点将台依赖。

根目录 `npm pack` / `npm publish` 必须失败或被脚本拒绝。

## 13. 验收标准

第 1 步（隔离并迁移点将台）：

- 源码 `go build ./cmd/doudian-open-cli` 得到的二进制 `--help` 无 `djt`，也无商家 `auth` / `api`。
- 源码 `go build ./cmd/doudian-open-cli-internal` 的二进制有完整 `djt` 子树；既有点将台命令行为不变。
- 点将台凭据从 `{UserConfigDir}/opencli/` 迁到 `{UserConfigDir}/doudian-open-cli/djt/`。
- 对外包安装后不能执行点将台配置，磁盘上无 `skills/djt`。
- 对内包 `djt self skill` 仍只装点将台 Skill。对外与对内根命令都没有 `self skill`；开放与业务 Skill 用 `doudian-open-cli skills` 列出或打印。
- PPE 只在根上注册；对内 `--help` 可见，对外 `--help` 隐藏；环境变量正式名与 `OPENCLI_DJT_*` 兼容名均生效。
- 根 `README.md`、`AGENTS.md` 按第 15 节改成双产物说明，不再把仓库写成「只有点将台」。

第 3 步（`docs/spec/open_cli_open_spec.md` 批准并实现后）：

- 两套凭据文件互不影响；错误 schema 互读失败。
- 带 PPE 时 `init` / `api` 请求带白名单头。
- 开放调用失败不把 token 打到终端；json 成功路径 stdout 可被 Agent 直接解析。

## 14. 与既有规格的关系

- 点将台**业务**行为（固定 Origin、Agent Interface / SPI、dry-run/apply）仍以 `docs/spec/agent-interface.md`、`djt-cli-spi-agent.md` 为准。
- PPE **挂载位置、环境变量正式名**以本文第 9 节为准；`agent-interface.md` 中子树 PPE 描述在本重构后作废。
- 根级不再提供 `self skill`；`djt self skill` 单对象 JSON 仍以 `npm-skill-distribution.md` 为准。
- npm 包根从仓库根改为 `npm/open` 与 `npm/internal` 后，`npm-skill-distribution.md` 中「仓库根是 npm 包根」作废，以本文第 3、11 节为准。
- 开放授权与原始 API 调用以后续 `docs/spec/open_cli_open_spec.md` 为准。

## 15. 文档怎么放

不要把所有读者塞进一份产品手册，也不要维护两份互相打架的 AGENTS。

| 文件 | 份数 | 读者 | 写什么 |
|---|---|---|---|
| `AGENTS.md` | **仓库永远一份** | 在本仓改代码的人 / Agent | 双产物、import 禁令、两套发布 SOP、先读哪份 spec |
| 根 `README.md` | **仓库永远一份** | clone 仓库的人 | 总览、**仓库目录树**、链到两份产品 README |
| `npm/internal/README.md` | 对内包英文主文档 | 安装 `@ecom-open-cli/opencli` 的人 | 安装/升级；完整 SOP 在 `README.zh-CN.md` |
| `npm/internal/README.zh-CN.md` | 对内包中文 | 同上 | 超集用法：开放命令 + 点将台 |
| `npm/open/README.md` | 对外包英文主文档 | 安装对外包的人 | **禁止出现 djt**。写 `init` / `auth status|logout` / `api` / `skills` |
| `npm/open/README.zh-CN.md` | 对外包中文 | 同上 | 与英文同范围；**禁止出现 djt** |
| `skills/djt/` | 对内 Skill | 跑点将台的 Agent | 仍只写 `doudian-open-cli djt …` |
| `skills/open_cli_skill/` | 对外 Skill | 跑开放调用的 Agent | CLI 用法；经 `doudian-open-cli skills open_cli_skill` 打印 |
| `skills/biz/` | 业务 Skill | 跑该业务的 Agent | 接口组合；经 `doudian-open-cli skills <业务名>` 打印。写法见目录内 README |
| `docs/open_cli_open_onepage.md` | 一份 | 对外建设 | auth、原始 API、core 地基、`skills` |
| `docs/spec/` | 多份 | 设计/评审 | 隔离用 dual-flavor（不含目录树）；点将台业务用既有 spec |

第 1 步必须改根 `README.md` 和 `AGENTS.md`：删掉「本仓库 = 点将台 CLI」的唯一表述，补上目录边界和 `npm/internal` 发布方式。点将台操作说明从根 README 迁到 `npm/internal/README.md`（可与现 README 主体相当），根 README 只保留短总览加链接。

`AGENTS.md` 继续一份，增加：对外入口不得 import `internal/djt`、两套 `release-npm --flavor`、文档索引。不要拆成 `AGENTS.open.md`。
