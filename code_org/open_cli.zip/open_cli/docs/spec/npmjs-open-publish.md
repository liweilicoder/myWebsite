# 对外包发公网 npmjs SOP

**状态：** 已落地  
**仓库：** `open_cli`  
**范围：** 只发 `@bytedance/doudian-open-cli` 到 `https://registry.npmjs.org`。  
**非范围：** BNPM、对内包 `@ecom-open-cli/opencli`。内网发版仍用 `AGENTS.md` 的 BNPM SOP。

可直接执行的入口：`npm run release:npmjs`（包装 `scripts/release-npmjs.mjs`）。细则与禁令以本文为准。

## 1. 必须在哪个目录

必须在 **本仓库根**（该目录的 `package.json` 里 `"name": "open_cli"`）。克隆路径因人而异，先进到这个目录再跑命令。

不要在它的上级目录跑 `npm run`（那里没有这份 `package.json`）。  
不要在 `npm/open/` 下、也不要在仓库根直接 `npm publish` / `npm stage publish`：根目录 `prepack` 会拒绝；`npm/open` 里没有五平台构建编排。

## 2. 版本与 tag 怎么定

版本只改 `npm/open/package.json` 的 `"version"`，并同步 `scripts/npm-package.test.mjs` 的断言、`CHANGELOG.md`。对外 CHANGELOG 只写用户可感知的能力，不写请求头、验签、网关实现或预发布内部条目。

| 类型 | 版本号示例 | 脚本打的 dist-tag | `npm install 包名`（latest） |
|---|---|---|---|
| 早期开发 | `1.3.0-alpha.0` | `alpha` | **不会**装到这一版 |
| 测试 | `1.3.0-beta.0` | `beta` | 不会 |
| 候选 | `1.3.0-rc.0` | `rc` | 不会 |
| 正式 | `1.3.0` | `latest` | 会 |

预发布 **禁止** `--tag latest`。脚本按版本号后缀自动选 tag。

线上已有版本不能再用。npm 把「占位 / 已暂存 / 已发布」都算占用；再提交同一号会 `E409 Cannot stage previously published version`。这时应升 `alpha.N` / `beta.N` 或正式号（如 `1.0.0`），不要重复提交。

`npm install 包名`（以及 `@latest`）只跟 **`latest`**。`--tag alpha` 只移动 `alpha`，不会改 `latest`。预发布不要靠 `@latest` 验收。若需要不带 tag 也能装到某预发布版，须维护者显式执行 `npm dist-tag add …@<version> latest`（默认 SOP **不做**这一步）。

## 3. 可直接执行的命令

在本仓库根执行。工作区干净、已合入并与 `origin/main` 一致（`main` 受保护，版本提交走功能分支 MR）。

刚发过对内 BNPM 时，先看 `git status`：`release:publish --flavor=internal` 可能把 `npm/open` 的包名 stamp 成本地脏文件。必须先还原再发公网，否则 preflight 失败或打出错误包名。

```bash
git switch main && git pull --ff-only
git status --short   # npm/open 若被 stamp，git checkout -- npm/open

# 登录公网 npm（不要用 BNPM 的 SSO 去登 npmjs；过期 401 就重新 login）
npm login --auth-type=web --registry=https://registry.npmjs.org
npm whoami --registry=https://registry.npmjs.org

# 只读检查（不上传）
npm run release:npmjs -- --check

# 构建、校验、提交暂存（会跑测试和五平台编译，较久）
npm run release:npmjs -- --publish --yes
```

成功时脚本把包交到 npm **暂存区**（Staged Packages），并打印 `stage id`。包此时还不能 `npm install`。你到网页点 **Approve**（过 2FA）之后，才真正对用户可见。Validating 期间按钮是灰的，等它变绿再点。

本机 Go 须为 **1.22+**（`go version`）。若 PATH 上仍是更旧的 Go，改用本机已安装的 1.22+，不要假定某台机器的 Homebrew 路径。只把 1.22 的 `go` 放到 PATH 前面不够：若 shell 里残留旧 `GOROOT`，会出现 `compile: version go1.20.x does not match go tool version go1.22.x`。先 `unset GOROOT GOTOOLDIR`，再用新 `go` 执行 `export GOROOT="$(go env GOROOT)"`。

Node ≥ 18。本机 npm 11 没有 `stage` 子命令，由脚本调用 `npx npm@latest`。

## 4. 网页确认（Approve）

1. 打开 https://www.npmjs.com/settings/~/#staged-packages （头像菜单 **Staged Packages**，不是 org 的 Packages 列表，也不是包 Settings）。
2. 状态 **Validating** 时 Approve 是灰的：等黄条消失。不要 Reject，不要再 `stage publish` 同一版本。
3. Approve 变绿后点击，过 **2FA**。
4. 核对：

```bash
npm dist-tag ls @bytedance/doudian-open-cli --registry=https://registry.npmjs.org
npm view @bytedance/doudian-open-cli versions --json --registry=https://registry.npmjs.org
```

安装核对（本机默认 registry 若是 BNPM，必须带 `--registry=https://registry.npmjs.org`）：

正式版（`x.y.z`，dist-tag `latest`）：

```bash
npm dist-tag ls @bytedance/doudian-open-cli --registry=https://registry.npmjs.org
npm install --global @bytedance/doudian-open-cli@latest --registry=https://registry.npmjs.org
doudian-open-cli --version
```

预发布（`x.y.z-alpha.N` 等）不要装 `@latest`，用对应 tag 或精确版本：

```bash
npm install --global @bytedance/doudian-open-cli@alpha --registry=https://registry.npmjs.org
# 或
npm install --global @bytedance/doudian-open-cli@1.0.0-alpha.2 --registry=https://registry.npmjs.org
doudian-open-cli --version
```

## 5. 脚本实际做了什么（不必手填）

| 问题 | 答案 |
|---|---|
| 版本从哪读 | `npm/open/package.json` 的 `version`，并写入二进制 `-ldflags` |
| 二进制从哪来 | 现场 `go build`：`cmd/doudian-open-cli`，五平台写入 `npm/open/binaries/` |
| 包名 | 仓库已是 `@bytedance/doudian-open-cli`；`--npmjs` **不**改成 BNPM 名 |
| 上传方式 | `npx npm@latest stage publish <tgz> --access public --tag <alpha\|beta\|rc\|latest>`，**不用**根目录 `npm publish` |

## 6. 禁止

- 在仓库上级目录、或 `npm/open` 下直接 `npm publish` / `npm stage publish`。
- 对已占用版本再暂存（会 409）。看到 409 就升版本号，不要改脚本绕过。
- 预发布打 `latest`（除非维护者书面要求）。
- 把 org **Packages** 列表里的占位行当成 Approve 入口。
- 用 BNPM SSO 登录 npmjs；用 `npm login --registry=https://registry.npmjs.org`。
- 把 `0.0.0-stage` 占位当成可安装的产品版本。新包第一次 `npm publish`（非 `stage publish`）曾只会留下这个占位并占用版本号；本 SOP 的脚本改为 `stage publish` 就是为了避免再踩。
- 提交 `*.tgz`、`binaries/`、token。

## 7. 占用版本的清理（可选）

72 小时内、无依赖时，维护者可在本机（需 2FA）下架误发版本：

```bash
npm unpublish @bytedance/doudian-open-cli@<version> --registry=https://registry.npmjs.org --force
```

下架后核对 `versions` 与 `dist-tag`。不要 unpublish 当前 `alpha`/`latest` 仍指向的版本，除非先改 tag。
