# doudian-open-cli DJT 固定 Base URL + PSM 命令重构（最小兼容）设计规格

## 背景
`open_cli` 已发布 npm 包版本 `0.1.0`，当前命令与配置能力包含：
- 可通过 `--base-url` / `OPENCLI_DJT_BASE_URL` / `<UserConfigDir>/doudian-open-cli/config.json` 覆盖点将台 Base URL。
- PSM 查询 canonical 命令为：`doudian-open-cli djt api psm list`。

本次改造目标是**删除所有可配置 Base URL 逻辑**并将 Base URL 唯一固定为：
- `https://djt.bytedance.net`

同时将 PSM 查询命令对齐 **domain-resource-action** 三段式：
- canonical：`doudian-open-cli djt psm list`

并在兼容性允许的范围内保留旧命令：
- `doudian-open-cli djt api psm list`（hidden + deprecated）

> 说明：`lark_cli_reference` 源码的“API 命令”实际分为 **shortcut / metadata API / raw API** 三层；本次仅吸收其“canonical 命令 + 兼容入口（deprecated）”的理念，不引入 metadata/raw API 抽象与生成逻辑。

## 目标（Goals）
1. **固定 Base URL**：任何情况下（flag/env/config/credential）都不能改变实际访问的点将台地址，唯一为 `https://djt.bytedance.net`。
2. **命令三段式**：PSM 命令迁移为 `doudian-open-cli djt psm list`，符合 `doudian-open-cli <domain> <resource> <action>`。
3. **0.1.0 兼容**：保留 `doudian-open-cli djt api psm list` 作为隐藏的废弃入口，给存量脚本迁移窗口。
4. **低风险改造**：不做元数据动态生成、统一 envelope、输出结构大改等高风险变更。

## 非目标（Non-Goals）
- 不新增/重做任何 API client 抽象（继续使用现有 `internal/djt.Client`）。
- 不改变 JSON 输出结构（如 PSM 仍为 `{"psm_list":...}`）。
- 不引入新依赖。
- 不做跨仓库改动。

## 用户可见行为变更
### 1) Base URL
- 删除全局 flag：`--base-url`
- 不再读取环境变量：`OPENCLI_DJT_BASE_URL`
- 不再读取/解析配置文件：`<os.UserConfigDir()>/doudian-open-cli/config.json`
- 登录与所有业务请求（device flow、whoami、psm list）统一访问：`https://djt.bytedance.net`
- `credentials.json` 中历史遗留的 `base_url` 字段 **被忽略**（只保留 schema 兼容），不会影响实际请求目标。

### 2) 命令路径
- 新 canonical：
  - `doudian-open-cli djt psm list --query <keyword>`
- 兼容入口：
  - `doudian-open-cli djt api psm list --query <keyword>`
    - `api` 命令设为 `Hidden: true`
    - `psm` 或 `list` 命令设为 `Deprecated: "已废弃，请使用 doudian-open-cli djt psm list"`
    - 执行该旧路径的 `list` 时，Cobra 会向 stderr 输出 **一次** deprecated 提示（stdout JSON 不应被污染）；单测需覆盖并断言“只输出一次”。

### 3) 帮助信息
- `doudian-open-cli djt --help` 只展示 `auth` 与 `psm` 两个资源；不展示 `api`。
- 用户显式输入 `doudian-open-cli djt api --help` 仍可看到该命令（但它不会出现在父命令帮助中）。

## 兼容策略
### A. 命令兼容
- **保留旧命令路径**：`doudian-open-cli djt api psm list` 继续可执行。
- **迁移提示**：执行旧命令时由 Cobra `Deprecated` 输出一次性提示到 stderr（不污染 stdout 的 JSON）。
- **移除时点建议**：在后续真正发布版本中按次版本周期评估移除（不在本次“只 push 不发布”范围内决定具体版本号）。

### B. Credential JSON 兼容迁移
- `credentials.json` 的 JSON schema **保持不变**（继续包含 `base_url` 字段），避免：
  - 旧版本 tooling/脚本在升级后读取失败
  - 新版本对旧文件 `DisallowUnknownFields` 误伤
- 运行时语义：
  - **不再信任/使用** `credentials.base_url` 来决定访问地址。
  - 任何网络请求均使用编译期常量 `https://djt.bytedance.net` 构造目标 URL。
  - `auth login` 写入的 `base_url` 固定为 `https://djt.bytedance.net`。

### C. config package 处理
- `internal/config` 仅服务于 Base URL 可配置逻辑；在 Base URL 固定后应删除：
  - 删除 `open_cli/internal/config/base_url.go`
  - 删除 `open_cli/internal/config/base_url_test.go`
  - 删除所有引用（`cmd/auth.go`、`cmd/psm.go`、文档与测试）

## 架构与边界（按现有代码最小改动）
- `cmd/`：命令树组装与输出适配。
  - 不引入任何 Base URL 注入点（不在 `Dependencies` 增加 baseURL 字段；不通过参数/flag/env/config 透传）。
  - 统一使用编译期常量 `https://djt.bytedance.net` 驱动登录与业务请求。
- `internal/auth/`、`internal/djt/`：继续保持现有依赖方向，不引入反向依赖。
- **测试策略**：因生产代码使用固定 host，为了覆盖重定向/HTTP 行为测试，可在测试中通过自定义 `http.RoundTripper` 或 `auth.HTTPDoer`：
  1) 先断言原始 `request.URL.Host` 为 `djt.bytedance.net`；
  2) 再把请求 URL 重写到 `httptest.Server` 的 host/scheme；
  3) 最终仍走真实 `http.Transport`/`http.Client` 完成请求。

## 验收标准

- 任何 flag/env/config/credential 均不能改变实际访问地址；唯一目标为 `https://djt.bytedance.net`。
- `doudian-open-cli djt psm list --query <keyword>` 为 canonical 命令，输出结构不变。
- `doudian-open-cli djt api psm list` 仍可执行；stderr 有且仅有一次 deprecated 提示。
- `--help` 不出现 `--base-url`；`djt --help` 不展示隐藏的 `api` 资源。
- 旧版 `credentials.json` 含 `base_url` 时仍可加载；运行时忽略该字段决定访问地址。
