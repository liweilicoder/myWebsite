# 对外 CLI 输出契约

**状态：** 与当前 `open_cli` 代码一致  
**范围：** 对外命令 `init`、`auth`、`api` 在默认 `--output json` 和 `--output text` 下的成功与失败输出；任意 HTTP 状态、非 JSON、超时如何映射到 stderr。  
**非范围：** `skills` 的纯文本列表、对内 `djt` 命令。`skills` 不受 `--output` 影响，见文末。不把 HTTP 响应头或对端整页打到终端。

默认 `--output json`。也可显式 `-o json`，人眼扫一眼可加 `-o text`。先看进程退出码，再解析对应流。成功 JSON 只在 stdout；失败时 stdout 为空，错误 JSON 只在 stderr。不要把 stderr 当成功 JSON 解析。

token、`app_secret`、`device_code` 不会出现在 stdout 或 stderr。

## 1. 两条流

| 结果 | 退出码 | stdout | stderr |
|---|---|---|---|
| 成功 | `0` | 一个 `Envelope`，以换行结束 | 过程提示。授权 URL 打在这里，不进 stdout |
| 失败 | `1`–`5` | 空 | 一个 `Error`，以换行结束 |

`auth status` 在未登录时仍是成功：退出码 `0`，`data.authenticated` 为 `false`。

默认 json。text 模式（`-o text`）不使用下面两套 JSON。成功是一行 `ok dry_run=false` 或 `ok dry_run=true`。失败是 `type: message`，下一行可能是 `hint`；若这次失败来自开放网关 JSON，再下一行是网关 body 原文。

## 2. 成功：`Envelope`

实现类型：`internal/core/output.Envelope`。空字段省略，但 `ok` 和 `dry_run` 始终出现。

| 字段 | 类型 | 含义 |
|---|---|---|
| `ok` | bool | 固定 `true` |
| `dry_run` | bool | `true` 表示没有发 HTTP |
| `identity` | object | 当前凭据摘要。未登录的 `auth status` / `auth logout` 没有此字段 |
| `identity.kind` | string | `authorized` 或 `generic` |
| `identity.app_key` | string | 应用 key |
| `identity.expires_at` | string | RFC3339。凭据里没有过期时间时省略 |
| `data` | any | 本命令的业务数据，形状见第 4 节 |
| `meta.log_id` | string | `api` 真实调用成功、且网关给了 `log_id` 时出现；授权 `init --no-wait` / `--complete`（及一次性 authorized init）成功且响应头有 `x-tt-logid` 时也会出现 |
| `meta.duration_ms` | int | 结构里预留，当前对外命令不填 |

`identity` 还有 `shop_id`、`shop_name` 两个字段，当前 `PublicIdentity` 不填，输出里不会出现。

`api` 成功时，`data` 只是网关 body 里的 `data`，不是整份网关 JSON。网关 `code` / `msg` / `sub_code` / `sub_msg` 在成功路径被丢掉。网关 `data` 为空或缺失时，CLI 的 `data` 为 `{}`。

## 3. 失败：`Error`

实现类型：`internal/core/errs.Error`。空字段省略。`Exit` 只决定进程退出码，不写入 JSON。

| 字段 | 类型 | 含义 |
|---|---|---|
| `type` | string | CLI 错误分类，见下表 |
| `code` | string | 网关 `sub_code`。只有解析到网关业务失败 JSON 时才有 |
| `message` | string | 给人看的原因 |
| `hint` | string | 下一步。认证类失败通常是 `先运行 doudian-open-cli init` |
| `log_id` | string | 网关日志 ID。本地校验、未发请求的认证失败没有 |
| `body` | object | 网关 HTTP body 原文。只有解析到网关 JSON 且 `code != 10000` 时才有 |

### `type` 与退出码

| `type` | 退出码 | 含义 | 当前会不会出现 |
|---|---|---|---|
| `api` | 1 | 网关或业务失败；或 HTTP 非 2xx / 响应不是 JSON | 会 |
| `validation` | 2 | 参数或本地凭据字段不合法，请求未发出或未当成功处理 | 会 |
| `auth` | 3 | 未登录、本地过期、授权会话失败，或网关判定 token 失效 | 会 |
| `network` | 4 | 连接失败、等待响应超时、读 body 失败 | 会 |
| `internal` | 5 | CLI 内部错误，或未分类的 Go error | 会 |
| `permission` | — | 枚举已定义 | 不会 |
| `rate_limit` | — | 枚举已定义 | 不会 |

未知的非 `Error` 失败按退出码 `1` 处理；打到 stderr 时会被包成 `type=internal`。

## 4. 成功时 `data` 长什么样

### `api` 真实调用

网关：

```json
{
  "code": 10000,
  "msg": "success",
  "data": {"total": 2, "current_page": 1, "video_list": []},
  "log_id": "20260924170000000000000000000001"
}
```

CLI stdout：

```json
{
  "ok": true,
  "dry_run": false,
  "identity": {
    "kind": "authorized",
    "app_key": "6845161900440045064",
    "expires_at": "2026-10-01T15:29:00+08:00"
  },
  "data": {"total": 2, "current_page": 1, "video_list": []},
  "meta": {"log_id": "20260924170000000000000000000001"}
}
```

### `api --dry-run`

不访问网关。`data` 含将要发出的方法和 body，不含 token、secret、CLI 审计头。

```json
{
  "ok": true,
  "dry_run": true,
  "identity": {
    "kind": "authorized",
    "app_key": "6845161900440045064",
    "expires_at": "2026-10-01T15:29:00+08:00"
  },
  "data": {
    "http_method": "POST",
    "path": "/shopVideo/listVideo",
    "method": "shopVideo.listVideo",
    "url": "https://openapi-fxg.jinritemai.com/shopVideo/listVideo",
    "query_keys": ["access_token", "app_key", "method", "sign", "sign_method", "timestamp", "v"],
    "body": {"page": 1, "size": 20}
  }
}
```

### `auth status`

未登录：

```json
{"ok": true, "dry_run": false, "data": {"authenticated": false}}
```

已登录：

```json
{
  "ok": true,
  "dry_run": false,
  "identity": {
    "kind": "authorized",
    "app_key": "6845161900440045064",
    "expires_at": "2026-10-01T15:29:00+08:00"
  },
  "data": {"authenticated": true}
}
```

### `auth logout`

```json
{"ok": true, "dry_run": false, "data": {"authenticated": false}}
```

### `init --kind generic`

三个凭据写入本地之后：

```json
{
  "ok": true,
  "dry_run": false,
  "identity": {
    "kind": "generic",
    "app_key": "6845161900440045064"
  },
  "data": {"kind": "generic", "authenticated": true}
}
```

未传 `--expires-at` 时没有 `identity.expires_at`。

### `init --kind authorized --no-wait`

凭据尚未写入。stdout 的 `data` 里有 `verification_url` 和 `user_code`，没有 `device_code`。同一链接再打到 stderr：`请在浏览器打开: <verification_url>`。

```json
{
  "ok": true,
  "dry_run": false,
  "data": {
    "kind": "authorized",
    "authenticated": false,
    "verification_url": "https://openapi-fxg.jinritemai.com/auth/cli?user_code=usr-example",
    "user_code": "usr-example",
    "expires_in": 598,
    "interval": 5,
    "hint": "请把 verification_url 原样交给用户。你可以立即执行 doudian-open-cli init --kind authorized --complete --output json 等待授权结束，也可以等用户确认完成后再执行。不要让用户自己运行这条命令。"
  },
  "meta": {"log_id": "20261012170000000000000000000001"}
}
```

`meta.log_id` 来自 `device/start` 响应头 `x-tt-logid`。本次未真正调用 start（复用本机未过期会话）时没有该字段。

### `init --kind authorized` 或 `--complete` 成功

```json
{
  "ok": true,
  "dry_run": false,
  "identity": {
    "kind": "authorized",
    "app_key": "6845161900440045064",
    "expires_at": "2026-10-01T15:29:00+08:00"
  },
  "data": {"kind": "authorized", "authenticated": true},
  "meta": {"log_id": "20261012170000000000000000000002"}
}
```

`meta.log_id` 来自最后一次 `device/token` 响应头 `x-tt-logid`。

## 5. HTTP 响应怎么映射

CLI **不会**把 HTTP 响应头或对端原文整页打到终端。响应头只取 `x-tt-logid`（有则进成功 `meta.log_id` 或失败 `log_id`）。HTTP 客户端整次请求超时 **30s**，且 **不跟随跳转**（301/302/307 当作最终响应）。

没有拿到 HTTP 响应（连不上、TLS 失败、30s 超时、读 body 失败）→ `type=network`，`message` 为底层错误字符串（超时常见 `Client.Timeout exceeded while awaiting headers` / `context deadline exceeded`），退出码 `4`。这和「对端回了某个 HTTP 状态码」不是一条路。

下面「任意 HTTP 状态」包含 1xx/3xx/4xx/5xx，以及非 200 的 2xx，不特指 403。

### 5.1 `api`

先读完整 body，再尝试当开放平台信封 JSON 解析（`code` / `msg` / `sub_code` / `sub_msg` / `log_id` / `data`）。

| 条件 | 终端 | 退出码 |
|---|---|---|
| body 是该 JSON 且 `code` 为数字 `10000` | **不以 HTTP 状态为准**，走成功；stdout 的 `data` 只等于信封里的 `data` | 0 |
| body 是该 JSON 且 `code != 10000` | **不以 HTTP 状态为准**；按第 5.4 节映射，失败 JSON 带 `body` 原文 | 1 或 3 |
| body **不是** JSON，且 status **不在 200–299** | `type=api`，`message` 为 `网关 HTTP ` + `resp.Status`（状态行，含数字和短语，例如 `网关 HTTP 401 Unauthorized`、`网关 HTTP 302 Found`、`网关 HTTP 502 Bad Gateway`）。**没有 `body`** | 1 |
| body 不是 JSON，但 status 是 2xx | `type=api`，`message` 为 `网关响应不是 JSON`。没有 `body` | 1 |

### 5.2 授权 `device/start`、`device/token`

对应 HTTP：`POST /auth/cli/device/start`、`POST /auth/cli/device/token`。

解析顺序：先看有没有 HTTP 响应；再按状态分流；2xx（start）或 200/400（token）才读 JSON。JSON 先看顶层 `error`（OAuth 协议码），再看 `CustomError.ErrNo`，最后才当成功字段校验。

**对外原则：** 同类语义由 open_auth 给出 **不同 ErrNo**；CLI **只按 ErrNo 映射**，**不解析、不匹配 `ErrMsg`**。stderr 只出固定中文 `message`（`auth` 类另带 `hint`：`先运行 doudian-open-cli init`）。**不透传** `ErrMsg`、`ErrNo`、协议码、字段名、内部依赖名。有 `x-tt-logid` 时失败 JSON 带 `log_id`。`device_code` / token 不出现在任何输出。须与 open_auth 的 `34003`–`34006` 一起发布。

#### HTTP 层（未进入或无法当业务 JSON 处理）

| 接口 | 接口返回 | CLI 对外（`--output json` stderr） | type | 退出码 |
|---|---|---|---|---|
| start / token | 连不上、TLS 失败、30s 超时、读 body 失败 | `message` 为底层错误字符串 | `network` | 4 |
| start | HTTP **非 2xx**（任意 1xx/3xx/4xx/5xx） | `授权 start 返回 HTTP {数字}`，不解析、不打印 body | `api` | 1 |
| token | HTTP **不是 200 也不是 400** | `授权 token 返回 HTTP {数字}`，不解析、不打印 body | `api` | 1 |
| token | HTTP **400**，body 不是可识别的 `error` / `CustomError` | `授权 token 返回非法 HTTP 400` | `api` | 1 |
| start | HTTP 2xx，body **不是 JSON** | `授权 start 响应不是 JSON` | `api` | 1 |
| token | HTTP 200，body **不是 JSON** | `授权 token 响应不是 JSON` | `api` | 1 |

示例（start 403，有 logid）：

```json
{"type": "api", "message": "授权 start 返回 HTTP 403", "log_id": "…"}
```

#### 业务 JSON：顶层 `error`（常见于 token HTTP 400）

| 接口 | 接口返回 | CLI 对外 | type | 退出码 | 备注 |
|---|---|---|---|---|---|
| token | `{"error":"authorization_pending"}` | **不输出**，继续 poll | — | — | 内部 `DeviceProtocolError` |
| token | `{"error":"slow_down"}` | **不输出**，间隔 +5s 再 poll | — | — | 内部消化 |
| start / token | `{"error":"access_denied"}` | `商家已拒绝授权` + hint init | `auth` | 3 | |
| start / token | `{"error":"expired_token"}` | `授权已过期，请重新登录` + hint init | `auth` | 3 | |
| start / token | `{"error":"invalid_grant"}` | `授权无效，请重新登录` + hint init | `auth` | 3 | |

#### 业务 JSON：`CustomError`（常见于 HTTP 200 信封）

`CustomError` 形如 `{"ErrNo": <数字>, "ErrMsg": "<服务端原文>"}`。下表只按 **ErrNo** 对照；`ErrMsg` 无论写成什么都不参与分流、也不打印。

| 接口 | 接口返回 `ErrNo` | 服务端语义 | CLI 对外 `message` | type | 退出码 |
|---|---|---|---|---|---|
| start / token | `34005` | 云电脑缺少合法登录身份 | `云电脑授权缺少登录身份，请在豆包内重试或切换为本地电脑` | `auth` | 3 |
| start / token | `100003` | 其它参数非法（mode、device_code、会话不一致等） | `授权请求无效，请稍后重试` | `api` | 1 |
| start / token | `100001` / `100002` / `100005` / `100006` / `100007` | 内部错误、下游、Redis、MQ、DB、KMS 等 | `授权服务暂时不可用，请稍后重试` | `api` | 1 |
| token | `34003` | 待用户登录或待商家确认 | **不输出**，继续 poll | — | — |
| token | `34004` | 商家拒绝授权 | `商家已拒绝授权` | `auth` | 3 |
| token | `34006` | 授权会话状态无法继续 | `授权状态异常，请重新登录` | `auth` | 3 |
| start / token | `200009` | 授权会话已过期 | `授权已过期，请重新登录` | `auth` | 3 |
| start / token | `34001` | CLI 凭证无效/归属不匹配 | `授权凭证无效，请重新登录` | `auth` | 3 |
| start / token | `34002` | CLI 凭证过期 | `授权已过期，请重新登录` | `auth` | 3 |
| start / token | 其它非 0（含旧码 `200008`） | 未识别 | `授权失败，请稍后重试` | `api` | 1 |

`auth` 类失败 JSON 另带 `"hint": "先运行 doudian-open-cli init"`。云电脑缺身份示例：

```json
{"type": "auth", "message": "云电脑授权缺少登录身份，请在豆包内重试或切换为本地电脑", "hint": "先运行 doudian-open-cli init", "log_id": "…"}
```

#### 业务成功字段不全或本地校验失败（HTTP 已 2xx/200，且无上述业务错误）

| 接口 | 接口返回 | CLI 对外 `message` | type | 退出码 |
|---|---|---|---|---|
| start | 缺 `device_code` 或 `user_code` | `授权发起失败，服务未返回完整结果` | `api` | 1 |
| start | `expires_in` / `interval` 非法 | `授权 start 时长字段无效` | `api` | 1 |
| start | `verification_uri` 不安全 | `verification_uri 不安全` | `api` | 1 |
| start | complete URL 不安全 | `verification_uri_complete 不安全` | `api` | 1 |
| start | complete 与 uri 不同源 | `verification_uri_complete 与 verification_uri 不同源` | `api` | 1 |
| token | 缺 access_token / app_key / expires_time | `授权完成失败，服务未返回完整结果` | `api` | 1 |
| token | `expires_time` 不是 RFC3339 | `授权 token expires_time 必须是 RFC3339` | `api` | 1 |
| poll（CLI 本地） | 扫码窗口到期，不是某次 HTTP | `授权超时` + hint init | `auth` | 3 |

### 5.3 非 JSON 失败示例（任意状态码同一模板）

`api` 对端返回 502 且 body 不是开放平台 JSON，stderr：

```json
{"type": "api", "message": "网关 HTTP 502 Bad Gateway"}
```

`init` 的 start 返回 403（或任意非 2xx），stderr：

```json
{"type": "api", "message": "授权 start 返回 HTTP 403"}
```

有 `x-tt-logid` 时上述 JSON 会多 `log_id`。

### 5.4 网关 JSON 且 `code != 10000`

CLI 读完整份网关 JSON。`code` 为数字 `10000` 走成功（见 5.1）。否则：

1. `message` 取 `sub_msg`，空则取 `msg`，仍空则用 `开放网关调用失败`。
2. `log_id` 优先用 body 里的 `log_id`，否则用响应头 `x-tt-logid`。
3. `code` 填网关 `sub_code`。
4. `body` 放入网关响应 JSON 原文，字段不裁剪。
5. `sub_code` 落在下表时 `type=auth` 且带 `hint`；其余 `type=api`。

| 网关 `sub_code` | CLI `type` |
|---|---|
| `isv.access-token-no-existed` | `auth` |
| `isv.access-token-expired` | `auth` |
| `isv.access-token-missing` | `auth` |
| `isv.cli-access-token-missing` | `auth` |
| `isv.access-token-invalid` | `auth` |
| `dop.authorization-no-existed` | `auth` |
| `dop.authorization-closed` | `auth` |
| 其他，例如 `dop.service-timeout-error`、`isv.parameter-invalid` | `api` |

### 业务或内部失败

网关：

```json
{
  "code": 20001,
  "msg": "内部服务超时",
  "sub_code": "dop.service-timeout-error",
  "sub_msg": "服务内部访问超时，请重试",
  "data": null,
  "log_id": "2026092416541870A80A208A3767DE168F"
}
```

CLI stderr，退出码 `1`：

```json
{
  "type": "api",
  "code": "dop.service-timeout-error",
  "message": "服务内部访问超时，请重试",
  "log_id": "2026092416541870A80A208A3767DE168F",
  "body": {
    "code": 20001,
    "msg": "内部服务超时",
    "sub_code": "dop.service-timeout-error",
    "sub_msg": "服务内部访问超时，请重试",
    "data": null,
    "log_id": "2026092416541870A80A208A3767DE168F"
  }
}
```

text 模式同一条失败：

```text
api: 服务内部访问超时，请重试
{"code":20001,"msg":"内部服务超时","sub_code":"dop.service-timeout-error","sub_msg":"服务内部访问超时，请重试","data":null,"log_id":"2026092416541870A80A208A3767DE168F"}
```

### token 失效

网关 `sub_code` 为 `isv.access-token-no-existed` 时，stderr 退出码 `3`：

```json
{
  "type": "auth",
  "code": "isv.access-token-no-existed",
  "message": "access_token不存在，请使用最新的access_token访问",
  "hint": "先运行 doudian-open-cli init",
  "log_id": "20260924163802231CAD329A205AFAF287",
  "body": {
    "code": 40003,
    "msg": "access_token不存在，请使用最新的access_token访问",
    "sub_code": "isv.access-token-no-existed",
    "sub_msg": "access_token不存在，请使用最新的access_token访问",
    "data": null,
    "log_id": "20260924163802231CAD329A205AFAF287"
  }
}
```

## 6. 没打到网关的失败

这些例子没有 `body`，也没有 `log_id`。授权 `device/start`、`device/token` 若已发出请求且响应头有 `x-tt-logid`，失败 JSON 会带 `log_id`。

参数不合法，退出码 `2`：

```json
{"type": "validation", "message": "--path 不能为空"}
```

未初始化就调用 `api`，退出码 `3`：

```json
{"type": "auth", "message": "未初始化", "hint": "先运行 doudian-open-cli init"}
```

本地凭据已过期，退出码 `3`：

```json
{"type": "auth", "message": "凭据已过期", "hint": "先运行 doudian-open-cli init"}
```

没有待完成的授权会话就 `--complete`，退出码 `3`：

```json
{"type": "auth", "message": "没有待完成的授权会话", "hint": "先运行 doudian-open-cli init --kind authorized --no-wait"}
```

连接或等待超时，退出码 `4`：

```json
{"type": "network", "message": "Post \"https://openapi-fxg.jinritemai.com/auth/cli/device/start\": context deadline exceeded (Client.Timeout exceeded while awaiting headers)"}
```

## 7. `skills` 例外

`skills` 和 `skills <name>` 忽略 `--output`。成功时 stdout 是纯文本，不是 `Envelope`。失败时 stdout 为空，退出码 `2`。
