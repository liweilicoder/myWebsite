# 点将台 SPI Agent CLI 设计规格

**状态：** 已实施
**仓库：** `open_cli`（命令/Skill），`open_admin` / `open_admin_web`（BFF + 领域门面）
**对照：** 飞书「点将台 SPI Agent CLI 设计 Spec」；当前网页 SPI 动线；已落地 `djt api` Agent Interface

## 1. 目标

给 Agent 一条与 `djt api` 同级的 SPI 链路：先有场景，再配单个 SPI 接口到待审核。网页行为不变。认证、PPE、Transport、JSON envelope、dry-run/`--apply`、失败 stdout 为空且 exit=1，全部沿用现有 CLI 底座。

CLI 做到待审核（模板状态 301）为止。审核结论、`ReleaseSpi`、场景上线/下线不在本期。

## 2. 命令

父命令不执行操作，leaf 不接受位置参数。二进制仍是 `doudian-open-cli`。

```text
doudian-open-cli djt spi scene list
doudian-open-cli djt spi scene get
doudian-open-cli djt spi scene save
doudian-open-cli djt spi scene sync-boe

doudian-open-cli djt spi scene access-app list
doudian-open-cli djt spi scene access-app get
doudian-open-cli djt spi scene access-app save
doudian-open-cli djt spi scene access-app enable

doudian-open-cli djt spi interface list
doudian-open-cli djt spi interface get
doudian-open-cli djt spi interface save
doudian-open-cli djt spi interface submit-review
doudian-open-cli djt spi interface cancel-upgrade
```

Agent 最短路径：`scene save` → `interface save`（带 `sceneId`）→ `interface submit-review`。接入应用和同步 BOE 不挡提审。

| 能做 | 不能做 |
|------|--------|
| 创建空场景（name + desc） | 改名、改描述、绑已有接口、上线/下线 |
| `scene sync-boe` | Mock、压测、线上流量验证 |
| 接入应用：列表/详情/新建/启用 | 禁用、删除；新建后不得默认启用 |
| 接口：读、整份 JSON 保存、提审到 301 | 审核通过/驳回、发布、客户端改 type/status |

写操作（`save` / `sync-boe` / `enable` / `submit-review`）默认 dry-run，显式 `--apply` 才落库；`--dry-run` 与 `--apply` 互斥。`list`/`get` 只读。

新建 SPI 接口必须带已有 `sceneId`，接口名为 `业务域前缀/名称`。创建接口的 `--apply` 必须同时带 `--confirmed-by-user`；Agent 须先跑 `djt biz-domain list` 并让用户确认业务域，不得默认测试域。场景创建不绑业务域。

`interface list` 支持 `name-like`、`scene-id`、`biz-domain-id` 模糊搜索与过滤；`interface get` 按精确 `interfaceName` 或 `interfaceId` 读取完整配置。`scene get` 按 `sceneId` 或精确场景名。`access-app get` 按 `authId` 或 `scene-id` + `app-id`，返回 `implList`（含 `interfaceImplUrl`）。

## 3. 实现分界

### 3.1 场景 / 同步 BOE / 接入应用

复用 `open_admin` 现有 `CreateScene`、`GetSceneList`、`CreateSceneAuth`、启用接入、`SyncSpiInfoToBoe`。`open_admin_web` 只增加 `/api/djt-cli/agent/spi/...`：Bearer 注入 `operatorEmail`，拒绝客户端伪造身份，写操作支持 dry-run。不改网页 `/api/spi/*`、场景上线/下线路由。

`access-app save` 只插入未启用记录，与网页「新建接入」一致。`access-app enable` 是另一次写操作。不注册禁用/删除的 CLI 路由。

### 3.2 接口配置：薄门面，不复制 `djt_cli_agent`

OpenAPI 的 `djt_cli_agent` 隔离是因为 BAM/IDL、`sections`、多步 `advance-step`、PPE 同步。SPI 网页已经是「一次 Save + 一次 Commit」，没有这些编排。

内部依赖：

```text
CLI → BFF /api/djt-cli/agent/spi/interface/*
  → djt_cli_agent_spi（门面：dry-run、状态门禁、版本 CAS、剥危险字段、current/diff/errors）
      → QuerySpiTemplateInterface / SaveSpiTemplateInterface / CommitSpiAuditTemplateInterface
```

- **门面负责：** 身份、dry-run 与 apply 共用校验、状态门禁、`modifyVersion` compare-and-set、丢弃 `operator`/`type`/`status`/`skipOperatorValidate`、返回 `current`/`preview`/`diff`/`errors`。
- **领域层负责：** 字段树、Header、用例表达式、已发布(6)开新草稿、`release_audit` 与审批。不重写这些逻辑。
- **禁止：** CLI 直调网页 `GET /api/interface/templateCommitAudit`；把 SPI 塞进 `djt api` 的 init/doc/advance-step。

`QuerySpiTemplateInterface` 现网不返回 `modifyVersion`。Agent `get` 必须带上权威 `modifyVersionId`、`status`、`interfaceId`、`sceneId` 和完整可编辑配置。复杂树在 CLI 用 `json.RawMessage` 透传，不在 `open_cli` 复制 schema。

## 4. 接口状态与版本

沿用模板状态，不用 OpenAPI 的 `statusV2` 步骤码。

| 状态 | 含义 | `interface save` | `submit-review` |
|------|------|------------------|-----------------|
| 不存在 | 新建 | 允许，apply 后 201 | 拒绝 |
| 201 | 待提交 | 允许，保持 201 | 允许，apply 后 301 |
| 301 | 待审核 | 拒绝 | 拒绝（不可重复提审） |
| 3 | 审核成功 | 拒绝 | 拒绝 |
| 4 | 审核失败 | 允许，保存后回到 201 | 拒绝（须先 save） |
| 6 | 全量发布 | 允许：基于线上版本**新建**草稿（201），不改已发布行 | 拒绝（对新草稿 201 再提审） |

网页 UI 在 301/3 不可编辑，但现有 `SaveSpiTemplateInterface` 后端不拦，更新时还会打回 201。Agent 门面必须在调用 Save 前拒绝 301/3，避免 CLI 改审核中的单。

版本：

- 已有草稿的 `save` / `submit-review` 必须带 `modifyVersionId`（与 get 返回值一致）。
- apply 时事务内重读；版本落后返回冲突和最新版本，不写库。
- 现有 Save 的 `modifyVersion+1` 不是 CAS。门面或 DAO 更新必须带旧版本条件；网页旧接口本期不改语义。
- dry-run 与 apply 走同一套校验；apply 不得信任 dry-run 结果，必须重读状态和版本。
- CLI 在 submit-review 的 apply 前先 get；本地发现非 201 或版本变化则拒绝。服务端仍重复校验。

`submit-review`：`interfaceId`、`modifyVersionId`、`reason` 必填；`meego` 可选。服务端固定 `InterfaceType_OpenSpi`，创建审批。dry-run 不算审核单、不改状态。

## 5. 接口 save 输入与出入参树

CLI 落库的权威输入是 **SaveSpi 同一套 DTO**（`requestInfo` / `responseInfo` / `headers` / `errorInfoList` / `bizUseCases` 等），不是业务示例 JSON。没有独立 `doc`，没有 `sections` 局部保存。控制字段与草稿字段分开；BFF 丢弃 `operatorEmail`、`type`、`status`、`skipOperatorValidate`。创建时 `ownerList` 缺省当前用户，更新时缺省保留原责任人。

网页「业务入参/出参 → 代码录入」把**示例 JSON 对象**解析成字段树（`parseObject` + `parseType`），再映射为 `requestName`/`responseName`、`type`、`subType`、`example`、`children`。CLI 不在服务端再做一套不同的推断。Agent 用法与 API 一样：

1. 用 Skill 自带本地脚本，把示例 JSON 转成与网页「代码录入」同构的 `requestInfo`/`responseInfo` 数组；
2. 补网页表格里 JSON 推断不到的字段（必填、描述、加密、Map 类型、Header）；
3. 把完整草稿交给 `djt spi interface save`（`--input` 一份 JSON，或拆开的 JSON source flags）。

脚本规则对齐网页、对齐 API Skill 脚本边界：

- 只做本地转换，不读凭据、不联网、不替代 dry-run。
- JSON 对象 → Struct，数组 → List，`number` → Int64，`boolean` → Bool，其余标量 → String。对象/数组节点的 example 置空（与网页一致）。
- **不**从 JSON 推断 Map、加密等级、标签；这些只能出现在转完后的树上或网页表格。
- 不写入前端展示用的 `$type` / `$securityLevel`；save 请求与库里的 `type`/`subType`/`map*` 才是权威形状。
- 脚本通过后仍必须以 `save --dry-run` 的服务端 `preview`/`errors` 为准。

Agent 禁止手写一套与网页不同的字段 schema。需要改树时改完整树后整区替换，CLI 不 merge。

## 6. Skill 与文档（仅使用说明）

分发的 `skills/djt/SKILL.md`、README、脚本 `--help` 只写 Agent **怎么用**：命令、必填参数、确认门禁、JSON source、示例、失败怎么改、提审后回网页。

禁止写进 Skill 的内容：门面/CAS/剥字段、RPC 名、表名、内部包名、与网页实现差异的设计讨论。脚本目录说明只保留「本地转换、不联网、不能代替 CLI」。这与现有 API Skill（`apply_style_patches.py` 等）同一标准。

SPI 增补脚本（名称实施时确定）至少包含：示例 JSON → `requestInfo`/`responseInfo` 树。golden fixture 必须覆盖网页 `parseObject`/`parseType` 的同一批示例。

## 7. 安全与输出

- 请求只打 `https://djt.bytedance.net`。CLI 不增加 origin/path/method/认证头覆盖。
- 仅批准本节命令对应的 `/api/djt-cli/agent/spi/*` 路径。
- JSON source：inline / `@file` / `@-`，单文档、8 MiB。
- 成功 stdout 一个 `{code,message,data}`；失败 stdout 空、stderr 一次、exit=1。
- PPE flags 挂在 `djt spi` 父命令，与 `djt api` 相同校验。
- Skill 与 README 见第 6 节，只说明使用。

## 8. 验收标准

- 默认写命令不产生 DB / 审核单 / 审批单写入。
- 两个客户端同一 `modifyVersionId` 保存，只有一个成功。
- 仅 201 可提审；成功后权威状态 301。
- 301/3 保存被门面拒绝；4 保存回到 201；6 保存产生新草稿。
- `access-app save` 后 enable=false；未 `--apply` 的 enable 不改变启用态。
- 无禁用/删除/上线/下线 CLI。
- 网页原路由行为不变。
- `open_cli` 命令测试覆盖 envelope、dry-run/apply、8 MiB、PPE、未知字段保留。
- Skill 正文不含内部实现细节；脚本无网络、无凭据。
- **库数据一致（硬标准，与 API 相同）：** 同一套业务含义下，网页保存与 CLI `interface save --apply` 写入的模板行、下游 `request_arg`/`response_arg`/headers、错误码、业务用例必须同构（忽略 UI 专用 `$` 字段和纯展示字段）。用同一示例 JSON：网页「代码录入」产物 vs Skill 脚本产物 vs 落库 JSON，三者字段名、type/subType、children 结构一致。不一致即验收失败。
