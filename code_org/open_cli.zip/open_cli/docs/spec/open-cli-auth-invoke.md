# 对外 CLI 授权与调用设计

**状态：** 设计已批准  
**仓库：** `open_cli`  
**范围：** 对外开放面的 `init` / 凭据 / `api` 组包。  
**非范围：** `open_gw` skip-sign 实现、豆包 MITM 实现（只写 CLI 必须遵守的契约）。服务端 Device Flow / fake token 以 `open_auth/docs/spec/2026-09-21-cli-pending-two-schemes.md` 为准。本地秘密与云电脑模式以 [open-cli-keychain-sandbox.md](open-cli-keychain-sandbox.md) 为准；下文与之冲突时以后者为准。  
**关联：** 实现后回写 `docs/spec/open_cli_open_spec.md` 第 4、9 节。

## 1. 目标

商家业务 Skill 指定 `authorized` 时，Agent 必须先检查身份，未登录或认证失败时先引导在线链接授权，授权成功前暂停业务调用和商品、目标、参数收集；不得向商家索要 app_key、app_secret、access_token，也不得降级为 generic。开发者凭据录入仅适用于用户明确要求的开发者接入场景。

一份对外 CLI、两套身份：商家在豆包里完成抖店授权（不感知应用与 sk），开发者本地录入 ak/sk/token 当 HTTP SDK。命令复用；只在 `init` 或过期时重新初始化。本地不泄漏授权型的真 token / sk。

## 2. 命令面

```text
doudian-open-cli init
doudian-open-cli auth status | logout
doudian-open-cli api [GET|POST] --path <path> --data <json> [--dry-run]
```

- `init` 取代 `auth login`。未初始化或已过期时，`api` 失败（`type=auth`），hint 指向 `init`。
- `api` / `auth status` / `auth logout` 两种类型完全共用；不按类型拆子命令；禁止 `--appkey`。
- `api` 的 METHOD 是唯一可选位置参数，省略时默认 POST；`--path` 必填，不接受 path 位置参数，也不兼容旧的 `api /path` / `api POST /path` 语法。
- 本期不做 `auth reset-sk`、不做 refresh token。换密钥或换类型：`auth logout` 再 `init`。
- 豆包环境不改变命令，只影响授权型请求是否被云端捕获换票。

## 3. 身份与凭据

同一套 Load/Save，用 `kind` 区分。本地（未设置云电脑）不写明文：凭据和待完成会话是钥匙串主密钥加密后的文件。云电脑（`DOUBAO_SANDBOX_TYPE=SaaS`）才使用 `{UserConfigDir}/doudian-open-cli/open/credentials.json` 与 `login-session.json`。详见钥匙串 spec。

| 字段 | 授权型 `authorized` | 通用型 `generic` |
|---|---|---|
| `kind` | `authorized` | `generic` |
| `app_key` | 轮询成功返回 | 用户录入 |
| `access_token` | fake token | 真 token |
| `app_secret` | **字段不出现** | 用户录入 |
| `expires_at` | 轮询返回 | 可选；未填则只靠网关过期错误 |
| 店铺等展示字段 | 轮询若返回则写入 | 可选，没有就不展示 |

`auth status` 打印 `kind`、`app_key`、过期时间、店铺名；永不打印 token / secret。  
`auth logout` 删除凭据密文和待完成会话。不删除登录钥匙串里的主密钥 `master.key`，也不删除降级文件 `master.key.file`。  
换类型或换应用：先 `logout` 再 `init`。

### 3.1 `init`

1. 已有凭据：提示已初始化，要求先 `auth logout`，不做静默覆盖。
2. 选择 `authorized` 或 `generic`。
3. **授权型：** 第一方 Device Flow（无商家 ak/sk）。`POST /auth/cli/device/start` 的 body 只有 `mode`：本地 `local`，云电脑 `cloud`。响应返回 `device_code`、`user_code`、complete URL。`device_code` 只留在本机待完成会话里：本地是钥匙串密文，云电脑才是明文 `login-session.json`。授权 URL 只带 `user_code`（可能是 AEAD 不透明长密文，拼 URL 时 QueryEscape）。`POST /auth/cli/device/token` 用 `device_code` 轮询；未完成回 `authorization_pending` / `slow_down`。成功 JSON 必须含 fake `access_token`、`app_key`、**`expires_time`（RFC3339 绝对时间）**；不得下发 `app_secret`；若含 sk，CLI **丢弃不落盘**。落盘凭据字段仍是 `expires_at`（值来自 `expires_time`）。服务端 start **不写 Redis/DB**；两码为带 `"u"`/`"d"` 前缀的 AEAD，仅服务端可解；商家确认后才落库。细节见 open_auth 最终方案，不在本仓实现。
   - 人工终端：`init --kind authorized`（start 后阻塞 token poll）。
   - **Agent 必用两段式：** `init --kind authorized --no-wait` 只 start（有效 pending 则复用），stdout 给出 `verification_url` / `user_code` / `hint`，**不输出 `device_code`**。用户打开 URL 后立刻跑 `init --kind authorized --complete`。`--no-wait` 不自动打开浏览器。
4. **通用型：** 交互录入 `app_key` / `app_secret` / `access_token` / 可选过期时间；前三项非空才写入。两段式旗标仅授权型可用。

start / poll 的 URL、JSON 字段名以实现时对照服务端为准；CLI 只依赖上述语义，不在代码里猜路径。

## 4. 组包

一份凭据、一个组包函数，按 `kind` 分叉。

**公共**

- `GET`/`POST` `https://openapi-fxg.jinritemai.com/{path}`
- path → `method`：`/product/detail` → `product.detail`
- query：`method`、`app_key`、`access_token`、`timestamp`、`v=2`、`sign`、`sign_method=hmac-sha256`（两种身份都带；算法与开平一致）
- body：`param_json`（`--data` 的 JSON）
- 头（审计用，**不可当开放平台鉴权**）：
  - 两种都带：`X-Cli-Source: doudian-open-cli`、`X-Doudian-Open-Cli-From`（默认 `cli`）、`X-Doudian-Open-Cli-Version`（当前 CLI 版本）、`X-Doudian-Open-Cli-Auth-Kind: authorized | generic`
  - **仅授权型**另带 `X-Doudian-Open-Cli-Access-Token`（本机 fake，不加 `Bearer`；**豆包会替换成真 token**）。通用型不带。验签 / 解票用的 fake 在 **query `access_token`**，豆包不得改 query。
  - 仅云电脑且 `DOUBAO_SANDBOX_CONTEXT_TOKEN` 非空时，授权型再带 `X-Sandbox-Context-Token`（原值，不加 `Bearer`）。通用型不带。Device Flow 的 start/token 同样带这个头。
  - `X-Cli-Source: doudian-open-cli` 与 `X-Doudian-Open-Cli-Version` 由 `identity.Apply` 注入，所有对外 HTTP 请求都带，包括 Device Flow 的 start/token、业务 `api`、点将台请求。版本值与 `doudian-open-cli version` / npm `-ldflags` 注入的 `BuildVersion` 一致，未注入时为 `dev`。

**通用型**

- 用 `app_secret` 按开平 / `open_gw` 拼串，HMAC-SHA256：
  `secret + app_key + {appId} + method + {method} + param_json + {规范化 JSON} + timestamp + {ts} + v + {v} + secret`
- query 的 `access_token` 为真 token
- 豆包 **不得改** `app_key` / `access_token` / `timestamp` / `v` / `sign`

**授权型**

- 同样带 `sign` / `sign_method`。HMAC 密钥用 query 里那份 fake `access_token`（本机无 `app_secret`）。组包形态与通用型一致
- query 的 `access_token` 为 fake token
- 真 token 只由豆包注入请求头；CLI 不读、不存、不打印
- 云电脑判定只看 `DOUBAO_SANDBOX_TYPE=SaaS`。上下文头只看 `DOUBAO_SANDBOX_CONTEXT_TOKEN`。二者都不覆盖 query 里的 fake `access_token`（以 `init` 落盘为准）。PPE 仍只来自 `--use-ppe` / `--ppe-env`，不从这两个变量推断。

**dry-run**

打印方法、URL、query 键、body；token / secret 脱敏。  
**隐藏** `X-Cli-Source`、`X-Doudian-Open-Cli-From`、`X-Doudian-Open-Cli-Version`、`X-Doudian-Open-Cli-Auth-Kind`、`X-Doudian-Open-Cli-Access-Token`。不发 HTTP。

## 5. 过期与错误

调用前：无文件 / `kind` 非法 / 有 `expires_at` 且已过期 → 不发请求，`type=auth`，hint `init`。通用型未填 `expires_at` 则跳过本地时间关。

网关返回 token 过期、授权失效、access_token 不存在等（对照 `open_gw` AuthInfo 错误，含 `isv.cli-access-token-missing`）→ 同样 `type=auth`，hint `init`。授权型缺真 token 头导致的失败也归 auth；stderr 不出现 fake token。

HTTP 任意状态码、非 JSON 拦截页、30s 超时如何变成 stderr：见 [cli-output.md 第 5 节](cli-output.md)。`device/start`、`device/token` 按 open_auth 的 CLI 专用 `ErrNo`（`34003`–`34006` 等）映射对外文案，见 [cli-output.md 第 5.2 节](cli-output.md)。CLI 不匹配 `ErrMsg`，不 dump 响应头或拦截页原文。

退出码与实现一致：0 成功，1 远端 API/通用失败，2 参数校验，3 未登录/认证失败，4 网络，5 内部错误。细类以信封 `type` 为准。签名失败、业务参数错误走 1。失败时 stdout 为空。token / secret / CLI 审计头（含 Access-Token 头）不出现在任何用户可见输出里。

## 6. 组件（本仓库）

| 单元 | 职责 | 依赖 |
|---|---|---|
| `internal/open/auth` | Credentials 结构、Load/Save/Logout、本地过期判断 | `credstore` |
| `internal/open/auth` 的 `init` | 选类型；授权型 start/poll；通用型录入 | Factory HTTP、IO |
| `internal/open/invoke` | path 规范化、按 kind 组包、签名、Send、dry-run 预览（隐藏 CLI 头） | Factory HTTP、auth.Load |
| `internal/open/cli` | 注册 `init` / `auth` / `api` | 以上 |
| `internal/core/errs` | auth 错误 hint 改为指向 `init` | — |

命令层不 new HTTP、不算签、不读豆包 env；组包与签名只在 `invoke`。

## 7. 数据流

**授权型调用：** `api` → Load 凭据 → 本地过期检查 → 组包（HMAC `sign`/`sign_method`，query=fake token，带 CLI 头）→ 豆包捕获 → 头注入真 token → `open_gw` 用 query fake 验 HMAC、用头里真 token 做授权校验 → RPC。

**通用型调用：** `api` → Load → 过期检查 → 组包（HMAC sign，query=真 token，同样 CLI 头）→ 直连网关（query 签名字段不被改）→ 验签 + 授权 → RPC。

## 8. 网关与豆包契约（非本仓库实现）

- 标准调用：[指南 814](https://op.jinritemai.com/docs/guide-docs/148/814)；`open_gw` 先 AuthInfo 再 SignCheck。
- 开平提供换票 RPC 给豆包：`DecryptFakeToken`，密文为 `{ v, cli_auth_id, exp }`，过期不查库；未过期定位 `op_auth_token` 真 token，注入请求头。
- `open_gw` 不得仅因 CLI 头存在就 SkipSignCheck。授权型走独立验签：HMAC 密钥为 **query `access_token`（fake）**，不回落 `app_secret`；真 token 只来自豆包替换后的 `X-Doudian-Open-Cli-Access-Token`。
- 头名、换票 URL 由网关 / 豆包侧定稿；**不阻塞**本仓库 CLI 实现。

## 9. 测试

httpmock，不打真网关。

- `init` 授权型：poll 含 sk 时文件无 `app_secret`。
- `init --no-wait`：不写凭据，stdout 含 `verification_url` / `user_code`，不含 `device_code`；随后 `--complete` 兑票。
- `init` 通用型：缺字段失败；写入后 `status` 不泄露 secret。
- `api` 通用型：有 `sign`；CLI 头（含 Version）在 mock 请求上；query 为真 token。
- `api` 授权型：有 `sign` / `sign_method`；query 为 fake token；CLI 头在。
- `api --path '/product/detail'` 默认 POST；`api GET --path '/product/list'` 与 `api POST --path '/product/detail'` 正确解析 METHOD。
- `api` / `api POST` 缺少 `--path`，以及旧的 `api /path` / `api POST /path` 语法，均在读取凭据或发 HTTP 前以参数错误拒绝，stdout 为空。
- 两种 dry-run：预览无 CLI 审计头（含 Version）、无 token / secret。
- 本地过期与网关过期：均 hint `init`。
- 已有凭据再 `init`：失败并提示 `logout`。
- 通用型 query 的 `app_key` / `access_token` / `timestamp` / `v` / `sign` 在断言中保持原样。

## 10. 明确不做

- 授权型落盘或打印 sk / 真 token
- CLI 自己刷 token、refresh token
- 按类型拆 `api` 子命令
- 在本仓库实现 `open_gw` 改造或豆包换票服务
- `--dry-run` 展示 CLI 审计头
