# DJT CLI Demo 设计规格

**状态：** 已实施（历史 Demo 规格；当前能力见 `agent-interface.md`）
**仓库：** `open_cli`

## 1. 目标

在 `doudian-open-cli` 中提供一个可演示的点将台（DJT）命令域。Demo 通过 `open_admin_web` 已有 HTTP 能力完成设备授权和 PSM 模糊查询，不引入对 `open_admin_web`、`open_admin` 或 `open_gw` 的改造。

最小可用命令集：

```text
doudian-open-cli djt auth login
doudian-open-cli djt auth status
doudian-open-cli djt auth whoami
doudian-open-cli djt auth logout
doudian-open-cli djt api psm list --query <关键字>
```

## 2. 范围

### 2.1 包含

- Go CLI，命令框架使用 Cobra。
- Device Flow：
  - `POST /api/djt-cli/device/start`
  - `POST /api/djt-cli/device/token`
- 业务接口：`GET /api/interface/getPsmList?psmLike=<query>`。
- 业务请求使用 `X-DJT-CLI-Authorization: Bearer <token>`。
- 全局 `--output text|json`，默认 `text`。
- 全局 `--base-url`：登录时按命令行参数、`OPENCLI_DJT_BASE_URL`、配置文件解析；已登录业务请求与 credential origin 绑定。
- Demo 阶段把凭据存入用户配置目录下权限为 `0600` 的 `credentials.json`。
- 自动打开浏览器；打开失败时不终止登录，而是在标准错误打印授权 URL。
- HTTP client、credential store、browser opener 都可注入测试。

### 2.2 不包含

- 不修改 `open_admin_web`、`open_admin`、`open_gw`。
- 不新增服务端路由、数据库、RPC 或网关能力。
- 不实现 PSM 查询之外的业务命令。
- 不实现 token refresh、多账号、多环境 profile、代理配置或 shell completion 定制。
- 不引入 Cobra 之外的第三方依赖。
- Demo 不接入系统 Keychain；正式化阶段必须替换明文文件存储。

## 3. 技术约束

- 语言：Go，模块声明使用保守基线 `go 1.21`。当前执行环境为 Go 1.25.8，关联仓库 `open_gw` 仍使用 Go 1.20；本独立 CLI 不依赖 Go 1.24+ 特性，因此不擅自抬高最低版本。
- CLI：`github.com/spf13/cobra`，并只保留其传递依赖。
- 其余能力只使用 Go 标准库，包括 HTTP、JSON、URL 校验、文件权限、浏览器启动和测试服务器。
- 所有网络请求都使用 `context.Context`。
- Base URL 只允许：
  - `https://`；
  - `http://localhost`、`http://127.0.0.0/8`、`http://[::1]` 等 loopback 主机。
- 禁止 URL 中包含 userinfo、query 或 fragment；配置时去掉末尾 `/`。
- token 不写入日志、错误信息、text 输出或 JSON 输出。
- 生产 `http.Client` 禁止全部自动重定向（`CheckRedirect` 返回 `http.ErrUseLastResponse`）；任意 3xx 作为命令错误返回，认证 header 不进入同域、跨域或多跳目标。
- `verification_uri`/`verification_uri_complete` 必须为无 userinfo 的绝对 HTTPS URL 或 loopback HTTP URL；前者禁止 query，后者允许 query，均拒绝 file/custom scheme。
- start 的 `expires_in` 范围为 `(0, 1h]`，轮询 `interval` 为 `(0, 5m]`，token `expires_in` 为 `(0, 30d]`；在乘 `time.Duration` 前校验。
- 远端错误 message 先脱敏当前 token，再清理 C0/ANSI 控制字符；text 用户字段同样做终端安全清理。

## 4. 命令与用户体验

### 4.1 全局参数

```text
--base-url string     open_admin_web 地址；优先于环境变量和配置文件
-o, --output string   输出格式：text 或 json（默认 text）
```

`login` 按 flag > env > config 解析 Base URL。PSM 在已登录后始终使用 credential Base URL，配置文件不得覆盖；若显式 flag/env 与 credential 规范化后的 origin（scheme、host、有效端口）不同，必须在请求前拒绝并提示先 logout/login，相同 origin 允许但不改写 credential Base URL。

Base URL 解析失败时退出码为 `1`，错误信息明确指出允许 HTTPS 或 loopback HTTP。没有任何来源可提供 Base URL 时，同样退出并提示三种配置方式。

配置文件位于：

```text
<os.UserConfigDir()>/doudian-open-cli/config.json
```

格式：

```json
{"base_url":"https://open-admin-web.example.com"}
```

不存在的配置文件等价于“未配置”；存在但无法读取、JSON 非法或 base URL 非法时必须报错。

### 4.2 `auth login`

流程：

1. 解析并校验 Base URL。
2. CLI 使用 `crypto/rand` 生成 32-byte 随机值，并以 base64url-no-padding（`base64.RawURLEncoding`）编码为 `code_verifier`；计算 `SHA256(code_verifier)` 后同样以 base64url-no-padding 编码为 `code_challenge`。verifier 只保存在当前进程内存中，不记录日志、不输出、不落盘。
3. `POST /api/djt-cli/device/start`，`Content-Type: application/json`，请求体严格为：

```json
{"code_challenge":"base64url-no-padding-sha256","code_challenge_method":"S256"}
```

4. 解析 HTTP 200 响应：

```json
{
  "device_code": "device-secret",
  "user_code": "ABCD-EFGH",
  "verification_uri": "https://example.com/device",
  "verification_uri_complete": "https://example.com/device?user_code=ABCD-EFGH",
  "expires_in": 600,
  "interval": 5
}
```

5. `Start` 成功后立即按当前时钟加 `expires_in` 计算 wall deadline；该时点早于浏览器调用，因此浏览器耗时计入设备码期限。优先打开 `verification_uri_complete`；为空时打开 `verification_uri`。
6. 浏览器返回后，service 立即调用显式 `PromptFunc(LoginPrompt)`，携带实际打开的 verification URL、`user_code` 和 browser error。回调必须发生在第一次 `Wait`/`Token` 前；回调写失败立即中止且不得轮询。text 模式回调把 URL/user code 写 stdout；JSON 模式把所有过程提示写 stderr；浏览器打开失败时额外向 stderr 打印可复制 URL。
7. 按服务端 `interval` 轮询 `POST /api/djt-cli/device/token`，每次都携带 start 阶段生成且仅保存在内存中的 verifier：

```json
{"device_code":"device-secret","code_verifier":"base64url-no-padding-random-32-bytes"}
```

8. token 未完成状态统一通过 HTTP 400 和如下 body 返回，不存在 `status` 或 `error_description` 字段：

```json
{"error":"authorization_pending"}
{"error":"slow_down"}
{"error":"access_denied"}
{"error":"expired_token"}
{"error":"invalid_grant"}
```

成功为 HTTP 200，响应只包含：

```json
{
  "access_token": "opaque-token",
  "token_type": "Bearer",
  "expires_in": 3600
}
```

9. HTTP 400 `authorization_pending` 保持当前间隔；`slow_down` 将后续间隔增加 5 秒；`access_denied`、`expired_token`、`invalid_grant`、未知 error、其他 HTTP 状态或协议错误立即失败。每轮等待时长取当前 interval、wall-clock remaining、logical remaining budget 三者最小值；logical budget 每次按请求的等待时长扣减。`Wait` 返回后必须重新检查 context、wall deadline 和 logical budget，过期/取消后不得再请求 token。logical budget 确保固定 fake `Now`、立即返回的 fake `Wait` 和永久 pending 组合也会有限终止。start/token 的成功和错误 body 均最多读取 1 MiB；错误不得包含 verifier、access token 或原始敏感响应体。
10. token 成功后，立即使用 `X-DJT-CLI-Authorization: Bearer <token>` 调用 `GET /api/user/getLoginUser`。只有远端身份查询成功且顶层 `code == 0`，才把用户与凭据一起原子保存；身份查询或落盘失败均视为登录失败。
11. `Credentials.expires_at` 由 CLI 收到 token 成功响应的时刻（receipt time）加 `expires_in` 计算；不得依赖服务端时钟或不存在的 `expires_at` 字段。

为使测试快速且确定，轮询等待通过 `func(context.Context, time.Duration) error` 注入；生产实现使用 `time.NewTimer` 并响应 context 取消。

`GET /api/user/getLoginUser` 的真实响应 envelope 为：

```json
{
  "code": 0,
  "message": "success",
  "data": {
    "employee": {
      "employeeId": "123",
      "employeeName": "吴昊天",
      "email": "user@example.com",
      "headUrl": "https://example.com/avatar.png"
    },
    "userType": 1,
    "authorityList": ["interface.read"]
  }
}
```

CLI 的本地 `User` 模型保留 `employee_id`、`employee_name`、`email`、`head_url`、`user_type`、`authority_list`；服务端 `data` 中其他字段可忽略。顶层 `code != 0` 时以 `message` 返回业务错误，不能保存凭据。

JSON 模式只在最终成功时向标准输出写一个 JSON 对象；登录过程提示和浏览器回退 URL 写标准错误，避免污染机器可读输出：

```json
{"authenticated":true,"user":{"employee_id":"123","employee_name":"吴昊天","email":"user@example.com","head_url":"https://example.com/avatar.png","user_type":1,"authority_list":["interface.read"]},"expires_at":"2026-08-06T12:00:00Z"}
```

### 4.3 `auth status`

只读取本地凭据，不发网络请求。

- 无凭据：text 输出 `未登录`；JSON 输出 `{"authenticated":false}`；命令成功退出。
- 有未过期凭据：输出已登录、用户和过期时间。
- 有已过期凭据：按未登录处理，并标识 `expired`；不自动删除文件。

JSON 示例：

```json
{"authenticated":true,"user":{"employee_id":"123","employee_name":"吴昊天","email":"user@example.com","head_url":"https://example.com/avatar.png","user_type":1,"authority_list":["interface.read"]},"expires_at":"2026-08-06T12:00:00Z"}
```

### 4.4 `auth whoami`

只读取本地凭据，不发网络请求。

- 凭据不存在或已过期：返回错误 `尚未登录，请先运行 doudian-open-cli djt auth login`。
- text：优先输出 `employee_name <email>`，缺少字段时输出已有身份字段。
- JSON：输出 `user` 对象与 `expires_at`，不输出 token。

### 4.5 `auth logout`

删除本地凭据。

- 文件存在：删除并成功。
- 文件不存在：幂等成功。
- text：`已退出登录`。
- JSON：`{"authenticated":false}`。

### 4.6 `api psm list --query`

`--query` 为必填参数；空白字符串也视为非法。请求：

```http
GET /api/interface/getPsmList?psmLike=<url.QueryEscape(query)> HTTP/1.1
X-DJT-CLI-Authorization: Bearer <access_token>
Accept: application/json
```

真实响应 envelope 为：

```json
{
  "code": 0,
  "message": "success",
  "data": {
    "psmList": ["cmp.ecom.open_admin"]
  }
}
```

CLI 检查顶层 `code`/`message`，仅在 `code == 0` 时读取 `data.psmList`；协议中不存在 `BizError`。HTTP 非 2xx 时返回包含状态码但不包含 token 或原始敏感 body 的错误；HTTP 2xx 但顶层 `code != 0` 时返回 `message`。凭据不存在或过期时，在发请求前报“尚未登录”。

- text：每行一个 PSM；空列表输出 `未找到匹配的 PSM`。
- JSON：稳定输出 `{"psm_list":[...]}`，空列表为 `[]` 而非 `null`。

## 5. 本地数据与安全

凭据路径：

```text
<os.UserConfigDir()>/doudian-open-cli/credentials.json
```

格式：

```json
{
  "base_url": "https://open-admin-web.example.com",
  "access_token": "opaque-token",
  "token_type": "Bearer",
  "expires_at": "2026-08-06T12:00:00Z",
  "user": {
    "employee_id":"123",
    "employee_name":"吴昊天",
    "email":"user@example.com",
    "head_url":"https://example.com/avatar.png",
    "user_type":1,
    "authority_list":["interface.read"]
  }
}
```

写入规则：

- 创建用户配置目录时使用 `0700`。
- 在同目录创建临时文件，并在写入任何凭据前强制调用 `Chmod(0600)`；Windows 也调用该步骤。
- 编码 JSON 后依次执行 `Sync`、`Close`，再 `Stat` 临时文件；Unix 要求 mode 精确为 `0600`，Windows 不做 POSIX mode 验证。
- 临时文件通过上述检查且 context 未取消后，原子 `Rename` 覆盖 `credentials.json`；`Rename` 成功即提交成功，不再对目标文件执行 `Chmod`，因此不存在提交后的失败点。
- 读取时拒绝 Unix 上 group/other 任意权限非零的凭据文件，并提示修复为 `0600`；Windows 不基于 POSIX mode 拒绝。
- JSON 使用 `DisallowUnknownFields`，缺少 token、Base URL 或 `user.employee_id` 时视为损坏。
- `logout` 只删除固定凭据路径，不接受用户输入路径。

> **后续安全改造（非 Demo）：** `credentials.json` 明文 token 仅用于 Demo。进入正式环境前，`CredentialStore` 的生产实现必须替换为 macOS Keychain、Windows Credential Manager、Linux Secret Service 等系统安全存储；命令层和 HTTP 层不得依赖文件实现细节。

## 6. 架构与可测试性

建议目录职责：

```text
cmd/doudian-open-cli/main.go                 进程入口
cmd/root.go                         Cobra 根命令、依赖组装、全局参数
cmd/djt.go                      djt 命令域
cmd/auth.go                     login/status/whoami/logout 命令适配
cmd/psm.go                      api psm list 命令适配
internal/config/base_url.go     Base URL 来源优先级与安全校验
internal/auth/model.go          凭据、用户、Device Flow 模型
internal/auth/store.go          CredentialStore 与文件实现
internal/auth/device_client.go  Device Flow HTTP 协议与 PKCE
internal/auth/whoami_client.go  GET /api/user/getLoginUser HTTP client
internal/auth/service.go        登录轮询、远端取用户与本地认证用例
internal/browser/opener.go      BrowserOpener 与系统实现
internal/djt/client.go          PSM HTTP client
internal/output/printer.go      text/json 稳定输出
```

必须提供的注入边界：

```go
type HTTPDoer interface {
    Do(*http.Request) (*http.Response, error)
}

type DeviceAPI interface {
    Start(context.Context, string) (DeviceStart, error)
    Token(context.Context, string, string, string) (DeviceToken, error) // baseURL, deviceCode, codeVerifier
}

type WhoAmIAPI interface {
    GetLoginUser(context.Context, string, string, string) (User, error) // baseURL, tokenType, accessToken
}

type CredentialStore interface {
    Load(context.Context) (Credentials, error)
    Save(context.Context, Credentials) error
    Delete(context.Context) error
}

type BrowserOpener interface {
    Open(string) error
}

type WaitFunc func(context.Context, time.Duration) error

type LoginPrompt struct {
    VerificationURL string
    UserCode string
    BrowserError error
}

type PromptFunc func(LoginPrompt) error
```

`Service.Login` 的接口为 `Login(context.Context, string, PromptFunc) (LoginResult, error)`。`PromptFunc` 是 service 与命令输出层之间唯一的过程提示契约；service 不直接依赖 stdout/stderr，命令层不得把过程提示延迟到 `Login` 返回后。

`DeviceStart` 在 CLI 内部额外携带不参与 JSON 编解码的 `CodeVerifier string`（JSON tag 为 `-`），`DeviceAPI.Token` 必须显式接收该 verifier，避免依赖全局状态或把 verifier 落盘。

`cmd.Dependencies` 集中持有这些依赖以及时钟、输入输出流，测试通过 fake 注入，不启动真实浏览器、不访问真实服务、不写真实用户目录。生产入口通过 `cmd.NewProductionRoot() (*cobra.Command, error)` 组装；`os.UserConfigDir()` 失败时直接返回错误，禁止退化为当前工作目录或相对 `credentials.json` 路径。安装命令为 `go install ./cmd/doudian-open-cli`，生成 `doudian-open-cli` 可执行文件。

## 7. 错误、输出与退出行为

- Cobra 根命令设置 `SilenceUsage: true`、`SilenceErrors: true`。
- 参数校验错误、未登录、网络错误、协议错误、文件错误统一由 `main` 打印到标准错误并以 `1` 退出。
- 成功为 `0`。
- 不为不同失败类型扩展退出码，避免 Demo 过度设计。
- JSON 使用 `json.Encoder`，每次命令恰好输出一个 JSON 值并以换行结束。
- start/token 的成功与错误响应体均最多读取 1 MiB；错误只报告端点、HTTP 状态或已识别的安全 error code，不拼接原始 body，确保 verifier/token 不泄漏。`getLoginUser` 与 PSM 响应同样限制为 1 MiB。
- HTTP client 默认超时 30 秒；Device Flow 的每次请求使用该超时，整体登录受设备码到期时间控制。

## 8. 验收标准

1. 五类命令均已注册，帮助层级与名称准确。
2. `--query` 缺失或空白时不发 HTTP 请求。
3. Base URL 的优先级和 HTTPS/loopback HTTP 限制有表驱动测试。
4. Device Flow 覆盖 PKCE verifier/challenge、成功、HTTP 400 pending/slow_down/拒绝/过期/invalid_grant、浏览器失败、1 MiB body 上限和 context 取消测试。
5. 登录成功路径验证 token 后使用 CLI Header 远端调用 `getLoginUser`，按 receipt time + `expires_in` 计算过期时间，并且远端取用户失败时不保存凭据。
6. PSM 查询验证 path、query 编码、认证 header、`code/message/data.psmList` envelope、业务错误和 text/json 输出。
7. credential store 覆盖 `0600`、原子覆盖、严格 JSON、过宽权限拒绝和幂等删除。
8. `status`、`whoami`、`logout` 只读本地/不依赖网络，且任何输出不泄露 token 或 verifier。
9. `go test ./...`、`go test -race ./...`、`go vet ./...` 均通过。
10. 依赖清单中除 Cobra 及其传递依赖外没有第三方包。
11. 实现提交不包含对 `open_admin_web` 或其他仓库的修改。

## 9. 已确认的服务边界

现状调研确认 `GET /api/interface/getPsmList` 是 `open_admin_web` BFF 路由，对应 `GetPsmList`，下游通过 TCE `SearchPsm(psmLike)` 返回 `psmList`。本 Demo 直接调用该 HTTP 路由；`open_gw` 不承载 `/api/interface` 路由，因此不作为调用目标。
