# 开放 CLI 钥匙串与云电脑模式

**状态：** 已落地  
**仓库：** `open_cli`  
**范围：** 对外开放面的本地秘密、待完成会话、`device/start` 的 `mode`、豆包云电脑请求头。  
**非范围：** 点将台 `djt` 仍用明文 `login-session.json`。服务端如何把 `mode` 封进授权码、如何作废 `device_code`，以 open_auth 为准。

## 1. 结论

本地模式只在系统钥匙串里放 32 字节主密钥。凭据和待完成会话是用这把密钥做 AES-GCM 之后的文件，不写明文 `credentials.json` / `login-session.json`。

macOS 与飞书 CLI 使用同一个库 `github.com/zalando/go-keyring v0.2.8`。该版本不链接 Security.framework，而是调用 `/usr/bin/security`。登录钥匙串已解锁时，创建或读取账号 `master.key` 不会弹出确认框。访问权限记在 `/usr/bin/security` 上，不会出现「允许 doudian-open-cli 访问钥匙串」。

「找不到钥匙串」不是授权确认。它表示进程按 `HOME` 找不到登录钥匙串。主目录正确且钥匙串解锁时不应出现。

`auth logout` 删除凭据密文和待完成会话，不删除登录钥匙串里的 `master.key`，也不删除降级文件 `master.key.file`。

云电脑只认环境变量 `DOUBAO_SANDBOX_TYPE=SaaS`。其他取值和未设置都是本地。云电脑不访问系统钥匙串。

## 2. 本地秘密放哪里

服务名固定为 `doudian-open-cli`。账号名按配置目录绝对路径的 SHA-256 区分，避免两套配置目录共用一条密文。

| 内容 | 账号 |
|---|---|
| 主密钥 | `master.key`（只在系统钥匙串或降级文件里） |
| 已登录凭据 | `open-credentials-` + 配置目录哈希 |
| 待完成会话 | `open-pending-` + 配置目录哈希 |

待完成会话字段仍是 `device_code`、`user_code`、`verification_url`、`expires_at`、`interval`。stdout、stderr 和对话不得出现 `device_code`。

密文文件：

| 系统 | 目录 |
|---|---|
| macOS | `~/Library/Application Support/doudian-open-cli/keychain/doudian-open-cli/` |
| Linux | `~/.local/share/doudian-open-cli/keychain/doudian-open-cli/` |
| Windows | 不落主密钥文件。密文在当前用户注册表 `Software\DoudianOpenCli\keychain`，经 DPAPI 保护 |

本地保存成功后删除同目录下的明文 `open/credentials.json` 和 `open/login-session.json`。若只剩旧明文文件，读取时迁入钥匙串再删掉明文。

通用型和授权型在本地都走这套存储。云电脑两种都走明文文件。

## 3. 主密钥怎么选

读取先用已有的 `master.key.file`，没有再用系统钥匙串。

写入：已有 `master.key.file` 就继续用它；否则写系统钥匙串；系统钥匙串失败再创建 `master.key.file`（权限 `0600`，32 字节）。

系统钥匙串单次访问限时 5 秒。超时或拒绝都算失败，然后走文件降级。Linux 没有系统钥匙串，只使用 `master.key.file`。Windows 没有文件降级。

`master.key.file` 出现表示这次没有用上系统钥匙串。同一用户若同时能读主密钥文件和密文文件，就可以解开内容。

## 4. 云电脑

仅 `DOUBAO_SANDBOX_TYPE` 精确等于 `SaaS` 时：

- `device/start` 的 JSON 为 `{"mode":"cloud"}`。未设置或其他取值时为 `{"mode":"local"}`。
- 凭据与待完成会话写 `{UserConfigDir}/doudian-open-cli/open/credentials.json` 和 `login-session.json`，不调用钥匙串。云电脑上的 `device_code` 只能换到 fake token。
- `DOUBAO_SANDBOX_CONTEXT_TOKEN` 去空白后非空时，原样放入请求头 `X-Sandbox-Context-Token`，不加 `Bearer`。
- 该头只出现在 Device Flow 的 start/token，以及授权型业务 `api`。通用型 `api` 不带。
- `X-Cli-Source: doudian-open-cli` 与 `X-Doudian-Open-Cli-Version`（当前 CLI 版本）所有对外 HTTP 都带，不区分云电脑或本地、不区分 Device Flow 或业务 `api`。

授权型业务请求仍把本机 fake token 放在 `X-Doudian-Open-Cli-Access-Token`，不加 `Bearer`。query `access_token` 仍是这份 fake token，供 HMAC 使用。

## 5. 明确不做

- 本地把 `device_code` 打到终端，或把它留在明文 `login-session.json`。
- `logout` 时删除系统钥匙串主密钥。
- 把非 `SaaS` 的 `DOUBAO_SANDBOX_TYPE` 当成云电脑。
- 在 CLI 里解开服务端授权码，或改写 query 里的 `access_token` / `sign`。
