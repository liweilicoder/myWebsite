# doudian-open-cli Agent Interface 设计规格

**状态：** 已实施；当前契约包含动态业务域查询、init 双重确认，以及 save 前补齐 example/description
**仓库：** `open_cli`

## 1. 背景

`open_cli` 当前提供 `doudian-open-cli djt auth login|status|whoami|logout`、`doudian-open-cli djt psm list` 与 npm/Skill 分发，但 Agent 配置点将台接口仍依赖过渡期 Python + curl 脚本。服务端已经在 `open_admin` / `open_admin_web` 的 `feat/djt-cli` 分支提供独立的 Agent 契约：

- `GET /api/djt-cli/agent/interface/get`
- `POST /api/djt-cli/agent/interface/init`
- `POST /api/djt-cli/agent/interface/save`
- `POST /api/djt-cli/agent/interface/doc`
- `POST /api/djt-cli/agent/interface/advanceStep`

本期把这五个能力收敛进正式 Go CLI，并把领域知识迁入 npm 分发的 `djt` Skill。设计参考 lark-cli 的三点经验：

1. 命令使用稳定的 `domain/resource/action` 层级；
2. 低层 HTTP transport 与高层安全编排分离；
3. 为 Agent 保留可检查的状态字段和结构化远端错误。

只吸收上述原则，不复制 lark-cli 的 metadata/raw API 体系。

## 2. 已确认的上游事实

### 2.1 固定网络边界

- 唯一 origin 为 `https://djt.bytedance.net`。
- 认证头为 `X-DJT-CLI-Authorization: Bearer <token>`。
- PPE 请求额外发送：
  - `x-use-ppe: 1`
  - `x-tt-env: <ppe-env>`
- 生产 `http.Client` 继续禁止自动重定向；任意 3xx 作为失败处理。
- 不恢复 `--base-url`、`OPENCLI_DJT_BASE_URL` 或配置文件覆盖能力。

### 2.2 服务端语义

- `save` 只保存，不推进 `statusV2`。
- `advanceStep` 可以保存并推进状态。
- `doc` 没有 `dryRun` 字段，调用即落库。
- `save` / `advanceStep` 的 `dryRun` 必须显式传给服务端。
- `init.fromBam` 才包含 BAM 解析出的初始参数树；新建后 `get.current.requestInfo` 可能是 `[]`。
- `doc` 后 `modifyVersionId` 可能变化，提审前必须重新 `get`。
- `errcode` 推进终态是 110；`cancel-audit` 终态是 200；`submit-audit` 终态是 310。
- 330 及以上属于审核通过和发布阶段，本期不得由 Agent CLI 推进。

### 2.3 HTTP envelope

成功：

```json
{
  "code": 0,
  "message": "success",
  "data": {}
}
```

业务失败通常仍为 HTTP 200：

```json
{
  "code": 8000037,
  "message": "版本冲突",
  "errors": [
    {
      "field": "modifyVersionId",
      "reason": "请求版本落后",
      "fix": "请用最新版本重试",
      "suggestedValue": "43"
    }
  ],
  "data": {
    "current": {
      "interfaceId": 2846,
      "modifyVersionId": 43,
      "statusV2": 110,
      "configPhase": "ready_for_ppe_test",
      "nextStep": "doc"
    }
  }
}
```

### 2.4 Device Flow PPE 完整链路（0.2.2）

真实 PPE 证据表明 Start、Token 与浏览器 approve 均命中 PPE，但 Login 最终 `GET /api/user/getLoginUser` 未携带 PPE header，导致请求落到生产并返回 SSO URL。登录网络链路因此固定为：

```text
Cobra ppe.Resolve
  -> auth.Service.Login(ppe.Config)
  -> DeviceAPI.StartWithPPE / TokenWithPPE
  -> WhoAmIAPI.GetLoginUserWithPPE
```

- `--use-ppe --ppe-env <env>` 时，Start、Token、GetLoginUser 三次 CLI HTTP 请求必须使用同一个不可变 `ppe.Config`，并同时发送 `x-use-ppe: 1` 与 `x-tt-env`。
- 生产默认配置下三次请求均不得发送这两个 header。
- 浏览器 approve 不由 CLI 注入 header，继续要求泳道浏览器/请求头环境。
- 独立 `auth whoami` 只返回凭据中的缓存身份，不调用远端 GetLoginUser。为避免凭据格式兼容风险，本期不持久化 PPE 信息、不扩展 `Credentials` schema，只保证同一次 Login 内的最终用户查询命中同一 PPE。
- 依赖方向固定为 `cmd -> auth -> ppe`；`ppe` 是叶子配置包，`auth` 不依赖 `djt`，不存在环或跨层 shortcut。
- 所有失败继续使用固定错误文本或经过 token 脱敏的远端 message，不拼接请求 token、认证头或原始响应体。

## 3. 约束

1. Go 最低版本保持 1.21。
2. 除现有 Cobra 及其传递依赖外不引入第三方依赖。
3. 只修改 `open_cli`；不修改服务端契约。
4. 成功内容写 stdout；错误与过程提示写 stderr；失败退出码固定为 1。
5. JSON 成功输出必须恰好是一个 JSON 文档并以换行结束。
6. 不改变 `cmd/doudian-open-cli/main.go`，尤其不能让失败 JSON 写入 stdout。
7. token、认证头和原始敏感错误体不得进入 stdout、stderr、日志、fixture 或文档示例。
8. 所有响应体和 JSON 输入必须有大小上限。
9. Agent 只允许调用动态业务域只读端点 `GET /api/domain/list` 和 `/api/djt-cli/agent/interface/*` 五个批准端点；不得调用其他网页配置 API。
10. `requestInfo` / `responseInfo` 等整棵树优先使用 `json.RawMessage`，状态、版本、动作和安全控制字段使用强类型。

## 4. 目标

1. 提供动态业务域查询和以下 canonical 命令：

```text
doudian-open-cli djt biz-domain list
doudian-open-cli djt api get
doudian-open-cli djt api init
doudian-open-cli djt api save
doudian-open-cli djt api doc
doudian-open-cli djt api advance-step
```

2. 为五个动作统一固定 origin、认证、PPE、响应上限、envelope 解码和 `RemoteError`。
3. 为复杂 JSON 入参统一支持 inline、`@file`、`@-`。
4. 为写操作提供 fail-closed 的 dry-run/apply 栅栏。
5. 为 Agent 输出稳定 JSON，并在进程内提供强类型 introspection。
6. 把完整配置流程、状态机、错误恢复和禁止事项同步到 README、AGENTS、Skill、embed 与 npm 测试。

## 5. 非目标

- 不做动态命令元数据。
- 不做 raw API 命令或任意 method/path/body 转发。
- 不做 schema engine、IDL codegen、JSON Schema 校验或自动生成 flags。
- 不实现 `docAutoFill` 独立命令；`doc --auto-fill` 已覆盖推荐路径。
- 不实现本地 style patch 引擎；Agent 可在输入 JSON 中完成变换，本期 CLI 只做语法和顶层类型校验。
- 不实现发布、灰度、小流量、全量动作，不允许推进到 330+。
- 不调用 `saveTemplateInfo`、`getTemplateDetail`、`interfaceStatusFlow`。
- 不改变认证凭据存储方案。
- 不增加新的输出格式或细分退出码。

## 6. 命令模型

### 6.1 层级

```text
doudian-open-cli
└── djt
    └── agent
        └── interface
            ├── get
            ├── init
            ├── save
            ├── doc
            └── advance-step
```

`agent` 和 `interface` 是无 `RunE` 的父命令。所有 action 使用 `cobra.NoArgs`。

### 6.2 共享 flags 与环境变量

`interface` 父命令提供两个 persistent flags，五个 action 共用：

| Flag | 环境变量 | 默认 | 语义 |
|---|---|---|---|
| `--use-ppe[=true\|false]` | `OPENCLI_DJT_USE_PPE` | `false` | 是否发送 PPE headers |
| `--ppe-env <name>` | `OPENCLI_DJT_PPE_ENV` | `ppe_djt_cli` | `x-tt-env` 值，仅 `use-ppe=true` 时使用 |

优先级为显式 flag > 环境变量 > 默认值。环境变量布尔值只接受 `1`、`0`、`true`、`false`，忽略大小写；其他值在读取凭据和网络请求前失败。`ppe-env` 必须匹配 `^[A-Za-z0-9._-]{1,128}$`，防止 header 注入。

过渡期 Python 环境变量 `DJT_CLI_USE_PPE` / `DJT_CLI_PPE_ENV` 不作为正式 CLI 隐式兼容入口；Skill 明确给出迁移后的 `OPENCLI_DJT_*` 名称。

全局现有 `-o, --output text|json` 保持不变。Agent 自动化应使用 `--output json`。

### 6.3 JSON source 语法

以下复杂字段统一接受一种 `JSON source`：

```bash
# inline
--request-info '[{"path":"shopId","style":2}]'

# 文件
--request-info @request.json

# stdin
doudian-open-cli ... --request-info @- < request.json
```

规则：

1. 非 `@` 开头按 inline JSON 解析。
2. `@-` 从命令 stdin 读取。
3. `@<path>` 从用户显式指定的文件读取。
4. 每项最多 8 MiB，必须是且仅是一个合法 JSON 文档。
5. 树/列表 flags 要求顶层为数组；不得传 `null`、标量或对象。
6. 同一命令最多一个 flag 使用 `@-`，第二次读取在网络请求前失败。
7. CLI 不重排、不 merge、不补写树节点；原始 JSON 通过 `json.RawMessage` 进入请求结构。
8. 未传表示省略字段；显式 inline `[]` 表示发送空数组。

适用 flags：`--request-info`、`--response-info`、`--err-config-list`、`--style-patches`、`--owner-list`、`--auth-subject-ids`。

### 6.4 写操作安全模式

#### save / advance-step

- `--dry-run` 与 `--apply` 互斥。
- 两者都未传时安全默认等价于 `--dry-run`。
- `--dry-run` 向服务端发送 `"dryRun": true`。
- `--apply` 向服务端发送 `"dryRun": false`。
- 不提供 `--no-dry-run`，避免否定式 flag 误操作。
- Skill 强制先执行显式 `--dry-run`，检查 `preview` / `diff` / `errors`，再执行 `--apply`。

#### init / doc

这两个服务端动作没有 dry-run：

- `init` 前必须先运行 `doudian-open-cli djt biz-domain list --output json`，展示动态结果，不得自动选择测试域；随后展示完整确认清单并等待用户明确答复。
- `init` 必须显式传 `--biz-domain-id > 0`、`--confirmed-by-user` 与 `--apply` 才执行；三类门禁错误都返回上述完整操作指引，并在读取凭据和发 HTTP 前失败。
- `doc` 必须显式传 `--apply` 才执行。
- 两者不注册 `--dry-run`。
- `--confirmed-by-user` 与 `--apply` 只是 CLI 本地确认，不进入 HTTP body。
- `doc` 的帮助和 Skill 必须醒目标注“一次调用即落库”。

这套设计让遗漏模式 flag 时 `save` / `advance-step` 只预览，让无预览能力的 `init` / `doc` fail closed；CLI 不再静默选择业务域 15 或任何其他测试域。

## 7. 各命令契约

### 7.0 `biz-domain list`

`doudian-open-cli djt biz-domain list --output json` 固定调用 `GET /api/domain/list`，query 与 body 均为空，复用统一 transport、凭据和 PPE 配置，响应上限为 1 MiB。JSON 原样输出 `{code,message,data}`，包括 `domainInfoList`、`ownerdomainInfoList` 各条目的未知字段。text 按 `domainInfoList` 的服务端顺序逐行输出 `id/name/prefix/available`；`available` 仅按 owner 列表中的 `domainId` 判断，重复或未知 owner 不改变结果，重复 domain 保留顺序，空 `suffixList` 显示 `prefix=-`，空 domain 列表不输出内容。

### 7.1 `get`

```text
doudian-open-cli djt api get \
  (--interface-id <int64> | --interface-name <string> | --interface-name-like <string>)
```

三个定位 flag 必须且只能传一个：

| Flag | HTTP query | 约束 |
|---|---|---|
| `--interface-id` | `interfaceId` | `> 0` |
| `--interface-name` | `interfaceName` | Trim 后非空 |
| `--interface-name-like` | `interfaceNameLike` | Trim 后非空 |

精确查询返回 `data.current`；模糊查询返回 `data.list`。CLI 不猜测多定位字段的服务端优先级。

### 7.2 `init`

```text
doudian-open-cli djt biz-domain list --output json
# 展示动态结果和完整确认清单，等待用户明确答复后：
doudian-open-cli djt api init \
  --psm cmp.ecom.open_admin \
  --method-name TestTemplateInterface \
  --bam-version-id 1.0.340 \
  --biz-domain-id 8 \
  --confirmed-by-user --apply
```

| Flag | 类型 | 必填 | 请求字段 |
|---|---|---:|---|
| `--psm` | string | 是 | `psm` |
| `--method-name` | string | 是 | `methodName` |
| `--bam-version-id` | string | 是 | `bamVersionId` |
| `--interface-id` | int64 | 否 | `interfaceId`，仅重绑 BAM |
| `--interface-name` | string | 否 | `interfaceName` |
| `--biz-domain-id` | int64 | 是 | `bizDomainId`；必须显式传入且 `> 0`，只能在展示动态查询结果后由用户确认选择 |
| `--desc` | string | 否 | `desc` |
| `--scene-desc` | string | 否 | `sceneDesc` |
| `--owner-list` | JSON source(array) | 否 | `ownerList` |
| `--interface-cate-id` | int64 | 否 | `interfaceCateId` |
| `--skip-auth[=bool]` | bool | 否 | `skipAuth` |
| `--confirmed-by-user` | bool | 是 | 本地确认用户已明确答复完整清单，不发送 |
| `--apply` | bool | 是 | 本地确认，不发送 |

`operatorEmail` 只由 BFF 从登录态填写，CLI 永不暴露该 flag。

成功后 Agent 必须保存 `data.fromBam.requestInfo` 和 `responseInfo`；不能用新建后可能为空的 `current` 树替代。`fromBam` 与网页「一键解析入参」同源：`mustNeed` 已按 BAM `optional` 映射，但 **`example` 经常为空**，`description` 也常不完整。CLI 没有单独的 `--example` / `--description` flag；这些字段写在 `--request-info` / `--response-info` 节点上。首次 `save --sections request|response --apply` 前，Agent 必须按 IDL/BAM 注释补齐对外叶子的示例和描述，不能把 fromBam 原样当网页文档。

### 7.3 `save`

```text
doudian-open-cli djt api save \
  --interface-id 2846 \
  --modify-version-id 42 \
  --sections request \
  --request-info @request.json \
  --dry-run
```

控制 flags：

| Flag | 类型 | 必填 | 请求字段 |
|---|---|---:|---|
| `--interface-id` | int64 | 是 | `interfaceId`，`>0` |
| `--modify-version-id` | int64 | 是 | `modifyVersionId`，`>0` |
| `--sections` | string slice | 是 | `sections` |
| `--dry-run` / `--apply` | mode | 否 | `dryRun` |

`--sections` 可重复或逗号分隔，只接受 `basic`、`request`、`response`、`errcode`、`doc`，去重后保留首次出现顺序。包含 `request` / `response` 时，对应 JSON 必须是完整树，而不是 patch。完整树须已含对外叶子的 `example` / `description`（及正确的 `mustNeed`）；只改 style 不够。`save --dry-run` 的 `preview` 未必回显这两列，`--apply` 后以 `get` 为准。

Payload flags：

| Flag | 请求字段 | 类型 |
|---|---|---|
| `--request-info` | `requestInfo` | JSON source(array) |
| `--response-info` | `responseInfo` | JSON source(array) |
| `--err-config-list` | `errConfigList` | JSON source(array) |
| `--style-patches` | `stylePatches` | JSON source(array) |
| `--owner-list` | `ownerList` | JSON source(array) |
| `--auth-subject-ids` | `authSubjectId` | JSON source(array) |

标量 flags 与请求字段一一对应：

```text
--bam-version-id      bamVersionId
--interface-name      interfaceName
--method-name         methodName
--psm                 psm
--desc                desc
--scene-desc          sceneDesc
--interface-cate-id   interfaceCateId
--skip-auth           skipAuth
--sla-rt              slaRt
--sla-ava             slaAva
--qps                 qps
--timeout             timeout
--call-type           callType
--biz-succ-err-code   bizSuccErrCode
--err-code             errCode
--err-msg              errMsg
--release-note         releaseNote
```

可选 scalar 只有 flag 被显式设置时才进入 JSON；因此 `--desc ""` 可以表达清空，未传则表达省略。

### 7.4 `doc`

```text
doudian-open-cli djt api doc \
  --interface-id 2846 \
  --modify-version-id 43 \
  --desc '查询订单' \
  --scene-desc '商家查询单笔订单' \
  --auto-fill=true \
  --apply
```

| Flag | 类型 | 必填 | 请求字段 |
|---|---|---:|---|
| `--interface-id` | int64 | 是 | `interfaceId` |
| `--modify-version-id` | int64 | 是 | `modifyVersionId`，必须 `> 0` |
| `--auto-fill[=bool]` | bool | 否 | `autoFill`；CLI 默认显式发送 `true` |
| `--with-preview-url[=bool]` | bool | 否 | `withPreviewUrl` |
| `--desc` | string | 否 | `desc` |
| `--scene-desc` | string | 否 | `sceneDesc` |
| `--release-note` | string | 否 | `releaseNote` |
| `--request-info` | JSON source(array) | 否 | `requestInfo` |
| `--response-info` | JSON source(array) | 否 | `responseInfo` |
| `--err-config-list` | JSON source(array) | 否 | `errConfigList` |
| `--biz-succ-err-code` | string | 否 | `bizSuccErrCode` |
| `--err-code` | string | 否 | `errCode` |
| `--err-msg` | string | 否 | `errMsg` |
| `--apply` | bool | 是 | 本地确认，不发送 |

不注册 `--dry-run`。未传的树和错误码字段由服务端从 DB 读取。调用成功后仍应重新 `get` 获取新版本。

### 7.5 `advance-step`

```text
doudian-open-cli djt api advance-step \
  --interface-id 2846 \
  --modify-version-id 44 \
  --step submit-audit \
  --audit-reason '首次发布' \
  --audit-meego 'https://project.example/item/1' \
  --dry-run
```

必填控制 flags：

- `--interface-id > 0`
- `--modify-version-id > 0`
- `--step basic|request|response|errcode|ppe|submit-audit|cancel-audit`
- 安全模式 `--dry-run` 或 `--apply`；省略时为 dry-run

可选 payload 与 save 共用：`requestInfo`、`responseInfo`、`errConfigList`、`stylePatches`、`ownerList`、`authSubjectId`、`interfaceName`、`methodName`、`psm`、`desc`、`sceneDesc`、`interfaceCateId`、`skipAuth`、`errCode`、`errMsg`、`bizSuccErrCode`、`releaseNote`。另有：

```text
--audit-reason   auditReason
--audit-meego    auditMeego
--skip-reason    skipReason
```

`step=submit-audit` 时 CLI 要求 `--audit-reason` 非空；`auditMeego` 是否必填继续由服务端根据升级场景权威判断。

执行 POST 前，高层编排必须先调用一次 `get --interface-id`：

1. `current` 缺失时失败；
2. `statusV2 >= 330` 时本地拒绝，不发送 advance POST；
3. 非零 `current.modifyVersionId` 与请求版本不一致时返回本地版本冲突提示；
4. 通过后才调用 `advanceStep`。

预检不能替代服务端并发控制；GET 与 POST 间发生竞争时，服务端 `RemoteError` 仍是最终权威。

## 8. 输入 schema

### 8.1 强类型控制字段

```go
type AgentFieldError struct {
    Field          string `json:"field"`
    Reason         string `json:"reason"`
    Fix            string `json:"fix"`
    SuggestedValue string `json:"suggestedValue,omitempty"`
}

type AgentCurrent struct {
    InterfaceID     int64           `json:"interfaceId"`
    InterfaceName   string          `json:"interfaceName"`
    PSM             string          `json:"psm"`
    MethodName      string          `json:"methodName"`
    ModifyVersionID int64           `json:"modifyVersionId"`
    StatusV2        *int64          `json:"statusV2,omitempty"`
    ConfigPhase     string          `json:"configPhase,omitempty"`
    NextStep        string          `json:"nextStep,omitempty"`
    RequestInfo     json.RawMessage `json:"requestInfo,omitempty"`
    ResponseInfo    json.RawMessage `json:"responseInfo,omitempty"`
    ErrConfigList   json.RawMessage `json:"errConfigList,omitempty"`
}
```

控制字段强类型用于本地校验、状态门禁和 text 摘要；复杂树保留 raw，避免 CLI 复制并落后于庞大的 thrift 节点定义。

### 8.2 请求 raw 字段

Go 请求 DTO 中以下字段使用 `json.RawMessage` + `omitempty`：

- `RequestInfo`
- `ResponseInfo`
- `ErrConfigList`
- `StylePatches`
- `OwnerList`
- `AuthSubjectIDs`

所有 ID、版本、步骤、dry-run、布尔开关和标量配置字段保持具体类型；可选标量使用指针表达“省略”和“显式零值/空值”的区别。

## 9. 输出 schema

### 9.1 JSON 成功输出

五个 action 统一输出：

```json
{
  "code": 0,
  "message": "success",
  "data": {}
}
```

约束：

- 顶层稳定字段固定为 `code`、`message`、`data`。
- stdout 恰好一个文档，不输出 `# summary`、日志或第二段 JSON。
- `data` 保留服务端 Agent 契约的 camelCase 和未知新增字段。
- CLI 用 `json.RawMessage` 保留复杂树，并额外解码强类型 control view；control view 不作为第二份输出。
- 远端 `code != 0` 时 stdout 为空。

典型 get：

```json
{"code":0,"message":"success","data":{"current":{"interfaceId":2846,"modifyVersionId":42,"statusV2":110,"configPhase":"ready_for_ppe_test","nextStep":"doc","requestInfo":[],"responseInfo":[]},"errTypeList":[]}}
```

典型 save dry-run：

```json
{"code":0,"message":"success","data":{"dryRun":true,"applied":false,"current":{"interfaceId":2846,"modifyVersionId":42,"statusV2":30},"preview":{"interfaceId":2846,"modifyVersionId":42,"statusV2":30},"diff":{"requestInfo":{"added":[],"removed":[],"changed":["shopId"]}}}}
```

### 9.2 text 成功输出

text 模式只输出短摘要，不打印完整树：

```text
interfaceId=2846 modifyVersionId=42 statusV2=110 configPhase=ready_for_ppe_test nextStep=doc
```

init/save/doc/advance 追加各自动作控制字段，例如 `applied`、`dryRun`、`autoFilled`、`auditSubmitted`、`tempDocUrl`。需要完整树的 Agent 必须使用 JSON。

### 9.3 失败输出与 `RemoteError`

统一错误类型：

```go
type RemoteError struct {
    HTTPStatus int
    Code       int64
    Message    string
    Errors     []AgentFieldError
    Current    *AgentCurrent
}
```

`errors.As(err, *RemoteError)` 可供命令测试与未来编排检查。`Error()` 生成确定性 stderr 文本：

```text
点将台请求失败: code=8000037 message=版本冲突
- field=modifyVersionId reason=请求版本落后 fix=请用最新版本重试 suggestedValue=43
- current.interfaceId=2846 current.modifyVersionId=43 current.statusV2=110
```

所有远端字符串在进入 `RemoteError` 时调用现有 `sanitize.RemoteMessage`，按当前 token 脱敏并清理 ANSI/C0 控制字符。HTTP 非 2xx、无效 JSON、超限响应和 transport 错误同样返回 error，但不拼接原始 body。`main.go` 保持现状：打印一次到 stderr，退出 1。

## 10. 模块架构

```text
cmd/
├── djt.go                         # 注册 biz-domain 与 agent 资源
├── djt_biz_domain.go              # 动态业务域查询与 text/json 输出
├── djt_agent_interface.go         # 五个 action 的 Cobra 适配、输出
├── djt_agent_interface_flags.go   # flags -> 强类型 request；JSON source 装配
├── root.go                        # Dependencies 增加 Stdin
└── doudian-open-cli/main.go                # 不修改

internal/jsoninput/
└── loader.go                      # inline/@file/@-、8 MiB、单文档和顶层类型

internal/djt/
├── transport.go                   # 固定 origin、headers、PPE、限流读取、envelope、RemoteError
├── client.go                      # PSM 与动态业务域只读客户端（1 MiB 响应上限）
├── agent_interface.go             # 五个端点 DTO 与低层 API client
└── agent_service.go               # advance 预检、330+ 和版本安全门禁
```

依赖方向：

```text
cmd -> internal/jsoninput
cmd -> internal/djt.AgentService -> internal/djt.AgentInterfaceAPI
internal/djt.AgentInterfaceClient -> internal/djt.Transport -> auth.HTTPDoer
internal/djt -> internal/auth（只消费 Credentials/HTTPDoer）
internal/djt -X-> cmd
```

职责：

- `cmd`：Cobra flags、环境变量优先级、凭据加载、stdin、text/json 渲染。
- `jsoninput`：只负责 JSON source，不理解 Agent 领域。
- `Transport`：只负责 HTTP 与 envelope，不理解状态机。
- `AgentInterfaceClient`：只负责批准端点和 DTO，不读取 flags/env。
- `AgentService`：只负责跨请求编排与状态安全，不直接构造 HTTP。

不存在反向依赖、跨层 shortcut 或全局可变状态。

## 11. Transport 设计

### 11.1 请求

```go
type PPEConfig struct {
    Enabled bool
    Env     string
}

type RequestOptions struct {
    Credentials auth.Credentials
    PPE         PPEConfig
}

func (t *Transport) Do(
    ctx context.Context,
    method string,
    path string,
    query url.Values,
    body any,
    options RequestOptions,
) (Envelope, error)
```

- origin 只能来自编译期常量 `djt.Origin`。
- path 只能由包内端点常量传入；不向 Cobra 暴露。
- GET body 必须为 nil；POST 用 `json.Marshal`。
- `Accept: application/json` 始终设置；POST 设置 `Content-Type: application/json`。
- token 只来自已加载且未过期的本地凭据。
- PPE disabled 时两个 PPE headers 都不发送。
- PPE enabled 时两个 headers 必须同时发送。

### 11.2 响应

- Agent Interface 响应最多读取 8 MiB；使用 `io.LimitReader(limit+1)`。
- 顶层必须是一个 JSON 对象，且 `code` 必须存在。
- HTTP 2xx + `code=0` 才是成功。
- 其他情况统一转换为安全错误。
- `data` 使用 `json.RawMessage`；端点 client 再解码 control view。

## 12. 失败模式

| 失败 | 检测层 | 行为 |
|---|---|---|
| 未登录/过期 | cmd | 请求前返回现有 auth error |
| PPE env 非法 | cmd | 凭据/网络前失败 |
| flags 缺失、冲突 | cmd | 网络前失败 |
| JSON source 不存在/超限/非法 | jsoninput | 网络前失败；不回显内容 |
| 两个字段都用 `@-` | jsoninput | 第二个读取前失败 |
| 固定 origin 被绕过 | transport test | 请求 host 断言失败 |
| redirect | 生产 HTTP client | 不跟随；按 HTTP 3xx 失败 |
| HTTP 非 2xx | transport | 安全状态错误，不包含 body/token |
| envelope 非法/缺 code | transport | 协议错误 |
| `code != 0` | transport | `*RemoteError`，stderr/exit 1 |
| 版本冲突 | service/remote | 展示 `suggestedValue` 和 current 版本 |
| statusV2 >= 330 | service | 不发送 advance POST |
| GET/POST 之间并发变化 | 服务端 | RemoteError，重新 get 后重试 |
| stdout 写失败 | output | 返回 error，exit 1 |
| context 取消 | transport | 优先返回 `context.Canceled/DeadlineExceeded` |

## 13. 安全

1. 固定 origin 和禁止 redirect 共同防止认证头外发。
2. PPE env 严格校验，不允许 CR/LF、空白和任意 header 值。
3. JSON 文件只读用户显式路径；不自动扫描目录。
4. Agent JSON 输入与响应均限制 8 MiB，避免无界内存占用。
5. 不记录请求 body，因为树中可能有业务敏感样例。
6. RemoteError 在构造时完成 token 脱敏和终端字符清理。
7. apply 语义必须显式；doc 必须显式 `--apply`，init 还必须先动态查询业务域、等待用户确认并同时传 `--biz-domain-id > 0 --confirmed-by-user --apply`。
8. advance 本地拒绝 330+，Skill 同时明确发布只能走网页。
9. 不暴露任意 URL、path、method、header 或 raw body flag。

## 14. 兼容性

- 现有 auth、PSM、self skill 命令路径和 JSON schema 不变。
- 全局 `--output` 行为不变。
- 固定 origin 行为不变，只把常量收敛到 `internal/djt`。
- Agent 命令是纯新增，不提供旧路径 alias。
- 正式 PPE env 使用 `OPENCLI_DJT_*`；过渡脚本 env 不隐式继承。
- 远端响应新增字段通过 raw `data` 原样保留；删除/改名仍视为上游破坏性变化。
- Skill 仍只有 `skills/djt/SKILL.md` 一个手工源，embed 通过同步脚本生成。

## 15. 测试策略

### 15.1 transport

- 固定 `https://djt.bytedance.net` host/path/query。
- Bearer、Accept、Content-Type。
- PPE enabled/disabled 及非法 env。
- GET/POST body。
- 8 MiB 边界。
- HTTP 3xx/4xx/5xx。
- code 缺失、非法 JSON、业务错误。
- `RemoteError` 的 errors/current/suggestedValue。
- token 与控制字符不泄漏。
- context 取消。

### 15.2 JSON input

- inline、@file、@-。
- 单 stdin 限制。
- 空输入、非法 JSON、多个 JSON、错误顶层、超 8 MiB。
- 文件错误不回显文件内容。

### 15.3 Agent client/service

- 五个方法的 method/path/query/body 精确断言。
- omitted 与显式空/零值语义。
- raw 树字节语义。
- `biz-domain list` 的 method/path/空 query/无 body、camelCase 解码、PPE、1 MiB 上限和业务错误。
- text available 边界：重复/空/null/未知 owner、重复 domain、空 suffix、空 domain 列表；输出保持服务端顺序。
- JSON 中 `domainInfoList` 与 `ownerdomainInfoList` 条目级未知字段原样保留。
- init 的 `bizDomainId` 必须显式传入且 `> 0`；缺失、`0`、负数均在凭据与 HTTP 前失败。
- init 缺 `--apply`、缺 `--confirmed-by-user` 或缺合法业务域时，均返回完整动态查询与确认指引。
- save/advance 默认 dry-run、显式 dry-run、apply、冲突 flags。
- submit-audit auditReason 校验。
- advance 预检；330+ 不发送 POST；版本不一致不发送 POST。
- 并发冲突透传 `RemoteError`。

### 15.4 Cobra/输出

- 命令树与 help。
- 共享 PPE flag/env 优先级。
- 未登录、过期、非法输入均不发 HTTP。
- JSON 成功 stdout 单文档，stderr 为空。
- 失败 stdout 为空，`run` 只向 stderr 打印一次并退出 1。
- `main.go` 无改动回归。

### 15.5 文档/npm

- `skills/djt/SKILL.md` 与 embed 字节一致。
- npm test 断言 Skill 包含五个命令、`--apply`、`--dry-run`、330+ 禁止、固定 origin 与新 PPE env。
- tarball allowlist 和 package 内容保持受控。

## 16. 性能与并发

- 单次 Agent Interface 请求最多分配约 8 MiB 响应缓冲；每个 raw 输入最多 8 MiB。命令是短生命周期工具，不缓存树。
- transport 不持有请求级可变状态，可并发复用。
- `jsoninput.Loader` 的 stdin-used 状态仅属于单次 Cobra action，不跨 goroutine共享；命令当前顺序解析 payload。
- `AgentService` 无共享可变状态。
- advance 多一次 GET，换取 330+ 和版本的客户端前置保护；最终并发正确性仍由服务端乐观锁保证。

## 17. 契约同步范围

变更 Agent Interface 行为时，下列产物须与本文 spec 保持一致：

- `README.md`：命令、PPE、输入语法、输出与安全示例。
- `AGENTS.md`：模块边界、测试门禁、apply/330+ 约束。
- `skills/djt/api.md` 与 `SKILL.md`：Agent 运行 SOP 与命令总览。
- `internal/skill/assets/djt/`：由 `sync-skill.mjs` 生成的 embed 镜像。
- `scripts/npm-package.test.mjs`：npm 包文档契约断言。

CLI 不提供任何业务发布到 330+ 的动作；npm 版本与发布节奏以 `package.json` 为准。

## 18. 风险与缓解

| 风险 | 缓解 |
|---|---|
| 服务端大树字段快速演进 | complex data 用 RawMessage，控制字段强类型 |
| Agent 误 apply | save/advance 默认 dry-run；doc 强制 apply；init 强制动态业务域查询、完整清单确认与 `--confirmed-by-user --apply` |
| 版本冲突 | 预检 + RemoteError.suggestedValue + 重新 get |
| PPE header 注入 | env allowlist 校验 |
| stdout 被错误污染 | main 不改；失败只返回 error；集成测试锁定 |
| 上游返回 HTTP 200 业务错误 | envelope code 是成功判据 |
| raw 输入演变成 raw API | 只允许命名字段和固定端点，不提供 body/method/path flag |
| status 竞争跨过本地检查 | 服务端状态机与乐观锁仍为权威 |
| npm Skill 漏同步 | sync check + Node tarball contract test |

## 19. 开放问题

以下是后续可评估项，不阻塞本期，且本期答案均为“不做”：

1. 是否增加 `doc-auto-fill` 独立命令：不做，优先 `doc --auto-fill`。
2. 是否把 style patch/树校验迁入 Go：不做，先稳定远端契约与 CLI I/O。
3. 是否支持动态 thrift/schema 校验：不做，避免形成 schema engine。
4. 是否支持 raw endpoint 调试：不做，防止绕过安全和领域边界。
5. 是否持久化 dry-run receipt 并要求 apply 携带 hash：不做；本期采用显式模式 + Skill 编排，服务端版本锁兜底。

## 20. 决策记录

| 决策 | 结论 | 原因 |
|---|---|---|
| 命令层级 | `djt api interface action` | 符合 domain/resource/action，作用域清晰 |
| origin | 编译期固定 | 防止认证信息外发，延续仓库约定 |
| PPE 配置 | interface 共享 flags/env | 五个动作一致，避免每个 action 重复 |
| apply 模式 | save/advance 默认 dry-run；doc 强制 apply；init 强制 `--confirmed-by-user --apply` 与正数业务域 | fail closed，贴合服务端能力并禁止自动测试域 |
| 输出 | 成功 envelope 单文档；错误 stderr | Agent 易解析且不破坏 main 约定 |
| 树类型 | RawMessage | 降低复杂 thrift 树复制与漂移成本 |
| 状态字段 | 强类型 | 支持 introspection、门禁和诊断 |
| 330+ | advance 前 GET 并拒绝 | 客户端明确边界，服务端继续兜底 |
| transport/service | 分层 | HTTP 细节与状态编排独立测试、单向依赖 |
| metadata/raw/schema | 本期不引入 | YAGNI，避免扩大攻击面和维护面 |
