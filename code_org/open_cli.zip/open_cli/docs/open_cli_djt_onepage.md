# 点将台 open_cli 架构与内容梳理

> 文档版本：2026-09-20  
> 分析范围：`temai/open_cli`、`temai/open_admin_web`、`temai/open_admin` 默认分支，以及团队知识库与服务拓扑元信息。  
> 目标读者：编码 Agent、研发、架构评审与维护者。

## 摘要

`open_cli` 是点将台面向 Agent 和内部研发的命令行入口。它不承载业务数据，也不复制点将台完整领域模型，而是通过 `https://djt.bytedance.net` 上一组固定 HTTP 契约，把登录、业务域发现、**OpenAPI 接口配置**与 **SPI 场景/接口配置**组织成可解析、可恢复、默认安全的工作流。

系统由三层协作完成：`open_cli` 负责本地交互与安全编排，`cmp.ecom.open_admin_web` 负责 Device Flow、CLI Token 鉴权和 HTTP/RPC 适配，`cmp.ecom.open_admin` 负责配置状态机、持久化、校验与文档能力。OpenAPI 链路依赖 BAM/IDL 绑定与 `modifyVersionId` 乐观锁；SPI 链路以场景、接口草稿和提审状态为核心。CLI 再用 dry-run、apply、用户确认和状态门禁形成前置保护。

**边界结论：**

- **OpenAPI**：CLI 的终点是「提交审核或撤销审核」（`statusV2` 至 310）；审核通过、灰度和全量发布仍必须在点将台网页完成（330+ 不向 CLI 开放）。
- **SPI**：CLI 的终点是「提审到待审核」（status 301）；审核结论、发布与下线留在网页完成。

---

## 一、系统概览

### 1.1 一句话系统定位

**open_cli 是点将台的 Agent-first 操作面：以固定 BFF 契约和结构化输出，把内部 OpenAPI 与 SPI 开放配置从网页手工操作转为可审计、可预览、可恢复的命令工作流。**

### 1.2 4W1H

| 维度 | 结论 |
|---|---|
| What | Go + Cobra CLI；核心对象是点将台 **OpenAPI 接口草稿**（BAM 方法、参数树、文档、测试）与 **SPI 场景/接口**（场景、接入应用、参数树、提审）。 |
| Why | 降低网页多步骤配置成本，使 Agent 能稳定解析结果、处理并发冲突，并把高风险动作锁在显式确认和网页边界内。 |
| Who | 使用者是内部研发和 Agent；接入方是 `cmp.ecom.open_admin_web`；业务维护方是 `cmp.ecom.open_admin`；BAM、文档服务、MySQL、Redis 提供下游能力。 |
| When | 登录、元数据发现、接口/场景初始化与分段配置、环境联调（OpenAPI）、文档完善、提交或撤销审核、SPI 场景创建与提审时触发；CLI 是短生命周期按需命令。 |
| How | CLI 解析参数和本地 JSON，Device Flow 获取身份，经固定 HTTPS 端点调用 BFF；BFF 注入操作人后同步调用 Kitex RPC；业务服务用状态机和版本锁落库。 |

### 1.3 系统全景脑图

```plantuml
@startmindmap
* 点将台 open_cli
** What
*** Agent-first CLI
*** OpenAPI + SPI 配置入口
*** 固定 BFF 契约
** Why
*** 降低网页手工配置成本
*** 让 Agent 可解析、可恢复
*** 用门禁约束高风险写入
** Who
*** 内部研发与 Agent
*** cmp.ecom.open_admin_web
*** cmp.ecom.open_admin
*** BAM / 文档服务 / MySQL / Redis
** When
*** 登录与业务域发现
*** OpenAPI 初始化与分段配置
*** SPI 场景与接口配置
*** BOE/PPE/PROD 联调（OpenAPI）
*** 文档与提审
*** 330+ / 301+ 转网页
** How
*** Cobra 命令树（djt api / djt spi）
*** Device Flow + PKCE
*** AgentService / AgentSPIService
*** modifyVersionId 乐观锁（OpenAPI）
*** dry-run / apply
*** npm + Skill 分发
@endmindmap
```

### 1.4 核心对象

| 对象 | 业务含义 | 权威来源 |
|---|---|---|
| 接口草稿（OpenAPI） | 尚在点将台配置流程中的接口版本 | `interface_template_info` |
| 接口元信息（OpenAPI） | 对外接口路径、PSM、Method、状态、SLA 与负责人等主数据 | `interface_meta_info` |
| 环境配置（OpenAPI） | BOE/PPE/PROD 的方法、参数树、错误码、Header 与版本 | `interface_meta_config_info` |
| 测试用例（OpenAPI） | 环境联调请求和响应快照，可反哺文档样例 | `interface_test_case` |
| AgentCurrent（OpenAPI） | CLI 可消费的当前控制视图，含 ID、版本、状态、下一步和参数树 | `cmp.ecom.open_admin` 组装 |
| SPI 场景 | 业务场景容器，关联业务域与待配置 SPI 接口 | SPI 场景表 / 领域服务 |
| SPI 接口草稿 | 场景下的 SPI 接口定义、参数树与生命周期状态 | SPI 模板/接口实体 |
| 接入应用（SPI） | 某应用在场景下的实现接入与 impl URL | SPI 接入关系 |
| Device Flow 会话 | `device_code`、用户确认状态、过期时间等短期认证状态 | `open_admin_web` 的 Redis |
| 本地凭据 | access token、用户身份、过期时间 | 用户配置目录下 `credentials.json`，0600 |

---

## 二、整体架构

### 2.1 C4 Container

```mermaid
graph TD
    U[Agent / 内部研发] -->|命令调用| CLI[doudian-open-cli]
    U -->|浏览器授权与发布| WEB[点将台网页]
    NPM[BNPM / Skill 目录] -->|二进制与 Skill| CLI

    subgraph LOCAL[本地 CLI]
      CMD[cmd / Cobra]
      API_SVC[AgentService]
      SPI_SVC[AgentSPIService]
      API_CLIENT[AgentInterfaceClient]
      SPI_CLIENT[AgentSPIClient]
      TRANSPORT[Transport]
      AUTH[auth.Service]
      JSON[jsoninput.Loader]
      SKILL[skill Installer]
      CMD --> API_SVC --> API_CLIENT --> TRANSPORT
      CMD --> SPI_SVC --> SPI_CLIENT --> TRANSPORT
      CMD --> AUTH
      CMD --> JSON
      CMD --> SKILL
    end

    CLI --> CMD
    TRANSPORT -->|HTTPS JSON\n固定 Origin 与 Header| BFF[cmp.ecom.open_admin_web]
    AUTH -->|Device Flow| BFF
    BFF -->|Device 会话| REDIS[(Redis)]
    BFF -->|Kitex RPC| ADMIN[cmp.ecom.open_admin]
    ADMIN -->|BAM 版本与 IDL 解析| BAM[BAM / IDL]
    ADMIN -->|临时文档| DOC[open_document_core]
    ADMIN --> MYSQL[(MySQL)]
    WEB --> BFF
```

### 2.2 分层说明

| 层 | 组件 | 核心职责 | 明确不做 |
|---|---|---|---|
| 使用层 | Agent、内部研发、点将台网页 | 发起命令、确认授权、审批后发布 | 不直接操作数据库 |
| CLI 命令层 | `cmd/` | Cobra 命令树（`djt api`、`djt spi`）、flags/env 校验、凭据加载、text/json 输出 | 不实现业务状态机 |
| CLI 领域编排层 | `AgentService`、`AgentSPIService`、`auth.Service` | 版本/状态预检、Device Flow、操作模式控制、SPI 提审本地预检 | 不直接拼 HTTP |
| CLI 协议层 | `AgentInterfaceClient`、`AgentSPIClient`、`Transport` | 固定端点 DTO、Header、envelope、响应上限、脱敏 | 不暴露 raw API |
| BFF 层 | `cmp.ecom.open_admin_web` | Device Flow、SSO/CLI 鉴权、操作人注入、HTTP/RPC 映射 | 不成为业务状态权威 |
| 业务服务层 | `cmp.ecom.open_admin` | OpenAPI/SPI 领域规则、状态推进、版本锁、BAM/IDL、测试与文档 | 不把发布能力开放给 CLI |
| 数据与外部能力层 | MySQL、Redis、BAM、文档服务 | 业务持久化、短期认证状态、IDL 元数据、文档预览 | CLI 不直连这些资源 |

### 2.3 边界与不变量

1. 网络目标固定为 `https://djt.bytedance.net`，不提供 URL、path、method 或 header 覆盖入口。
2. OpenAPI 依赖方向固定为 `cmd -> AgentService -> AgentInterfaceClient -> Transport -> auth.HTTPDoer`；SPI 为 `cmd -> AgentSPIService -> AgentSPIClient -> Transport`。
3. CLI 不保存接口业务状态；成功与否以服务端 envelope 的 `code` 和返回体为准。
4. 写操作默认 dry-run，需显式 `--apply` 才落库；新建类操作另需 `--confirmed-by-user`（OpenAPI init、SPI interface save 新建）。
5. OpenAPI：`statusV2 >= 330` 时 CLI 拒绝推进；SPI：提审后（301+）停止 CLI，审核与发布交网页。
6. 核心链路是同步 HTTP + Kitex RPC + MySQL。当前 Agent 主链未发现 MQ 参与。

---

## 三、核心模块

### 3.1 open_cli

| 模块 | 职责 | 设计亮点 |
|---|---|---|
| `cmd/` | 注册 `djt` 命令域，完成 flags/env 校验、依赖组装、输出适配 | 父命令不执行操作；leaf 使用 `cobra.NoArgs` |
| `internal/auth/` | Device Flow、PKCE、身份查询、本地凭据和可恢复登录会话 | start/complete 两段式适配 Agent |
| `internal/ppe/` | 解析 `--use-ppe`、`--ppe-env` 与环境变量 | flag 优先；环境名 allowlist；PPE Header 成对注入 |
| `internal/djt/transport.go` | 固定 Origin、认证 Header、HTTP、envelope 与 RemoteError | 禁止 redirect；响应 8 MiB；远端消息脱敏 |
| `internal/djt/agent_interface.go` | OpenAPI 五个 Agent Interface 端点 DTO 与低层客户端 | 控制字段强类型，参数树用 `json.RawMessage` |
| `internal/djt/agent_service.go` | OpenAPI 跨请求状态、版本与安全编排 | advance 前 GET 预检；拒绝 330+ |
| `internal/djt/agent_spi.go` | SPI Agent 端点 DTO 与低层 `AgentSPIClient` | 场景、接口、接入、提审、撤销升级 |
| `internal/djt/agent_spi_service.go` | SPI 高层编排 | submit-review 本地预检；不直接构造 HTTP |
| `cmd/djt_spi.go` 等 | SPI Cobra 命令树（`scene`、`interface`） | 与 `djt api` 同级，共用 auth/biz-domain/PPE |
| `internal/djt/api_testing.go` | BOE/PPE/PROD 测试与授权主体添加（OpenAPI） | no-auth 接口可不传授权主体 |
| `internal/jsoninput/` | inline、`@file`、`@-` JSON 输入 | 每项 8 MiB、数组顶层 |
| `internal/skill/` | Skill 安装、状态检查与更新 | 固定目标、原子替换、保留未知用户文件 |
| `skills/djt/scripts/json_to_spi_param_tree.py` | JSON 示例转 SPI 参数树（离线） | 不联网；结果仍须经 CLI dry-run 校验 |
| npm 脚本 | 四平台交叉编译、allowlist 打包、发布门禁 | Skill 唯一源与 embed 镜像字节一致性校验 |

### 3.2 open_admin_web

`cmp.ecom.open_admin_web` 是 CLI 的唯一网络入口，承担协议适配和认证边界。

- Device Flow：`start` 与 `token` 匿名可访问；`confirm`、`approve`、`deny` 依赖网页 SSO。
- CLI Bearer：`/api/djt-cli/agent/*` 必须使用 `X-DJT-CLI-Authorization: Bearer <token>`。
- 兼容入口：`/api/domain/list` 和 `/api/user/getLoginUser` 在携带 CLI Header 时走 CLI Token 鉴权。
- 身份注入：BFF 从登录态补充 `operatorEmail`，CLI 不允许伪造该参数。
- RPC 适配：HTTP handler 将请求转换为 Kitex DTO，同步调用 `cmp.ecom.open_admin`。
- Redis：保存 Device Flow 会话；不是接口配置的业务数据库。

### 3.3 open_admin

`cmp.ecom.open_admin` 是配置的业务权威，分 **OpenAPI Agent Interface** 与 **SPI Agent** 两套 RPC。

**OpenAPI（`djt_cli_agent`）**

- `AgentGetInterface` / `AgentInitInterface` / `AgentSaveInterface` / `AgentSaveDoc` / `AgentAdvanceInterfaceStep`
- BAM 绑定、参数树解析、分段保存、文档自动填充、状态机推进
- `TestApiForTestUtil` / `AddTestAuth`：环境测试与测试授权

**SPI（`djt_cli_agent_spi`）**

- 场景：`AgentSpiSceneList/Get/Save`、`AgentSpiSceneSyncBoe`
- 接口：`AgentSpiListInterface`、`AgentSpiGetInterface`、`AgentSpiSaveInterface`、`AgentSpiSubmitReview`、`AgentSpiCancelUpgrade`
- 接入：`AgentSpiAccessAppList/Get/Save/Enable`
- 严格字段校验、跨场景同名绑定防护、权限与网页对齐

### 3.4 模块与接口关系

```mermaid
graph LR
    CMD[cmd/Cobra] --> API_SVC[AgentService]
    CMD --> SPI_SVC[AgentSPIService]
    CMD --> JSON[jsoninput.Loader]
    CMD --> AUTH[auth.Service]
    API_SVC --> AIC[AgentInterfaceClient]
    SPI_SVC --> ASC[AgentSPIClient]
    AIC --> TR[Transport]
    ASC --> TR
    TR --> BFF[open_admin_web]
    BFF --> RPC[open_admin RPC]
    RPC --> DB[(MySQL)]
    RPC --> BAM[BAM / IDL]
    RPC --> DOC[open_document_core]
```

---

## 四、接口与交互

### 4.1 CLI 命令清单

**共享基础**

| 命令 | 核心输入 | 核心输出 | 写入语义 |
|---|---|---|---|
| `djt auth login start/complete` | PKCE、恢复 session | 授权 URL、用户身份 | 成功后写 credentials |
| `djt auth status/whoami/logout` | 本地凭据 | 登录状态 | status/whoami 只读 |
| `djt biz-domain list/apply` | 域 ID 列表（apply） | 业务域列表 / 审批 URL | list 只读；apply 提交审批 |
| `djt self skill install/status/update` | 固定 Agent 目标 | 各目标状态 | install/update 原子写 |
| `djt version` | 无 | CLI 版本 | 只读 |

**OpenAPI（`djt api`）**

| 命令 | 核心输入 | 核心输出 | 写入语义 |
|---|---|---|---|
| `djt api get` | ID、精确名、模糊名三选一 | `current` 或 `list` | 只读 |
| `djt api init` | PSM、Method、BAM 版本、业务域等 | `fromBam`、`current` | 无 dry-run；必须确认并 apply |
| `djt api save` | ID、版本、sections、payload | preview、diff、current | 默认 dry-run |
| `djt api doc` | ID、版本、描述、参数树等 | current、autoFilled、tempDocUrl | 调用即落库；必须 apply |
| `djt api advance-step` | ID、版本、step | preview/current | 默认 dry-run |
| `djt api test boe/ppe/prod` | 接口名、环境、lane | 调用结果 | 执行真实环境测试 |
| `djt api test auth add` | authId、authSubjectBizId、env | 授权结果 | 添加测试授权主体 |

**SPI（`djt spi`）**

| 命令 | 核心输入 | 核心输出 | 写入语义 |
|---|---|---|---|
| `djt spi scene list/get` | 场景 ID 或过滤条件 | 场景列表/详情 | 只读 |
| `djt spi scene save` | 名称、描述、业务域 | preview/current | 默认 dry-run；创建场景 |
| `djt spi scene sync-boe` | 场景 ID | 同步结果 | 可选 BOE 同步 |
| `djt spi scene access-app list/get` | 场景 ID、authId 或 appId | 接入列表/详情（含 impl URL） | 只读 |
| `djt spi scene access-app save/enable` | 场景、应用 ID | preview/current | 默认 dry-run；enable 显式 apply |
| `djt spi interface list` | name-like、scene-id、分页 | 接口摘要列表 | 只读 |
| `djt spi interface get` | interface-id 或 interface-name | 完整配置树 | 只读 |
| `djt spi interface save` | 版本、参数树、headers 等 | preview/errors、current | 默认 dry-run；新建需 confirmed-by-user |
| `djt spi interface submit-review` | interface-id、modifyVersionId | 提审结果 | 默认 dry-run；apply 后到 301 |
| `djt spi interface cancel-upgrade` | interface-id | 撤销结果 | 仅 status=201；默认 dry-run |

PPE 联调在 `djt api` 或 `djt spi` **父命令**上挂 `--use-ppe --ppe-env`，不是 leaf 子命令。

### 4.2 HTTP 接口清单

**OpenAPI Agent Interface**

| 方法 | 路径 | 下游 RPC |
|---|---|---|
| GET | `/api/djt-cli/agent/interface/get` | `AgentGetInterface` |
| POST | `/api/djt-cli/agent/interface/init` | `AgentInitInterface` |
| POST | `/api/djt-cli/agent/interface/save` | `AgentSaveInterface` |
| POST | `/api/djt-cli/agent/interface/doc` | `AgentSaveDoc` |
| POST | `/api/djt-cli/agent/interface/advanceStep` | `AgentAdvanceInterfaceStep` |
| POST | `/api/djt-cli/agent/api-test/execute` | `TestApiForTestUtil` |
| POST | `/api/djt-cli/agent/api-test/auth/add` | `AddTestAuth` |

**SPI Agent**

| 方法 | 路径 | 下游 RPC |
|---|---|---|
| GET | `/api/djt-cli/agent/spi/scene/list` | `AgentSpiSceneList` |
| GET | `/api/djt-cli/agent/spi/scene/get` | `AgentSpiSceneGet` |
| POST | `/api/djt-cli/agent/spi/scene/save` | `AgentSpiSceneSave` |
| POST | `/api/djt-cli/agent/spi/scene/sync-boe` | `AgentSpiSceneSyncBoe` |
| GET | `/api/djt-cli/agent/spi/scene/access-app/list` | `AgentSpiAccessAppList` |
| GET | `/api/djt-cli/agent/spi/scene/access-app/get` | `AgentSpiAccessAppGet` |
| POST | `/api/djt-cli/agent/spi/scene/access-app/save` | `AgentSpiAccessAppSave` |
| POST | `/api/djt-cli/agent/spi/scene/access-app/enable` | `AgentSpiAccessAppEnable` |
| GET | `/api/djt-cli/agent/spi/interface/list` | `AgentSpiListInterface` |
| GET | `/api/djt-cli/agent/spi/interface/get` | `AgentSpiGetInterface` |
| POST | `/api/djt-cli/agent/spi/interface/save` | `AgentSpiSaveInterface` |
| POST | `/api/djt-cli/agent/spi/interface/submit-review` | `AgentSpiSubmitReview` |
| POST | `/api/djt-cli/agent/spi/interface/cancel-upgrade` | `AgentSpiCancelUpgrade` |

**认证与公共**

| 方法 | 路径 | 说明 |
|---|---|---|
| POST | `/api/djt-cli/device/start` | Device Flow 发起 |
| POST | `/api/djt-cli/device/token` | Device Flow 换 token |
| GET | `/api/user/getLoginUser` | 当前用户（CLI Header） |
| GET | `/api/domain/list` | 动态业务域列表 |

### 4.3 HTTP envelope 与错误恢复

成功响应固定为 `{code,message,data}`。HTTP 2xx 但 `code != 0` 仍是业务失败；CLI 将其转换为 `RemoteError`，保留字段级 `errors` 和最新 `current`，但不把失败 JSON 写入 stdout。

常见恢复策略：

- **OpenAPI** `modifyVersionId` 冲突：重新 get，使用最新版本重做 dry-run，再 apply。
- **OpenAPI** `statusV2 >= 330`：停止 CLI 推进，转点将台网页。
- **SPI** 校验失败：按 `data.errors[].fix` 修正后重试 dry-run。
- **SPI** 提审后（301+）：停止 CLI，审核交网页。
- Device Flow `authorization_pending` / `slow_down` / `expired_token`：按协议等待或重新 start。

### 4.4 核心业务时序

**OpenAPI 配置主链**

```mermaid
sequenceDiagram
    actor U as Agent/研发
    participant C as open_cli
    participant W as open_admin_web
    participant A as open_admin

    U->>C: auth login
    C->>W: Device Flow
    C->>W: GET /domain/list
    U->>C: 确认 init
    C->>W: POST /interface/init
    W->>A: AgentInitInterface
    C->>W: POST /save dryRun=true
    U->>C: apply
    C->>W: POST /save dryRun=false
    C->>W: POST /doc --apply
    C->>W: POST /advanceStep submit-audit
    Note over C,A: statusV2 >= 330 时 CLI 拒绝推进
```

**SPI 配置主链**

```mermaid
sequenceDiagram
    actor U as Agent/研发
    participant C as open_cli
    participant W as open_admin_web
    participant A as open_admin

    U->>C: auth + biz-domain list
    C->>W: POST /spi/scene/save --apply
    W->>A: AgentSpiSceneSave
    Note over C: json_to_spi_param_tree.py（本地）
    C->>W: POST /spi/interface/save dryRun=true
    W->>A: AgentSpiSaveInterface
    U->>C: apply
    C->>W: POST /spi/interface/save dryRun=false
    C->>W: POST /spi/interface/submit-review --apply
    W->>A: AgentSpiSubmitReview
    Note over C,A: status 301+ 后 CLI 停止，审核交网页
```

### 4.5 域外交互、鉴权与限流

| 对象 | 协议 | 用途 | 安全/一致性 |
|---|---|---|---|
| 浏览器 SSO | HTTPS + Cookie | Device Flow 授权、审核后发布 | CLI 不向浏览器注入认证 Header |
| BAM / IDL | 内部服务调用 | OpenAPI PSM/Method/Version 绑定与参数树 | init 候选须用户确认 |
| open_document_core | Kitex RPC | OpenAPI 临时文档预览 | 预览失败可恢复 |
| MySQL | DAO/GORM | 业务持久化 | OpenAPI 乐观锁；SPI 状态由服务端规则检查 |
| Redis | BFF 侧缓存 | Device Flow 短期会话 | 过期后清理本地 login-session |
| PPE Header | HTTP Header | CLI 请求路由到指定泳道 | `x-use-ppe` 与 `x-tt-env` 成对出现 |

---

## 五、数据模型与流转

### 5.1 OpenAPI 数据流（概要）

```mermaid
graph LR
    DISCOVER[发现 PSM/Method/Version] --> CONFIRM[查询业务域并确认]
    CONFIRM --> INIT[init 创建草稿]
    INIT --> PARSE[BAM/IDL 解析参数树]
    PARSE --> SAVE[save 分段配置]
    SAVE --> TEST[BOE/PPE/PROD 测试]
    TEST --> DOC[doc 自动填充]
    DOC --> AUDIT[submit-audit 至 310]
    AUDIT --> WEB[网页审核与发布]
```

核心实体：`interface_template_info`、`interface_meta_info`、`interface_meta_config_info`、`interface_test_case`。`modify_version` 是 OpenAPI 并发控制核心。

### 5.2 SPI 数据流（概要）

```mermaid
graph LR
    SCENE[scene save 创建场景] --> LIST[interface list/get 定位]
    LIST --> TREE[json_to_spi_param_tree 本地转树]
    TREE --> SAVE[interface save 草稿]
    SAVE --> REVIEW[submit-review 至 301]
    REVIEW --> WEB[网页审核与发布]
    SCENE -.-> ACCESS[access-app 接入可选]
```

SPI 以场景为容器，接口草稿挂在场景下；接入应用记录 impl URL 与实现进度。更新接口不允许改名；跨场景同名绑定由服务端校验拦截。

### 5.3 OpenAPI 状态机（摘要）

BOE 初始化 → 请求/响应/错误码配置 → BOE/PPE Released → 文档完善 → 待提交(300) → 待审核(310) → 审核结果(320/330+) → 网页灰度/全量。

状态值：10–50 配置阶段、100 BOE Released、110 PPE Released、200–300 文档与提交、310 待审核、320 审核失败、330+ 审核成功及后续发布态。CLI 在 330+ 拒绝推进。

### 5.4 SPI 状态机（摘要）

草稿编辑 → 提审待审核(301) → 网页审核与发布。`cancel-upgrade` 仅在升级中(201)可用。CLI 在 301 之后停止。

---

## 六、设计模式与架构决策

### 6.1 设计模式

| 模式 | 应用位置 | 解决的问题 |
|---|---|---|
| 分层架构 | `cmd -> service -> client -> transport` | 隔离交互、业务编排与 HTTP 细节 |
| Ports & Adapters | `HTTPDoer`、`CredentialStore` 等接口 | 测试可注入 fake |
| Facade / Application Service | `AgentService`、`AgentSPIService` | 收敛预检、版本与状态门禁 |
| Typed Control + Raw Payload | 强类型控制字段 + `json.RawMessage` | 可校验且兼容演进中的参数树 |
| Optimistic Concurrency Control | OpenAPI `modifyVersionId` | 防止覆盖并发提交 |
| Fail-closed Command | dry-run/apply、用户确认 | 缺少显式意图时不执行高风险写入 |
| Allowlist | 固定 Origin、固定端点、固定 Skill 目标 | 限制攻击面 |
| Envelope Adapter | `Transport` / `RemoteError` | 统一 HTTP 与业务错误映射 |

### 6.2 关键决策与权衡

| 决策 | 收益 | 代价/限制 | 结论 |
|---|---|---|---|
| 固定生产 Origin | 消除 token 外发风险 | 不能随意接第三方地址 | PPE 通过受控 Header |
| 不做 raw API | 行为可审计 | 调试灵活性低 | 高风险写链路必须受控 |
| OpenAPI 与 SPI 同级命令域 | Agent 统一入口与 Skill 结构 | 两套状态机须分别理解 | `api.md` / `spi.md` 分文档 |
| SPI 本地脚本只做树转换 | 不联网、不替代服务端校验 | 仍须 CLI dry-run | `json_to_spi_param_tree.py` |
| npm + 内置 Skill | Agent 无需 Go 环境 | 发布需二进制与文档一致 | release gate 校验 |

### 6.3 非功能性特征

| 维度 | 当前设计 |
|---|---|
| 安全 | 固定 Origin、禁止 redirect、PPE 校验、脱敏、凭据 0600 |
| 可用性 | Device Flow 可恢复、RemoteError 含 fix 提示、dry-run 展示 diff |
| 可维护性 | 单向依赖、Skill 单一源、embed 镜像校验 |
| 测试性 | HTTP/文件可注入；Go/Node/race/vet/build/npm pack 多层门禁 |

---

## 七、Q&A

### Q1：open_cli 是 open_admin 的另一个客户端，还是独立业务系统？

它是受控客户端，不是业务权威。CLI 提供 Agent 友好的命令与前置安全编排，状态、版本、权限和落库规则仍由 `cmp.ecom.open_admin` 决定。

### Q2：为什么不直接调用 open_admin RPC？

BFF 统一处理 Device Flow、CLI Token、SSO 兼容、PPE Header 和 `operatorEmail` 注入。让 CLI 直接访问 RPC 会扩大身份边界。

### Q3：OpenAPI 与 SPI 有什么区别？

OpenAPI 面向开放 API 接口，依赖 BAM/IDL 绑定，状态机到 310 提审、330+ 发布；SPI 面向店铺 SPI 场景与接口，以场景为容器，提审到 301 后交网页。两者共用登录、业务域与 BFF，命令域分别为 `djt api` 与 `djt spi`。

### Q4：为什么 save/advance 默认 dry-run，doc 却没有？

服务端 save/advance 原生支持 `dryRun`，doc 不支持。CLI 对 doc 采用 fail-closed：没有 `--apply` 就不调用。

### Q5：CLI 能完成发布吗？

不能。OpenAPI 在 `statusV2 >= 330` 停止；SPI 在提审后（301+）停止。灰度、生产与审核结论必须在网页完成。

### Q6：SPI 参数树怎么准备？

可用 `skills/djt/scripts/json_to_spi_param_tree.py` 把 JSON 示例转为字段树，再补必填/加密/Map/Header，最后经 `interface save --dry-run` 由服务端校验。脚本不联网，不能替代 dry-run。

### Q7：新增命令时最容易漏什么？

除 Go 代码和测试外，须同步 `skills/djt/`（`SKILL.md`、`api.md` 或 `spi.md`）、embed 镜像和 npm 契约测试；端点 allowlist 与 stdout/stderr 契约不能被破坏。

---

## 附录：仓库与关键代码索引

### open_cli

- `cmd/doudian-open-cli/main.go`：进程入口
- `cmd/djt_spi.go`：SPI 命令树
- `internal/djt/agent_interface.go`、`agent_service.go`：OpenAPI Agent
- `internal/djt/agent_spi.go`、`agent_spi_service.go`：SPI Agent
- `internal/djt/transport.go`：固定网络边界
- `internal/auth/`、`internal/skill/`、`skills/djt/`：认证与 Skill
- `scripts/release-npm.mjs`：npm 发布门禁

### open_admin_web

- `router.go`、`middleware/djt_cli_auth.go`：路由与 CLI 鉴权
- `biz/handler/agent_*`：OpenAPI HTTP → RPC
- `biz/handler/agent_spi_*`：SPI HTTP → RPC

### open_admin

- `biz/service/djt_cli_agent/`：OpenAPI Agent 业务
- `biz/service/djt_cli_agent_spi/`：SPI Agent 业务
- `biz/service/interface_info/spi.go`：SPI 领域逻辑（网页与 Agent 共用）

## 详细规格

子域设计规格见 `docs/spec/`（spec coding：只含设计，不含实施计划）：`agent-interface.md`、`djt-cli-spi-agent.md`、`djt-fixed-baseurl-and-psm.md`、`npm-skill-distribution.md`、`djt-cli-demo.md`。Agent 实操仍以 `skills/djt/` 为准；迭代时先改 spec，再改代码。

## 参考资料

- [点将台 OpenCLI OnePage](https://bytedance.larkoffice.com/wiki/YqJ2wWOX7iE2PQk4Xu0cCAcrnHd)
- [店铺 SPI 场景默认应用逻辑架构与内容梳理](https://bytedance.larkoffice.com/docx/MqiDdk7W5oSZ2ixAYe3c4z6xnjf)
- [开放平台 Oncall 指南 - 对内](https://bytedance.larkoffice.com/docx/AnPedvv4GoR4Nhx2Ir4cRLNKnae)
