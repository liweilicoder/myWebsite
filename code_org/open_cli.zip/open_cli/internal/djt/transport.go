package djt

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"

	"code.byted.org/temai/open_cli/internal/core/identity"
	"code.byted.org/temai/open_cli/internal/core/jsonenc"
	"code.byted.org/temai/open_cli/internal/core/ppe"
	"code.byted.org/temai/open_cli/internal/core/sanitize"
	"code.byted.org/temai/open_cli/internal/djt/auth"
)

const Origin = "https://djt.bytedance.net"
const MaxResponseBytes = 8 << 20
const AuthorizationHeader = "X-DJT-CLI-Authorization"

type PPEConfig = ppe.Config

type RequestOptions struct {
	Credentials auth.Credentials
	PPE         PPEConfig
}

type AgentFieldError struct {
	Field          string  `json:"field"`
	Reason         string  `json:"reason"`
	Fix            string  `json:"fix"`
	SuggestedValue *string `json:"suggestedValue,omitempty"`
}

type AgentCurrent struct {
	InterfaceID           int64                   `json:"interfaceId"`
	InterfaceName         string                  `json:"interfaceName"`
	PSM                   string                  `json:"psm"`
	MethodName            string                  `json:"methodName"`
	BoundBAMVersionID     *string                 `json:"boundBamVersionId,omitempty"`
	ModifyVersionID       int64                   `json:"modifyVersionId"`
	StatusV2              *int32                  `json:"statusV2,omitempty"`
	ConfigURL             string                  `json:"configUrl"`
	RequestInfo           json.RawMessage         `json:"requestInfo"`
	ResponseInfo          json.RawMessage         `json:"responseInfo"`
	ErrConfigList         json.RawMessage         `json:"errConfigList,omitempty"`
	Owners                []string                `json:"owners"`
	AuthSubjectIDs        []int32                 `json:"authSubjectId,omitempty"`
	BizDomainID           int64                   `json:"bizDomainId"`
	RequestStyleIndex     *AgentRequestStyleIndex `json:"requestStyleIndex,omitempty"`
	ConfigPhase           *string                 `json:"configPhase,omitempty"`
	IsOldInterface        *bool                   `json:"isOldInterface,omitempty"`
	ReservedInnerVarNames []string                `json:"reservedInnerVarNames,omitempty"`
	ErrCode               *string                 `json:"errCode,omitempty"`
	ErrMsg                *string                 `json:"errMsg,omitempty"`
	BizSuccErrCode        *string                 `json:"bizSuccErrCode,omitempty"`
	Desc                  *string                 `json:"desc,omitempty"`
	SceneDesc             *string                 `json:"sceneDesc,omitempty"`
	ReleaseNote           *string                 `json:"releaseNote,omitempty"`
	NextStep              *string                 `json:"nextStep,omitempty"`
}

type Envelope struct {
	Code    int64             `json:"code"`
	Message string            `json:"message"`
	Data    json.RawMessage   `json:"data"`
	Errors  []AgentFieldError `json:"errors,omitempty"`
}

type RemoteError struct {
	HTTPStatus int
	Code       int64
	Message    string
	Errors     []AgentFieldError
	Current    *AgentCurrent
}

func (e *RemoteError) Error() string {
	var message strings.Builder
	fmt.Fprintf(&message, "点将台请求失败: code=%d message=%s", e.Code, e.Message)
	for _, fieldError := range e.Errors {
		fmt.Fprintf(&message, "\n- field=%s reason=%s fix=%s", fieldError.Field, fieldError.Reason, fieldError.Fix)
		if fieldError.SuggestedValue != nil {
			fmt.Fprintf(&message, " suggestedValue=%s", *fieldError.SuggestedValue)
		}
	}
	if e.Current != nil {
		fmt.Fprintf(
			&message,
			"\n- current.interfaceId=%d current.modifyVersionId=%d",
			e.Current.InterfaceID,
			e.Current.ModifyVersionID,
		)
		if e.Current.StatusV2 != nil {
			fmt.Fprintf(&message, " current.statusV2=%d", *e.Current.StatusV2)
		}
	}
	return message.String()
}

type Transport struct {
	http             auth.HTTPDoer
	maxResponseBytes int64
}

func NewTransport(httpClient auth.HTTPDoer) *Transport {
	return newTransport(httpClient, MaxResponseBytes)
}

func newTransport(httpClient auth.HTTPDoer, maxResponseBytes int64) *Transport {
	return &Transport{http: httpClient, maxResponseBytes: maxResponseBytes}
}

type wireEnvelope struct {
	Code    *int64            `json:"code"`
	Message string            `json:"message"`
	Data    json.RawMessage   `json:"data"`
	Errors  []AgentFieldError `json:"errors,omitempty"`
}

func (t *Transport) Do(
	ctx context.Context,
	method string,
	path string,
	query url.Values,
	body any,
	options RequestOptions,
) (Envelope, error) {
	requestURL, err := buildRequestURL(path, query)
	if err != nil {
		return Envelope{}, err
	}

	var requestBody io.Reader
	switch method {
	case http.MethodGet:
		if body != nil {
			return Envelope{}, errors.New("GET 请求不能包含 body")
		}
	case http.MethodPost:
		payload, marshalErr := json.Marshal(body)
		if marshalErr != nil {
			return Envelope{}, errors.New("编码点将台请求失败")
		}
		requestBody = bytes.NewReader(payload)
	default:
		return Envelope{}, fmt.Errorf("不支持的 HTTP method %q", method)
	}

	request, err := http.NewRequestWithContext(ctx, method, requestURL.String(), requestBody)
	if err != nil {
		return Envelope{}, errors.New("创建点将台请求失败")
	}
	request.Header.Set("Accept", "application/json")
	request.Header.Set(AuthorizationHeader, authorizationValue(options.Credentials))
	identity.Apply(request.Header)
	if method == http.MethodPost {
		request.Header.Set("Content-Type", "application/json")
	}
	if err := options.PPE.Apply(request.Header); err != nil {
		return Envelope{}, err
	}

	if t == nil || t.http == nil {
		return Envelope{}, errors.New("点将台 HTTP client 未配置")
	}
	response, err := t.http.Do(request)
	if err != nil {
		if ctxErr := ctx.Err(); ctxErr != nil {
			return Envelope{}, ctxErr
		}
		return Envelope{}, errors.New("点将台请求失败")
	}
	if response == nil {
		return Envelope{}, errors.New("点将台请求返回空响应")
	}
	defer response.Body.Close()

	if response.StatusCode < http.StatusOK || response.StatusCode >= http.StatusMultipleChoices {
		return Envelope{}, fmt.Errorf("点将台请求返回 HTTP %d", response.StatusCode)
	}

	data, err := readResponse(response.Body, t.maxResponseBytes)
	if err != nil {
		if ctxErr := ctx.Err(); ctxErr != nil {
			return Envelope{}, ctxErr
		}
		return Envelope{}, err
	}
	var wire wireEnvelope
	if err := json.Unmarshal(data, &wire); err != nil {
		return Envelope{}, errors.New("解析点将台响应失败")
	}
	if wire.Code == nil {
		return Envelope{}, errors.New("点将台响应缺少 code")
	}

	envelope := Envelope{
		Code:    *wire.Code,
		Message: sanitize.RemoteMessage(wire.Message, options.Credentials.AccessToken),
		Data:    wire.Data,
		Errors:  sanitizeFieldErrors(wire.Errors, options.Credentials.AccessToken),
	}
	if envelope.Code == 0 {
		envelope.Data, err = redactTokenFromJSON(envelope.Data, options.Credentials.AccessToken)
		if err != nil {
			return Envelope{}, err
		}
		return envelope, nil
	}

	remote := &RemoteError{
		HTTPStatus: response.StatusCode,
		Code:       envelope.Code,
		Message:    envelope.Message,
		Errors:     envelope.Errors,
	}
	if len(envelope.Data) != 0 && string(envelope.Data) != "null" {
		var remoteData struct {
			Current *AgentCurrent `json:"current"`
		}
		if err := json.Unmarshal(envelope.Data, &remoteData); err != nil {
			return Envelope{}, errors.New("解析点将台错误响应失败")
		}
		remote.Current = sanitizeCurrent(remoteData.Current, options.Credentials.AccessToken)
	}
	return Envelope{}, remote
}

func buildRequestURL(path string, query url.Values) (*url.URL, error) {
	if !strings.HasPrefix(path, "/api/") {
		return nil, errors.New("点将台请求 path 必须是以 /api/ 开头的相对路径")
	}
	requestURL, err := url.Parse(Origin)
	if err != nil {
		return nil, errors.New("解析点将台固定 origin 失败")
	}
	requestURL.Path = path
	requestURL.RawQuery = query.Encode()
	return requestURL, nil
}

func authorizationValue(credentials auth.Credentials) string {
	if credentials.TokenType == "" {
		return credentials.AccessToken
	}
	return credentials.TokenType + " " + credentials.AccessToken
}

func readResponse(reader io.Reader, maxBytes int64) ([]byte, error) {
	if reader == nil {
		return nil, errors.New("读取点将台响应失败")
	}
	data, err := io.ReadAll(io.LimitReader(reader, maxBytes+1))
	if err != nil {
		return nil, errors.New("读取点将台响应失败")
	}
	if int64(len(data)) > maxBytes {
		return nil, fmt.Errorf("点将台响应体超过 %d MiB", maxBytes/(1<<20))
	}
	return data, nil
}

func redactTokenFromJSON(value json.RawMessage, token string) (json.RawMessage, error) {
	if len(value) == 0 || token == "" {
		return value, nil
	}
	decoder := json.NewDecoder(bytes.NewReader(value))
	decoder.UseNumber()
	var decoded any
	if err := decoder.Decode(&decoded); err != nil {
		return nil, errors.New("解析点将台成功响应 data 失败")
	}
	redacted, err := jsonenc.Marshal(redactTokenFromJSONValue(decoded, token))
	if err != nil {
		return nil, errors.New("编码点将台成功响应 data 失败")
	}
	return json.RawMessage(redacted), nil
}

func redactTokenFromJSONValue(value any, token string) any {
	switch typed := value.(type) {
	case string:
		return strings.ReplaceAll(typed, token, "[REDACTED]")
	case []any:
		result := make([]any, len(typed))
		for i, item := range typed {
			result[i] = redactTokenFromJSONValue(item, token)
		}
		return result
	case map[string]any:
		result := make(map[string]any, len(typed))
		for key, item := range typed {
			result[strings.ReplaceAll(key, token, "[REDACTED]")] = redactTokenFromJSONValue(item, token)
		}
		return result
	default:
		return value
	}
}

func sanitizeFieldErrors(fieldErrors []AgentFieldError, token string) []AgentFieldError {
	if fieldErrors == nil {
		return nil
	}
	result := make([]AgentFieldError, len(fieldErrors))
	for i, fieldError := range fieldErrors {
		result[i] = AgentFieldError{
			Field:          sanitize.RemoteMessage(fieldError.Field, token),
			Reason:         sanitize.RemoteMessage(fieldError.Reason, token),
			Fix:            sanitize.RemoteMessage(fieldError.Fix, token),
			SuggestedValue: sanitizeOptionalRemoteMessage(fieldError.SuggestedValue, token),
		}
	}
	return result
}

func sanitizeCurrent(current *AgentCurrent, token string) *AgentCurrent {
	if current == nil {
		return nil
	}
	result := *current
	result.InterfaceName = sanitize.RemoteMessage(result.InterfaceName, token)
	result.PSM = sanitize.RemoteMessage(result.PSM, token)
	result.MethodName = sanitize.RemoteMessage(result.MethodName, token)
	result.BoundBAMVersionID = sanitizeOptionalRemoteMessage(result.BoundBAMVersionID, token)
	result.ConfigURL = sanitize.RemoteMessage(result.ConfigURL, token)
	result.RequestInfo = sanitizeRawMessage(result.RequestInfo, token)
	result.ResponseInfo = sanitizeRawMessage(result.ResponseInfo, token)
	result.ErrConfigList = sanitizeRawMessage(result.ErrConfigList, token)
	result.Owners = sanitizeRemoteMessages(result.Owners, token)
	result.RequestStyleIndex = sanitizeRequestStyleIndex(result.RequestStyleIndex, token)
	result.ConfigPhase = sanitizeOptionalRemoteMessage(result.ConfigPhase, token)
	result.ReservedInnerVarNames = sanitizeRemoteMessages(result.ReservedInnerVarNames, token)
	result.ErrCode = sanitizeOptionalRemoteMessage(result.ErrCode, token)
	result.ErrMsg = sanitizeOptionalRemoteMessage(result.ErrMsg, token)
	result.BizSuccErrCode = sanitizeOptionalRemoteMessage(result.BizSuccErrCode, token)
	result.Desc = sanitizeOptionalRemoteMessage(result.Desc, token)
	result.SceneDesc = sanitizeOptionalRemoteMessage(result.SceneDesc, token)
	result.ReleaseNote = sanitizeOptionalRemoteMessage(result.ReleaseNote, token)
	result.NextStep = sanitizeOptionalRemoteMessage(result.NextStep, token)
	return &result
}

func sanitizeRequestStyleIndex(index *AgentRequestStyleIndex, token string) *AgentRequestStyleIndex {
	if index == nil {
		return nil
	}
	result := *index
	result.External = sanitizeRemoteMessages(result.External, token)
	result.Variable = sanitizeRemoteMessages(result.Variable, token)
	if index.Constant != nil {
		result.Constant = make([]AgentStyleConstantEntry, len(index.Constant))
		for i, entry := range index.Constant {
			result.Constant[i] = AgentStyleConstantEntry{
				Path:          sanitize.RemoteMessage(entry.Path, token),
				ConstantValue: sanitizeOptionalRemoteMessage(entry.ConstantValue, token),
			}
		}
	}
	return &result
}

func sanitizeRemoteMessages(values []string, token string) []string {
	if values == nil {
		return nil
	}
	result := make([]string, len(values))
	for i, value := range values {
		result[i] = sanitize.RemoteMessage(value, token)
	}
	return result
}

func sanitizeRawMessage(value json.RawMessage, token string) json.RawMessage {
	if len(value) == 0 {
		return nil
	}
	decoder := json.NewDecoder(bytes.NewReader(value))
	decoder.UseNumber()
	var decoded any
	if err := decoder.Decode(&decoded); err != nil {
		return marshalSanitizedRawFallback(value, token)
	}
	sanitized, err := jsonenc.Marshal(sanitizeJSONValue(decoded, token))
	if err != nil {
		return marshalSanitizedRawFallback(value, token)
	}
	return json.RawMessage(sanitized)
}

func sanitizeJSONValue(value any, token string) any {
	switch typed := value.(type) {
	case string:
		return sanitize.RemoteMessage(typed, token)
	case []any:
		for i, item := range typed {
			typed[i] = sanitizeJSONValue(item, token)
		}
		return typed
	case map[string]any:
		result := make(map[string]any, len(typed))
		for key, item := range typed {
			result[sanitize.RemoteMessage(key, token)] = sanitizeJSONValue(item, token)
		}
		return result
	default:
		return value
	}
}

func marshalSanitizedRawFallback(value json.RawMessage, token string) json.RawMessage {
	sanitized, _ := jsonenc.Marshal(sanitize.RemoteMessage(string(value), token))
	return json.RawMessage(sanitized)
}

func sanitizeOptionalRemoteMessage(value *string, token string) *string {
	if value == nil {
		return nil
	}
	result := sanitize.RemoteMessage(*value, token)
	return &result
}
