package djt

import (
	"context"
	"encoding/json"
	"io"
	"net/http"
	"testing"
)

func TestAgentSPIClientEndpoints(t *testing.T) {
	tests := []struct {
		name   string
		method string
		path   string
		query  string
		body   string
		call   func(*AgentSPIClient, RequestOptions) error
	}{
		{
			name: "interface get", method: http.MethodGet, path: "/api/djt-cli/agent/spi/interface/get",
			query: "interfaceId=2846&interfaceName=a%2Fb",
			call: func(client *AgentSPIClient, options RequestOptions) error {
				name := "a/b"
				_, err := client.GetInterface(context.Background(), AgentSpiGetInterfaceRequest{
					InterfaceID: agentInt64Pointer(2846), InterfaceName: &name,
				}, options)
				return err
			},
		},
		{
			name: "interface list", method: http.MethodGet, path: "/api/djt-cli/agent/spi/interface/list",
			query: "nameLike=trade&page=1&pageSize=20&sceneId=248",
			call: func(client *AgentSPIClient, options RequestOptions) error {
				nameLike, sceneID := "trade", int64(248)
				page, pageSize := int32(1), int32(20)
				_, err := client.ListInterface(context.Background(), AgentSpiListInterfaceRequest{
					NameLike: &nameLike, SceneID: &sceneID, Page: &page, PageSize: &pageSize,
				}, options)
				return err
			},
		},
		{
			name: "interface save", method: http.MethodPost, path: "/api/djt-cli/agent/spi/interface/save",
			body: `{"interfaceId":2846,"modifyVersionId":42,"dryRun":false,"requestInfo":[{"requestName":"shop_id"}]}`,
			call: func(client *AgentSPIClient, options RequestOptions) error {
				_, err := client.SaveInterface(context.Background(), AgentSpiSaveInterfaceRequest{
					InterfaceID: agentInt64Pointer(2846), ModifyVersionID: agentInt64Pointer(42),
					DryRun: false, RequestInfo: json.RawMessage(`[{"requestName":"shop_id"}]`),
				}, options)
				return err
			},
		},
		{
			name: "submit review", method: http.MethodPost, path: "/api/djt-cli/agent/spi/interface/submit-review",
			body: `{"interfaceId":2846,"modifyVersionId":42,"dryRun":true,"reason":"ready"}`,
			call: func(client *AgentSPIClient, options RequestOptions) error {
				_, err := client.SubmitReview(context.Background(), AgentSpiSubmitReviewRequest{
					InterfaceID: 2846, ModifyVersionID: 42, DryRun: true, Reason: "ready",
				}, options)
				return err
			},
		},
		{
			name: "scene list", method: http.MethodGet, path: "/api/djt-cli/agent/spi/scene/list",
			query: "page=1&pageSize=20&sceneName=trade",
			call: func(client *AgentSPIClient, options RequestOptions) error {
				name, page, pageSize := "trade", int32(1), int32(20)
				_, err := client.SceneList(context.Background(), AgentSpiSceneListRequest{
					SceneName: &name, Page: &page, PageSize: &pageSize,
				}, options)
				return err
			},
		},
		{
			name: "scene get", method: http.MethodGet, path: "/api/djt-cli/agent/spi/scene/get",
			query: "sceneId=7",
			call: func(client *AgentSPIClient, options RequestOptions) error {
				_, err := client.SceneGet(context.Background(), AgentSpiSceneGetRequest{SceneID: agentInt64Pointer(7)}, options)
				return err
			},
		},
		{
			name: "scene save", method: http.MethodPost, path: "/api/djt-cli/agent/spi/scene/save",
			body: `{"dryRun":false,"sceneName":"trade","sceneDesc":"trade APIs","bizDomainId":0}`,
			call: func(client *AgentSPIClient, options RequestOptions) error {
				_, err := client.SceneSave(context.Background(), AgentSpiSceneSaveRequest{
					DryRun: false, SceneName: "trade", SceneDesc: "trade APIs",
				}, options)
				return err
			},
		},
		{
			name: "scene sync boe", method: http.MethodPost, path: "/api/djt-cli/agent/spi/scene/sync-boe",
			body: `{"dryRun":true,"sceneId":7,"appIds":[1,2]}`,
			call: func(client *AgentSPIClient, options RequestOptions) error {
				_, err := client.SyncBoe(context.Background(), AgentSpiSceneSyncBoeRequest{
					DryRun: true, SceneID: 7, AppIDs: []int64{1, 2},
				}, options)
				return err
			},
		},
		{
			name: "access app list", method: http.MethodGet, path: "/api/djt-cli/agent/spi/scene/access-app/list",
			query: "page=1&pageSize=20&sceneId=7",
			call: func(client *AgentSPIClient, options RequestOptions) error {
				page, pageSize := int32(1), int32(20)
				_, err := client.AccessAppList(context.Background(), AgentSpiAccessAppListRequest{
					SceneID: 7, Page: &page, PageSize: &pageSize,
				}, options)
				return err
			},
		},
		{
			name: "access app get", method: http.MethodGet, path: "/api/djt-cli/agent/spi/scene/access-app/get",
			query: "authId=9",
			call: func(client *AgentSPIClient, options RequestOptions) error {
				_, err := client.AccessAppGet(context.Background(), AgentSpiAccessAppGetRequest{AuthID: agentInt64Pointer(9)}, options)
				return err
			},
		},
		{
			name: "access app save", method: http.MethodPost, path: "/api/djt-cli/agent/spi/scene/access-app/save",
			body: `{"dryRun":false,"sceneId":7,"appId":8}`,
			call: func(client *AgentSPIClient, options RequestOptions) error {
				_, err := client.AccessAppSave(context.Background(), AgentSpiAccessAppSaveRequest{
					DryRun: false, SceneID: 7, AppID: 8,
				}, options)
				return err
			},
		},
		{
			name: "access app enable", method: http.MethodPost, path: "/api/djt-cli/agent/spi/scene/access-app/enable",
			body: `{"dryRun":true,"authId":9}`,
			call: func(client *AgentSPIClient, options RequestOptions) error {
				_, err := client.AccessAppEnable(context.Background(), AgentSpiAccessAppEnableRequest{
					DryRun: true, AuthID: 9,
				}, options)
				return err
			},
		},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			doer := httpDoerFunc(func(request *http.Request) (*http.Response, error) {
				if request.Method != test.method {
					t.Errorf("method=%q want=%q", request.Method, test.method)
				}
				if request.URL.Path != test.path {
					t.Errorf("path=%q want=%q", request.URL.Path, test.path)
				}
				if request.URL.RawQuery != test.query {
					t.Errorf("query=%q want=%q", request.URL.RawQuery, test.query)
				}
				var body string
				if request.Body != nil {
					payload, err := io.ReadAll(request.Body)
					if err != nil {
						t.Fatal(err)
					}
					body = string(payload)
				}
				if body != test.body {
					t.Errorf("body=%s want=%s", body, test.body)
				}
				return jsonResponse(http.StatusOK, `{"code":0,"message":"success","data":{}}`), nil
			})
			client := NewAgentSPIClient(NewTransport(doer))
			if err := test.call(client, RequestOptions{Credentials: testCredentials()}); err != nil {
				t.Fatal(err)
			}
		})
	}
}
