package djt

import (
	"context"
	"encoding/json"
	"io"
	"net/http"
	"reflect"
	"strings"
	"testing"
)

func TestAgentInterfaceClientEndpoints(t *testing.T) {
	trueValue := true
	tests := []struct {
		name   string
		method string
		path   string
		query  string
		body   string
		call   func(*AgentInterfaceClient, RequestOptions) error
	}{
		{
			name:   "get",
			method: http.MethodGet,
			path:   "/api/djt-cli/agent/interface/get",
			query:  "interfaceId=2846",
			call: func(client *AgentInterfaceClient, options RequestOptions) error {
				_, err := client.Get(context.Background(), AgentGetRequest{InterfaceID: agentInt64Pointer(2846)}, options)
				return err
			},
		},
		{
			name:   "init",
			method: http.MethodPost,
			path:   "/api/djt-cli/agent/interface/init",
			body:   `{"psm":"cmp.a","methodName":"Get","bamVersionId":"1.0.1"}`,
			call: func(client *AgentInterfaceClient, options RequestOptions) error {
				_, err := client.Init(context.Background(), AgentInitRequest{
					PSM:          "cmp.a",
					MethodName:   "Get",
					BAMVersionID: "1.0.1",
				}, options)
				return err
			},
		},
		{
			name:   "save",
			method: http.MethodPost,
			path:   "/api/djt-cli/agent/interface/save",
			body:   `{"interfaceId":2846,"modifyVersionId":42,"sections":["request"],"dryRun":true,"requestInfo":[{"path":"a"}]}`,
			call: func(client *AgentInterfaceClient, options RequestOptions) error {
				_, err := client.Save(context.Background(), AgentSaveRequest{
					InterfaceID:     2846,
					ModifyVersionID: 42,
					Sections:        []string{"request"},
					DryRun:          &trueValue,
					AgentPayload: AgentPayload{
						RequestInfo: json.RawMessage(`[{"path":"a"}]`),
					},
				}, options)
				return err
			},
		},
		{
			name:   "doc",
			method: http.MethodPost,
			path:   "/api/djt-cli/agent/interface/doc",
			body:   `{"interfaceId":2846,"modifyVersionId":42,"autoFill":true}`,
			call: func(client *AgentInterfaceClient, options RequestOptions) error {
				_, err := client.Doc(context.Background(), AgentDocRequest{
					InterfaceID:     2846,
					ModifyVersionID: 42,
					AutoFill:        agentBoolPointer(true),
				}, options)
				return err
			},
		},
		{
			name:   "advance",
			method: http.MethodPost,
			path:   "/api/djt-cli/agent/interface/advanceStep",
			body:   `{"interfaceId":2846,"modifyVersionId":42,"step":"request","dryRun":true}`,
			call: func(client *AgentInterfaceClient, options RequestOptions) error {
				_, err := client.AdvanceStep(context.Background(), AgentAdvanceRequest{
					InterfaceID:     2846,
					ModifyVersionID: 42,
					Step:            "request",
					DryRun:          true,
				}, options)
				return err
			},
		},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			doer := httpDoerFunc(func(request *http.Request) (*http.Response, error) {
				if request.Method != test.method {
					t.Errorf("method=%q want=%q", request.Method, test.method)
				}
				if request.URL.Path != test.path {
					t.Errorf("path=%q want=%q", request.URL.Path, test.path)
				}
				if request.URL.RawQuery != test.query {
					t.Errorf("query=%q want=%q", request.URL.RawQuery, test.query)
				}
				var body string
				if request.Body != nil {
					payload, err := io.ReadAll(request.Body)
					if err != nil {
						t.Fatal(err)
					}
					body = string(payload)
				}
				if body != test.body {
					t.Errorf("body=%s want=%s", body, test.body)
				}
				return jsonResponse(http.StatusOK, `{"code":0,"message":"success","data":{}}`), nil
			})
			client := NewAgentInterfaceClient(NewTransport(doer))
			if err := test.call(client, RequestOptions{Credentials: testCredentials()}); err != nil {
				t.Fatal(err)
			}
		})
	}
}

func TestAgentGetRequestPreservesOptionalScalarPresence(t *testing.T) {
	empty := ""
	zero := int64(0)
	doer := httpDoerFunc(func(request *http.Request) (*http.Response, error) {
		if got := request.URL.RawQuery; got != "interfaceId=0&interfaceName=&interfaceNameLike=" {
			t.Fatalf("query=%q", got)
		}
		return jsonResponse(http.StatusOK, `{"code":0,"message":"success","data":{}}`), nil
	})

	_, err := NewAgentInterfaceClient(NewTransport(doer)).Get(
		context.Background(),
		AgentGetRequest{InterfaceID: &zero, InterfaceName: &empty, InterfaceNameLike: &empty},
		RequestOptions{Credentials: testCredentials()},
	)
	if err != nil {
		t.Fatal(err)
	}
}

func TestAgentGetResultPreservesCompleteCurrentListAndErrTypes(t *testing.T) {
	const response = `{"code":0,"message":"success","data":{"current":{"interfaceId":2846,"interfaceName":"/test/get","psm":"cmp.a","methodName":"Get","boundBamVersionId":"1.0.1","modifyVersionId":42,"statusV2":110,"configUrl":"https://config.example/2846","requestInfo":[{"path":"a","futureNode":{"mode":"new"}}],"responseInfo":[{"fromName":"b"}],"errConfigList":[{"errCode":"7"}],"owners":["alice"],"authSubjectId":[0,10001],"bizDomainId":9,"requestStyleIndex":{"external":["a"],"variable":["shop_id"],"constant":[{"path":"fixed","constantValue":"x"}]},"configPhase":"doc_editing","isOldInterface":false,"reservedInnerVarNames":["shop_id"],"errCode":"baseResp.code","errMsg":"baseResp.message","bizSuccErrCode":"0","desc":"desc","sceneDesc":"scene","releaseNote":"note","nextStep":"doc"},"list":[{"interfaceId":2846,"interfaceName":"/test/get","psm":"cmp.a","methodName":"Get","statusV2":110,"configUrl":"https://config.example/2846"}],"errTypeList":[{"errTypeId":2,"errTypeDesc":"参数错误"}],"errors":[{"field":"warning","reason":"r","fix":"f","suggestedValue":"v"}],"futureTop":{"enabled":true}}}`
	client := NewAgentInterfaceClient(NewTransport(responseDoer(http.StatusOK, response)))

	result, err := client.Get(context.Background(), AgentGetRequest{InterfaceID: agentInt64Pointer(2846)}, RequestOptions{Credentials: testCredentials()})
	if err != nil {
		t.Fatal(err)
	}
	current := result.Current
	if current == nil {
		t.Fatal("current=nil")
	}
	if current.InterfaceID != 2846 || current.InterfaceName != "/test/get" || current.PSM != "cmp.a" || current.MethodName != "Get" {
		t.Fatalf("current identity=%+v", current)
	}
	if agentStringValue(current.BoundBAMVersionID) != "1.0.1" || current.ModifyVersionID != 42 || agentInt32Value(current.StatusV2) != 110 || current.ConfigURL == "" {
		t.Fatalf("current control=%+v", current)
	}
	if string(current.RequestInfo) == "" || string(current.ResponseInfo) == "" || string(current.ErrConfigList) == "" {
		t.Fatalf("current trees=%+v", current)
	}
	if !reflect.DeepEqual(current.Owners, []string{"alice"}) || !reflect.DeepEqual(current.AuthSubjectIDs, []int32{0, 10001}) || current.BizDomainID != 9 {
		t.Fatalf("current ownership=%+v", current)
	}
	if current.RequestStyleIndex == nil || !reflect.DeepEqual(current.RequestStyleIndex.External, []string{"a"}) || !reflect.DeepEqual(current.RequestStyleIndex.Variable, []string{"shop_id"}) || len(current.RequestStyleIndex.Constant) != 1 {
		t.Fatalf("requestStyleIndex=%+v", current.RequestStyleIndex)
	}
	if agentStringValue(current.ConfigPhase) != "doc_editing" || current.IsOldInterface == nil || *current.IsOldInterface || !reflect.DeepEqual(current.ReservedInnerVarNames, []string{"shop_id"}) {
		t.Fatalf("current phase=%+v", current)
	}
	if agentStringValue(current.ErrCode) != "baseResp.code" || agentStringValue(current.ErrMsg) != "baseResp.message" || agentStringValue(current.BizSuccErrCode) != "0" {
		t.Fatalf("current err mapping=%+v", current)
	}
	if agentStringValue(current.Desc) != "desc" || agentStringValue(current.SceneDesc) != "scene" || agentStringValue(current.ReleaseNote) != "note" || agentStringValue(current.NextStep) != "doc" {
		t.Fatalf("current docs=%+v", current)
	}
	if len(result.List) != 1 || result.List[0].InterfaceID != 2846 || agentInt32Value(result.List[0].StatusV2) != 110 {
		t.Fatalf("list=%+v", result.List)
	}
	if len(result.ErrTypeList) != 1 || result.ErrTypeList[0].ErrTypeID != 2 || result.ErrTypeList[0].ErrTypeDesc != "参数错误" {
		t.Fatalf("errTypeList=%+v", result.ErrTypeList)
	}
	if len(result.Errors) != 1 || agentStringValue(result.Errors[0].SuggestedValue) != "v" {
		t.Fatalf("errors=%+v", result.Errors)
	}
	var data map[string]json.RawMessage
	if err := json.Unmarshal(result.Envelope.Data, &data); err != nil {
		t.Fatal(err)
	}
	if got := string(data["futureTop"]); got != `{"enabled":true}` {
		t.Fatalf("futureTop=%s", got)
	}
	var requestInfo []map[string]json.RawMessage
	if err := json.Unmarshal(current.RequestInfo, &requestInfo); err != nil {
		t.Fatal(err)
	}
	if got := string(requestInfo[0]["futureNode"]); got != `{"mode":"new"}` {
		t.Fatalf("futureNode=%s", got)
	}
}

func TestAgentGetResultRedactsTokenAndPreservesBusinessStringSemantics(t *testing.T) {
	const businessString = "接口文档\n\t示例\x1b[31m"
	response := `{"code":0,"message":"success","data":{"current":{"interfaceId":2846,"modifyVersionId":42,"desc":"接口文档\n\t示例\u001b[31m ` + testToken + `","requestInfo":[{"example":"接口文档\n\t示例\u001b[31m ` + testToken + `"}]},"list":[{"interfaceId":2846,"interfaceName":"` + testToken + `","psm":"cmp.a","methodName":"Get","configUrl":""}]}}`
	result, err := NewAgentInterfaceClient(NewTransport(responseDoer(http.StatusOK, response))).Get(
		context.Background(),
		AgentGetRequest{InterfaceID: agentInt64Pointer(2846)},
		RequestOptions{Credentials: testCredentials()},
	)
	if err != nil {
		t.Fatal(err)
	}
	if result.Current == nil || agentStringValue(result.Current.Desc) != businessString+" [REDACTED]" {
		t.Fatalf("current=%+v", result.Current)
	}
	var requestInfo []map[string]string
	if err := json.Unmarshal(result.Current.RequestInfo, &requestInfo); err != nil {
		t.Fatal(err)
	}
	if len(requestInfo) != 1 || requestInfo[0]["example"] != businessString+" [REDACTED]" {
		t.Fatalf("requestInfo=%#v", requestInfo)
	}
	encoded, err := json.Marshal(result)
	if err != nil {
		t.Fatal(err)
	}
	if strings.Contains(string(encoded), testToken) || !json.Valid(result.Envelope.Data) {
		t.Fatalf("typed DTO 泄漏 token 或 data 非法: %s", encoded)
	}
}

func TestAgentInitResultPreservesFromBAMAndWarnings(t *testing.T) {
	const response = `{"code":0,"message":"success","data":{"bamVersionId":"1.0.1","psm":"cmp.a","methodName":"Get","fromBam":{"requestInfo":[{"path":"request"}],"responseInfo":[{"fromName":"response"}]},"current":{"interfaceId":1,"modifyVersionId":2},"warnings":[{"kind":"style","toName":"ShopId","message":"check"}],"errors":[{"field":"f","reason":"r","fix":"x"}]}}`
	result, err := NewAgentInterfaceClient(NewTransport(responseDoer(http.StatusOK, response))).Init(
		context.Background(),
		AgentInitRequest{PSM: "cmp.a", MethodName: "Get", BAMVersionID: "1.0.1"},
		RequestOptions{Credentials: testCredentials()},
	)
	if err != nil {
		t.Fatal(err)
	}
	if result.BAMVersionID != "1.0.1" || result.PSM != "cmp.a" || result.MethodName != "Get" || result.FromBAM == nil || result.Current == nil {
		t.Fatalf("result=%+v", result)
	}
	if string(result.FromBAM.RequestInfo) != `[{"path":"request"}]` || string(result.FromBAM.ResponseInfo) != `[{"fromName":"response"}]` {
		t.Fatalf("fromBam=%+v", result.FromBAM)
	}
	if len(result.Warnings) != 1 || result.Warnings[0].Kind != "style" || len(result.Errors) != 1 {
		t.Fatalf("warnings/errors=%+v/%+v", result.Warnings, result.Errors)
	}
}

func TestAgentSaveResultPreservesPreviewDiffAndFlags(t *testing.T) {
	const response = `{"code":0,"message":"success","data":{"dryRun":true,"applied":false,"current":{"interfaceId":1,"modifyVersionId":2},"preview":{"interfaceId":1,"modifyVersionId":3},"diff":{"requestInfo":{"added":["a"],"removed":["b"],"changed":["c"]},"responseInfo":{"added":["x"],"removed":[],"changed":[]}},"errors":[{"field":"f","reason":"r","fix":"x"}]}}`
	result, err := NewAgentInterfaceClient(NewTransport(responseDoer(http.StatusOK, response))).Save(
		context.Background(),
		AgentSaveRequest{InterfaceID: 1, ModifyVersionID: 2, Sections: []string{"request"}, DryRun: agentBoolPointer(true)},
		RequestOptions{Credentials: testCredentials()},
	)
	if err != nil {
		t.Fatal(err)
	}
	if !result.DryRun || result.Applied || result.Current == nil || result.Preview == nil || result.Diff == nil || result.Diff.RequestInfo == nil || result.Diff.ResponseInfo == nil {
		t.Fatalf("result=%+v", result)
	}
	if !reflect.DeepEqual(result.Diff.RequestInfo.Added, []string{"a"}) || !reflect.DeepEqual(result.Diff.RequestInfo.Removed, []string{"b"}) || !reflect.DeepEqual(result.Diff.RequestInfo.Changed, []string{"c"}) || len(result.Errors) != 1 {
		t.Fatalf("diff/errors=%+v/%+v", result.Diff, result.Errors)
	}
}

func TestAgentDocResultPreservesDocumentFields(t *testing.T) {
	const response = `{"code":0,"message":"success","data":{"applied":true,"autoFilled":false,"current":{"interfaceId":1,"modifyVersionId":3},"tempDocUrl":"https://doc.example/temp","requestInfo":[{"path":"a"}],"responseInfo":[{"fromName":"b"}],"errors":[{"field":"f","reason":"r","fix":"x"}]}}`
	result, err := NewAgentInterfaceClient(NewTransport(responseDoer(http.StatusOK, response))).Doc(
		context.Background(),
		AgentDocRequest{InterfaceID: 1, ModifyVersionID: 2},
		RequestOptions{Credentials: testCredentials()},
	)
	if err != nil {
		t.Fatal(err)
	}
	if result.Applied == nil || !*result.Applied || result.AutoFilled == nil || *result.AutoFilled || result.Current == nil || agentStringValue(result.TempDocURL) != "https://doc.example/temp" {
		t.Fatalf("result=%+v", result)
	}
	if string(result.RequestInfo) != `[{"path":"a"}]` || string(result.ResponseInfo) != `[{"fromName":"b"}]` || len(result.Errors) != 1 {
		t.Fatalf("doc payload=%+v", result)
	}
}

func TestAgentAdvanceResultPreservesStatusAndAuditFields(t *testing.T) {
	const response = `{"code":0,"message":"success","data":{"dryRun":false,"applied":true,"current":{"interfaceId":1,"modifyVersionId":3},"preview":{"interfaceId":1,"modifyVersionId":4},"diff":{"requestInfo":{"added":[],"removed":[],"changed":["a"]}},"statusSteps":["ppe","submit-audit"],"auditSubmitted":true,"errors":[{"field":"f","reason":"r","fix":"x"}]}}`
	result, err := NewAgentInterfaceClient(NewTransport(responseDoer(http.StatusOK, response))).AdvanceStep(
		context.Background(),
		AgentAdvanceRequest{InterfaceID: 1, ModifyVersionID: 2, Step: "submit-audit", DryRun: false},
		RequestOptions{Credentials: testCredentials()},
	)
	if err != nil {
		t.Fatal(err)
	}
	if result.DryRun || !result.Applied || result.Current == nil || result.Preview == nil || result.Diff == nil || !reflect.DeepEqual(result.StatusSteps, []string{"ppe", "submit-audit"}) || result.AuditSubmitted == nil || !*result.AuditSubmitted || len(result.Errors) != 1 {
		t.Fatalf("result=%+v", result)
	}
}

func TestAgentRequestDTOJSONContracts(t *testing.T) {
	stringValue := ""
	int64Value := int64(0)
	int32Value := int32(0)
	boolValue := false

	tests := []struct {
		name string
		in   any
		want string
	}{
		{
			name: "get omitted",
			in:   AgentGetRequest{},
			want: `{}`,
		},
		{
			name: "get explicit zero values",
			in: AgentGetRequest{
				InterfaceID:       &int64Value,
				InterfaceName:     &stringValue,
				InterfaceNameLike: &stringValue,
			},
			want: `{"interfaceId":0,"interfaceName":"","interfaceNameLike":""}`,
		},
		{
			name: "init optional fields",
			in: AgentInitRequest{
				InterfaceID:     &int64Value,
				PSM:             "cmp.a",
				MethodName:      "Get",
				BAMVersionID:    "1.0.1",
				InterfaceName:   &stringValue,
				BizDomainID:     &int64Value,
				Desc:            &stringValue,
				SceneDesc:       &stringValue,
				OwnerList:       json.RawMessage(`[]`),
				InterfaceCateID: &int64Value,
				SkipAuth:        &boolValue,
			},
			want: `{"interfaceId":0,"psm":"cmp.a","methodName":"Get","bamVersionId":"1.0.1","interfaceName":"","bizDomainId":0,"desc":"","sceneDesc":"","ownerList":[],"interfaceCateId":0,"skipAuth":false}`,
		},
		{
			name: "save payload fields and explicit false dryRun",
			in: AgentSaveRequest{
				InterfaceID:     2846,
				ModifyVersionID: 42,
				Sections:        []string{"basic"},
				DryRun:          &boolValue,
				AgentPayload: AgentPayload{
					BAMVersionID:    &stringValue,
					RequestInfo:     json.RawMessage(`[]`),
					ResponseInfo:    json.RawMessage(`[]`),
					ErrConfigList:   json.RawMessage(`[]`),
					InterfaceName:   &stringValue,
					MethodName:      &stringValue,
					PSM:             &stringValue,
					Desc:            &stringValue,
					SceneDesc:       &stringValue,
					OwnerList:       json.RawMessage(`[]`),
					InterfaceCateID: &int64Value,
					AuthSubjectIDs:  json.RawMessage(`[]`),
					SkipAuth:        &boolValue,
					SLART:           &int32Value,
					SLAAva:          &stringValue,
					QPS:             &int32Value,
					Timeout:         &int32Value,
					CallType:        &int32Value,
					BizSuccErrCode:  &stringValue,
					ErrCode:         &stringValue,
					ErrMsg:          &stringValue,
					StylePatches:    json.RawMessage(`[]`),
					ReleaseNote:     &stringValue,
				},
			},
			want: `{"interfaceId":2846,"modifyVersionId":42,"sections":["basic"],"dryRun":false,"bamVersionId":"","requestInfo":[],"responseInfo":[],"errConfigList":[],"interfaceName":"","methodName":"","psm":"","desc":"","sceneDesc":"","ownerList":[],"interfaceCateId":0,"authSubjectId":[],"skipAuth":false,"slaRt":0,"slaAva":"","qps":0,"timeout":0,"callType":0,"bizSuccErrCode":"","errCode":"","errMsg":"","stylePatches":[],"releaseNote":""}`,
		},
		{
			name: "save omitted dryRun",
			in: AgentSaveRequest{
				InterfaceID:     2846,
				ModifyVersionID: 42,
				Sections:        []string{"request"},
			},
			want: `{"interfaceId":2846,"modifyVersionId":42,"sections":["request"]}`,
		},
		{
			name: "doc payload fields",
			in: AgentDocRequest{
				InterfaceID:     2846,
				ModifyVersionID: 42,
				AutoFill:        &boolValue,
				WithPreviewURL:  &boolValue,
				AgentDocPayload: AgentDocPayload{
					Desc:           &stringValue,
					SceneDesc:      &stringValue,
					ReleaseNote:    &stringValue,
					RequestInfo:    json.RawMessage(`[]`),
					ResponseInfo:   json.RawMessage(`[]`),
					ErrConfigList:  json.RawMessage(`[]`),
					BizSuccErrCode: &stringValue,
					ErrCode:        &stringValue,
					ErrMsg:         &stringValue,
				},
			},
			want: `{"interfaceId":2846,"modifyVersionId":42,"autoFill":false,"withPreviewUrl":false,"desc":"","sceneDesc":"","releaseNote":"","requestInfo":[],"responseInfo":[],"errConfigList":[],"bizSuccErrCode":"","errCode":"","errMsg":""}`,
		},
		{
			name: "advance audit fields",
			in: AgentAdvanceRequest{
				InterfaceID:     2846,
				ModifyVersionID: 42,
				Step:            "submit-audit",
				DryRun:          false,
				AuditReason:     &stringValue,
				AuditMeego:      &stringValue,
				SkipReason:      &stringValue,
			},
			want: `{"interfaceId":2846,"modifyVersionId":42,"step":"submit-audit","dryRun":false,"auditReason":"","auditMeego":"","skipReason":""}`,
		},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			got, err := json.Marshal(test.in)
			if err != nil {
				t.Fatal(err)
			}
			if string(got) != test.want {
				t.Fatalf("JSON=%s\nwant=%s", got, test.want)
			}
		})
	}
}

func agentBoolPointer(value bool) *bool {
	return &value
}

func agentInt64Pointer(value int64) *int64 {
	return &value
}

func agentStringValue(value *string) string {
	if value == nil {
		return ""
	}
	return *value
}

func agentInt32Value(value *int32) int32 {
	if value == nil {
		return 0
	}
	return *value
}
