package cli

import (
	corecli "code.byted.org/temai/open_cli/internal/core/cli"
	djtskill "code.byted.org/temai/open_cli/internal/djt/skill"
	"github.com/spf13/cobra"
)

func newDJTCommand(deps Dependencies, format *corecli.OutputFormat, version string) *cobra.Command {
	djt := &cobra.Command{
		Use:   "djt",
		Short: "点将台命令",
	}

	api := newAPICommand(deps, format)
	spi := newSPICommand(deps, format)
	self := &cobra.Command{Use: "self", Short: "管理点将台 CLI 自身资源"}
	self.AddCommand(corecli.NewSingleSkillCommand(corecli.RootOptions{
		Stdout: deps.Stdout, Stderr: deps.Stderr, HomeDir: deps.HomeDir,
	}, format, djtskill.Bundle()))

	djt.AddCommand(
		corecli.NewVersionCommand(deps.Stdout, version),
		self,
		newAuthCommand(deps, format),
		newBizDomainCommand(deps, format),
		api,
		spi,
	)
	return djt
}
