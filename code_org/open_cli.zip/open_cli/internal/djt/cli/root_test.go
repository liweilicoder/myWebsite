package cli

import (
	"bytes"
	"context"
	"errors"
	"io"
	"net/http"
	"net/http/httptest"
	"net/url"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"code.byted.org/temai/open_cli/internal/core/ppe"
	"code.byted.org/temai/open_cli/internal/djt/auth"
	"github.com/spf13/cobra"
)

func TestRootExposesVersionCommandAndFlag(t *testing.T) {
	for _, test := range []struct {
		name string
		args []string
	}{
		{name: "subcommand", args: []string{"djt", "version"}},
		{name: "flag", args: []string{"--version"}},
	} {
		t.Run(test.name, func(t *testing.T) {
			var stdout, stderr bytes.Buffer
			root := newRootCommand(Dependencies{Stdout: &stdout, Stderr: &stderr}, "0.2.3")
			root.SetOut(&stdout)
			root.SetErr(&stderr)
			root.SetArgs(test.args)
			if err := root.Execute(); err != nil {
				t.Fatal(err)
			}
			if got := stdout.String(); got != "0.2.3\n" {
				t.Fatalf("stdout=%q", got)
			}
			if stderr.Len() != 0 {
				t.Fatalf("stderr=%q", stderr.String())
			}
		})
	}
}

func TestCommandsRejectUnknownOutputOnParentAndHelpPaths(t *testing.T) {
	tests := []struct {
		name string
		args []string
	}{
		{name: "root", args: []string{"--output", "yaml"}},
		{name: "root help", args: []string{"--output", "yaml", "--help"}},
		{name: "djt", args: []string{"djt", "--output", "yaml"}},
		{name: "djt help", args: []string{"djt", "--output", "yaml", "--help"}},
		{name: "auth", args: []string{"djt", "auth", "--output", "yaml"}},
		{name: "auth help", args: []string{"djt", "auth", "--output", "yaml", "--help"}},
		{name: "api", args: []string{"djt", "api", "--output", "yaml"}},
		{name: "api help", args: []string{"djt", "api", "--output", "yaml", "--help"}},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			root := NewRootCommand(Dependencies{Stdout: io.Discard, Stderr: io.Discard})
			root.SetOut(io.Discard)
			root.SetErr(io.Discard)
			root.SetArgs(tt.args)
			if err := root.Execute(); err == nil || !strings.Contains(err.Error(), "text 或 json") {
				t.Fatalf("err=%v", err)
			}
		})
	}
}

func TestParentCommandsKeepHelpSemantics(t *testing.T) {
	tests := []struct {
		args []string
		want string
	}{
		{args: nil, want: "Usage:"},
		{args: []string{"djt"}, want: "Usage:"},
		{args: []string{"djt", "--help"}, want: "Usage:"},
		{args: []string{"djt", "auth", "--help"}, want: "管理点将台登录状态"},
		{args: []string{"djt", "api", "--help"}, want: "管理点将台 API"},
		{args: []string{"djt", "api", "get", "--help"}, want: "查询接口配置或模糊搜索接口"},
	}
	for _, tt := range tests {
		var stdout bytes.Buffer
		root := NewRootCommand(Dependencies{Stdout: &stdout, Stderr: io.Discard})
		root.SetOut(&stdout)
		root.SetArgs(tt.args)
		if err := root.Execute(); err != nil {
			t.Fatalf("args=%v err=%v", tt.args, err)
		}
		if !strings.Contains(stdout.String(), tt.want) {
			t.Fatalf("args=%v output=%q want=%q", tt.args, stdout.String(), tt.want)
		}
	}
}

func TestDJTParentHasNoRunE(t *testing.T) {
	root := NewRootCommand(Dependencies{Stdout: io.Discard, Stderr: io.Discard})
	for _, path := range [][]string{{"djt"}, {"djt", "api"}} {
		command, remaining, err := root.Find(path)
		if err != nil || len(remaining) != 0 {
			t.Fatalf("path=%v remaining=%v err=%v", path, remaining, err)
		}
		if command.RunE != nil {
			t.Fatalf("%v 父命令不应设置 RunE", path)
		}
	}
}

func TestInternalRootIsSuperset(t *testing.T) {
	root := NewRootCommand(Dependencies{Stdout: io.Discard, Stderr: io.Discard})
	if root.Use != "doudian-open-cli" {
		t.Fatalf("root use=%q", root.Use)
	}
	for _, path := range [][]string{
		{"version"},
		{"djt", "version"},
		{"djt", "self", "skill", "install"},
		{"djt", "auth", "login"},
	} {
		command, remaining, err := root.Find(path)
		if err != nil || command == nil || len(remaining) != 0 {
			t.Fatalf("path=%v command=%v remaining=%v err=%v", path, command, remaining, err)
		}
	}
	if cmd, remaining, err := root.Find([]string{"self"}); err == nil && cmd != nil && cmd != root && len(remaining) == 0 {
		t.Fatal("根命令不得再挂 self skill")
	}
	for _, path := range [][]string{{"auth"}, {"api", "invoke"}} {
		command, remaining, err := root.Find(path)
		if err == nil && command != nil && command != root && len(remaining) == 0 {
			t.Fatalf("step 1 public open commands must not exist: %v", path)
		}
	}
}

func TestRootDoesNotExposeBaseURLFlag(t *testing.T) {
	root := NewRootCommand(Dependencies{Stdout: io.Discard, Stderr: io.Discard})
	if root.PersistentFlags().Lookup("base-url") != nil {
		t.Fatal("base-url flag must be removed")
	}
}

func TestCommandTreeAndPersistentFlags(t *testing.T) {
	root := NewRootCommand(Dependencies{Stdout: io.Discard, Stderr: io.Discard})
	for _, path := range [][]string{{"djt"}, {"djt", "auth"}, {"djt", "api"}} {
		command, remaining, err := root.Find(path)
		if err != nil || len(remaining) != 0 {
			t.Fatalf("path=%v command=%v remaining=%v err=%v", path, command, remaining, err)
		}
	}
	for _, flag := range []string{"output"} {
		if root.PersistentFlags().Lookup(flag) == nil {
			t.Fatalf("root 缺少 persistent flag %q", flag)
		}
	}
	if got := root.PersistentFlags().Lookup("output").Shorthand; got != "o" {
		t.Fatalf("output shorthand=%q", got)
	}
	if got := root.PersistentFlags().Lookup("output").DefValue; got != "json" {
		t.Fatalf("output default=%q", got)
	}
}

type commandTokenResult struct {
	token auth.DeviceToken
	err   error
}

type commandDeviceAPI struct {
	start      auth.DeviceStart
	tokens     []commandTokenResult
	calls      int
	startCalls int
}

func (f *commandDeviceAPI) StartWithPPE(context.Context, string, ppe.Config) (auth.DeviceStart, error) {
	f.startCalls++
	return f.start, nil
}

func (f *commandDeviceAPI) TokenWithPPE(context.Context, string, string, string, ppe.Config) (auth.DeviceToken, error) {
	result := f.tokens[f.calls]
	f.calls++
	return result.token, result.err
}

type capturingStartDeviceAPI struct {
	inner      *commandDeviceAPI
	gotBaseURL string
}

func (c *capturingStartDeviceAPI) StartWithPPE(ctx context.Context, baseURL string, config ppe.Config) (auth.DeviceStart, error) {
	c.gotBaseURL = baseURL
	return c.inner.StartWithPPE(ctx, baseURL, config)
}

func (c *capturingStartDeviceAPI) TokenWithPPE(ctx context.Context, baseURL, deviceCode, verifier string, config ppe.Config) (auth.DeviceToken, error) {
	return c.inner.TokenWithPPE(ctx, baseURL, deviceCode, verifier, config)
}

func TestAuthLoginIgnoresConfigJSONBaseURL(t *testing.T) {
	configDir := t.TempDir()
	if err := os.WriteFile(filepath.Join(configDir, "config.json"), []byte(`{"base_url":"https://config.example.com"}`), 0o600); err != nil {
		t.Fatal(err)
	}
	inner := &commandDeviceAPI{
		start:  auth.DeviceStart{DeviceCode: "d", CodeVerifier: "v", UserCode: "ABCD", VerificationURI: "https://verify", ExpiresIn: 60, Interval: 1},
		tokens: []commandTokenResult{{err: &auth.DeviceProtocolError{Code: "access_denied"}}},
	}
	device := &capturingStartDeviceAPI{inner: inner}

	root := NewRootCommand(Dependencies{
		DeviceAPI: device,
		WhoAmIAPI: &commandWhoAmI{},
		Store:     &commandStore{},
		Browser:   commandBrowser{},
		Wait:      func(context.Context, time.Duration) error { return nil },
		Now:       commandNow,
		ConfigDir: configDir,
		Stdout:    io.Discard,
		Stderr:    io.Discard,
	})
	root.SetArgs([]string{"djt", "auth", "login"})
	_ = root.Execute()
	if device.gotBaseURL != "https://djt.bytedance.net" {
		t.Fatalf("baseURL=%q want=%q", device.gotBaseURL, "https://djt.bytedance.net")
	}
}

type loginPPEHTTPRecorder struct {
	requests []*http.Request
}

func (r *loginPPEHTTPRecorder) Do(request *http.Request) (*http.Response, error) {
	r.requests = append(r.requests, request.Clone(request.Context()))
	switch request.URL.Path {
	case "/api/djt-cli/device/start":
		return commandJSONResponse(http.StatusOK, `{"device_code":"d","user_code":"U","verification_uri":"https://verify.example.com","expires_in":60,"interval":1}`), nil
	case "/api/djt-cli/device/token":
		return commandJSONResponse(http.StatusOK, `{"access_token":"secret","token_type":"Bearer","expires_in":60}`), nil
	case "/api/user/getLoginUser":
		return commandJSONResponse(http.StatusOK, `{"code":0,"message":"success","data":{"employee":{"employeeId":"123"},"userType":1,"authorityList":[]}}`), nil
	default:
		return nil, errors.New("unexpected login request")
	}
}

func newLoginPPECommand(recorder *loginPPEHTTPRecorder) *cobra.Command {
	device := auth.NewDeviceClient(recorder)
	return NewRootCommand(Dependencies{
		DeviceAPI: device,
		WhoAmIAPI: device,
		Store:     &commandStore{},
		Browser:   commandBrowser{},
		Wait:      func(context.Context, time.Duration) error { return nil },
		Now:       commandNow,
		Stdout:    io.Discard,
		Stderr:    io.Discard,
	})
}

func TestAuthLoginPPEFlagsReachStartTokenAndGetLoginUser(t *testing.T) {
	tests := []struct {
		name   string
		args   []string
		usePPE string
		ppeEnv string
	}{
		{
			name:   "flags",
			args:   []string{"djt", "auth", "login", "--use-ppe", "--ppe-env", "ppe_djt_cli"},
			usePPE: "1",
			ppeEnv: "ppe_djt_cli",
		},
		{
			name:   "explicit false",
			args:   []string{"djt", "auth", "login", "--use-ppe=false"},
		},
		{
			name: "production default",
			args: []string{"djt", "auth", "login"},
		},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			recorder := &loginPPEHTTPRecorder{}
			root := newLoginPPECommand(recorder)
			root.SetArgs(test.args)
			if err := root.Execute(); err != nil {
				t.Fatal(err)
			}
			if len(recorder.requests) != 3 {
				t.Fatalf("requests=%d", len(recorder.requests))
			}
			for index, request := range recorder.requests {
				if got := request.Header.Get("x-use-ppe"); got != test.usePPE {
					t.Fatalf("request[%d] %s x-use-ppe=%q want=%q", index, request.URL.Path, got, test.usePPE)
				}
				if got := request.Header.Get("x-tt-env"); got != test.ppeEnv {
					t.Fatalf("request[%d] %s x-tt-env=%q want=%q", index, request.URL.Path, got, test.ppeEnv)
				}
			}
		})
	}
}

func TestAuthLoginRejectsInvalidPPEConfigurationBeforeHTTP(t *testing.T) {
	tests := []struct {
		name string
		args []string
		want string
	}{
		{
			name: "ppe env flag without use ppe",
			args: []string{"djt", "auth", "login", "--ppe-env", "ppe_flag"},
			want: "--ppe-env 只能与 --use-ppe=true 一起使用",
		},
		{
			name: "invalid ppe environment",
			args: []string{"djt", "auth", "login", "--use-ppe=true", "--ppe-env", "ppe\\r\\ninjected"},
			want: "PPE 环境名无效",
		},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			recorder := &loginPPEHTTPRecorder{}
			root := newLoginPPECommand(recorder)
			root.SetArgs(test.args)
			err := root.Execute()
			if err == nil || !strings.Contains(err.Error(), test.want) {
				t.Fatalf("err=%v want substring=%q", err, test.want)
			}
			if len(recorder.requests) != 0 {
				t.Fatalf("invalid PPE config reached HTTP: %d requests", len(recorder.requests))
			}
		})
	}
}

func TestAuthLoginHelpDocumentsBrowserAuth(t *testing.T) {
	var stdout bytes.Buffer
	root := NewRootCommand(Dependencies{Stdout: &stdout, Stderr: io.Discard})
	root.SetOut(&stdout)
	root.SetArgs([]string{"djt", "auth", "login", "--help"})
	if err := root.Execute(); err != nil {
		t.Fatal(err)
	}
	out := stdout.String()
	for _, want := range []string{"打开浏览器授权页", "授权 URL", "用户代码"} {
		if !strings.Contains(out, want) {
			t.Fatalf("help=%q missing=%q", out, want)
		}
	}
}

func TestInternalRootHelpShowsPPE(t *testing.T) {
	var stdout bytes.Buffer
	root := NewRootCommand(Dependencies{Stdout: &stdout, Stderr: io.Discard})
	root.SetOut(&stdout)
	root.SetArgs([]string{"--help"})
	if err := root.Execute(); err != nil {
		t.Fatal(err)
	}
	out := stdout.String()
	for _, want := range []string{"--use-ppe", "--ppe-env"} {
		if !strings.Contains(out, want) {
			t.Fatalf("internal help=%q missing=%q", out, want)
		}
	}
}

type commandWhoAmI struct {
	user  auth.User
	calls int
}

func (f *commandWhoAmI) GetLoginUserWithPPE(context.Context, string, string, string, ppe.Config) (auth.User, error) {
	f.calls++
	return f.user, nil
}

type commandStore struct {
	credentials auth.Credentials
	loadErr     error
	loads       int
	saved       auth.Credentials
	saves       int
	deletes     int
}

func (f *commandStore) Load(context.Context) (auth.Credentials, error) {
	f.loads++
	return f.credentials, f.loadErr
}

func (f *commandStore) Save(_ context.Context, credentials auth.Credentials) error {
	f.saved = credentials
	f.saves++
	return nil
}

func (f *commandStore) Delete(context.Context) error {
	f.deletes++
	return nil
}

type commandBrowser struct {
	err error
}

func (f commandBrowser) Open(string) error { return f.err }

func TestAuthCommandTree(t *testing.T) {
	root := NewRootCommand(Dependencies{Stdout: io.Discard, Stderr: io.Discard})
	for _, path := range [][]string{
		{"djt", "auth", "login"},
		{"djt", "auth", "status"},
		{"djt", "auth", "whoami"},
		{"djt", "auth", "logout"},
	} {
		command, remaining, err := root.Find(path)
		if err != nil || command == nil || len(remaining) != 0 {
			t.Fatalf("path=%v command=%v remaining=%v err=%v", path, command, remaining, err)
		}
	}
}

func TestAuthLoginJSONDoesNotLeakToken(t *testing.T) {
	now := time.Date(2026, 8, 6, 11, 0, 0, 0, time.UTC)
	device := &commandDeviceAPI{
		start:  auth.DeviceStart{DeviceCode: "device-secret", CodeVerifier: "verifier-secret", UserCode: "ABCD", VerificationURI: "https://verify", ExpiresIn: 60, Interval: 1},
		tokens: []commandTokenResult{{token: auth.DeviceToken{AccessToken: "token-secret", TokenType: "Bearer", ExpiresIn: 3600}}},
	}
	store := &commandStore{}
	who := &commandWhoAmI{user: auth.User{EmployeeID: "123", EmployeeName: "吴昊天", Email: "u@example.com", HeadURL: "avatar", UserType: 1, AuthorityList: []string{"interface.read"}}}
	var stdout, stderr bytes.Buffer
	root := NewRootCommand(Dependencies{
		DeviceAPI: device, WhoAmIAPI: who, Store: store, Browser: commandBrowser{},
		Wait: func(context.Context, time.Duration) error { return nil }, Now: func() time.Time { return now },
		Stdout: &stdout, Stderr: &stderr,
	})
	root.SetArgs([]string{"--output", "json", "djt", "auth", "login"})
	if err := root.Execute(); err != nil {
		t.Fatal(err)
	}
	want := `{"authenticated":true,"user":{"employee_id":"123","employee_name":"吴昊天","email":"u@example.com","head_url":"avatar","user_type":1,"authority_list":["interface.read"]},"expires_at":"2026-08-06T12:00:00Z"}` + "\n"
	if stdout.String() != want {
		t.Fatalf("stdout=%q want=%q", stdout.String(), want)
	}
	if got := stderr.String(); got != "请访问：https://verify\n用户代码：ABCD\n" {
		t.Fatalf("stderr=%q", got)
	}
	for _, output := range []string{stdout.String(), stderr.String()} {
		for _, secret := range []string{"token-secret", "verifier-secret", "device-secret"} {
			if strings.Contains(output, secret) {
				t.Fatalf("输出泄漏 %q: %q", secret, output)
			}
		}
	}
	if store.saves != 1 || who.calls != 1 {
		t.Fatalf("saves=%d who calls=%d", store.saves, who.calls)
	}
}

func TestAuthLoginTextAndBrowserFallback(t *testing.T) {
	device := &commandDeviceAPI{
		start:  auth.DeviceStart{DeviceCode: "d", CodeVerifier: "v", UserCode: "ABCD", VerificationURI: "https://verify", ExpiresIn: 60, Interval: 1},
		tokens: []commandTokenResult{{token: auth.DeviceToken{AccessToken: "secret", TokenType: "Bearer", ExpiresIn: 60}}},
	}
	var stdout, stderr bytes.Buffer
	root := NewRootCommand(Dependencies{
		DeviceAPI: device, WhoAmIAPI: &commandWhoAmI{user: auth.User{EmployeeID: "123", EmployeeName: "吴昊天", Email: "u@example.com"}}, Store: &commandStore{},
		Browser: commandBrowser{err: errors.New("browser failed")}, Wait: func(context.Context, time.Duration) error { return nil }, Now: commandNow,
		Stdout: &stdout, Stderr: &stderr,
	})
	root.SetArgs([]string{"--output", "text", "djt", "auth", "login"})
	if err := root.Execute(); err != nil {
		t.Fatal(err)
	}
	for _, want := range []string{"https://verify", "ABCD", "吴昊天 <u@example.com>", "登录成功"} {
		if !strings.Contains(stdout.String(), want) {
			t.Fatalf("stdout=%q missing=%q", stdout.String(), want)
		}
	}
	if got := stderr.String(); got != "无法打开浏览器，请访问：https://verify\n" {
		t.Fatalf("stderr=%q", got)
	}
	if strings.Contains(stdout.String()+stderr.String(), "secret") {
		t.Fatal("输出泄漏 token")
	}
}

func TestAuthStatusTextAndJSONStayLocal(t *testing.T) {
	t.Run("missing text", func(t *testing.T) {
		var stdout bytes.Buffer
		root := NewRootCommand(Dependencies{Store: &commandStore{loadErr: auth.ErrNotLoggedIn}, Now: commandNow, Stdout: &stdout, Stderr: io.Discard})
		root.SetArgs([]string{"--output", "text", "djt", "auth", "status"})
		if err := root.Execute(); err != nil || stdout.String() != "未登录\n" {
			t.Fatalf("err=%v stdout=%q", err, stdout.String())
		}
	})

	t.Run("expired json", func(t *testing.T) {
		var stdout bytes.Buffer
		store := &commandStore{credentials: auth.Credentials{AccessToken: "token-secret", ExpiresAt: commandNow()}}
		root := NewRootCommand(Dependencies{Store: store, Now: commandNow, Stdout: &stdout, Stderr: io.Discard})
		root.SetArgs([]string{"--output", "json", "djt", "auth", "status"})
		if err := root.Execute(); err != nil || stdout.String() != "{\"authenticated\":false,\"expired\":true}\n" {
			t.Fatalf("err=%v stdout=%q", err, stdout.String())
		}
		if strings.Contains(stdout.String(), "token-secret") {
			t.Fatal("status 泄漏 token")
		}
	})
}

func TestAuthWhoAmIJSONAndLogoutDoNotLeakToken(t *testing.T) {
	credentials := auth.Credentials{
		BaseURL: "https://admin.example.com", AccessToken: "token-secret", TokenType: "Bearer", ExpiresAt: commandNow().Add(time.Hour),
		User: auth.User{EmployeeID: "123", EmployeeName: "吴昊天", Email: "u@example.com"},
	}
	t.Run("whoami", func(t *testing.T) {
		var stdout bytes.Buffer
		root := NewRootCommand(Dependencies{Store: &commandStore{credentials: credentials}, Now: commandNow, Stdout: &stdout, Stderr: io.Discard})
		root.SetArgs([]string{"--output", "json", "djt", "auth", "whoami"})
		if err := root.Execute(); err != nil {
			t.Fatal(err)
		}
		want := `{"user":{"employee_id":"123","employee_name":"吴昊天","email":"u@example.com","head_url":"","user_type":0,"authority_list":null},"expires_at":"2026-08-06T12:00:00Z"}` + "\n"
		if stdout.String() != want || strings.Contains(stdout.String(), "token-secret") {
			t.Fatalf("stdout=%q", stdout.String())
		}
	})

	t.Run("logout", func(t *testing.T) {
		var stdout bytes.Buffer
		store := &commandStore{credentials: credentials}
		root := NewRootCommand(Dependencies{Store: store, Now: commandNow, Stdout: &stdout, Stderr: io.Discard})
		root.SetArgs([]string{"--output", "json", "djt", "auth", "logout"})
		if err := root.Execute(); err != nil || stdout.String() != "{\"authenticated\":false}\n" || store.deletes != 1 {
			t.Fatalf("err=%v stdout=%q deletes=%d", err, stdout.String(), store.deletes)
		}
	})
}

func TestAuthStatusWhoAmIAndLogoutDoNotResolveBaseURL(t *testing.T) {
	credentials := auth.Credentials{ExpiresAt: commandNow().Add(time.Hour), User: auth.User{EmployeeID: "123"}}
	for _, args := range [][]string{{"djt", "auth", "status"}, {"djt", "auth", "whoami"}, {"djt", "auth", "logout"}} {
		root := NewRootCommand(Dependencies{Store: &commandStore{credentials: credentials}, Now: commandNow, ConfigDir: t.TempDir(), Stdout: io.Discard, Stderr: io.Discard})
		root.SetArgs(args)
		if err := root.Execute(); err != nil {
			t.Fatalf("args=%v err=%v", args, err)
		}
	}
}

func commandNow() time.Time {
	return time.Date(2026, 8, 6, 11, 0, 0, 0, time.UTC)
}

func TestAuthLoginBrowserFallbackIsPrintedWhenAuthorizationFails(t *testing.T) {
	device := &commandDeviceAPI{
		start:  auth.DeviceStart{DeviceCode: "d", CodeVerifier: "v", UserCode: "ABCD", VerificationURI: "https://verify", ExpiresIn: 60, Interval: 1},
		tokens: []commandTokenResult{{err: &auth.DeviceProtocolError{Code: "access_denied"}}},
	}
	var stdout, stderr bytes.Buffer
	root := NewRootCommand(Dependencies{
		DeviceAPI: device, WhoAmIAPI: &commandWhoAmI{}, Store: &commandStore{}, Browser: commandBrowser{err: errors.New("browser failed")},
		Wait: func(context.Context, time.Duration) error { return nil }, Now: commandNow, Stdout: &stdout, Stderr: &stderr,
	})
	root.SetArgs([]string{"--output", "text", "djt", "auth", "login"})
	err := root.Execute()
	var protocolErr *auth.DeviceProtocolError
	if !errors.As(err, &protocolErr) || protocolErr.Code != "access_denied" {
		t.Fatalf("err=%v", err)
	}
	if stdout.String() != "请访问：https://verify\n用户代码：ABCD\n" || stderr.String() != "无法打开浏览器，请访问：https://verify\n" {
		t.Fatalf("stdout=%q stderr=%q", stdout.String(), stderr.String())
	}
}

type failingWriter struct {
	err error
}

func (w failingWriter) Write([]byte) (int, error) {
	return 0, w.err
}

func TestAuthLoginPrintsPromptBeforeFirstWait(t *testing.T) {
	device := &commandDeviceAPI{
		start:  auth.DeviceStart{DeviceCode: "d", CodeVerifier: "v", UserCode: "ABCD", VerificationURI: "https://verify", ExpiresIn: 60, Interval: 1},
		tokens: []commandTokenResult{{token: auth.DeviceToken{AccessToken: "secret", TokenType: "Bearer", ExpiresIn: 60}}},
	}
	var stdout bytes.Buffer
	waitCalls := 0
	root := NewRootCommand(Dependencies{
		DeviceAPI: device, WhoAmIAPI: &commandWhoAmI{user: auth.User{EmployeeID: "123"}}, Store: &commandStore{}, Browser: commandBrowser{},
		Wait: func(context.Context, time.Duration) error {
			waitCalls++
			if stdout.String() != "请访问：https://verify\n用户代码：ABCD\n" {
				t.Fatalf("首次等待前 stdout=%q", stdout.String())
			}
			return nil
		},
		Now: commandNow, Stdout: &stdout, Stderr: io.Discard,
	})
	root.SetArgs([]string{"--output", "text", "djt", "auth", "login"})
	if err := root.Execute(); err != nil {
		t.Fatal(err)
	}
	if waitCalls != 1 || device.calls != 1 {
		t.Fatalf("waitCalls=%d tokenCalls=%d", waitCalls, device.calls)
	}
}

func TestAuthLoginPromptWriteFailureStopsPolling(t *testing.T) {
	writeErr := errors.New("stdout failed")
	device := &commandDeviceAPI{start: auth.DeviceStart{DeviceCode: "d", CodeVerifier: "v", UserCode: "ABCD", VerificationURI: "https://verify", ExpiresIn: 60, Interval: 1}}
	waitCalls := 0
	root := NewRootCommand(Dependencies{
		DeviceAPI: device, WhoAmIAPI: &commandWhoAmI{}, Store: &commandStore{}, Browser: commandBrowser{},
		Wait: func(context.Context, time.Duration) error { waitCalls++; return nil }, Now: commandNow,
		Stdout: failingWriter{err: writeErr}, Stderr: io.Discard,
	})
	root.SetArgs([]string{"--output", "text", "djt", "auth", "login"})
	err := root.Execute()
	if !errors.Is(err, writeErr) || waitCalls != 0 || device.calls != 0 {
		t.Fatalf("err=%v waitCalls=%d tokenCalls=%d", err, waitCalls, device.calls)
	}
}

type rewriteHostTransport struct {
	t      *testing.T
	target *url.URL
	next   http.RoundTripper
}

func (rt rewriteHostTransport) RoundTrip(req *http.Request) (*http.Response, error) {
	if req.URL.Host != "djt.bytedance.net" {
		rt.t.Fatalf("host=%q", req.URL.Host)
	}
	cloned := req.Clone(req.Context())
	u := *cloned.URL
	u.Scheme = rt.target.Scheme
	u.Host = rt.target.Host
	cloned.URL = &u
	return rt.next.RoundTrip(cloned)
}

type commandHTTPDoer func(*http.Request) (*http.Response, error)

func (f commandHTTPDoer) Do(request *http.Request) (*http.Response, error) {
	return f(request)
}

func commandJSONResponse(status int, body string) *http.Response {
	return &http.Response{
		StatusCode: status,
		Body:       io.NopCloser(strings.NewReader(body)),
		Header:     make(http.Header),
	}
}

func validCommandCredentials() auth.Credentials {
	return auth.Credentials{
		BaseURL:     "https://djt.bytedance.net",
		AccessToken: "token-secret",
		TokenType:   "Bearer",
		ExpiresAt:   commandNow().Add(time.Hour),
		User:        auth.User{EmployeeID: "123"},
	}
}

func TestPSMListCommandIsNotExposed(t *testing.T) {
	root := NewRootCommand(Dependencies{Stdout: io.Discard, Stderr: io.Discard})
	_, remaining, err := root.Find([]string{"djt", "psm", "list"})
	if err == nil && len(remaining) == 0 {
		t.Fatal("removed PSM list command must not resolve")
	}
}

func TestDJTHelpShowsCanonicalAPIAndNotAgent(t *testing.T) {
	var stdout bytes.Buffer
	root := NewRootCommand(Dependencies{Stdout: &stdout, Stderr: io.Discard})
	root.SetOut(&stdout)
	root.SetArgs([]string{"djt", "--help"})
	if err := root.Execute(); err != nil {
		t.Fatal(err)
	}
	out := stdout.String()
	if !strings.Contains(out, "api") || !strings.Contains(out, "管理点将台 API") {
		t.Fatalf("help must show canonical api command: %q", out)
	}
	if strings.Contains(out, "agent") || strings.Contains(out, "Agent-first") {
		t.Fatalf("help must not show removed agent command: %q", out)
	}
	if strings.Contains(out, "psm") {
		t.Fatalf("help must not expose removed psm resource: %q", out)
	}
}

func TestRemovedDJTCommandLayersAreNotResolvable(t *testing.T) {
	root := NewRootCommand(Dependencies{Stdout: io.Discard, Stderr: io.Discard})
	for _, args := range [][]string{
		{"djt", "agent"},
		{"djt", "api", "interface"},
		{"djt", "api", "psm", "list"},
		{"djt", "psm", "list"},
	} {
		_, remaining, err := root.Find(args)
		if err == nil && len(remaining) == 0 {
			t.Fatalf("removed path must not resolve: %v", args)
		}
	}
}

func TestProductionDependenciesUseOneDeviceClientAndHTTPTimeout(t *testing.T) {
	deps := newProductionDependencies(t.TempDir(), io.Discard, io.Discard)
	httpClient, ok := deps.HTTPClient.(*http.Client)
	if !ok || httpClient.Timeout != 30*time.Second {
		t.Fatalf("http client=%T timeout=%v", deps.HTTPClient, httpClient.Timeout)
	}
	deviceAPI, ok := deps.DeviceAPI.(*auth.DeviceClient)
	if !ok {
		t.Fatalf("device API=%T", deps.DeviceAPI)
	}
	whoAmIAPI, ok := deps.WhoAmIAPI.(*auth.DeviceClient)
	if !ok || deviceAPI != whoAmIAPI {
		t.Fatalf("DeviceAPI=%T WhoAmIAPI=%T same=%v", deps.DeviceAPI, deps.WhoAmIAPI, deviceAPI == whoAmIAPI)
	}
	if deps.ConfigDir == "" || deps.Store == nil || deps.Browser == nil || deps.Wait == nil || deps.Now == nil || deps.Stdin == nil {
		t.Fatalf("生产依赖不完整: %+v", deps)
	}
}

func TestHTTPClientDoesNotFollowRedirects(t *testing.T) {
	redirectCalls := 0
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		redirectCalls++
		if redirectCalls == 1 {
			if got := r.Header.Get("X-DJT-CLI-Authorization"); got == "" {
				t.Error("first request must have auth header")
			}
			http.Redirect(w, r, "/target", http.StatusFound)
			return
		}
		t.Errorf("must not follow redirect to %s", r.URL.Path)
	}))
	defer srv.Close()

	deps := newProductionDependencies(t.TempDir(), io.Discard, io.Discard)
	req, _ := http.NewRequest(http.MethodGet, srv.URL, nil)
	req.Header.Set("X-DJT-CLI-Authorization", "Bearer token")

	resp, err := deps.HTTPClient.Do(req)
	if err != nil {
		t.Fatalf("Do failed: %v", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusFound {
		t.Errorf("status = %d, want 302", resp.StatusCode)
	}
	if redirectCalls != 1 {
		t.Errorf("calls = %d, want 1", redirectCalls)
	}
}

func TestNewProductionRootFailsClosedWhenUserConfigDirFails(t *testing.T) {
	configErr := errors.New("user config dir unavailable")
	root, err := newProductionRoot(func() (string, error) {
		return "", configErr
	})
	if root != nil {
		t.Fatal("用户配置目录失败时不应构造命令或相对 credentials 路径")
	}
	if !errors.Is(err, configErr) {
		t.Fatalf("err=%v want=%v", err, configErr)
	}
	if err == nil || !strings.Contains(err.Error(), "用户配置目录") {
		t.Fatalf("err=%v", err)
	}
}

type commandLoginSessionStore struct {
	session auth.LoginSession
	loadErr error
	saves   int
	deletes int
}

func (s *commandLoginSessionStore) Load(context.Context) (auth.LoginSession, error) {
	return s.session, s.loadErr
}
func (s *commandLoginSessionStore) Save(_ context.Context, session auth.LoginSession) error {
	s.session = session
	s.saves++
	return nil
}
func (s *commandLoginSessionStore) Delete(context.Context) error { s.deletes++; return nil }

func TestAuthLoginStartPersistsSessionAndReturnsOnlyPublicPrompt(t *testing.T) {
	now := commandNow()
	device := &commandDeviceAPI{start: auth.DeviceStart{DeviceCode: "device-secret", CodeVerifier: "verifier-secret", UserCode: "ABCD", VerificationURI: "https://verify", ExpiresIn: 60, Interval: 1}}
	sessions := &commandLoginSessionStore{}
	var stdout bytes.Buffer
	root := NewRootCommand(Dependencies{DeviceAPI: device, WhoAmIAPI: &commandWhoAmI{}, Store: &commandStore{}, LoginSessions: sessions, Browser: commandBrowser{}, Wait: func(context.Context, time.Duration) error { return nil }, Now: func() time.Time { return now }, Stdout: &stdout, Stderr: io.Discard})
	root.SetArgs([]string{"--output", "json", "djt", "auth", "login", "start"})
	if err := root.Execute(); err != nil {
		t.Fatal(err)
	}
	if sessions.saves != 1 || sessions.session.DeviceCode != "device-secret" {
		t.Fatalf("sessions=%+v", sessions)
	}
	if strings.Contains(stdout.String(), "device-secret") || strings.Contains(stdout.String(), "verifier-secret") {
		t.Fatal("输出泄漏登录会话秘密")
	}
	for _, want := range []string{"verification_url", "user_code", "expires_at", "https://verify", "ABCD"} {
		if !strings.Contains(stdout.String(), want) {
			t.Fatalf("stdout=%q missing=%q", stdout.String(), want)
		}
	}
}

func TestAuthLoginStartReusesActiveSession(t *testing.T) {
	now := commandNow()
	sessions := &commandLoginSessionStore{session: auth.LoginSession{BaseURL: "https://djt.bytedance.net", DeviceCode: "device-secret", CodeVerifier: "verifier-secret", UserCode: "EXISTING", VerificationURL: "https://verify-existing", ExpiresAt: now.Add(time.Minute), Interval: 1}}
	device := &commandDeviceAPI{}
	var stdout bytes.Buffer
	root := NewRootCommand(Dependencies{DeviceAPI: device, WhoAmIAPI: &commandWhoAmI{}, Store: &commandStore{}, LoginSessions: sessions, Browser: commandBrowser{}, Wait: func(context.Context, time.Duration) error { return nil }, Now: func() time.Time { return now }, Stdout: &stdout, Stderr: io.Discard})
	root.SetArgs([]string{"--output", "json", "djt", "auth", "login", "start"})
	if err := root.Execute(); err != nil {
		t.Fatal(err)
	}
	if device.startCalls != 0 || sessions.saves != 0 || sessions.deletes != 0 {
		t.Fatalf("startCalls=%d saves=%d deletes=%d", device.startCalls, sessions.saves, sessions.deletes)
	}
	if !strings.Contains(stdout.String(), "https://verify-existing") || !strings.Contains(stdout.String(), "EXISTING") {
		t.Fatalf("stdout=%q", stdout.String())
	}
}

func TestAuthLoginCompleteResumesAndDeletesSession(t *testing.T) {
	now := commandNow()
	sessions := &commandLoginSessionStore{session: auth.LoginSession{BaseURL: "https://djt.bytedance.net", DeviceCode: "device-secret", CodeVerifier: "verifier-secret", UserCode: "ABCD", VerificationURL: "https://verify", ExpiresAt: now.Add(time.Minute), Interval: 1}}
	device := &commandDeviceAPI{tokens: []commandTokenResult{{token: auth.DeviceToken{AccessToken: "token-secret", TokenType: "Bearer", ExpiresIn: 3600}}}}
	store := &commandStore{}
	var stdout bytes.Buffer
	root := NewRootCommand(Dependencies{DeviceAPI: device, WhoAmIAPI: &commandWhoAmI{user: auth.User{EmployeeID: "123"}}, Store: store, LoginSessions: sessions, Browser: commandBrowser{}, Wait: func(context.Context, time.Duration) error { return nil }, Now: func() time.Time { return now }, Stdout: &stdout, Stderr: io.Discard})
	root.SetArgs([]string{"--output", "json", "djt", "auth", "login", "complete"})
	if err := root.Execute(); err != nil {
		t.Fatal(err)
	}
	if store.saves != 1 || sessions.deletes != 1 {
		t.Fatalf("credential saves=%d session deletes=%d", store.saves, sessions.deletes)
	}
	if !strings.Contains(stdout.String(), `"authenticated":true`) || strings.Contains(stdout.String(), "token-secret") {
		t.Fatalf("stdout=%q", stdout.String())
	}
}

func TestMigrateDJTConfigDirMovesLegacyFiles(t *testing.T) {
	base := t.TempDir()
	legacy := filepath.Join(base, "opencli")
	if err := os.MkdirAll(legacy, 0o700); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(legacy, "credentials.json"), []byte(`{"ok":true}`), 0o600); err != nil {
		t.Fatal(err)
	}
	var stderr bytes.Buffer
	dest, err := migrateDJTConfigDir(base, &stderr)
	if err != nil {
		t.Fatal(err)
	}
	want := filepath.Join(base, "doudian-open-cli", "djt")
	if dest != want {
		t.Fatalf("dest=%q want=%q", dest, want)
	}
	if _, err := os.Stat(filepath.Join(want, "credentials.json")); err != nil {
		t.Fatal(err)
	}
	if _, err := os.Stat(filepath.Join(legacy, "credentials.json")); !errors.Is(err, os.ErrNotExist) {
		t.Fatalf("legacy file should be moved: %v", err)
	}
}

func TestMigrateDJTConfigDirKeepsLegacyWhenDestExists(t *testing.T) {
	base := t.TempDir()
	legacy := filepath.Join(base, "opencli")
	dest := filepath.Join(base, "doudian-open-cli", "djt")
	if err := os.MkdirAll(legacy, 0o700); err != nil {
		t.Fatal(err)
	}
	if err := os.MkdirAll(dest, 0o700); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(legacy, "credentials.json"), []byte("old"), 0o600); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(dest, "credentials.json"), []byte("new"), 0o600); err != nil {
		t.Fatal(err)
	}
	var stderr bytes.Buffer
	got, err := migrateDJTConfigDir(base, &stderr)
	if err != nil {
		t.Fatal(err)
	}
	if got != dest {
		t.Fatalf("dest=%q", got)
	}
	content, err := os.ReadFile(filepath.Join(dest, "credentials.json"))
	if err != nil || string(content) != "new" {
		t.Fatalf("dest content=%q err=%v", content, err)
	}
	if _, err := os.Stat(filepath.Join(legacy, "credentials.json")); err != nil {
		t.Fatal(err)
	}
	if !strings.Contains(stderr.String(), "保留旧文件") {
		t.Fatalf("stderr=%q", stderr.String())
	}
}

func TestRootDoesNotInstallOpenSkill(t *testing.T) {
	home := t.TempDir()
	root := NewRootCommand(Dependencies{HomeDir: home, Stdout: io.Discard, Stderr: io.Discard})
	root.SetArgs([]string{"self", "skill", "install"})
	if err := root.Execute(); err == nil {
		t.Fatal("根命令不应再提供 self skill install")
	}
	if _, err := os.Stat(filepath.Join(home, ".agents", "skills", "open")); !os.IsNotExist(err) {
		t.Fatalf("不得安装 open Skill: %v", err)
	}
}
