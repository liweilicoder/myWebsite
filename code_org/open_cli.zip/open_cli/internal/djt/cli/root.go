package cli

import (
	"fmt"
	"io"
	"os"
	"path/filepath"
	"time"

	"code.byted.org/temai/open_cli/internal/core/browser"
	corecli "code.byted.org/temai/open_cli/internal/core/cli"
	"code.byted.org/temai/open_cli/internal/core/factory"
	"code.byted.org/temai/open_cli/internal/core/httpx"
	"code.byted.org/temai/open_cli/internal/djt/auth"
	"github.com/spf13/cobra"
)

type Dependencies struct {
	HTTPClient    auth.HTTPDoer
	DeviceAPI     auth.DeviceAPI
	WhoAmIAPI     auth.WhoAmIAPI
	Store         auth.CredentialStore
	LoginSessions auth.LoginSessionStore
	Browser       auth.BrowserOpener
	Wait          auth.WaitFunc
	Now           func() time.Time
	ConfigDir     string
	HomeDir       string
	Stdin         io.Reader
	Stdout        io.Writer
	Stderr        io.Writer
}

func NewRootCommand(deps Dependencies) *cobra.Command {
	return newRootCommand(deps, corecli.BuildVersion)
}

func newRootCommand(deps Dependencies, version string) *cobra.Command {
	root, format := corecli.NewRoot(corecli.RootOptions{
		Version: version,
		Stdout:  deps.Stdout,
		Stderr:  deps.Stderr,
		HomeDir: deps.HomeDir,
		ShowPPE: true,
	})
	root.AddCommand(newDJTCommand(deps, format, version))
	return root
}

func newProductionDependencies(configDir string, stdout, stderr io.Writer) Dependencies {
	return dependenciesWithHTTP(configDir, stdout, stderr, httpx.NewClient())
}

func dependenciesWithHTTP(configDir string, stdout, stderr io.Writer, httpClient auth.HTTPDoer) Dependencies {
	deviceClient := auth.NewDeviceClient(httpClient)
	return Dependencies{
		HTTPClient:    httpClient,
		DeviceAPI:     deviceClient,
		WhoAmIAPI:     deviceClient,
		Store:         auth.NewFileStore(configDir),
		LoginSessions: auth.NewLoginSessionFileStore(configDir),
		Browser:       browser.SystemOpener{},
		Wait:          auth.Wait,
		Now:           time.Now,
		ConfigDir:     configDir,
		Stdin:         os.Stdin,
		Stdout:        stdout,
		Stderr:        stderr,
	}
}

func DependenciesFromFactory(f *factory.Factory, djtConfigDir string) (Dependencies, error) {
	client, err := f.HttpClient()
	if err != nil {
		return Dependencies{}, err
	}
	stdin, stdout, stderr := io.Reader(os.Stdin), io.Writer(os.Stdout), io.Writer(os.Stderr)
	if f.IOStreams != nil {
		if f.IOStreams.In != nil {
			stdin = f.IOStreams.In
		}
		if f.IOStreams.Out != nil {
			stdout = f.IOStreams.Out
		}
		if f.IOStreams.ErrOut != nil {
			stderr = f.IOStreams.ErrOut
		}
	}
	deps := dependenciesWithHTTP(djtConfigDir, stdout, stderr, client)
	deps.Stdin = stdin
	deps.HomeDir = f.HomeDir
	return deps, nil
}

func Attach(root *cobra.Command, f *factory.Factory, format *corecli.OutputFormat, version string) error {
	stderr := io.Writer(io.Discard)
	if f != nil && f.IOStreams != nil && f.IOStreams.ErrOut != nil {
		stderr = f.IOStreams.ErrOut
	}
	djtDir := filepath.Join(f.ConfigDir, "djt")
	if filepath.Base(f.ConfigDir) == "doudian-open-cli" {
		migrated, err := migrateDJTConfigDir(filepath.Dir(f.ConfigDir), stderr)
		if err != nil {
			return err
		}
		djtDir = migrated
	} else if err := os.MkdirAll(djtDir, 0o700); err != nil {
		return err
	}
	deps, err := DependenciesFromFactory(f, djtDir)
	if err != nil {
		return err
	}
	if version == "" {
		version = corecli.BuildVersion
	}
	root.AddCommand(newDJTCommand(deps, format, version))
	return nil
}

func newProductionRoot(userConfigDir func() (string, error)) (*cobra.Command, error) {
	base, err := userConfigDir()
	if err != nil {
		return nil, fmt.Errorf("无法获取用户配置目录: %w", err)
	}
	configDir, err := migrateDJTConfigDir(base, os.Stderr)
	if err != nil {
		return nil, err
	}
	homeDir, err := os.UserHomeDir()
	if err != nil {
		return nil, fmt.Errorf("无法获取用户主目录: %w", err)
	}
	deps := newProductionDependencies(configDir, os.Stdout, os.Stderr)
	deps.HomeDir = homeDir
	return NewRootCommand(deps), nil
}

func NewProductionRoot() (*cobra.Command, error) {
	return newProductionRoot(os.UserConfigDir)
}

func migrateDJTConfigDir(userConfigDir string, stderr io.Writer) (string, error) {
	dest := filepath.Join(userConfigDir, "doudian-open-cli", "djt")
	legacy := filepath.Join(userConfigDir, "opencli")
	if err := os.MkdirAll(dest, 0o700); err != nil {
		return "", fmt.Errorf("创建点将台配置目录: %w", err)
	}
	for _, name := range []string{"credentials.json", "login-session.json"} {
		from := filepath.Join(legacy, name)
		to := filepath.Join(dest, name)
		if _, err := os.Stat(from); err != nil {
			continue
		}
		if _, err := os.Stat(to); err == nil {
			_, _ = fmt.Fprintf(stderr, "已存在 %s，保留旧文件 %s\n", to, from)
			continue
		}
		if err := os.Rename(from, to); err != nil {
			return "", fmt.Errorf("迁移 %s: %w", name, err)
		}
	}
	return dest, nil
}
