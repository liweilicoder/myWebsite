package cli

const djtBaseURL = "https://djt.bytedance.net"
