package cli

import (
	"bytes"
	"encoding/json"
	"errors"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"testing"

	"code.byted.org/temai/open_cli/internal/djt"
	"code.byted.org/temai/open_cli/internal/djt/auth"
)

type agentRequestSnapshot struct {
	method string
	path   string
	query  string
	header http.Header
	body   []byte
}

type agentCommandRecorder struct {
	requests []agentRequestSnapshot
	status   int32
}

func (r *agentCommandRecorder) Do(request *http.Request) (*http.Response, error) {
	var body []byte
	var err error
	if request.Body != nil {
		body, err = io.ReadAll(request.Body)
	}
	if err != nil {
		return nil, err
	}
	r.requests = append(r.requests, agentRequestSnapshot{
		method: request.Method,
		path:   request.URL.Path,
		query:  request.URL.RawQuery,
		header: request.Header.Clone(),
		body:   body,
	})
	status := r.status
	if status == 0 {
		status = 110
	}
	if request.Method == http.MethodGet {
		return commandJSONResponse(http.StatusOK, `{"code":0,"message":"success","data":{"current":{"interfaceId":2846,"modifyVersionId":42,"statusV2":`+agentInt32String(status)+`,"configPhase":"doc_editing","nextStep":"doc","requestInfo":[{"path":"secret-tree"}],"responseInfo":[]}}}`), nil
	}
	switch request.URL.Path {
	case "/api/djt-cli/agent/interface/save":
		return commandJSONResponse(http.StatusOK, `{"code":0,"message":"success","data":{"dryRun":true,"applied":false,"current":{"interfaceId":2846,"modifyVersionId":42,"statusV2":30}}}`), nil
	case "/api/djt-cli/agent/interface/doc":
		return commandJSONResponse(http.StatusOK, `{"code":0,"message":"success","data":{"applied":true,"autoFilled":true,"current":{"interfaceId":2846,"modifyVersionId":43,"statusV2":300},"tempDocUrl":"https://doc.example/preview"}}`), nil
	case "/api/djt-cli/agent/interface/advanceStep":
		return commandJSONResponse(http.StatusOK, `{"code":0,"message":"success","data":{"dryRun":true,"applied":false,"current":{"interfaceId":2846,"modifyVersionId":42,"statusV2":110}}}`), nil
	default:
		return commandJSONResponse(http.StatusOK, `{"code":0,"message":"success","data":{"bamVersionId":"1.0.1","psm":"cmp.a","methodName":"Get","current":{"interfaceId":2846,"modifyVersionId":42,"statusV2":30}}}`), nil
	}
}

func agentInt32String(value int32) string {
	return strings.TrimSpace(string(mustJSONMarshal(value)))
}

func mustJSONMarshal(value any) []byte {
	data, err := json.Marshal(value)
	if err != nil {
		panic(err)
	}
	return data
}

func newAgentTestRoot(recorder *agentCommandRecorder, stdout io.Writer, stdin io.Reader) *cobraCommandFacade {
	if stdout == nil {
		stdout = io.Discard
	}
	if stdin == nil {
		stdin = strings.NewReader("")
	}
	root := NewRootCommand(Dependencies{
		HTTPClient: recorder,
		Store:      &commandStore{credentials: validCommandCredentials()},
		Now:        commandNow,
		Stdin:      stdin,
		Stdout:     stdout,
		Stderr:     io.Discard,
	})
	return &cobraCommandFacade{root: root}
}

// cobraCommandFacade keeps test setup terse while all assertions still execute the real Cobra tree.
type cobraCommandFacade struct {
	root interface {
		SetArgs([]string)
		Execute() error
	}
}

func (f *cobraCommandFacade) execute(args ...string) error {
	f.root.SetArgs(args)
	return f.root.Execute()
}

func TestAgentInterfaceCommandTreeAndSharedFlags(t *testing.T) {
	root := NewRootCommand(Dependencies{Stdout: io.Discard, Stderr: io.Discard})
	for _, path := range [][]string{
		{"djt", "api"},
		{"djt", "api", "get"},
		{"djt", "api", "init"},
		{"djt", "api", "save"},
		{"djt", "api", "doc"},
		{"djt", "api", "advance-step"},
	} {
		command, remaining, err := root.Find(path)
		if err != nil || command == nil || len(remaining) != 0 {
			t.Fatalf("path=%v command=%v remaining=%v err=%v", path, command, remaining, err)
		}
		if len(path) <= 2 && command.RunE != nil {
			t.Fatalf("父命令 %v 不应设置 RunE", path)
		}
	}
	iface, _, _ := root.Find([]string{"djt", "api"})
	if iface.PersistentFlags().Lookup("use-ppe") != nil {
		t.Fatal("PPE flag 应只注册在根命令")
	}
	for _, name := range []string{"use-ppe", "ppe-env"} {
		flag := root.PersistentFlags().Lookup(name)
		if flag == nil {
			t.Fatalf("root 缺少 persistent flag --%s", name)
		}
		if flag.Hidden {
			t.Fatalf("对内 root persistent flag --%s 应在 help 中可见", name)
		}
	}
}

func TestAgentGetRequiresExactlyOneSelectorBeforeCredentials(t *testing.T) {
	for _, args := range [][]string{
		{"djt", "api", "get"},
		{"djt", "api", "get", "--interface-id", "2846", "--interface-name", "orders"},
	} {
		called := false
		root := NewRootCommand(Dependencies{
			HTTPClient: commandHTTPDoer(func(*http.Request) (*http.Response, error) { called = true; return nil, nil }),
			Store:      &commandStore{loadErr: errors.New("不应读取凭据")},
			Now:        commandNow,
			Stdout:     io.Discard,
			Stderr:     io.Discard,
		})
		root.SetArgs(args)
		err := root.Execute()
		if err == nil || !strings.Contains(err.Error(), "必须且只能传一个") {
			t.Fatalf("args=%v err=%v", args, err)
		}
		if called {
			t.Fatalf("args=%v 不应发 HTTP", args)
		}
	}
}

func TestAgentJSONSourceSupportsInlineFileAndStdin(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "request.json")
	if err := os.WriteFile(path, []byte(`[{"path":"shopId"}]`), 0o600); err != nil {
		t.Fatal(err)
	}
	for _, test := range []struct {
		name   string
		source string
		stdin  string
	}{
		{name: "inline", source: `[{"path":"shopId"}]`},
		{name: "file", source: "@" + path},
		{name: "stdin", source: "@-", stdin: `[{"path":"shopId"}]`},
	} {
		t.Run(test.name, func(t *testing.T) {
			recorder := &agentCommandRecorder{}
			var stdout bytes.Buffer
			root := newAgentTestRoot(recorder, &stdout, strings.NewReader(test.stdin))
			err := root.execute("--output", "json", "djt", "api", "save", "--interface-id", "2846", "--modify-version-id", "42", "--sections", "request", "--request-info", test.source)
			if err != nil {
				t.Fatal(err)
			}
			if len(recorder.requests) != 1 {
				t.Fatalf("requests=%d", len(recorder.requests))
			}
			var body map[string]json.RawMessage
			if err := json.Unmarshal(recorder.requests[0].body, &body); err != nil {
				t.Fatal(err)
			}
			if string(body["dryRun"]) != "true" || string(body["requestInfo"]) != `[{"path":"shopId"}]` {
				t.Fatalf("body=%s", recorder.requests[0].body)
			}
			var got agentJSONOutput
			if err := json.Unmarshal(stdout.Bytes(), &got); err != nil {
				t.Fatalf("stdout 非法 JSON: %v; stdout=%q", err, stdout.String())
			}
			want := agentJSONOutput{
				Code:    0,
				Message: "success",
				Data:    json.RawMessage(`{"dryRun":true,"applied":false,"current":{"interfaceId":2846,"modifyVersionId":42,"statusV2":30}}`),
			}
			if got.Code != want.Code || got.Message != want.Message {
				t.Fatalf("stdout envelope=%+v want=%+v", got, want)
			}
			var gotData, wantData any
			if err := json.Unmarshal(got.Data, &gotData); err != nil {
				t.Fatal(err)
			}
			if err := json.Unmarshal(want.Data, &wantData); err != nil {
				t.Fatal(err)
			}
			if !reflect.DeepEqual(gotData, wantData) {
				t.Fatalf("stdout data=%s want=%s", got.Data, want.Data)
			}
		})
	}
}

func TestAgentPPEFlagsReachHTTP(t *testing.T) {
	recorder := &agentCommandRecorder{}
	root := newAgentTestRoot(recorder, nil, nil)
	err := root.execute("djt", "api", "--use-ppe=true", "--ppe-env", "ppe_flag", "get", "--interface-id", "2846")
	if err != nil {
		t.Fatal(err)
	}
	if len(recorder.requests) != 1 || recorder.requests[0].header.Get("x-use-ppe") != "1" || recorder.requests[0].header.Get("x-tt-env") != "ppe_flag" {
		t.Fatalf("requests=%+v", recorder.requests)
	}
}

func TestAgentRejectsInvalidPPEEnvironmentBeforeHTTP(t *testing.T) {
	called := false
	root := NewRootCommand(Dependencies{
		HTTPClient: commandHTTPDoer(func(*http.Request) (*http.Response, error) { called = true; return nil, nil }),
		Store:      &commandStore{loadErr: errors.New("不应读取凭据")},
		Now:        commandNow,
		Stdout:     io.Discard,
		Stderr:     io.Discard,
	})
	root.SetArgs([]string{"djt", "api", "get", "--interface-id", "2846", "--use-ppe=true", "--ppe-env", "ppe\\r\\ninjected"})
	err := root.Execute()
	if err == nil || !strings.Contains(err.Error(), "PPE 环境名无效") || called {
		t.Fatalf("err=%v called=%v", err, called)
	}
}

func TestAgentSaveAndAdvanceDefaultToDryRun(t *testing.T) {
	t.Run("save", func(t *testing.T) {
		recorder := &agentCommandRecorder{}
		root := newAgentTestRoot(recorder, nil, nil)
		if err := root.execute("djt", "api", "save", "--interface-id", "2846", "--modify-version-id", "42", "--sections", "basic"); err != nil {
			t.Fatal(err)
		}
		assertAgentBodyBool(t, recorder.requests[0].body, "dryRun", true)
	})
	t.Run("advance", func(t *testing.T) {
		recorder := &agentCommandRecorder{}
		root := newAgentTestRoot(recorder, nil, nil)
		if err := root.execute("djt", "api", "advance-step", "--interface-id", "2846", "--modify-version-id", "42", "--step", "request"); err != nil {
			t.Fatal(err)
		}
		if len(recorder.requests) != 2 || recorder.requests[0].method != http.MethodGet || recorder.requests[1].path != "/api/djt-cli/agent/interface/advanceStep" {
			t.Fatalf("requests=%+v", recorder.requests)
		}
		assertAgentBodyBool(t, recorder.requests[1].body, "dryRun", true)
	})
}

func TestAgentWriteModesAreMutuallyExclusive(t *testing.T) {
	for _, args := range [][]string{
		{"djt", "api", "save", "--interface-id", "2846", "--modify-version-id", "42", "--sections", "basic", "--dry-run", "--apply"},
		{"djt", "api", "advance-step", "--interface-id", "2846", "--modify-version-id", "42", "--step", "request", "--dry-run", "--apply"},
	} {
		recorder := &agentCommandRecorder{}
		root := newAgentTestRoot(recorder, nil, nil)
		err := root.execute(args...)
		if err == nil || !strings.Contains(err.Error(), "互斥") || len(recorder.requests) != 0 {
			t.Fatalf("args=%v err=%v requests=%d", args, err, len(recorder.requests))
		}
	}
}

func TestAgentInitGateErrorsGiveCompleteGuidanceBeforeCredentialsOrHTTP(t *testing.T) {
	base := []string{
		"djt", "api", "init",
		"--psm", "cmp.a",
		"--method-name", "Get",
		"--bam-version-id", "1.0.1",
	}
	tests := []struct {
		name  string
		flags []string
	}{
		{name: "缺 apply", flags: []string{"--biz-domain-id", "8", "--confirmed-by-user"}},
		{name: "缺 confirmed", flags: []string{"--biz-domain-id", "8", "--apply"}},
		{name: "缺 biz domain", flags: []string{"--confirmed-by-user", "--apply"}},
	}
	guidance := []string{
		"先运行 doudian-open-cli djt biz-domain list --output json",
		"展示动态结果",
		"不得自动选择测试域",
		"完整确认清单",
		"等待用户明确答复",
		"--confirmed-by-user --apply",
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			store := &commandStore{credentials: validCommandCredentials()}
			httpCalls := 0
			root := NewRootCommand(Dependencies{
				HTTPClient: commandHTTPDoer(func(*http.Request) (*http.Response, error) {
					httpCalls++
					return nil, errors.New("不应发 HTTP")
				}),
				Store:  store,
				Now:    commandNow,
				Stdout: io.Discard,
				Stderr: io.Discard,
			})
			root.SetArgs(append(append([]string(nil), base...), test.flags...))
			err := root.Execute()
			if err == nil {
				t.Fatal("expected init gate error")
			}
			for _, want := range guidance {
				if !strings.Contains(err.Error(), want) {
					t.Fatalf("err=%q missing=%q", err, want)
				}
			}
			if store.loads != 0 || httpCalls != 0 {
				t.Fatalf("credentials loads=%d HTTP calls=%d", store.loads, httpCalls)
			}
		})
	}
}

func TestAgentInitRequiresExplicitPositiveBizDomainIDBeforeHTTP(t *testing.T) {
	for _, test := range []struct {
		name string
		flag []string
	}{
		{name: "未传"},
		{name: "零值", flag: []string{"--biz-domain-id", "0"}},
		{name: "负数", flag: []string{"--biz-domain-id", "-9"}},
	} {
		t.Run(test.name, func(t *testing.T) {
			store := &commandStore{credentials: validCommandCredentials()}
			httpCalls := 0
			root := NewRootCommand(Dependencies{
				HTTPClient: commandHTTPDoer(func(*http.Request) (*http.Response, error) {
					httpCalls++
					return nil, errors.New("不应发 HTTP")
				}),
				Store:  store,
				Now:    commandNow,
				Stdout: io.Discard,
				Stderr: io.Discard,
			})
			args := []string{
				"djt", "api", "init",
				"--psm", "cmp.a",
				"--method-name", "Get",
				"--bam-version-id", "1.0.1",
				"--confirmed-by-user",
				"--apply",
			}
			args = append(args, test.flag...)
			root.SetArgs(args)
			err := root.Execute()
			if err == nil {
				t.Fatal("expected biz-domain-id validation error")
			}
			for _, want := range []string{
				"doudian-open-cli djt biz-domain list --output json",
				"展示动态结果",
				"向用户确认业务域",
				"等待用户明确答复",
			} {
				if !strings.Contains(err.Error(), want) {
					t.Fatalf("err=%q missing=%q", err, want)
				}
			}
			if store.loads != 0 {
				t.Fatalf("credential store loads=%d, want 0", store.loads)
			}
			if httpCalls != 0 {
				t.Fatalf("HTTP calls=%d, want 0", httpCalls)
			}
		})
	}
}

func TestAgentInitRequiresUserConfirmationBeforeHTTP(t *testing.T) {
	recorder := &agentCommandRecorder{}
	root := newAgentTestRoot(recorder, nil, nil)
	err := root.execute(
		"djt", "api", "init",
		"--psm", "cmp.a",
		"--method-name", "Get",
		"--bam-version-id", "1.0.1",
		"--biz-domain-id", "8",
		"--apply",
	)
	if err == nil || !strings.Contains(err.Error(), "--confirmed-by-user") || !strings.Contains(err.Error(), "确认清单") {
		t.Fatalf("err=%v", err)
	}
	if len(recorder.requests) != 0 {
		t.Fatalf("requests=%d", len(recorder.requests))
	}
}

func TestAgentInitWithBothGatesOmitsLocalConfirmationFromBody(t *testing.T) {
	recorder := &agentCommandRecorder{}
	root := newAgentTestRoot(recorder, nil, nil)
	if err := root.execute(
		"djt", "api", "init",
		"--psm", "cmp.a",
		"--method-name", "Get",
		"--bam-version-id", "1.0.1",
		"--biz-domain-id", "8",
		"--confirmed-by-user",
		"--apply",
	); err != nil {
		t.Fatal(err)
	}
	if len(recorder.requests) != 1 {
		t.Fatalf("requests=%d", len(recorder.requests))
	}
	var body map[string]json.RawMessage
	if err := json.Unmarshal(recorder.requests[0].body, &body); err != nil {
		t.Fatal(err)
	}
	if _, exists := body["confirmedByUser"]; exists {
		t.Fatalf("本地门禁不应发送给服务端: %s", recorder.requests[0].body)
	}
	if got := string(body["bizDomainId"]); got != "8" {
		t.Fatalf("bizDomainId=%s body=%s", got, recorder.requests[0].body)
	}
}

func TestAgentInitHelpExplainsConfirmationChecklistAndPersistence(t *testing.T) {
	var stdout bytes.Buffer
	root := NewRootCommand(Dependencies{Stdout: &stdout, Stderr: io.Discard})
	root.SetOut(&stdout)
	root.SetArgs([]string{"djt", "api", "init", "--help"})
	if err := root.Execute(); err != nil {
		t.Fatal(err)
	}
	for _, want := range []string{
		"新建/重绑", "PSM", "methodName", "bamVersionId", "interfaceName", "省略会生成测试路径",
		"bizDomainId", "ownerList", "省略为当前用户", "skipAuth", "desc", "sceneDesc", "interfaceCateId",
		"直接落库", "BAM 绑定/解析失败草稿不回滚", "--confirmed-by-user --apply",
	} {
		if !strings.Contains(stdout.String(), want) {
			t.Fatalf("help=%q missing=%q", stdout.String(), want)
		}
	}
}

func TestAgentInitAndDocRequireApplyBeforeHTTP(t *testing.T) {
	for _, test := range []struct {
		name string
		args []string
		want string
	}{
		{name: "init", args: []string{"djt", "api", "init", "--psm", "cmp.a", "--method-name", "Get", "--bam-version-id", "1.0.1"}, want: "init 会直接落库，必须显式传 --apply"},
		{name: "doc", args: []string{"djt", "api", "doc", "--interface-id", "2846", "--modify-version-id", "42", "--desc", "查询订单"}, want: "doc 会直接落库，必须显式传 --apply"},
	} {
		t.Run(test.name, func(t *testing.T) {
			recorder := &agentCommandRecorder{}
			root := newAgentTestRoot(recorder, nil, nil)
			err := root.execute(test.args...)
			if err == nil || !strings.Contains(err.Error(), test.want) || len(recorder.requests) != 0 {
				t.Fatalf("err=%v requests=%d", err, len(recorder.requests))
			}
		})
	}
}

func TestAgentDocDoesNotExposeDryRun(t *testing.T) {
	root := NewRootCommand(Dependencies{Stdout: io.Discard, Stderr: io.Discard})
	doc, _, err := root.Find([]string{"djt", "api", "doc"})
	if err != nil {
		t.Fatal(err)
	}
	if doc.Flags().Lookup("dry-run") != nil {
		t.Fatal("doc 不应注册 --dry-run")
	}
	root.SetArgs([]string{"djt", "api", "doc", "--interface-id", "2846", "--modify-version-id", "42", "--apply", "--dry-run"})
	if err := root.Execute(); err == nil || !strings.Contains(err.Error(), "unknown flag") {
		t.Fatalf("err=%v", err)
	}
}

func TestAgentSubmitAuditRequiresReasonBeforeHTTP(t *testing.T) {
	recorder := &agentCommandRecorder{}
	root := newAgentTestRoot(recorder, nil, nil)
	err := root.execute("djt", "api", "advance-step", "--interface-id", "2846", "--modify-version-id", "42", "--step", "submit-audit", "--apply")
	if err == nil || !strings.Contains(err.Error(), "--audit-reason 不能为空") || len(recorder.requests) != 0 {
		t.Fatalf("err=%v requests=%d", err, len(recorder.requests))
	}
}

func TestAgentSubmitAuditRequiresMeegoBeforeHTTP(t *testing.T) {
	recorder := &agentCommandRecorder{}
	root := newAgentTestRoot(recorder, nil, nil)
	err := root.execute(
		"djt", "api", "advance-step",
		"--interface-id", "2846",
		"--modify-version-id", "42",
		"--step", "submit-audit",
		"--audit-reason", "reason",
		"--apply",
	)
	if err == nil || !strings.Contains(err.Error(), "--audit-meego") || len(recorder.requests) != 0 {
		t.Fatalf("err=%v requests=%d", err, len(recorder.requests))
	}
}

func TestAgentAdvanceRejects330BeforePost(t *testing.T) {
	recorder := &agentCommandRecorder{status: 330}
	root := newAgentTestRoot(recorder, nil, nil)
	err := root.execute("djt", "api", "advance-step", "--interface-id", "2846", "--modify-version-id", "42", "--step", "request", "--apply")
	if err == nil || !strings.Contains(err.Error(), "330 及以上只能在网页发布") {
		t.Fatalf("err=%v", err)
	}
	if len(recorder.requests) != 1 || recorder.requests[0].method != http.MethodGet {
		t.Fatalf("requests=%+v", recorder.requests)
	}
}

func TestAgentCredentialsCheckedBeforeHTTP(t *testing.T) {
	for _, test := range []struct {
		name  string
		store *commandStore
		want  error
	}{
		{name: "missing", store: &commandStore{loadErr: auth.ErrNotLoggedIn}, want: auth.ErrNotLoggedIn},
		{name: "expired", store: &commandStore{credentials: func() auth.Credentials { c := validCommandCredentials(); c.ExpiresAt = commandNow(); return c }()}, want: auth.ErrExpired},
	} {
		t.Run(test.name, func(t *testing.T) {
			called := false
			root := NewRootCommand(Dependencies{
				HTTPClient: commandHTTPDoer(func(*http.Request) (*http.Response, error) { called = true; return nil, nil }),
				Store:      test.store,
				Now:        commandNow,
				Stdout:     io.Discard,
				Stderr:     io.Discard,
			})
			root.SetArgs([]string{"djt", "api", "get", "--interface-id", "2846"})
			if err := root.Execute(); !errors.Is(err, test.want) || called {
				t.Fatalf("err=%v called=%v", err, called)
			}
		})
	}
}

func TestAgentFlagToJSONMapping(t *testing.T) {
	tests := []struct {
		name string
		args []string
		post int
		want map[string]any
	}{
		{
			name: "init",
			args: []string{"djt", "api", "init", "--psm", "cmp.a", "--method-name", "Get", "--bam-version-id", "1.0.1", "--interface-id", "9", "--interface-name", "", "--biz-domain-id", "8", "--desc", "", "--scene-desc", "scene", "--owner-list", `["alice"]`, "--interface-cate-id", "7", "--skip-auth=false", "--confirmed-by-user", "--apply"},
			post: 0,
			want: map[string]any{"interfaceId": float64(9), "psm": "cmp.a", "methodName": "Get", "bamVersionId": "1.0.1", "interfaceName": "", "bizDomainId": float64(8), "desc": "", "sceneDesc": "scene", "ownerList": []any{"alice"}, "interfaceCateId": float64(7), "skipAuth": false},
		},
		{
			name: "save",
			args: []string{"djt", "api", "save", "--interface-id", "2846", "--modify-version-id", "42", "--sections", "request,response,request", "--request-info", `[]`, "--response-info", `[]`, "--err-config-list", `[]`, "--style-patches", `[]`, "--owner-list", `[]`, "--auth-subject-ids", `[0]`, "--bam-version-id", "", "--interface-name", "", "--method-name", "", "--psm", "", "--desc", "", "--scene-desc", "", "--interface-cate-id", "0", "--skip-auth=false", "--sla-rt", "0", "--sla-ava", "", "--qps", "0", "--timeout", "0", "--call-type", "0", "--biz-succ-err-code", "", "--err-code", "", "--err-msg", "", "--release-note", "", "--apply"},
			post: 0,
			want: map[string]any{"interfaceId": float64(2846), "modifyVersionId": float64(42), "sections": []any{"request", "response"}, "dryRun": false, "requestInfo": []any{}, "responseInfo": []any{}, "errConfigList": []any{}, "stylePatches": []any{}, "ownerList": []any{}, "authSubjectId": []any{float64(0)}, "bamVersionId": "", "interfaceName": "", "methodName": "", "psm": "", "desc": "", "sceneDesc": "", "interfaceCateId": float64(0), "skipAuth": false, "slaRt": float64(0), "slaAva": "", "qps": float64(0), "timeout": float64(0), "callType": float64(0), "bizSuccErrCode": "", "errCode": "", "errMsg": "", "releaseNote": ""},
		},
		{
			name: "doc",
			args: []string{"djt", "api", "doc", "--interface-id", "2846", "--modify-version-id", "42", "--auto-fill=false", "--with-preview-url=false", "--desc", "", "--scene-desc", "", "--release-note", "", "--request-info", `[]`, "--response-info", `[]`, "--err-config-list", `[]`, "--biz-succ-err-code", "", "--err-code", "", "--err-msg", "", "--apply"},
			post: 0,
			want: map[string]any{"interfaceId": float64(2846), "modifyVersionId": float64(42), "autoFill": false, "withPreviewUrl": false, "desc": "", "sceneDesc": "", "releaseNote": "", "requestInfo": []any{}, "responseInfo": []any{}, "errConfigList": []any{}, "bizSuccErrCode": "", "errCode": "", "errMsg": ""},
		},
		{
			name: "advance",
			args: []string{"djt", "api", "advance-step", "--interface-id", "2846", "--modify-version-id", "42", "--step", "submit-audit", "--audit-reason", "reason", "--audit-meego", "https://meego.example.test/story/123", "--skip-reason", "", "--request-info", `[]`, "--response-info", `[]`, "--err-config-list", `[]`, "--style-patches", `[]`, "--owner-list", `[]`, "--auth-subject-ids", `[]`, "--interface-name", "", "--method-name", "", "--psm", "", "--desc", "", "--scene-desc", "", "--interface-cate-id", "0", "--skip-auth=false", "--biz-succ-err-code", "", "--err-code", "", "--err-msg", "", "--release-note", "", "--apply"},
			post: 1,
			want: map[string]any{"interfaceId": float64(2846), "modifyVersionId": float64(42), "step": "submit-audit", "dryRun": false, "auditReason": "reason", "auditMeego": "https://meego.example.test/story/123", "skipReason": "", "requestInfo": []any{}, "responseInfo": []any{}, "errConfigList": []any{}, "stylePatches": []any{}, "ownerList": []any{}, "authSubjectId": []any{}, "interfaceName": "", "methodName": "", "psm": "", "desc": "", "sceneDesc": "", "interfaceCateId": float64(0), "skipAuth": false, "bizSuccErrCode": "", "errCode": "", "errMsg": "", "releaseNote": ""},
		},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			recorder := &agentCommandRecorder{}
			root := newAgentTestRoot(recorder, nil, nil)
			if err := root.execute(test.args...); err != nil {
				t.Fatal(err)
			}
			var got map[string]any
			if err := json.Unmarshal(recorder.requests[test.post].body, &got); err != nil {
				t.Fatal(err)
			}
			if string(mustJSONMarshal(got)) != string(mustJSONMarshal(test.want)) {
				t.Fatalf("body=%s\nwant=%s", mustJSONMarshal(got), mustJSONMarshal(test.want))
			}
		})
	}
}

func TestAgentCredentialsValidateOriginBeforeHTTP(t *testing.T) {
	tests := []struct {
		name      string
		baseURL   string
		wantError string
		wantCalls int
	}{
		{name: "same origin", baseURL: "https://DJT.bytedance.net:443/login", wantCalls: 1},
		{name: "empty legacy base URL", baseURL: "", wantCalls: 1},
		{name: "cross origin", baseURL: "https://credential.example.com", wantError: "与固定点将台 origin 不一致"},
		{name: "invalid base URL", baseURL: "http://evil.example.com", wantError: "base_url 无效"},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			credentials := validCommandCredentials()
			credentials.BaseURL = test.baseURL
			recorder := &agentCommandRecorder{}
			root := NewRootCommand(Dependencies{
				HTTPClient: recorder,
				Store:      &commandStore{credentials: credentials},
				Now:        commandNow,
				Stdin:      strings.NewReader(""),
				Stdout:     io.Discard,
				Stderr:     io.Discard,
			})
			root.SetArgs([]string{"djt", "api", "get", "--interface-id", "2846"})
			err := root.Execute()
			if test.wantError == "" {
				if err != nil {
					t.Fatalf("err=%v", err)
				}
			} else if err == nil || !strings.Contains(err.Error(), test.wantError) {
				t.Fatalf("err=%v want substring=%q", err, test.wantError)
			}
			if len(recorder.requests) != test.wantCalls {
				t.Fatalf("HTTP calls=%d want=%d", len(recorder.requests), test.wantCalls)
			}
			if err != nil && strings.Contains(err.Error(), "token-secret") {
				t.Fatalf("错误泄漏 token: %v", err)
			}
		})
	}
}

func TestAgentJSONSuccessWritesOneDocumentToStdout(t *testing.T) {
	recorder := &agentCommandRecorder{}
	var stdout, stderr bytes.Buffer
	root := NewRootCommand(Dependencies{
		HTTPClient: recorder,
		Store:      &commandStore{credentials: validCommandCredentials()},
		Now:        commandNow,
		Stdin:      strings.NewReader(""),
		Stdout:     &stdout,
		Stderr:     &stderr,
	})
	root.SetArgs([]string{"--output", "json", "djt", "api", "get", "--interface-id", "2846"})
	if err := root.Execute(); err != nil {
		t.Fatal(err)
	}

	output := append([]byte(nil), stdout.Bytes()...)
	decoder := json.NewDecoder(bytes.NewReader(output))
	var document agentJSONOutput
	if err := decoder.Decode(&document); err != nil {
		t.Fatalf("解码 stdout: %v; stdout=%q", err, output)
	}
	if document.Code != 0 || document.Message != "success" || !bytes.Contains(document.Data, []byte(`"interfaceId":2846`)) {
		t.Fatalf("document=%+v", document)
	}
	var extra json.RawMessage
	if err := decoder.Decode(&extra); !errors.Is(err, io.EOF) {
		t.Fatalf("stdout 必须只有一个 JSON 文档: err=%v extra=%s stdout=%q", err, extra, output)
	}
	if !bytes.HasSuffix(output, []byte("\n")) {
		t.Fatalf("stdout JSON 必须以换行结束: %q", output)
	}
	if stderr.Len() != 0 {
		t.Fatalf("stderr=%q", stderr.String())
	}
	if bytes.Contains(output, []byte("token-secret")) || bytes.IndexAny(output, "\x00\x07\x1b\t\r") >= 0 {
		t.Fatalf("成功输出泄漏 token 或控制字符: %q", output)
	}
}

func TestAgentJSONSuccessRedactsTokenAndPreservesBusinessStrings(t *testing.T) {
	const businessString = "接口文档\n\t示例\x1b[31m"
	const response = `{"code":0,"message":"success","data":{"current":{"interfaceId":2846,"modifyVersionId":42,"desc":"接口文档\n\t示例\u001b[31m token-secret","requestInfo":[{"example":"接口文档\n\t示例\u001b[31m token-secret"}]},"future":{"token":"token-secret"}}}`
	var stdout bytes.Buffer
	root := NewRootCommand(Dependencies{
		HTTPClient: commandHTTPDoer(func(*http.Request) (*http.Response, error) {
			return commandJSONResponse(http.StatusOK, response), nil
		}),
		Store:  &commandStore{credentials: validCommandCredentials()},
		Now:    commandNow,
		Stdin:  strings.NewReader(""),
		Stdout: &stdout,
		Stderr: io.Discard,
	})
	root.SetArgs([]string{"--output", "json", "djt", "api", "get", "--interface-id", "2846"})
	if err := root.Execute(); err != nil {
		t.Fatal(err)
	}
	if bytes.Contains(stdout.Bytes(), []byte("token-secret")) {
		t.Fatalf("stdout 泄漏 token: %q", stdout.String())
	}
	var document agentJSONOutput
	if err := json.Unmarshal(stdout.Bytes(), &document); err != nil {
		t.Fatalf("stdout 非法 JSON: %v; stdout=%q", err, stdout.String())
	}
	var data struct {
		Current struct {
			Desc        string              `json:"desc"`
			RequestInfo []map[string]string `json:"requestInfo"`
		} `json:"current"`
		Future map[string]string `json:"future"`
	}
	if err := json.Unmarshal(document.Data, &data); err != nil {
		t.Fatal(err)
	}
	if data.Current.Desc != businessString+" [REDACTED]" || len(data.Current.RequestInfo) != 1 || data.Current.RequestInfo[0]["example"] != businessString+" [REDACTED]" || data.Future["token"] != "[REDACTED]" {
		t.Fatalf("data 语义错误: %+v", data)
	}
}

func TestAgentRemoteErrorLeavesStdoutEmpty(t *testing.T) {
	const response = `{"code":8000037,"message":"版本\u001b[31m冲突 token-secret\u001b[0m","errors":[{"field":"modifyVersionId\u0007 token-secret","reason":"版本\r\n冲突 token-secret","fix":"重新\u001b[31m获取 token-secret\u001b[0m","suggestedValue":"43\u0000token-secret"}],"data":{"current":{"interfaceId":2846,"modifyVersionId":43,"statusV2":110,"configPhase":"doc\u0007token-secret","nextStep":"save\u001b[31mtoken-secret\u001b[0m"}}}`
	var stdout, stderr bytes.Buffer
	root := NewRootCommand(Dependencies{
		HTTPClient: commandHTTPDoer(func(*http.Request) (*http.Response, error) {
			return commandJSONResponse(http.StatusOK, response), nil
		}),
		Store:  &commandStore{credentials: validCommandCredentials()},
		Now:    commandNow,
		Stdin:  strings.NewReader(""),
		Stdout: &stdout,
		Stderr: &stderr,
	})
	root.SetArgs([]string{"--output", "json", "djt", "api", "get", "--interface-id", "2846"})
	err := root.Execute()
	var remote *djt.RemoteError
	if !errors.As(err, &remote) {
		t.Fatalf("err=%T %v", err, err)
	}
	if stdout.Len() != 0 || stderr.Len() != 0 {
		t.Fatalf("root 层不应打印失败: stdout=%q stderr=%q", stdout.String(), stderr.String())
	}
	if len(remote.Errors) != 1 || remote.Errors[0].SuggestedValue == nil {
		t.Fatalf("remote=%+v", remote)
	}
	diagnostic := remote.Error()
	for _, want := range []string{
		"code=8000037",
		"message=版本冲突 [REDACTED]",
		"field=modifyVersionId [REDACTED]",
		"reason=版本  冲突 [REDACTED]",
		"fix=重新获取 [REDACTED]",
		"suggestedValue=43[REDACTED]",
		"current.interfaceId=2846",
		"current.modifyVersionId=43",
		"current.statusV2=110",
	} {
		if !strings.Contains(diagnostic, want) {
			t.Fatalf("RemoteError 不可读: missing=%q diagnostic=%q", want, diagnostic)
		}
	}
	if strings.Contains(diagnostic, "token-secret") || strings.ContainsAny(diagnostic, "\x00\x07\x1b\r") {
		t.Fatalf("RemoteError 泄漏 token 或远端控制字符: %q", diagnostic)
	}
}

func TestAgentTextOutputContainsOnlyControlFields(t *testing.T) {
	recorder := &agentCommandRecorder{}
	var stdout bytes.Buffer
	root := newAgentTestRoot(recorder, &stdout, nil)
	if err := root.execute("--output", "text", "djt", "api", "get", "--interface-id", "2846"); err != nil {
		t.Fatal(err)
	}
	for _, want := range []string{"interfaceId=2846", "modifyVersionId=42", "statusV2=110", "configPhase=doc_editing", "nextStep=doc"} {
		if !strings.Contains(stdout.String(), want) {
			t.Fatalf("stdout=%q missing=%q", stdout.String(), want)
		}
	}
	if strings.Contains(stdout.String(), "secret-tree") || strings.Contains(stdout.String(), "requestInfo") {
		t.Fatalf("text 不应输出 raw 树: %q", stdout.String())
	}
}

func assertAgentBodyBool(t *testing.T, body []byte, field string, want bool) {
	t.Helper()
	var value map[string]any
	if err := json.Unmarshal(body, &value); err != nil {
		t.Fatal(err)
	}
	if got, ok := value[field].(bool); !ok || got != want {
		t.Fatalf("body=%s %s=%v", body, field, value[field])
	}
}
