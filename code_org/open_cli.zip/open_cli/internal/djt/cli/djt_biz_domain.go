package cli

import (
	corecli "code.byted.org/temai/open_cli/internal/core/cli"
	"encoding/json"
	"fmt"
	"strconv"
	"strings"

	"code.byted.org/temai/open_cli/internal/core/output"
	"code.byted.org/temai/open_cli/internal/djt"
	"github.com/spf13/cobra"
)

type bizDomainJSONOutput struct {
	Code    int64           `json:"code"`
	Message string          `json:"message"`
	Data    json.RawMessage `json:"data"`
}

func newBizDomainCommand(deps Dependencies, format *corecli.OutputFormat) *cobra.Command {
	network := &agentNetworkFlags{}
	command := &cobra.Command{Use: "biz-domain", Short: "查询点将台业务域"}
	network.bind(command)
	command.AddCommand(
		newBizDomainListCommand(deps, format, network),
		newBizDomainApplyCommand(deps, format, network),
	)
	return command
}

func newBizDomainListCommand(deps Dependencies, format *corecli.OutputFormat, network *agentNetworkFlags) *cobra.Command {
	return &cobra.Command{
		Use:   "list",
		Short: "列出当前环境业务域及当前用户可用域",
		Args:  cobra.NoArgs,
		RunE: func(command *cobra.Command, _ []string) error {
			options, err := network.resolve(command)
			if err != nil {
				return err
			}
			credentials, err := loadAgentCredentials(command.Context(), deps)
			if err != nil {
				return err
			}
			options.Credentials = credentials
			result, err := djt.NewClient(deps.HTTPClient).ListBizDomains(command.Context(), options)
			if err != nil {
				return err
			}
			printer, err := output.New(deps.Stdout, string(*format))
			if err != nil {
				return err
			}
			if printer.IsJSON() {
				return printer.JSON(bizDomainJSONOutput{
					Code:    result.Envelope.Code,
					Message: result.Envelope.Message,
					Data:    result.Envelope.Data,
				})
			}
			available := make(map[int64]struct{}, len(result.Data.OwnerdomainInfoList))
			for _, domain := range result.Data.OwnerdomainInfoList {
				available[domain.DomainID] = struct{}{}
			}
			for _, domain := range result.Data.DomainInfoList {
				prefix := strings.Join(domain.SuffixList, ",")
				if prefix == "" {
					prefix = "-"
				}
				_, isAvailable := available[domain.DomainID]
				if err := printer.Text(
					"id=%s name=%s prefix=%s available=%s\n",
					strconv.FormatInt(domain.DomainID, 10),
					domain.DomainName,
					prefix,
					formatBool(isAvailable),
				); err != nil {
					return err
				}
			}
			return nil
		},
	}
}

func newBizDomainApplyCommand(deps Dependencies, format *corecli.OutputFormat, network *agentNetworkFlags) *cobra.Command {
	var domainIDs []int64
	command := &cobra.Command{
		Use:   "apply",
		Short: "申请业务域权限",
		Args:  cobra.NoArgs,
		RunE: func(command *cobra.Command, _ []string) error {
			if len(domainIDs) == 0 {
				return fmt.Errorf("domain-ids 不能为空")
			}
			options, err := network.resolve(command)
			if err != nil {
				return err
			}
			credentials, err := loadAgentCredentials(command.Context(), deps)
			if err != nil {
				return err
			}
			options.Credentials = credentials
			result, err := djt.NewClient(deps.HTTPClient).ApplyBizDomainAuth(command.Context(), options, domainIDs)
			if err != nil {
				return err
			}
			printer, err := output.New(deps.Stdout, string(*format))
			if err != nil {
				return err
			}
			if printer.IsJSON() {
				return printer.JSON(bizDomainJSONOutput{
					Code:    result.Envelope.Code,
					Message: result.Envelope.Message,
					Data:    result.Envelope.Data,
				})
			}
			return printer.Text("auditManageUrl=%s\n", result.Data.AuditManageURL)
		},
	}
	command.Flags().Int64SliceVar(&domainIDs, "domain-ids", nil, "要申请的业务域 ID 列表，逗号分隔")
	return command
}
