package cli

import (
	corecli "code.byted.org/temai/open_cli/internal/core/cli"
	"errors"
	"fmt"
	"strings"
	"time"

	"code.byted.org/temai/open_cli/internal/core/output"
	"code.byted.org/temai/open_cli/internal/core/ppe"
	"code.byted.org/temai/open_cli/internal/core/sanitize"
	"code.byted.org/temai/open_cli/internal/djt/auth"
	"github.com/spf13/cobra"
)

type authStateJSON struct {
	Authenticated bool       `json:"authenticated"`
	Expired       bool       `json:"expired,omitempty"`
	User          *auth.User `json:"user,omitempty"`
	ExpiresAt     *time.Time `json:"expires_at,omitempty"`
}

func newAuthCommand(deps Dependencies, format *corecli.OutputFormat) *cobra.Command {
	authCommand := &cobra.Command{Use: "auth", Short: "管理点将台登录状态"}
	authCommand.AddCommand(
		newLoginCommand(deps, format),
		newStatusCommand(deps, format),
		newWhoAmICommand(deps, format),
		newLogoutCommand(deps, format),
	)
	return authCommand
}

func newLoginCommand(deps Dependencies, format *corecli.OutputFormat) *cobra.Command {
	command := &cobra.Command{
		Use:   "login",
		Short: "登录点将台",
		Long:  "登录点将台。命令会打开浏览器授权页；若自动打开失败，请按 stderr 中的授权 URL 和用户代码完成公司 SSO 与授权。",
		Args:  cobra.NoArgs,
		RunE: func(command *cobra.Command, _ []string) error {
			ppeConfig, err := ppe.Resolve(corecli.PPEInput(command))
			if err != nil {
				return err
			}
			resolvedBaseURL := djtBaseURL
			printer, err := output.New(deps.Stdout, string(*format))
			if err != nil {
				return err
			}
			prompt := func(loginPrompt auth.LoginPrompt) error {
				verificationURL := sanitize.Terminal(loginPrompt.VerificationURL)
				userCode := sanitize.Terminal(loginPrompt.UserCode)
				if printer.IsJSON() {
					if _, err := fmt.Fprintf(deps.Stderr, "请访问：%s\n用户代码：%s\n", verificationURL, userCode); err != nil {
						return err
					}
				} else if err := printer.Text("请访问：%s\n用户代码：%s\n", loginPrompt.VerificationURL, loginPrompt.UserCode); err != nil {
					return err
				}
				if loginPrompt.BrowserError != nil {
					if _, err := fmt.Fprintf(deps.Stderr, "无法打开浏览器，请访问：%s\n", verificationURL); err != nil {
						return err
					}
				}
				return nil
			}
			result, loginErr := authService(deps).Login(command.Context(), resolvedBaseURL, ppeConfig, prompt)
			if loginErr != nil {
				return loginErr
			}
			if printer.IsJSON() {
				return printer.JSON(authStateJSON{Authenticated: true, User: &result.Credentials.User, ExpiresAt: &result.Credentials.ExpiresAt})
			}
			if err := printer.Text("登录成功：%s\n", formatIdentity(result.Credentials.User)); err != nil {
				return err
			}
			return printer.Text("过期时间：%s\n", result.Credentials.ExpiresAt.Format(time.RFC3339))
		},
	}
	command.AddCommand(newLoginStartCommand(deps, format), newLoginCompleteCommand(deps, format))
	return command
}

type loginStartJSON struct {
	Pending         bool      `json:"pending"`
	VerificationURL string    `json:"verification_url"`
	UserCode        string    `json:"user_code"`
	ExpiresAt       time.Time `json:"expires_at"`
}

func newLoginStartCommand(deps Dependencies, format *corecli.OutputFormat) *cobra.Command {
	return &cobra.Command{
		Use:   "start",
		Short: "创建可跨对话轮次完成的登录会话",
		Args:  cobra.NoArgs,
		RunE: func(command *cobra.Command, _ []string) error {
			if deps.LoginSessions == nil {
				return errors.New("登录会话存储未配置")
			}
			printer, err := output.New(deps.Stdout, string(*format))
			if err != nil {
				return err
			}
			session, err := deps.LoginSessions.Load(command.Context())
			if err == nil && deps.Now().Before(session.ExpiresAt) {
				return printLoginStart(printer, session)
			}
			if err != nil && !errors.Is(err, auth.ErrNoLoginSession) {
				return err
			}
			if err == nil {
				if err := deps.LoginSessions.Delete(command.Context()); err != nil {
					return err
				}
			}
			session, err = authService(deps).StartLogin(command.Context(), djtBaseURL, ppe.Config{}, nil)
			if err != nil {
				return err
			}
			if err := deps.LoginSessions.Save(command.Context(), session); err != nil {
				return err
			}
			return printLoginStart(printer, session)
		},
	}
}

func printLoginStart(printer *output.Printer, session auth.LoginSession) error {
	if printer.IsJSON() {
		return printer.JSON(loginStartJSON{Pending: true, VerificationURL: session.VerificationURL, UserCode: session.UserCode, ExpiresAt: session.ExpiresAt})
	}
	return printer.Text("请访问：%s\n用户代码：%s\n过期时间：%s\n", session.VerificationURL, session.UserCode, session.ExpiresAt.Format(time.RFC3339))
}

func newLoginCompleteCommand(deps Dependencies, format *corecli.OutputFormat) *cobra.Command {
	return &cobra.Command{
		Use:   "complete",
		Short: "完成最近创建的登录会话",
		Args:  cobra.NoArgs,
		RunE: func(command *cobra.Command, _ []string) error {
			if deps.LoginSessions == nil {
				return errors.New("登录会话存储未配置")
			}
			session, err := deps.LoginSessions.Load(command.Context())
			if err != nil {
				return err
			}
			result, err := authService(deps).CompleteLogin(command.Context(), session)
			if err != nil {
				if errors.Is(err, auth.ErrExpired) {
					_ = deps.LoginSessions.Delete(command.Context())
				}
				return err
			}
			if err := deps.LoginSessions.Delete(command.Context()); err != nil {
				return err
			}
			printer, err := output.New(deps.Stdout, string(*format))
			if err != nil {
				return err
			}
			if printer.IsJSON() {
				return printer.JSON(authStateJSON{Authenticated: true, User: &result.Credentials.User, ExpiresAt: &result.Credentials.ExpiresAt})
			}
			return printer.Text("登录成功：%s\n", formatIdentity(result.Credentials.User))
		},
	}
}

func newStatusCommand(deps Dependencies, format *corecli.OutputFormat) *cobra.Command {
	return &cobra.Command{
		Use:   "status",
		Short: "查看本地登录状态",
		Args:  cobra.NoArgs,
		RunE: func(command *cobra.Command, _ []string) error {
			printer, err := output.New(deps.Stdout, string(*format))
			if err != nil {
				return err
			}
			status, err := authService(deps).Status(command.Context())
			if err != nil {
				return err
			}
			if printer.IsJSON() {
				result := authStateJSON{Authenticated: status.Authenticated, Expired: status.Expired}
				if status.Authenticated {
					result.User = &status.User
					result.ExpiresAt = &status.ExpiresAt
				}
				return printer.JSON(result)
			}
			if !status.Authenticated {
				if status.Expired {
					return printer.Text("登录已过期\n")
				}
				return printer.Text("未登录\n")
			}
			if err := printer.Text("已登录：%s\n", formatIdentity(status.User)); err != nil {
				return err
			}
			return printer.Text("过期时间：%s\n", status.ExpiresAt.Format(time.RFC3339))
		},
	}
}

func newWhoAmICommand(deps Dependencies, format *corecli.OutputFormat) *cobra.Command {
	return &cobra.Command{
		Use:   "whoami",
		Short: "查看本地登录身份",
		Args:  cobra.NoArgs,
		RunE: func(command *cobra.Command, _ []string) error {
			printer, err := output.New(deps.Stdout, string(*format))
			if err != nil {
				return err
			}
			identity, err := authService(deps).WhoAmI(command.Context())
			if err != nil {
				return err
			}
			if printer.IsJSON() {
				return printer.JSON(identity)
			}
			return printer.Text("%s\n", formatIdentity(identity.User))
		},
	}
}

func newLogoutCommand(deps Dependencies, format *corecli.OutputFormat) *cobra.Command {
	return &cobra.Command{
		Use:   "logout",
		Short: "退出点将台登录",
		Args:  cobra.NoArgs,
		RunE: func(command *cobra.Command, _ []string) error {
			printer, err := output.New(deps.Stdout, string(*format))
			if err != nil {
				return err
			}
			if err := authService(deps).Logout(command.Context()); err != nil {
				return err
			}
			if printer.IsJSON() {
				return printer.JSON(authStateJSON{})
			}
			return printer.Text("已退出登录\n")
		},
	}
}

func authService(deps Dependencies) *auth.Service {
	return auth.NewService(deps.DeviceAPI, deps.WhoAmIAPI, deps.Store, deps.Browser, deps.Wait, deps.Now)
}

func formatIdentity(user auth.User) string {
	name := strings.TrimSpace(user.EmployeeName)
	email := strings.TrimSpace(user.Email)
	switch {
	case name != "" && email != "":
		return fmt.Sprintf("%s <%s>", name, email)
	case name != "":
		return name
	case email != "":
		return email
	default:
		return user.EmployeeID
	}
}
