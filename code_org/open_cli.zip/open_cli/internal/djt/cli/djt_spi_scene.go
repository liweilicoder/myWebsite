package cli

import (
	corecli "code.byted.org/temai/open_cli/internal/core/cli"
	"code.byted.org/temai/open_cli/internal/core/jsoninput"
	"github.com/spf13/cobra"
)

func newSPISceneCommand(deps Dependencies, format *corecli.OutputFormat, network *agentNetworkFlags) *cobra.Command {
	command := &cobra.Command{Use: "scene", Short: "管理 SPI 场景"}
	command.AddCommand(
		newSPISceneListCommand(deps, format, network),
		newSPISceneGetCommand(deps, format, network),
		newSPISceneSaveCommand(deps, format, network),
		newSPISceneSyncBoeCommand(deps, format, network),
		newSPIAccessAppCommand(deps, format, network),
	)
	return command
}

func newSPISceneListCommand(deps Dependencies, format *corecli.OutputFormat, network *agentNetworkFlags) *cobra.Command {
	flags := &spiSceneListFlags{}
	command := &cobra.Command{
		Use:   "list",
		Short: "列出 SPI 场景",
		Args:  cobra.NoArgs,
		RunE: func(command *cobra.Command, _ []string) error {
			request, err := flags.request(command)
			if err != nil {
				return err
			}
			options, err := prepareSPI(command.Context(), command, deps, network)
			if err != nil {
				return err
			}
			result, err := newSPIService(deps).SceneList(command.Context(), request, options)
			if err != nil {
				return err
			}
			return renderSPIResult(deps.Stdout, *format, result)
		},
	}
	flags.bind(command.Flags())
	return command
}

func newSPISceneGetCommand(deps Dependencies, format *corecli.OutputFormat, network *agentNetworkFlags) *cobra.Command {
	flags := &spiSceneGetFlags{}
	command := &cobra.Command{
		Use:   "get",
		Short: "查询 SPI 场景",
		Args:  cobra.NoArgs,
		RunE: func(command *cobra.Command, _ []string) error {
			request, err := flags.request(command)
			if err != nil {
				return err
			}
			options, err := prepareSPI(command.Context(), command, deps, network)
			if err != nil {
				return err
			}
			result, err := newSPIService(deps).SceneGet(command.Context(), request, options)
			if err != nil {
				return err
			}
			return renderSPIResult(deps.Stdout, *format, result)
		},
	}
	flags.bind(command.Flags())
	return command
}

func newSPISceneSaveCommand(deps Dependencies, format *corecli.OutputFormat, network *agentNetworkFlags) *cobra.Command {
	flags := &spiSceneSaveFlags{}
	command := &cobra.Command{
		Use:   "save",
		Short: "保存 SPI 场景（默认 dry-run）",
		Args:  cobra.NoArgs,
		RunE: func(command *cobra.Command, _ []string) error {
			request, err := flags.request()
			if err != nil {
				return err
			}
			options, err := prepareSPI(command.Context(), command, deps, network)
			if err != nil {
				return err
			}
			result, err := newSPIService(deps).SceneSave(command.Context(), request, options)
			if err != nil {
				return err
			}
			return renderSPIResult(deps.Stdout, *format, result)
		},
	}
	flags.bind(command.Flags())
	return command
}

func newSPISceneSyncBoeCommand(deps Dependencies, format *corecli.OutputFormat, network *agentNetworkFlags) *cobra.Command {
	flags := &spiSceneSyncBoeFlags{}
	command := &cobra.Command{
		Use:   "sync-boe",
		Short: "同步 SPI 场景 BOE 应用（默认 dry-run）",
		Args:  cobra.NoArgs,
		RunE: func(command *cobra.Command, _ []string) error {
			request, err := flags.request(jsoninput.NewLoader(agentStdin(deps)))
			if err != nil {
				return err
			}
			options, err := prepareSPI(command.Context(), command, deps, network)
			if err != nil {
				return err
			}
			result, err := newSPIService(deps).SyncBoe(command.Context(), request, options)
			if err != nil {
				return err
			}
			return renderSPIResult(deps.Stdout, *format, result)
		},
	}
	flags.bind(command.Flags())
	return command
}
