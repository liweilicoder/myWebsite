package cli

import (
	"bytes"
	"encoding/json"
	"io"
	"strings"
	"testing"
)

func TestSPIHelpListsLeaves(t *testing.T) {
	var stdout, stderr bytes.Buffer
	root := NewRootCommand(Dependencies{Stdout: &stdout, Stderr: &stderr})
	root.SetOut(&stdout)
	root.SetErr(&stderr)
	root.SetArgs([]string{"djt", "spi", "--help"})
	if err := root.Execute(); err != nil {
		t.Fatal(err)
	}
	if stderr.Len() != 0 {
		t.Fatalf("stderr=%s", stderr.String())
	}
	for _, want := range []string{"scene", "interface"} {
		if !strings.Contains(stdout.String(), want) {
			t.Fatalf("help missing %s: %s", want, stdout.String())
		}
	}
}

func TestInterfaceSaveDefaultDryRun(t *testing.T) {
	recorder := &agentCommandRecorder{}
	root := newAgentTestRoot(recorder, io.Discard, nil)
	err := root.execute("djt", "spi", "interface", "save", "--input", `{"sceneId":1,"interfaceName":"a/b","bizDomainId":8}`)
	if err != nil {
		t.Fatal(err)
	}
	if len(recorder.requests) != 1 {
		t.Fatalf("requests=%d", len(recorder.requests))
	}
	var body map[string]json.RawMessage
	if err := json.Unmarshal(recorder.requests[0].body, &body); err != nil {
		t.Fatal(err)
	}
	if recorder.requests[0].path != "/api/djt-cli/agent/spi/interface/save" || string(body["dryRun"]) != "true" {
		t.Fatalf("request=%+v body=%s", recorder.requests[0], recorder.requests[0].body)
	}
}

func TestInterfaceSaveCreateApplyNeedsConfirm(t *testing.T) {
	recorder := &agentCommandRecorder{}
	root := newAgentTestRoot(recorder, io.Discard, nil)
	err := root.execute(
		"djt", "spi", "interface", "save",
		"--scene-id", "1",
		"--interface-name", "a/b",
		"--biz-domain-id", "8",
		"--apply",
	)
	if err == nil || !strings.Contains(err.Error(), "--confirmed-by-user") {
		t.Fatalf("err=%v", err)
	}
	if len(recorder.requests) != 0 {
		t.Fatalf("requests=%d", len(recorder.requests))
	}
}

func TestSPIInterfaceModifyVersionZeroIsAcceptedWhenSet(t *testing.T) {
	tests := []struct {
		name string
		args []string
	}{
		{
			name: "save",
			args: []string{"djt", "spi", "interface", "save", "--interface-id", "2846", "--modify-version-id", "0"},
		},
		{
			name: "submit review",
			args: []string{"djt", "spi", "interface", "submit-review", "--interface-id", "2846", "--modify-version-id", "0", "--reason", "review"},
		},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			recorder := &agentCommandRecorder{}
			root := newAgentTestRoot(recorder, io.Discard, nil)
			if err := root.execute(test.args...); err != nil {
				t.Fatal(err)
			}
			if len(recorder.requests) != 1 || !strings.Contains(string(recorder.requests[0].body), `"modifyVersionId":0`) {
				t.Fatalf("requests=%+v", recorder.requests)
			}
		})
	}
}

func TestSPIInterfaceModifyVersionIsRequired(t *testing.T) {
	tests := []struct {
		name string
		args []string
	}{
		{
			name: "save",
			args: []string{"djt", "spi", "interface", "save", "--interface-id", "2846"},
		},
		{
			name: "submit review",
			args: []string{"djt", "spi", "interface", "submit-review", "--interface-id", "2846", "--reason", "review"},
		},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			recorder := &agentCommandRecorder{}
			root := newAgentTestRoot(recorder, io.Discard, nil)
			err := root.execute(test.args...)
			if err == nil || !strings.Contains(err.Error(), "--modify-version-id") || len(recorder.requests) != 0 {
				t.Fatalf("err=%v requests=%d", err, len(recorder.requests))
			}
		})
	}
}

func TestNoDisableCommand(t *testing.T) {
	root := NewRootCommand(Dependencies{Stdout: io.Discard, Stderr: io.Discard})
	root.SetArgs([]string{"djt", "spi", "scene", "access-app", "disable"})
	if err := root.Execute(); err == nil {
		t.Fatal("disable must not exist")
	}
}

func TestSPIParentOwnsHiddenPPEFlags(t *testing.T) {
	root := NewRootCommand(Dependencies{Stdout: io.Discard, Stderr: io.Discard})
	command, remaining, err := root.Find([]string{"djt", "spi"})
	if err != nil || len(remaining) != 0 {
		t.Fatalf("command=%v remaining=%v err=%v", command, remaining, err)
	}
	for _, name := range []string{"use-ppe", "ppe-env"} {
		if command.PersistentFlags().Lookup(name) != nil {
			t.Fatalf("PPE flag --%s 不应注册在 spi 子树", name)
		}
		flag := root.PersistentFlags().Lookup(name)
		if flag == nil || flag.Hidden {
			t.Fatalf("对内 root --%s flag=%v", name, flag)
		}
	}
}
