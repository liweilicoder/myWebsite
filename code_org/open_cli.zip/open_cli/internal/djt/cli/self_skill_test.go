package cli

import (
	"bytes"
	"io"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestSelfSkillCommandTree(t *testing.T) {
	root := NewRootCommand(Dependencies{HomeDir: t.TempDir(), Stdout: io.Discard, Stderr: io.Discard})
	for _, path := range [][]string{{"djt", "self"}, {"djt", "self", "skill"}, {"djt", "self", "skill", "install"}, {"djt", "self", "skill", "status"}, {"djt", "self", "skill", "update"}} {
		command, remaining, err := root.Find(path)
		if err != nil || command == nil || len(remaining) != 0 {
			t.Fatalf("path=%v command=%v remaining=%v err=%v", path, command, remaining, err)
		}
	}
}

func TestSelfSkillInstallJSONOutput(t *testing.T) {
	home := t.TempDir()
	var stdout bytes.Buffer
	root := NewRootCommand(Dependencies{HomeDir: home, Stdout: &stdout, Stderr: io.Discard})
	root.SetArgs([]string{"djt", "self", "skill", "install", "--output", "json"})
	if err := root.Execute(); err != nil {
		t.Fatal(err)
	}
	wantPath := filepath.ToSlash(filepath.Join(home, ".agents", "skills", "djt"))
	want := `{"skill":"djt","targets":[{"agent":"universal","path":"` + wantPath + `","status":"installed"}]}` + "\n"
	if stdout.String() != want {
		t.Fatalf("stdout=%q want=%q", stdout.String(), want)
	}
	for _, relative := range []string{
		"SKILL.md", "api.md", "spi.md", "README.md", ".skillignore",
		filepath.Join("scripts", "apply_style_patches.py"),
		filepath.Join("scripts", "validate_style_tree.py"),
		filepath.Join("scripts", "request_style.py"),
		filepath.Join("scripts", "json_to_spi_param_tree.py"),
	} {
		if _, err := os.Stat(filepath.Join(home, ".agents", "skills", "djt", relative)); err != nil {
			t.Fatalf("未安装 %s: %v", relative, err)
		}
	}
}

func TestSelfSkillTextReportsEveryTargetAndReturnsAggregateError(t *testing.T) {
	home := t.TempDir()
	if err := os.Mkdir(filepath.Join(home, ".claude"), 0o755); err != nil {
		t.Fatal(err)
	}
	if err := os.Symlink(t.TempDir(), filepath.Join(home, ".agents")); err != nil {
		t.Skipf("无法创建符号链接: %v", err)
	}
	var stdout bytes.Buffer
	root := NewRootCommand(Dependencies{HomeDir: home, Stdout: &stdout, Stderr: io.Discard})
	root.SetArgs([]string{"--output", "text", "djt", "self", "skill", "install"})
	err := root.Execute()
	if err == nil {
		t.Fatal("存在目标错误时命令应失败")
	}
	for _, want := range []string{"universal", "error", "claude", "installed"} {
		if !strings.Contains(stdout.String(), want) {
			t.Fatalf("stdout=%q missing=%q", stdout.String(), want)
		}
	}
}

func TestSelfSkillJSONReportsEveryTargetBeforeReturningAggregateError(t *testing.T) {
	home := t.TempDir()
	claude := filepath.Join(home, ".claude")
	if err := os.Mkdir(claude, 0o755); err != nil {
		t.Fatal(err)
	}
	if err := os.Symlink(t.TempDir(), filepath.Join(home, ".agents")); err != nil {
		t.Skipf("无法创建符号链接: %v", err)
	}
	var stdout bytes.Buffer
	root := NewRootCommand(Dependencies{HomeDir: home, Stdout: &stdout, Stderr: io.Discard})
	root.SetArgs([]string{"djt", "self", "skill", "install", "--output", "json"})
	if err := root.Execute(); err == nil {
		t.Fatal("部分目标失败时命令应非零")
	}
	claudePath := filepath.ToSlash(filepath.Join(claude, "skills", "djt"))
	if !strings.Contains(stdout.String(), `"agent":"universal"`) || !strings.Contains(stdout.String(), `"status":"error"`) ||
		!strings.Contains(stdout.String(), `"agent":"claude","path":"`+claudePath+`","status":"installed"`) {
		t.Fatalf("JSON 应完整包含失败和成功目标: %q", stdout.String())
	}
}
