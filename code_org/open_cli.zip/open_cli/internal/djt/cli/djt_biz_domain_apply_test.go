package cli

import (
	"bytes"
	"encoding/json"
	"io"
	"net/http"
	"testing"
)

const bizDomainApplyResponse = `{"code":0,"message":"success","data":{"auditManageUrl":"https://djt.bytedance.net/auditManage/task?type=domainPerm&recordId=1"}}`

func TestBizDomainApplySendsTokenPOST(t *testing.T) {
	recorder := &agentCommandRecorder{}
	var stdout bytes.Buffer
	root := NewRootCommand(Dependencies{
		HTTPClient: commandHTTPDoer(func(got *http.Request) (*http.Response, error) {
			_, _ = recorder.Do(got)
			return commandJSONResponse(http.StatusOK, bizDomainApplyResponse), nil
		}),
		Store:  &commandStore{credentials: validCommandCredentials()},
		Now:    commandNow,
		Stdout: &stdout,
		Stderr: io.Discard,
	})
	root.SetArgs([]string{"djt", "biz-domain", "apply", "--domain-ids", "8,15", "--output", "json"})
	if err := root.Execute(); err != nil {
		t.Fatal(err)
	}
	if len(recorder.requests) != 1 {
		t.Fatalf("requests=%d", len(recorder.requests))
	}
	request := recorder.requests[0]
	if request.method != http.MethodPost || request.path != "/api/djt-cli/domain/apply" {
		t.Fatalf("request=%s %s", request.method, request.path)
	}
	if got := request.header.Get("X-DJT-CLI-Authorization"); got != "Bearer token-secret" {
		t.Fatalf("authorization=%q", got)
	}
	var payload struct {
		DomainIDs []int64 `json:"domainIds"`
	}
	if err := json.Unmarshal(request.body, &payload); err != nil {
		t.Fatalf("body=%s err=%v", request.body, err)
	}
	if len(payload.DomainIDs) != 2 || payload.DomainIDs[0] != 8 || payload.DomainIDs[1] != 15 {
		t.Fatalf("domainIds=%v", payload.DomainIDs)
	}
	var envelope struct {
		Code    int64  `json:"code"`
		Message string `json:"message"`
		Data    struct {
			AuditManageURL string `json:"auditManageUrl"`
		} `json:"data"`
	}
	if err := json.Unmarshal(stdout.Bytes(), &envelope); err != nil {
		t.Fatalf("stdout=%s err=%v", stdout.String(), err)
	}
	if envelope.Code != 0 || envelope.Data.AuditManageURL == "" {
		t.Fatalf("envelope=%+v", envelope)
	}
	if bytes.Contains(stdout.Bytes(), []byte(`\u0026`)) {
		t.Fatalf("JSON HTML-escaped URL: %s", stdout.String())
	}
	if !bytes.Contains(stdout.Bytes(), []byte(`type=domainPerm&recordId=1`)) {
		t.Fatalf("stdout=%s", stdout.String())
	}
}

func TestBizDomainApplyTextOutput(t *testing.T) {
	var stdout bytes.Buffer
	root := NewRootCommand(Dependencies{
		HTTPClient: commandHTTPDoer(func(*http.Request) (*http.Response, error) {
			return commandJSONResponse(http.StatusOK, bizDomainApplyResponse), nil
		}),
		Store:  &commandStore{credentials: validCommandCredentials()},
		Now:    commandNow,
		Stdout: &stdout,
		Stderr: io.Discard,
	})
	root.SetArgs([]string{"--output", "text", "djt", "biz-domain", "apply", "--domain-ids", "8"})
	if err := root.Execute(); err != nil {
		t.Fatal(err)
	}
	want := "auditManageUrl=https://djt.bytedance.net/auditManage/task?type=domainPerm&recordId=1\n"
	if got := stdout.String(); got != want {
		t.Fatalf("stdout=%q want=%q", got, want)
	}
}
