package cli

import (
	"bytes"
	"encoding/json"
	"io"
	"net/http"
	"testing"
)

const bizDomainListResponse = `{"code":0,"message":"success","data":{"total":2,"domainInfoList":[{"domainId":8,"domainName":"订单","suffixList":["order","trade"],"future":"kept"},{"domainId":15,"domainName":"测试","suffixList":["test"]}],"ownerdomainInfoList":[{"domainId":8,"domainName":"订单","suffixList":["order","trade"],"ownerFuture":"kept"}],"futureData":{"kept":true}}}`

func TestBizDomainListSendsTokenGETAndPreservesJSONEnvelope(t *testing.T) {
	var request *http.Request
	var stdout bytes.Buffer
	root := NewRootCommand(Dependencies{
		HTTPClient: commandHTTPDoer(func(got *http.Request) (*http.Response, error) {
			request = got.Clone(got.Context())
			return commandJSONResponse(http.StatusOK, bizDomainListResponse), nil
		}),
		Store:  &commandStore{credentials: validCommandCredentials()},
		Now:    commandNow,
		Stdout: &stdout,
		Stderr: io.Discard,
	})
	root.SetArgs([]string{"djt", "biz-domain", "list", "--output", "json"})
	if err := root.Execute(); err != nil {
		t.Fatal(err)
	}
	if request == nil {
		t.Fatal("未发送 HTTP 请求")
	}
	if request.Method != http.MethodGet || request.URL.Path != "/api/domain/list" || request.URL.RawQuery != "" {
		t.Fatalf("request=%s %s", request.Method, request.URL.String())
	}
	if got := request.Header.Get("X-DJT-CLI-Authorization"); got != "Bearer token-secret" {
		t.Fatalf("authorization=%q", got)
	}
	if got := request.Header.Get("Accept"); got != "application/json" {
		t.Fatalf("accept=%q", got)
	}
	if request.Body != nil {
		t.Fatal("GET 不应包含 body")
	}

	var envelope struct {
		Code    int64  `json:"code"`
		Message string `json:"message"`
		Data    struct {
			Total               int64             `json:"total"`
			DomainInfoList      []json.RawMessage `json:"domainInfoList"`
			OwnerdomainInfoList []json.RawMessage `json:"ownerdomainInfoList"`
			FutureData          json.RawMessage   `json:"futureData"`
		} `json:"data"`
	}
	if err := json.Unmarshal(stdout.Bytes(), &envelope); err != nil {
		t.Fatalf("stdout 非法 JSON: %v; stdout=%q", err, stdout.String())
	}
	if envelope.Code != 0 || envelope.Message != "success" || envelope.Data.Total != 2 {
		t.Fatalf("envelope=%+v", envelope)
	}
	if len(envelope.Data.DomainInfoList) != 2 || len(envelope.Data.OwnerdomainInfoList) != 1 {
		t.Fatalf("data=%+v", envelope.Data)
	}
	if !bytes.Contains(envelope.Data.DomainInfoList[0], []byte(`"domainId":8`)) ||
		!bytes.Contains(envelope.Data.DomainInfoList[0], []byte(`"domainName":"订单"`)) ||
		!bytes.Contains(envelope.Data.DomainInfoList[0], []byte(`"suffixList":["order","trade"]`)) ||
		!bytes.Contains(envelope.Data.DomainInfoList[0], []byte(`"future":"kept"`)) ||
		!bytes.Contains(envelope.Data.OwnerdomainInfoList[0], []byte(`"ownerFuture":"kept"`)) ||
		string(envelope.Data.FutureData) != `{"kept":true}` {
		t.Fatalf("data 未完整保留: %s", stdout.Bytes())
	}
	decoder := json.NewDecoder(bytes.NewReader(stdout.Bytes()))
	var document json.RawMessage
	if err := decoder.Decode(&document); err != nil {
		t.Fatal(err)
	}
	if err := decoder.Decode(&document); err != io.EOF {
		t.Fatalf("stdout 必须只有一个 JSON 文档: %v", err)
	}
	if !bytes.HasSuffix(stdout.Bytes(), []byte("\n")) {
		t.Fatalf("stdout 必须换行结尾: %q", stdout.String())
	}
}

func TestBizDomainListTextAvailabilityBoundaries(t *testing.T) {
	tests := []struct {
		name     string
		response string
		want     string
	}{
		{
			name:     "重复 owner",
			response: `{"code":0,"message":"success","data":{"domainInfoList":[{"domainId":8,"domainName":"订单","suffixList":["order"]},{"domainId":15,"domainName":"测试","suffixList":["test"]}],"ownerdomainInfoList":[{"domainId":8},{"domainId":8}]}}`,
			want:     "id=8 name=订单 prefix=order available=true\nid=15 name=测试 prefix=test available=false\n",
		},
		{
			name:     "空 owner",
			response: `{"code":0,"message":"success","data":{"domainInfoList":[{"domainId":8,"domainName":"订单","suffixList":["order"]}],"ownerdomainInfoList":[]}}`,
			want:     "id=8 name=订单 prefix=order available=false\n",
		},
		{
			name:     "null owner",
			response: `{"code":0,"message":"success","data":{"domainInfoList":[{"domainId":8,"domainName":"订单","suffixList":["order"]}],"ownerdomainInfoList":null}}`,
			want:     "id=8 name=订单 prefix=order available=false\n",
		},
		{
			name:     "未知 owner",
			response: `{"code":0,"message":"success","data":{"domainInfoList":[{"domainId":8,"domainName":"订单","suffixList":["order"]}],"ownerdomainInfoList":[{"domainId":99}]}}`,
			want:     "id=8 name=订单 prefix=order available=false\n",
		},
		{
			name:     "重复 domain 保留服务端顺序",
			response: `{"code":0,"message":"success","data":{"domainInfoList":[{"domainId":8,"domainName":"订单一","suffixList":["first"]},{"domainId":8,"domainName":"订单二","suffixList":["second"]}],"ownerdomainInfoList":[{"domainId":8}]}}`,
			want:     "id=8 name=订单一 prefix=first available=true\nid=8 name=订单二 prefix=second available=true\n",
		},
		{
			name:     "空 suffixList",
			response: `{"code":0,"message":"success","data":{"domainInfoList":[{"domainId":8,"domainName":"订单","suffixList":[]}],"ownerdomainInfoList":[]}}`,
			want:     "id=8 name=订单 prefix=- available=false\n",
		},
		{
			name:     "空 domain 列表",
			response: `{"code":0,"message":"success","data":{"domainInfoList":[],"ownerdomainInfoList":[{"domainId":8}]}}`,
			want:     "",
		},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			var stdout bytes.Buffer
			root := NewRootCommand(Dependencies{
				HTTPClient: commandHTTPDoer(func(*http.Request) (*http.Response, error) {
					return commandJSONResponse(http.StatusOK, test.response), nil
				}),
				Store:  &commandStore{credentials: validCommandCredentials()},
				Now:    commandNow,
				Stdout: &stdout,
				Stderr: io.Discard,
			})
			root.SetArgs([]string{"--output", "text", "djt", "biz-domain", "list"})
			if err := root.Execute(); err != nil {
				t.Fatal(err)
			}
			if got := stdout.String(); got != test.want {
				t.Fatalf("stdout=%q want=%q", got, test.want)
			}
		})
	}
}
