package cli

import (
	corecli "code.byted.org/temai/open_cli/internal/core/cli"
	"fmt"

	"github.com/spf13/cobra"
)

func newSPIAccessAppCommand(deps Dependencies, format *corecli.OutputFormat, network *agentNetworkFlags) *cobra.Command {
	command := &cobra.Command{
		Use:   "access-app",
		Short: "管理 SPI 场景接入应用",
		RunE: func(command *cobra.Command, args []string) error {
			if len(args) != 0 {
				return fmt.Errorf("unknown command %q for %q", args[0], command.CommandPath())
			}
			return command.Help()
		},
	}
	command.AddCommand(
		newSPIAccessAppListCommand(deps, format, network),
		newSPIAccessAppGetCommand(deps, format, network),
		newSPIAccessAppSaveCommand(deps, format, network),
		newSPIAccessAppEnableCommand(deps, format, network),
	)
	return command
}

func newSPIAccessAppListCommand(deps Dependencies, format *corecli.OutputFormat, network *agentNetworkFlags) *cobra.Command {
	flags := &spiAccessAppListFlags{}
	command := &cobra.Command{
		Use:   "list",
		Short: "列出 SPI 场景接入应用",
		Args:  cobra.NoArgs,
		RunE: func(command *cobra.Command, _ []string) error {
			request, err := flags.request()
			if err != nil {
				return err
			}
			options, err := prepareSPI(command.Context(), command, deps, network)
			if err != nil {
				return err
			}
			result, err := newSPIService(deps).AccessAppList(command.Context(), request, options)
			if err != nil {
				return err
			}
			return renderSPIResult(deps.Stdout, *format, result)
		},
	}
	flags.bind(command.Flags())
	return command
}

func newSPIAccessAppGetCommand(deps Dependencies, format *corecli.OutputFormat, network *agentNetworkFlags) *cobra.Command {
	flags := &spiAccessAppGetFlags{}
	command := &cobra.Command{
		Use:   "get",
		Short: "查询 SPI 场景接入应用及接口实现详情",
		Args:  cobra.NoArgs,
		RunE: func(command *cobra.Command, _ []string) error {
			request, err := flags.request(command)
			if err != nil {
				return err
			}
			options, err := prepareSPI(command.Context(), command, deps, network)
			if err != nil {
				return err
			}
			result, err := newSPIService(deps).AccessAppGet(command.Context(), request, options)
			if err != nil {
				return err
			}
			return renderSPIResult(deps.Stdout, *format, result)
		},
	}
	flags.bind(command.Flags())
	return command
}

func newSPIAccessAppSaveCommand(deps Dependencies, format *corecli.OutputFormat, network *agentNetworkFlags) *cobra.Command {
	flags := &spiAccessAppSaveFlags{}
	command := &cobra.Command{
		Use:   "save",
		Short: "保存 SPI 场景接入应用（默认 dry-run）",
		Args:  cobra.NoArgs,
		RunE: func(command *cobra.Command, _ []string) error {
			request, err := flags.request()
			if err != nil {
				return err
			}
			options, err := prepareSPI(command.Context(), command, deps, network)
			if err != nil {
				return err
			}
			result, err := newSPIService(deps).AccessAppSave(command.Context(), request, options)
			if err != nil {
				return err
			}
			return renderSPIResult(deps.Stdout, *format, result)
		},
	}
	flags.bind(command.Flags())
	return command
}

func newSPIAccessAppEnableCommand(deps Dependencies, format *corecli.OutputFormat, network *agentNetworkFlags) *cobra.Command {
	flags := &spiAccessAppEnableFlags{}
	command := &cobra.Command{
		Use:   "enable",
		Short: "启用 SPI 场景接入应用（默认 dry-run）",
		Args:  cobra.NoArgs,
		RunE: func(command *cobra.Command, _ []string) error {
			request, err := flags.request()
			if err != nil {
				return err
			}
			options, err := prepareSPI(command.Context(), command, deps, network)
			if err != nil {
				return err
			}
			result, err := newSPIService(deps).AccessAppEnable(command.Context(), request, options)
			if err != nil {
				return err
			}
			return renderSPIResult(deps.Stdout, *format, result)
		},
	}
	flags.bind(command.Flags())
	return command
}
