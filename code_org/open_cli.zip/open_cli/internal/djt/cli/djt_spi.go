package cli

import (
	corecli "code.byted.org/temai/open_cli/internal/core/cli"
	"context"
	"encoding/json"
	"io"

	"code.byted.org/temai/open_cli/internal/core/output"
	"code.byted.org/temai/open_cli/internal/djt"
	"github.com/spf13/cobra"
)

func newSPICommand(deps Dependencies, format *corecli.OutputFormat) *cobra.Command {
	network := &agentNetworkFlags{}
	command := &cobra.Command{Use: "spi", Short: "管理点将台 SPI"}
	network.bind(command)
	command.AddCommand(
		newSPISceneCommand(deps, format, network),
		newSPIInterfaceCommand(deps, format, network),
	)
	return command
}

func prepareSPI(ctx context.Context, command *cobra.Command, deps Dependencies, network *agentNetworkFlags) (djt.RequestOptions, error) {
	options, err := network.resolve(command)
	if err != nil {
		return djt.RequestOptions{}, err
	}
	credentials, err := loadAgentCredentials(ctx, deps)
	if err != nil {
		return djt.RequestOptions{}, err
	}
	options.Credentials = credentials
	return options, nil
}

func newSPIService(deps Dependencies) *djt.AgentSPIService {
	return djt.NewAgentSPIService(djt.NewAgentSPIClient(djt.NewTransport(deps.HTTPClient)))
}

func renderSPIResult(writer io.Writer, format corecli.OutputFormat, result any) error {
	envelope := spiResultEnvelope(result)
	printer, err := output.New(writer, string(format))
	if err != nil {
		return err
	}
	if printer.IsJSON() {
		return printer.JSON(agentJSONOutput{Code: envelope.Code, Message: envelope.Message, Data: envelope.Data})
	}
	data := envelope.Data
	if len(data) == 0 {
		data = json.RawMessage(`{}`)
	}
	return printer.Text("%s\n", string(data))
}

func spiResultEnvelope(result any) djt.Envelope {
	switch value := result.(type) {
	case djt.AgentSpiGetInterfaceResult:
		return value.Envelope
	case djt.AgentSpiListInterfaceResult:
		return value.Envelope
	case djt.AgentSpiSaveInterfaceResult:
		return value.Envelope
	case djt.AgentSpiSubmitReviewResult:
		return value.Envelope
	case djt.AgentSpiCancelUpgradeResult:
		return value.Envelope
	case djt.AgentSpiSceneListResult:
		return value.Envelope
	case djt.AgentSpiSceneGetResult:
		return value.Envelope
	case djt.AgentSpiSceneSaveResult:
		return value.Envelope
	case djt.AgentSpiSceneSyncBoeResult:
		return value.Envelope
	case djt.AgentSpiAccessAppListResult:
		return value.Envelope
	case djt.AgentSpiAccessAppGetResult:
		return value.Envelope
	case djt.AgentSpiAccessAppSaveResult:
		return value.Envelope
	case djt.AgentSpiAccessAppEnableResult:
		return value.Envelope
	default:
		return djt.Envelope{}
	}
}
