package cli

import (
	"encoding/json"
	"errors"
	"fmt"
	"strings"

	corecli "code.byted.org/temai/open_cli/internal/core/cli"
	"code.byted.org/temai/open_cli/internal/core/jsoninput"
	"code.byted.org/temai/open_cli/internal/core/ppe"
	"code.byted.org/temai/open_cli/internal/djt"
	"code.byted.org/temai/open_cli/internal/djt/auth"
	"github.com/spf13/cobra"
	"github.com/spf13/pflag"
)

const bizDomainSelectionError = "--biz-domain-id 必须显式传入且大于 0；请先执行 doudian-open-cli djt biz-domain list --output json，向用户确认业务域后再传"

type agentNetworkFlags struct {
	usePPE        bool
	usePPEChanged bool
	ppeEnv        string
	ppeEnvChanged bool
}

type writeMode struct {
	dryRun bool
	apply  bool
}

func (m writeMode) dryRunValue() (bool, error) {
	if m.dryRun && m.apply {
		return false, errors.New("--dry-run 与 --apply 互斥")
	}
	return !m.apply, nil
}

func (f agentNetworkFlags) options(credentials auth.Credentials) (djt.RequestOptions, error) {
	config, err := ppe.Resolve(ppe.Input{
		UsePPE:    f.usePPE,
		UsePPESet: f.usePPEChanged,
		Env:       f.ppeEnv,
		EnvSet:    f.ppeEnvChanged,
	})
	if err != nil {
		return djt.RequestOptions{}, err
	}
	return djt.RequestOptions{Credentials: credentials, PPE: config}, nil
}

func normalizeSections(values []string) ([]string, error) {
	allowed := map[string]struct{}{
		"basic": {}, "request": {}, "response": {}, "errcode": {}, "doc": {},
	}
	seen := make(map[string]struct{})
	var sections []string
	for _, value := range values {
		for _, candidate := range strings.Split(value, ",") {
			section := strings.TrimSpace(candidate)
			if _, ok := allowed[section]; !ok {
				return nil, fmt.Errorf("--sections 只接受 basic、request、response、errcode 或 doc，收到 %q", section)
			}
			if _, ok := seen[section]; ok {
				continue
			}
			seen[section] = struct{}{}
			sections = append(sections, section)
		}
	}
	if len(sections) == 0 {
		return nil, errors.New("--sections 不能为空")
	}
	return sections, nil
}

func (f *agentNetworkFlags) bind(command *cobra.Command) {
	// PPE flags live on the root command and are inherited.
}

func (f *agentNetworkFlags) resolve(command *cobra.Command) (djt.RequestOptions, error) {
	input := corecli.PPEInput(command)
	config, err := ppe.Resolve(input)
	if err != nil {
		return djt.RequestOptions{}, err
	}
	return djt.RequestOptions{Credentials: auth.Credentials{}, PPE: config}, nil
}

func flagChanged(command *cobra.Command, name string) bool {
	flag := command.Flag(name)
	return flag != nil && flag.Changed
}

type agentGetFlags struct {
	interfaceID       int64
	interfaceName     string
	interfaceNameLike string
}

func (f *agentGetFlags) bind(flags *pflag.FlagSet) {
	flags.Int64Var(&f.interfaceID, "interface-id", 0, "接口 ID")
	flags.StringVar(&f.interfaceName, "interface-name", "", "精确接口名")
	flags.StringVar(&f.interfaceNameLike, "interface-name-like", "", "模糊接口名")
}

func (f agentGetFlags) request(command *cobra.Command) (djt.AgentGetRequest, error) {
	selectors := 0
	request := djt.AgentGetRequest{}
	if flagChanged(command, "interface-id") {
		selectors++
		if f.interfaceID <= 0 {
			return request, errors.New("--interface-id 必须大于 0")
		}
		request.InterfaceID = &f.interfaceID
	}
	if flagChanged(command, "interface-name") {
		selectors++
		value := strings.TrimSpace(f.interfaceName)
		if value == "" {
			return request, errors.New("--interface-name 不能为空")
		}
		request.InterfaceName = &value
	}
	if flagChanged(command, "interface-name-like") {
		selectors++
		value := strings.TrimSpace(f.interfaceNameLike)
		if value == "" {
			return request, errors.New("--interface-name-like 不能为空")
		}
		request.InterfaceNameLike = &value
	}
	if selectors != 1 {
		return request, errors.New("必须且只能传一个 --interface-id、--interface-name 或 --interface-name-like")
	}
	return request, nil
}

type agentInitFlags struct {
	interfaceID     int64
	psm             string
	methodName      string
	bamVersionID    string
	interfaceName   string
	bizDomainID     int64
	desc            string
	sceneDesc       string
	ownerList       string
	interfaceCateID int64
	skipAuth        bool
	confirmedByUser bool
	apply           bool
}

func (f *agentInitFlags) bind(flags *pflag.FlagSet) {
	flags.Int64Var(&f.interfaceID, "interface-id", 0, "重绑 BAM 的接口 ID")
	flags.StringVar(&f.psm, "psm", "", "服务 PSM")
	flags.StringVar(&f.methodName, "method-name", "", "BAM 方法名")
	flags.StringVar(&f.bamVersionID, "bam-version-id", "", "BAM 版本 ID")
	flags.StringVar(&f.interfaceName, "interface-name", "", "接口名；省略时服务端生成测试路径")
	flags.Int64Var(&f.bizDomainID, "biz-domain-id", 0, "业务域 ID；必须先 list 并向用户确认后显式传入正数")
	flags.StringVar(&f.desc, "desc", "", "接口描述")
	flags.StringVar(&f.sceneDesc, "scene-desc", "", "场景描述")
	flags.StringVar(&f.ownerList, "owner-list", "", "负责人 JSON 数组：inline、@file 或 @-")
	flags.Int64Var(&f.interfaceCateID, "interface-cate-id", 0, "接口分类 ID")
	flags.BoolVar(&f.skipAuth, "skip-auth", false, "是否跳过鉴权")
	flags.BoolVar(&f.confirmedByUser, "confirmed-by-user", false, "确认用户已明确核对 init 清单（仅本地门禁，不发送服务端）")
	flags.BoolVar(&f.apply, "apply", false, "确认直接落库")
}

func (f agentInitFlags) request(command *cobra.Command, loader *jsoninput.Loader) (djt.AgentInitRequest, error) {
	bizDomainID := f.bizDomainID
	request := djt.AgentInitRequest{
		PSM:          strings.TrimSpace(f.psm),
		MethodName:   strings.TrimSpace(f.methodName),
		BAMVersionID: strings.TrimSpace(f.bamVersionID),
		BizDomainID:  &bizDomainID,
	}
	if request.PSM == "" {
		return request, errors.New("--psm 不能为空")
	}
	if request.MethodName == "" {
		return request, errors.New("--method-name 不能为空")
	}
	if request.BAMVersionID == "" {
		return request, errors.New("--bam-version-id 不能为空")
	}
	if flagChanged(command, "interface-id") {
		if f.interfaceID <= 0 {
			return request, errors.New("--interface-id 必须大于 0")
		}
		request.InterfaceID = &f.interfaceID
	}
	setOptionalString(command, "interface-name", f.interfaceName, &request.InterfaceName)
	setOptionalString(command, "desc", f.desc, &request.Desc)
	setOptionalString(command, "scene-desc", f.sceneDesc, &request.SceneDesc)
	setOptionalInt64(command, "interface-cate-id", f.interfaceCateID, &request.InterfaceCateID)
	setOptionalBool(command, "skip-auth", f.skipAuth, &request.SkipAuth)
	if flagChanged(command, "owner-list") {
		value, err := loader.Array(f.ownerList, "--owner-list")
		if err != nil {
			return request, err
		}
		request.OwnerList = value
	}
	return request, nil
}

type agentPayloadFlags struct {
	bamVersionID    string
	requestInfo     string
	responseInfo    string
	errConfigList   string
	interfaceName   string
	methodName      string
	psm             string
	desc            string
	sceneDesc       string
	ownerList       string
	interfaceCateID int64
	authSubjectIDs  string
	skipAuth        bool
	slaRT           int32
	slaAva          string
	qps             int32
	timeout         int32
	callType        int32
	bizSuccErrCode  string
	errCode         string
	errMsg          string
	stylePatches    string
	releaseNote     string
}

func (f *agentPayloadFlags) bind(flags *pflag.FlagSet, includeSaveOnly bool) {
	flags.StringVar(&f.requestInfo, "request-info", "", "请求参数树 JSON 数组：inline、@file 或 @-")
	flags.StringVar(&f.responseInfo, "response-info", "", "响应参数树 JSON 数组：inline、@file 或 @-")
	flags.StringVar(&f.errConfigList, "err-config-list", "", "错误码配置 JSON 数组：inline、@file 或 @-")
	flags.StringVar(&f.stylePatches, "style-patches", "", "样式补丁 JSON 数组：inline、@file 或 @-")
	flags.StringVar(&f.ownerList, "owner-list", "", "负责人 JSON 数组：inline、@file 或 @-")
	flags.StringVar(&f.authSubjectIDs, "auth-subject-ids", "", "鉴权主体 ID JSON 数组：inline、@file 或 @-")
	flags.StringVar(&f.interfaceName, "interface-name", "", "接口名")
	flags.StringVar(&f.methodName, "method-name", "", "方法名")
	flags.StringVar(&f.psm, "psm", "", "服务 PSM")
	flags.StringVar(&f.desc, "desc", "", "接口描述")
	flags.StringVar(&f.sceneDesc, "scene-desc", "", "场景描述")
	flags.Int64Var(&f.interfaceCateID, "interface-cate-id", 0, "接口分类 ID")
	flags.BoolVar(&f.skipAuth, "skip-auth", false, "是否跳过鉴权")
	flags.StringVar(&f.bizSuccErrCode, "biz-succ-err-code", "", "业务成功错误码")
	flags.StringVar(&f.errCode, "err-code", "", "错误码字段路径")
	flags.StringVar(&f.errMsg, "err-msg", "", "错误信息字段路径")
	flags.StringVar(&f.releaseNote, "release-note", "", "发布说明")
	if includeSaveOnly {
		flags.StringVar(&f.bamVersionID, "bam-version-id", "", "BAM 版本 ID")
		flags.Int32Var(&f.slaRT, "sla-rt", 0, "SLA RT")
		flags.StringVar(&f.slaAva, "sla-ava", "", "SLA 可用性")
		flags.Int32Var(&f.qps, "qps", 0, "QPS")
		flags.Int32Var(&f.timeout, "timeout", 0, "超时时间")
		flags.Int32Var(&f.callType, "call-type", 0, "调用类型")
	}
}

func (f agentPayloadFlags) request(command *cobra.Command, loader *jsoninput.Loader) (djt.AgentPayload, error) {
	payload := djt.AgentPayload{}
	setOptionalString(command, "bam-version-id", f.bamVersionID, &payload.BAMVersionID)
	setOptionalString(command, "interface-name", f.interfaceName, &payload.InterfaceName)
	setOptionalString(command, "method-name", f.methodName, &payload.MethodName)
	setOptionalString(command, "psm", f.psm, &payload.PSM)
	setOptionalString(command, "desc", f.desc, &payload.Desc)
	setOptionalString(command, "scene-desc", f.sceneDesc, &payload.SceneDesc)
	setOptionalInt64(command, "interface-cate-id", f.interfaceCateID, &payload.InterfaceCateID)
	setOptionalBool(command, "skip-auth", f.skipAuth, &payload.SkipAuth)
	setOptionalInt32(command, "sla-rt", f.slaRT, &payload.SLART)
	setOptionalString(command, "sla-ava", f.slaAva, &payload.SLAAva)
	setOptionalInt32(command, "qps", f.qps, &payload.QPS)
	setOptionalInt32(command, "timeout", f.timeout, &payload.Timeout)
	setOptionalInt32(command, "call-type", f.callType, &payload.CallType)
	setOptionalString(command, "biz-succ-err-code", f.bizSuccErrCode, &payload.BizSuccErrCode)
	setOptionalString(command, "err-code", f.errCode, &payload.ErrCode)
	setOptionalString(command, "err-msg", f.errMsg, &payload.ErrMsg)
	setOptionalString(command, "release-note", f.releaseNote, &payload.ReleaseNote)

	complex := []struct {
		name   string
		source string
		target *json.RawMessage
	}{
		{name: "request-info", source: f.requestInfo, target: &payload.RequestInfo},
		{name: "response-info", source: f.responseInfo, target: &payload.ResponseInfo},
		{name: "err-config-list", source: f.errConfigList, target: &payload.ErrConfigList},
		{name: "style-patches", source: f.stylePatches, target: &payload.StylePatches},
		{name: "owner-list", source: f.ownerList, target: &payload.OwnerList},
		{name: "auth-subject-ids", source: f.authSubjectIDs, target: &payload.AuthSubjectIDs},
	}
	for _, item := range complex {
		if !flagChanged(command, item.name) {
			continue
		}
		value, err := loader.Array(item.source, "--"+item.name)
		if err != nil {
			return payload, err
		}
		*item.target = value
	}
	return payload, nil
}

type agentSaveFlags struct {
	interfaceID     int64
	modifyVersionID int64
	sections        []string
	mode            writeMode
	payload         agentPayloadFlags
}

func (f *agentSaveFlags) bind(flags *pflag.FlagSet) {
	flags.Int64Var(&f.interfaceID, "interface-id", 0, "接口 ID")
	flags.Int64Var(&f.modifyVersionID, "modify-version-id", 0, "修改版本 ID")
	flags.StringSliceVar(&f.sections, "sections", nil, "保存区块，可重复或逗号分隔")
	flags.BoolVar(&f.mode.dryRun, "dry-run", false, "仅预览，不落库")
	flags.BoolVar(&f.mode.apply, "apply", false, "确认落库")
	f.payload.bind(flags, true)
}

func (f agentSaveFlags) request(command *cobra.Command, loader *jsoninput.Loader, dryRun bool) (djt.AgentSaveRequest, error) {
	request := djt.AgentSaveRequest{InterfaceID: f.interfaceID, ModifyVersionID: f.modifyVersionID, DryRun: &dryRun}
	if request.InterfaceID <= 0 {
		return request, errors.New("--interface-id 必须大于 0")
	}
	if request.ModifyVersionID <= 0 {
		return request, errors.New("--modify-version-id 必须大于 0")
	}
	sections, err := normalizeSections(f.sections)
	if err != nil {
		return request, err
	}
	request.Sections = sections
	payload, err := f.payload.request(command, loader)
	if err != nil {
		return request, err
	}
	request.AgentPayload = payload
	return request, nil
}

type agentDocFlags struct {
	interfaceID     int64
	modifyVersionID int64
	autoFill        bool
	withPreviewURL  bool
	desc            string
	sceneDesc       string
	releaseNote     string
	requestInfo     string
	responseInfo    string
	errConfigList   string
	bizSuccErrCode  string
	errCode         string
	errMsg          string
	apply           bool
}

func (f *agentDocFlags) bind(flags *pflag.FlagSet) {
	flags.Int64Var(&f.interfaceID, "interface-id", 0, "接口 ID")
	flags.Int64Var(&f.modifyVersionID, "modify-version-id", 0, "修改版本 ID")
	flags.BoolVar(&f.autoFill, "auto-fill", true, "自动补全文档示例")
	flags.BoolVar(&f.withPreviewURL, "with-preview-url", false, "返回预览 URL")
	flags.StringVar(&f.desc, "desc", "", "接口描述")
	flags.StringVar(&f.sceneDesc, "scene-desc", "", "场景描述")
	flags.StringVar(&f.releaseNote, "release-note", "", "发布说明")
	flags.StringVar(&f.requestInfo, "request-info", "", "请求参数树 JSON 数组：inline、@file 或 @-")
	flags.StringVar(&f.responseInfo, "response-info", "", "响应参数树 JSON 数组：inline、@file 或 @-")
	flags.StringVar(&f.errConfigList, "err-config-list", "", "错误码配置 JSON 数组：inline、@file 或 @-")
	flags.StringVar(&f.bizSuccErrCode, "biz-succ-err-code", "", "业务成功错误码")
	flags.StringVar(&f.errCode, "err-code", "", "错误码字段路径")
	flags.StringVar(&f.errMsg, "err-msg", "", "错误信息字段路径")
	flags.BoolVar(&f.apply, "apply", false, "确认直接落库")
}

func (f agentDocFlags) request(command *cobra.Command, loader *jsoninput.Loader) (djt.AgentDocRequest, error) {
	request := djt.AgentDocRequest{InterfaceID: f.interfaceID, ModifyVersionID: f.modifyVersionID, AutoFill: boolPointer(f.autoFill)}
	if request.InterfaceID <= 0 {
		return request, errors.New("--interface-id 必须大于 0")
	}
	if request.ModifyVersionID <= 0 {
		return request, errors.New("--modify-version-id 必须大于 0")
	}
	if flagChanged(command, "with-preview-url") {
		request.WithPreviewURL = boolPointer(f.withPreviewURL)
	}
	setOptionalString(command, "desc", f.desc, &request.Desc)
	setOptionalString(command, "scene-desc", f.sceneDesc, &request.SceneDesc)
	setOptionalString(command, "release-note", f.releaseNote, &request.ReleaseNote)
	setOptionalString(command, "biz-succ-err-code", f.bizSuccErrCode, &request.BizSuccErrCode)
	setOptionalString(command, "err-code", f.errCode, &request.ErrCode)
	setOptionalString(command, "err-msg", f.errMsg, &request.ErrMsg)
	complex := []struct {
		name   string
		source string
		target *json.RawMessage
	}{
		{name: "request-info", source: f.requestInfo, target: &request.RequestInfo},
		{name: "response-info", source: f.responseInfo, target: &request.ResponseInfo},
		{name: "err-config-list", source: f.errConfigList, target: &request.ErrConfigList},
	}
	for _, item := range complex {
		if !flagChanged(command, item.name) {
			continue
		}
		value, err := loader.Array(item.source, "--"+item.name)
		if err != nil {
			return request, err
		}
		*item.target = value
	}
	return request, nil
}

type agentAdvanceFlags struct {
	interfaceID     int64
	modifyVersionID int64
	step            string
	mode            writeMode
	auditReason     string
	auditMeego      string
	skipReason      string
	payload         agentPayloadFlags
}

func (f *agentAdvanceFlags) bind(flags *pflag.FlagSet) {
	flags.Int64Var(&f.interfaceID, "interface-id", 0, "接口 ID")
	flags.Int64Var(&f.modifyVersionID, "modify-version-id", 0, "修改版本 ID")
	flags.StringVar(&f.step, "step", "", "推进步骤")
	flags.BoolVar(&f.mode.dryRun, "dry-run", false, "仅预览，不推进")
	flags.BoolVar(&f.mode.apply, "apply", false, "确认推进")
	flags.StringVar(&f.auditReason, "audit-reason", "", "提审原因")
	flags.StringVar(&f.auditMeego, "audit-meego", "", "提审 Meego")
	flags.StringVar(&f.skipReason, "skip-reason", "", "跳过原因")
	f.payload.bind(flags, false)
}

func (f agentAdvanceFlags) request(command *cobra.Command, loader *jsoninput.Loader, dryRun bool) (djt.AgentAdvanceRequest, error) {
	request := djt.AgentAdvanceRequest{
		InterfaceID:     f.interfaceID,
		ModifyVersionID: f.modifyVersionID,
		Step:            strings.TrimSpace(f.step),
		DryRun:          dryRun,
	}
	if request.InterfaceID <= 0 {
		return request, errors.New("--interface-id 必须大于 0")
	}
	if request.ModifyVersionID <= 0 {
		return request, errors.New("--modify-version-id 必须大于 0")
	}
	if !allowedAdvanceStep(request.Step) {
		return request, errors.New("--step 只接受 basic、request、response、errcode、ppe、submit-audit 或 cancel-audit")
	}
	if request.Step == "submit-audit" {
		if strings.TrimSpace(f.auditReason) == "" {
			return request, errors.New("step=submit-audit 时 --audit-reason 不能为空")
		}
		if strings.TrimSpace(f.auditMeego) == "" {
			return request, errors.New("step=submit-audit 时 --audit-meego 不能为空")
		}
	}
	setOptionalString(command, "audit-reason", f.auditReason, &request.AuditReason)
	setOptionalString(command, "audit-meego", f.auditMeego, &request.AuditMeego)
	setOptionalString(command, "skip-reason", f.skipReason, &request.SkipReason)
	payload, err := f.payload.request(command, loader)
	if err != nil {
		return request, err
	}
	request.AgentPayload = payload
	return request, nil
}

func allowedAdvanceStep(step string) bool {
	switch step {
	case "basic", "request", "response", "errcode", "ppe", "submit-audit", "cancel-audit":
		return true
	default:
		return false
	}
}

func setOptionalString(command *cobra.Command, name, value string, target **string) {
	if flagChanged(command, name) {
		copyValue := value
		*target = &copyValue
	}
}

func setOptionalInt64(command *cobra.Command, name string, value int64, target **int64) {
	if flagChanged(command, name) {
		copyValue := value
		*target = &copyValue
	}
}

func setOptionalInt32(command *cobra.Command, name string, value int32, target **int32) {
	if flagChanged(command, name) {
		copyValue := value
		*target = &copyValue
	}
}

func setOptionalBool(command *cobra.Command, name string, value bool, target **bool) {
	if flagChanged(command, name) {
		*target = boolPointer(value)
	}
}

func boolPointer(value bool) *bool {
	return &value
}

func (f agentInitFlags) validate(command *cobra.Command) error {
	if !flagChanged(command, "biz-domain-id") || f.bizDomainID <= 0 {
		return errors.New(bizDomainSelectionError)
	}
	if strings.TrimSpace(f.psm) == "" {
		return errors.New("--psm 不能为空")
	}
	if strings.TrimSpace(f.methodName) == "" {
		return errors.New("--method-name 不能为空")
	}
	if strings.TrimSpace(f.bamVersionID) == "" {
		return errors.New("--bam-version-id 不能为空")
	}
	if flagChanged(command, "interface-id") && f.interfaceID <= 0 {
		return errors.New("--interface-id 必须大于 0")
	}
	return nil
}

func (f agentSaveFlags) validate() error {
	if f.interfaceID <= 0 {
		return errors.New("--interface-id 必须大于 0")
	}
	if f.modifyVersionID <= 0 {
		return errors.New("--modify-version-id 必须大于 0")
	}
	_, err := normalizeSections(f.sections)
	return err
}

func (f agentDocFlags) validate() error {
	if f.interfaceID <= 0 {
		return errors.New("--interface-id 必须大于 0")
	}
	if f.modifyVersionID <= 0 {
		return errors.New("--modify-version-id 必须大于 0")
	}
	return nil
}

func (f agentAdvanceFlags) validate() error {
	if f.interfaceID <= 0 {
		return errors.New("--interface-id 必须大于 0")
	}
	if f.modifyVersionID <= 0 {
		return errors.New("--modify-version-id 必须大于 0")
	}
	step := strings.TrimSpace(f.step)
	if !allowedAdvanceStep(step) {
		return errors.New("--step 只接受 basic、request、response、errcode、ppe、submit-audit 或 cancel-audit")
	}
	if step == "submit-audit" {
		if strings.TrimSpace(f.auditReason) == "" {
			return errors.New("step=submit-audit 时 --audit-reason 不能为空")
		}
		if strings.TrimSpace(f.auditMeego) == "" {
			return errors.New("step=submit-audit 时 --audit-meego 不能为空")
		}
	}
	return nil
}
