package cli

import (
	"bytes"
	"encoding/json"
	"net/http"
	"strings"
	"testing"
)

func TestAPITestCommandExecutesFriendlyPPERequest(t *testing.T) {
	recorder := &agentCommandRecorder{}
	var stdout bytes.Buffer
	root := newAgentTestRoot(recorder, &stdout, nil)
	err := root.execute("--output", "json", "djt", "api", "test", "ppe", "--interface-name", "/test/zzhTestDDD", "--lane", "ppe_djt_cli", "--params", `{"foo":"bar"}`)
	if err != nil {
		t.Fatal(err)
	}
	if len(recorder.requests) != 1 || recorder.requests[0].method != http.MethodPost || recorder.requests[0].path != "/api/djt-cli/agent/api-test/execute" {
		t.Fatalf("requests = %+v", recorder.requests)
	}
	var body map[string]json.RawMessage
	if err := json.Unmarshal(recorder.requests[0].body, &body); err != nil {
		t.Fatal(err)
	}
	if string(body["env"]) != `"PPE"` || string(body["interfaceName"]) != `"/test/zzhTestDDD"` || string(body["params"]) != `{"foo":"bar"}` {
		t.Fatalf("body = %s", recorder.requests[0].body)
	}
}

func TestAPITestProdRequiresExplicitConfirmation(t *testing.T) {
	called := false
	root := NewRootCommand(Dependencies{
		HTTPClient: commandHTTPDoer(func(*http.Request) (*http.Response, error) { called = true; return nil, nil }),
		Store:      &commandStore{credentials: validCommandCredentials()},
		Now:        commandNow,
		Stdout:     &bytes.Buffer{},
		Stderr:     &bytes.Buffer{},
	})
	root.SetArgs([]string{"djt", "api", "test", "prod", "--interface-name", "/test/zzhTestDDD"})
	err := root.Execute()
	if err == nil || !strings.Contains(err.Error(), "--confirmed-by-user") {
		t.Fatalf("err = %v", err)
	}
	if called {
		t.Fatal("未确认 PROD 时不应发起 HTTP 请求")
	}
}

func TestAPITestAuthAddCommand(t *testing.T) {
	recorder := &agentCommandRecorder{}
	root := newAgentTestRoot(recorder, &bytes.Buffer{}, nil)
	err := root.execute("djt", "api", "test", "auth", "add", "--env", "ppe", "--auth-id", "90419", "--auth-subject-biz-id", "0")
	if err != nil {
		t.Fatal(err)
	}
	if len(recorder.requests) != 1 || recorder.requests[0].path != "/api/djt-cli/agent/api-test/auth/add" {
		t.Fatalf("requests = %+v", recorder.requests)
	}
}
