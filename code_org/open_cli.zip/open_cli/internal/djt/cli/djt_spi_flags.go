package cli

import (
	"encoding/json"
	"errors"
	"fmt"
	"strings"

	"code.byted.org/temai/open_cli/internal/core/jsoninput"
	"code.byted.org/temai/open_cli/internal/djt"
	"github.com/spf13/cobra"
	"github.com/spf13/pflag"
)

const spiCreateGuidance = "操作顺序：先运行 doudian-open-cli djt biz-domain list --output json，展示动态结果，不得自动选择测试域；确认 sceneId 已存在、接口名为 业务域前缀/名称；再带 --biz-domain-id --confirmed-by-user --apply。"

type spiSceneListFlags struct {
	sceneName string
	page      int32
	pageSize  int32
}

func (f *spiSceneListFlags) bind(flags *pflag.FlagSet) {
	flags.StringVar(&f.sceneName, "scene-name", "", "场景名称")
	flags.Int32Var(&f.page, "page", 0, "页码")
	flags.Int32Var(&f.pageSize, "page-size", 0, "每页数量")
}

func (f spiSceneListFlags) request(command *cobra.Command) (djt.AgentSpiSceneListRequest, error) {
	request := djt.AgentSpiSceneListRequest{}
	setOptionalString(command, "scene-name", strings.TrimSpace(f.sceneName), &request.SceneName)
	setOptionalInt32(command, "page", f.page, &request.Page)
	setOptionalInt32(command, "page-size", f.pageSize, &request.PageSize)
	if request.Page != nil && *request.Page <= 0 {
		return request, errors.New("--page 必须大于 0")
	}
	if request.PageSize != nil && *request.PageSize <= 0 {
		return request, errors.New("--page-size 必须大于 0")
	}
	return request, nil
}

type spiSceneGetFlags struct {
	sceneID   int64
	sceneName string
}

func (f *spiSceneGetFlags) bind(flags *pflag.FlagSet) {
	flags.Int64Var(&f.sceneID, "scene-id", 0, "场景 ID")
	flags.StringVar(&f.sceneName, "scene-name", "", "场景名称")
}

func (f spiSceneGetFlags) request(command *cobra.Command) (djt.AgentSpiSceneGetRequest, error) {
	request := djt.AgentSpiSceneGetRequest{}
	if flagChanged(command, "scene-id") {
		if f.sceneID <= 0 {
			return request, errors.New("--scene-id 必须大于 0")
		}
		request.SceneID = &f.sceneID
	}
	if flagChanged(command, "scene-name") {
		name := strings.TrimSpace(f.sceneName)
		if name == "" {
			return request, errors.New("--scene-name 不能为空")
		}
		request.SceneName = &name
	}
	if (request.SceneID == nil) == (request.SceneName == nil) {
		return request, errors.New("必须且只能传一个 --scene-id 或 --scene-name")
	}
	return request, nil
}

type spiSceneSaveFlags struct {
	sceneName   string
	sceneDesc   string
	bizDomainID int64
	mode        writeMode
}

func (f *spiSceneSaveFlags) bind(flags *pflag.FlagSet) {
	flags.StringVar(&f.sceneName, "scene-name", "", "场景名称")
	flags.StringVar(&f.sceneDesc, "scene-desc", "", "场景描述")
	flags.Int64Var(&f.bizDomainID, "biz-domain-id", 0, "业务域 ID")
	bindWriteMode(flags, &f.mode)
}

func (f spiSceneSaveFlags) request() (djt.AgentSpiSceneSaveRequest, error) {
	dryRun, err := f.mode.dryRunValue()
	request := djt.AgentSpiSceneSaveRequest{
		DryRun: dryRun, SceneName: strings.TrimSpace(f.sceneName), SceneDesc: strings.TrimSpace(f.sceneDesc),
		BizDomainID: f.bizDomainID,
	}
	if err != nil {
		return request, err
	}
	if request.SceneName == "" {
		return request, errors.New("--scene-name 不能为空")
	}
	if request.BizDomainID <= 0 {
		return request, fmt.Errorf("创建场景时 --biz-domain-id 必须大于 0。%s", spiCreateGuidance)
	}
	return request, nil
}

type spiSceneSyncBoeFlags struct {
	sceneID int64
	appIDs  string
	mode    writeMode
}

func (f *spiSceneSyncBoeFlags) bind(flags *pflag.FlagSet) {
	flags.Int64Var(&f.sceneID, "scene-id", 0, "场景 ID")
	flags.StringVar(&f.appIDs, "app-ids", "", "应用 ID JSON 数组：inline、@file 或 @-")
	bindWriteMode(flags, &f.mode)
}

func (f spiSceneSyncBoeFlags) request(loader *jsoninput.Loader) (djt.AgentSpiSceneSyncBoeRequest, error) {
	dryRun, err := f.mode.dryRunValue()
	request := djt.AgentSpiSceneSyncBoeRequest{DryRun: dryRun, SceneID: f.sceneID}
	if err != nil {
		return request, err
	}
	if request.SceneID <= 0 {
		return request, errors.New("--scene-id 必须大于 0")
	}
	raw, err := loader.Array(f.appIDs, "--app-ids")
	if err != nil {
		return request, err
	}
	if err := json.Unmarshal(raw, &request.AppIDs); err != nil {
		return request, fmt.Errorf("--app-ids 必须是整数数组: %w", err)
	}
	return request, nil
}

type spiAccessAppListFlags struct {
	sceneID int64
}

func (f *spiAccessAppListFlags) bind(flags *pflag.FlagSet) {
	flags.Int64Var(&f.sceneID, "scene-id", 0, "场景 ID")
}

func (f spiAccessAppListFlags) request() (djt.AgentSpiAccessAppListRequest, error) {
	request := djt.AgentSpiAccessAppListRequest{SceneID: f.sceneID}
	if request.SceneID <= 0 {
		return request, errors.New("--scene-id 必须大于 0")
	}
	return request, nil
}

type spiAccessAppGetFlags struct {
	authID  int64
	sceneID int64
	appID   int64
}

func (f *spiAccessAppGetFlags) bind(flags *pflag.FlagSet) {
	flags.Int64Var(&f.authID, "auth-id", 0, "授权 ID")
	flags.Int64Var(&f.sceneID, "scene-id", 0, "场景 ID")
	flags.Int64Var(&f.appID, "app-id", 0, "应用 ID")
}

func (f spiAccessAppGetFlags) request(command *cobra.Command) (djt.AgentSpiAccessAppGetRequest, error) {
	request := djt.AgentSpiAccessAppGetRequest{}
	if flagChanged(command, "auth-id") {
		if f.authID <= 0 {
			return request, errors.New("--auth-id 必须大于 0")
		}
		request.AuthID = &f.authID
	}
	if flagChanged(command, "scene-id") {
		if f.sceneID <= 0 {
			return request, errors.New("--scene-id 必须大于 0")
		}
		request.SceneID = &f.sceneID
	}
	if flagChanged(command, "app-id") {
		if f.appID <= 0 {
			return request, errors.New("--app-id 必须大于 0")
		}
		request.AppID = &f.appID
	}
	switch {
	case request.AuthID != nil && (request.SceneID != nil || request.AppID != nil):
		return request, errors.New("--auth-id 不能与 --scene-id/--app-id 同时传")
	case request.AuthID != nil:
		return request, nil
	case request.SceneID != nil && request.AppID != nil:
		return request, nil
	default:
		return request, errors.New("必须传 --auth-id，或同时传 --scene-id 与 --app-id")
	}
}

type spiInterfaceListFlags struct {
	nameLike    string
	sceneID     int64
	bizDomainID int64
	page        int32
	pageSize    int32
}

func (f *spiInterfaceListFlags) bind(flags *pflag.FlagSet) {
	flags.StringVar(&f.nameLike, "name-like", "", "接口名称模糊搜索")
	flags.Int64Var(&f.sceneID, "scene-id", 0, "场景 ID")
	flags.Int64Var(&f.bizDomainID, "biz-domain-id", 0, "业务域 ID")
	flags.Int32Var(&f.page, "page", 0, "页码")
	flags.Int32Var(&f.pageSize, "page-size", 0, "每页数量")
}

func (f spiInterfaceListFlags) request(command *cobra.Command) (djt.AgentSpiListInterfaceRequest, error) {
	request := djt.AgentSpiListInterfaceRequest{}
	setOptionalString(command, "name-like", strings.TrimSpace(f.nameLike), &request.NameLike)
	if flagChanged(command, "scene-id") {
		if f.sceneID <= 0 {
			return request, errors.New("--scene-id 必须大于 0")
		}
		request.SceneID = &f.sceneID
	}
	if flagChanged(command, "biz-domain-id") {
		if f.bizDomainID <= 0 {
			return request, errors.New("--biz-domain-id 必须大于 0")
		}
		request.BizDomainID = &f.bizDomainID
	}
	setOptionalInt32(command, "page", f.page, &request.Page)
	setOptionalInt32(command, "page-size", f.pageSize, &request.PageSize)
	if request.Page != nil && *request.Page <= 0 {
		return request, errors.New("--page 必须大于 0")
	}
	if request.PageSize != nil && *request.PageSize <= 0 {
		return request, errors.New("--page-size 必须大于 0")
	}
	return request, nil
}

type spiAccessAppSaveFlags struct {
	sceneID int64
	appID   int64
	mode    writeMode
}

func (f *spiAccessAppSaveFlags) bind(flags *pflag.FlagSet) {
	flags.Int64Var(&f.sceneID, "scene-id", 0, "场景 ID")
	flags.Int64Var(&f.appID, "app-id", 0, "应用 ID")
	bindWriteMode(flags, &f.mode)
}

func (f spiAccessAppSaveFlags) request() (djt.AgentSpiAccessAppSaveRequest, error) {
	dryRun, err := f.mode.dryRunValue()
	request := djt.AgentSpiAccessAppSaveRequest{DryRun: dryRun, SceneID: f.sceneID, AppID: f.appID}
	if err != nil {
		return request, err
	}
	if request.SceneID <= 0 {
		return request, errors.New("--scene-id 必须大于 0")
	}
	if request.AppID <= 0 {
		return request, errors.New("--app-id 必须大于 0")
	}
	return request, nil
}

type spiAccessAppEnableFlags struct {
	authID int64
	mode   writeMode
}

func (f *spiAccessAppEnableFlags) bind(flags *pflag.FlagSet) {
	flags.Int64Var(&f.authID, "auth-id", 0, "授权 ID")
	bindWriteMode(flags, &f.mode)
}

func (f spiAccessAppEnableFlags) request() (djt.AgentSpiAccessAppEnableRequest, error) {
	dryRun, err := f.mode.dryRunValue()
	request := djt.AgentSpiAccessAppEnableRequest{DryRun: dryRun, AuthID: f.authID}
	if err != nil {
		return request, err
	}
	if request.AuthID <= 0 {
		return request, errors.New("--auth-id 必须大于 0")
	}
	return request, nil
}

type spiInterfaceGetFlags struct {
	interfaceID   int64
	interfaceName string
}

func (f *spiInterfaceGetFlags) bind(flags *pflag.FlagSet) {
	flags.Int64Var(&f.interfaceID, "interface-id", 0, "接口 ID")
	flags.StringVar(&f.interfaceName, "interface-name", "", "接口名称")
}

func (f spiInterfaceGetFlags) request(command *cobra.Command) (djt.AgentSpiGetInterfaceRequest, error) {
	request := djt.AgentSpiGetInterfaceRequest{}
	if flagChanged(command, "interface-id") {
		if f.interfaceID <= 0 {
			return request, errors.New("--interface-id 必须大于 0")
		}
		request.InterfaceID = &f.interfaceID
	}
	if flagChanged(command, "interface-name") {
		name := strings.TrimSpace(f.interfaceName)
		if name == "" {
			return request, errors.New("--interface-name 不能为空")
		}
		request.InterfaceName = &name
	}
	if (request.InterfaceID == nil) == (request.InterfaceName == nil) {
		return request, errors.New("必须且只能传一个 --interface-id 或 --interface-name")
	}
	return request, nil
}

type spiInterfaceSaveFlags struct {
	input           string
	interfaceID     int64
	modifyVersionID int64
	sceneID         int64
	interfaceName   string
	bizDomainID     int64
	desc            string
	userSceneDesc   string
	ownerList       string
	httpMethod      string
	timeout         int64
	requestInfo     string
	responseInfo    string
	headers         string
	errorInfoList   string
	bizUseCases     string
	confirmedByUser bool
	mode            writeMode
}

func (f *spiInterfaceSaveFlags) bind(flags *pflag.FlagSet) {
	flags.StringVar(&f.input, "input", "", "完整保存请求 JSON 对象：inline、@file 或 @-")
	flags.Int64Var(&f.interfaceID, "interface-id", 0, "接口 ID")
	flags.Int64Var(&f.modifyVersionID, "modify-version-id", 0, "修改版本 ID")
	flags.Int64Var(&f.sceneID, "scene-id", 0, "场景 ID")
	flags.StringVar(&f.interfaceName, "interface-name", "", "接口名称")
	flags.Int64Var(&f.bizDomainID, "biz-domain-id", 0, "业务域 ID")
	flags.StringVar(&f.desc, "desc", "", "接口描述")
	flags.StringVar(&f.userSceneDesc, "user-scene-desc", "", "用户场景描述")
	flags.StringVar(&f.ownerList, "owner-list", "", "负责人 JSON 数组：inline、@file 或 @-")
	flags.StringVar(&f.httpMethod, "http-method", "", "HTTP 方法")
	flags.Int64Var(&f.timeout, "timeout", 0, "超时时间")
	flags.StringVar(&f.requestInfo, "request-info", "", "请求参数 JSON 数组：inline、@file 或 @-")
	flags.StringVar(&f.responseInfo, "response-info", "", "响应参数 JSON 数组：inline、@file 或 @-")
	flags.StringVar(&f.headers, "headers", "", "请求头 JSON 数组：inline、@file 或 @-")
	flags.StringVar(&f.errorInfoList, "error-info-list", "", "错误信息 JSON 数组：inline、@file 或 @-")
	flags.StringVar(&f.bizUseCases, "biz-use-cases", "", "业务用例 JSON 数组：inline、@file 或 @-")
	flags.BoolVar(&f.confirmedByUser, "confirmed-by-user", false, "确认用户已核对创建信息（仅本地门禁，不发送服务端）")
	bindWriteMode(flags, &f.mode)
}

func (f spiInterfaceSaveFlags) request(command *cobra.Command, loader *jsoninput.Loader) (djt.AgentSpiSaveInterfaceRequest, error) {
	dryRun, err := f.mode.dryRunValue()
	request := djt.AgentSpiSaveInterfaceRequest{DryRun: dryRun}
	if err != nil {
		return request, err
	}
	if flagChanged(command, "input") {
		if f.hasSplitInput(command) {
			return request, errors.New("--input 与拆分字段 flags 不要混用")
		}
		raw, loadErr := loader.Object(f.input, "--input")
		if loadErr != nil {
			return request, loadErr
		}
		if unmarshalErr := json.Unmarshal(raw, &request); unmarshalErr != nil {
			return request, fmt.Errorf("解析 --input 失败: %w", unmarshalErr)
		}
		request.DryRun = dryRun
	} else {
		setOptionalInt64(command, "interface-id", f.interfaceID, &request.InterfaceID)
		setOptionalInt64(command, "modify-version-id", f.modifyVersionID, &request.ModifyVersionID)
		setOptionalInt64(command, "scene-id", f.sceneID, &request.SceneID)
		setOptionalString(command, "interface-name", strings.TrimSpace(f.interfaceName), &request.InterfaceName)
		setOptionalInt64(command, "biz-domain-id", f.bizDomainID, &request.BizDomainID)
		setOptionalString(command, "desc", f.desc, &request.Desc)
		setOptionalString(command, "user-scene-desc", f.userSceneDesc, &request.UserSceneDesc)
		setOptionalString(command, "http-method", strings.TrimSpace(f.httpMethod), &request.HTTPMethod)
		setOptionalInt64(command, "timeout", f.timeout, &request.Timeout)
		if err := f.loadArrays(command, loader, &request); err != nil {
			return request, err
		}
	}
	if err := f.validateRequest(request); err != nil {
		return request, err
	}
	return request, nil
}

func (f spiInterfaceSaveFlags) hasSplitInput(command *cobra.Command) bool {
	for _, name := range []string{
		"interface-id", "modify-version-id", "scene-id", "interface-name", "biz-domain-id",
		"desc", "user-scene-desc", "owner-list", "http-method", "timeout", "request-info",
		"response-info", "headers", "error-info-list", "biz-use-cases",
	} {
		if flagChanged(command, name) {
			return true
		}
	}
	return false
}

func (f spiInterfaceSaveFlags) loadArrays(command *cobra.Command, loader *jsoninput.Loader, request *djt.AgentSpiSaveInterfaceRequest) error {
	rawTargets := []struct {
		name   string
		source string
		target *json.RawMessage
	}{
		{name: "request-info", source: f.requestInfo, target: &request.RequestInfo},
		{name: "response-info", source: f.responseInfo, target: &request.ResponseInfo},
		{name: "headers", source: f.headers, target: &request.Headers},
		{name: "error-info-list", source: f.errorInfoList, target: &request.ErrorInfoList},
		{name: "biz-use-cases", source: f.bizUseCases, target: &request.BizUseCases},
	}
	for _, item := range rawTargets {
		if !flagChanged(command, item.name) {
			continue
		}
		value, err := loader.Array(item.source, "--"+item.name)
		if err != nil {
			return err
		}
		*item.target = value
	}
	if flagChanged(command, "owner-list") {
		value, err := loader.Array(f.ownerList, "--owner-list")
		if err != nil {
			return err
		}
		if err := json.Unmarshal(value, &request.OwnerList); err != nil {
			return fmt.Errorf("--owner-list 必须是字符串数组: %w", err)
		}
	}
	return nil
}

func (f spiInterfaceSaveFlags) validateRequest(request djt.AgentSpiSaveInterfaceRequest) error {
	if request.InterfaceID != nil {
		if *request.InterfaceID <= 0 {
			return errors.New("--interface-id 必须大于 0")
		}
		if request.ModifyVersionID == nil {
			return errors.New("更新接口时必须显式传 --modify-version-id")
		}
		return nil
	}
	if request.SceneID == nil || *request.SceneID <= 0 {
		return fmt.Errorf("创建接口时 --scene-id 必须大于 0。%s", spiCreateGuidance)
	}
	if request.InterfaceName == nil || strings.TrimSpace(*request.InterfaceName) == "" {
		return fmt.Errorf("创建接口时 --interface-name 不能为空。%s", spiCreateGuidance)
	}
	if request.BizDomainID == nil || *request.BizDomainID <= 0 {
		return fmt.Errorf("创建接口时 --biz-domain-id 必须大于 0。%s", spiCreateGuidance)
	}
	if !request.DryRun && !f.confirmedByUser {
		return fmt.Errorf("创建接口 apply 必须显式传 --confirmed-by-user。%s", spiCreateGuidance)
	}
	return nil
}

type spiSubmitReviewFlags struct {
	interfaceID     int64
	modifyVersionID int64
	reason          string
	meego           string
	mode            writeMode
}

func (f *spiSubmitReviewFlags) bind(flags *pflag.FlagSet) {
	flags.Int64Var(&f.interfaceID, "interface-id", 0, "接口 ID")
	flags.Int64Var(&f.modifyVersionID, "modify-version-id", 0, "修改版本 ID")
	flags.StringVar(&f.reason, "reason", "", "提审原因")
	flags.StringVar(&f.meego, "meego", "", "Meego 链接")
	bindWriteMode(flags, &f.mode)
}

type spiCancelUpgradeFlags struct {
	interfaceID   int64
	interfaceName string
	mode          writeMode
}

func (f *spiCancelUpgradeFlags) bind(flags *pflag.FlagSet) {
	flags.Int64Var(&f.interfaceID, "interface-id", 0, "接口 ID")
	flags.StringVar(&f.interfaceName, "interface-name", "", "接口名称")
	bindWriteMode(flags, &f.mode)
}

func (f spiCancelUpgradeFlags) request(command *cobra.Command) (djt.AgentSpiCancelUpgradeRequest, error) {
	dryRun, err := f.mode.dryRunValue()
	request := djt.AgentSpiCancelUpgradeRequest{DryRun: dryRun}
	if err != nil {
		return request, err
	}
	hasID := flagChanged(command, "interface-id")
	hasName := flagChanged(command, "interface-name")
	if hasID == hasName {
		return request, errors.New("必须且只能传一个 --interface-id 或 --interface-name")
	}
	if hasID {
		if f.interfaceID <= 0 {
			return request, errors.New("--interface-id 必须大于 0")
		}
		request.InterfaceID = &f.interfaceID
	}
	if hasName {
		name := strings.TrimSpace(f.interfaceName)
		if name == "" {
			return request, errors.New("--interface-name 不能为空")
		}
		request.InterfaceName = &name
	}
	return request, nil
}

func (f spiSubmitReviewFlags) request(command *cobra.Command) (djt.AgentSpiSubmitReviewRequest, error) {
	dryRun, err := f.mode.dryRunValue()
	request := djt.AgentSpiSubmitReviewRequest{
		InterfaceID: f.interfaceID, ModifyVersionID: f.modifyVersionID,
		DryRun: dryRun, Reason: strings.TrimSpace(f.reason),
	}
	if err != nil {
		return request, err
	}
	if request.InterfaceID <= 0 {
		return request, errors.New("--interface-id 必须大于 0")
	}
	if !flagChanged(command, "modify-version-id") {
		return request, errors.New("必须显式传 --modify-version-id")
	}
	if request.Reason == "" {
		return request, errors.New("--reason 不能为空")
	}
	setOptionalString(command, "meego", strings.TrimSpace(f.meego), &request.Meego)
	return request, nil
}

func bindWriteMode(flags *pflag.FlagSet, mode *writeMode) {
	flags.BoolVar(&mode.dryRun, "dry-run", false, "仅预览，不落库")
	flags.BoolVar(&mode.apply, "apply", false, "确认落库")
}
