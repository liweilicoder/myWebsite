package cli

import (
	corecli "code.byted.org/temai/open_cli/internal/core/cli"
	"code.byted.org/temai/open_cli/internal/core/jsoninput"
	"github.com/spf13/cobra"
)

func newSPIInterfaceCommand(deps Dependencies, format *corecli.OutputFormat, network *agentNetworkFlags) *cobra.Command {
	command := &cobra.Command{Use: "interface", Short: "管理 SPI 接口"}
	command.AddCommand(
		newSPIInterfaceListCommand(deps, format, network),
		newSPIInterfaceGetCommand(deps, format, network),
		newSPIInterfaceSaveCommand(deps, format, network),
		newSPIInterfaceSubmitReviewCommand(deps, format, network),
		newSPIInterfaceCancelUpgradeCommand(deps, format, network),
	)
	return command
}

func newSPIInterfaceListCommand(deps Dependencies, format *corecli.OutputFormat, network *agentNetworkFlags) *cobra.Command {
	flags := &spiInterfaceListFlags{}
	command := &cobra.Command{
		Use:   "list",
		Short: "搜索 SPI 接口",
		Args:  cobra.NoArgs,
		RunE: func(command *cobra.Command, _ []string) error {
			request, err := flags.request(command)
			if err != nil {
				return err
			}
			options, err := prepareSPI(command.Context(), command, deps, network)
			if err != nil {
				return err
			}
			result, err := newSPIService(deps).ListInterface(command.Context(), request, options)
			if err != nil {
				return err
			}
			return renderSPIResult(deps.Stdout, *format, result)
		},
	}
	flags.bind(command.Flags())
	return command
}

func newSPIInterfaceGetCommand(deps Dependencies, format *corecli.OutputFormat, network *agentNetworkFlags) *cobra.Command {
	flags := &spiInterfaceGetFlags{}
	command := &cobra.Command{
		Use:   "get",
		Short: "查询 SPI 接口",
		Args:  cobra.NoArgs,
		RunE: func(command *cobra.Command, _ []string) error {
			request, err := flags.request(command)
			if err != nil {
				return err
			}
			options, err := prepareSPI(command.Context(), command, deps, network)
			if err != nil {
				return err
			}
			result, err := newSPIService(deps).GetInterface(command.Context(), request, options)
			if err != nil {
				return err
			}
			return renderSPIResult(deps.Stdout, *format, result)
		},
	}
	flags.bind(command.Flags())
	return command
}

func newSPIInterfaceSaveCommand(deps Dependencies, format *corecli.OutputFormat, network *agentNetworkFlags) *cobra.Command {
	flags := &spiInterfaceSaveFlags{}
	command := &cobra.Command{
		Use:   "save",
		Short: "创建或更新 SPI 接口（默认 dry-run）",
		Long:  "创建或更新 SPI 接口（默认 dry-run）。\n\n" + spiCreateGuidance,
		Args:  cobra.NoArgs,
		RunE: func(command *cobra.Command, _ []string) error {
			request, err := flags.request(command, jsoninput.NewLoader(agentStdin(deps)))
			if err != nil {
				return err
			}
			options, err := prepareSPI(command.Context(), command, deps, network)
			if err != nil {
				return err
			}
			result, err := newSPIService(deps).SaveInterface(command.Context(), request, options)
			if err != nil {
				return err
			}
			return renderSPIResult(deps.Stdout, *format, result)
		},
	}
	flags.bind(command.Flags())
	return command
}

func newSPIInterfaceSubmitReviewCommand(deps Dependencies, format *corecli.OutputFormat, network *agentNetworkFlags) *cobra.Command {
	flags := &spiSubmitReviewFlags{}
	command := &cobra.Command{
		Use:   "submit-review",
		Short: "提交 SPI 接口审核（默认 dry-run）",
		Args:  cobra.NoArgs,
		RunE: func(command *cobra.Command, _ []string) error {
			request, err := flags.request(command)
			if err != nil {
				return err
			}
			options, err := prepareSPI(command.Context(), command, deps, network)
			if err != nil {
				return err
			}
			result, err := newSPIService(deps).SubmitReview(command.Context(), request, options)
			if err != nil {
				return err
			}
			return renderSPIResult(deps.Stdout, *format, result)
		},
	}
	flags.bind(command.Flags())
	return command
}

func newSPIInterfaceCancelUpgradeCommand(deps Dependencies, format *corecli.OutputFormat, network *agentNetworkFlags) *cobra.Command {
	flags := &spiCancelUpgradeFlags{}
	command := &cobra.Command{
		Use:   "cancel-upgrade",
		Short: "撤销 SPI 接口升级草稿（默认 dry-run，仅 status=201 可撤销）",
		Args:  cobra.NoArgs,
		RunE: func(command *cobra.Command, _ []string) error {
			request, err := flags.request(command)
			if err != nil {
				return err
			}
			options, err := prepareSPI(command.Context(), command, deps, network)
			if err != nil {
				return err
			}
			result, err := newSPIService(deps).CancelUpgrade(command.Context(), request, options)
			if err != nil {
				return err
			}
			return renderSPIResult(deps.Stdout, *format, result)
		},
	}
	flags.bind(command.Flags())
	return command
}
