package cli

import (
	corecli "code.byted.org/temai/open_cli/internal/core/cli"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"strconv"
	"strings"
	"time"

	"code.byted.org/temai/open_cli/internal/core/jsoninput"
	"code.byted.org/temai/open_cli/internal/core/output"
	"code.byted.org/temai/open_cli/internal/core/urlpolicy"
	"code.byted.org/temai/open_cli/internal/djt"
	"code.byted.org/temai/open_cli/internal/djt/auth"
	"github.com/spf13/cobra"
)

type agentJSONOutput struct {
	Code    int64           `json:"code"`
	Message string          `json:"message"`
	Data    json.RawMessage `json:"data"`
}

const initPreparationGuidance = "操作顺序：先运行 doudian-open-cli djt biz-domain list --output json，展示动态结果，不得自动选择测试域；之后展示完整确认清单并等待用户明确答复，再带 --confirmed-by-user --apply。"
const initConfirmationChecklist = "确认清单：新建/重绑、PSM、methodName、bamVersionId、interfaceName（省略会生成测试路径）、bizDomainId、ownerList（省略为当前用户）、skipAuth、desc、sceneDesc、interfaceCateId。"
const initPersistenceWarning = "init 直接落库，BAM 绑定/解析失败草稿不回滚。"

func initGuidanceError(err error) error {
	return fmt.Errorf("%w。%s %s %s", err, initPreparationGuidance, initConfirmationChecklist, initPersistenceWarning)
}

func newAPICommand(deps Dependencies, format *corecli.OutputFormat) *cobra.Command {
	network := &agentNetworkFlags{}
	command := &cobra.Command{Use: "api", Short: "管理点将台 API"}
	network.bind(command)
	command.AddCommand(
		newAgentGetCommand(deps, format, network),
		newAgentInitCommand(deps, format, network),
		newAgentSaveCommand(deps, format, network),
		newAgentDocCommand(deps, format, network),
		newAgentAdvanceCommand(deps, format, network),
		newAPITestCommand(deps, format, network),
	)
	return command
}

func newAgentGetCommand(deps Dependencies, format *corecli.OutputFormat, network *agentNetworkFlags) *cobra.Command {
	flags := &agentGetFlags{}
	command := &cobra.Command{
		Use:   "get",
		Short: "查询接口配置或模糊搜索接口",
		Args:  cobra.NoArgs,
		RunE: func(command *cobra.Command, _ []string) error {
			request, err := flags.request(command)
			if err != nil {
				return err
			}
			options, err := network.resolve(command)
			if err != nil {
				return err
			}
			credentials, err := loadAgentCredentials(command.Context(), deps)
			if err != nil {
				return err
			}
			options.Credentials = credentials
			result, err := newAgentService(deps).Get(command.Context(), request, options)
			if err != nil {
				return err
			}
			return renderAgentResult(deps.Stdout, *format, result)
		},
	}
	flags.bind(command.Flags())
	return command
}

func newAgentInitCommand(deps Dependencies, format *corecli.OutputFormat, network *agentNetworkFlags) *cobra.Command {
	flags := &agentInitFlags{}
	command := &cobra.Command{
		Use:   "init",
		Short: "从 BAM 初始化接口（直接落库，需用户确认与 --apply）",
		Long:  "从 BAM 新建或重绑接口。\n\n" + initPreparationGuidance + "\n" + initConfirmationChecklist + "\n" + initPersistenceWarning,
		Args:  cobra.NoArgs,
		RunE: func(command *cobra.Command, _ []string) error {
			if !flags.apply {
				return initGuidanceError(errors.New("init 会直接落库，必须显式传 --apply"))
			}
			if !flags.confirmedByUser {
				return initGuidanceError(errors.New("必须获得用户对确认清单的明确答复，并显式传 --confirmed-by-user"))
			}
			if err := flags.validate(command); err != nil {
				return initGuidanceError(err)
			}
			options, err := network.resolve(command)
			if err != nil {
				return err
			}
			request, err := flags.request(command, jsoninput.NewLoader(agentStdin(deps)))
			if err != nil {
				return initGuidanceError(err)
			}
			credentials, err := loadAgentCredentials(command.Context(), deps)
			if err != nil {
				return err
			}
			options.Credentials = credentials
			result, err := newAgentService(deps).Init(command.Context(), request, options)
			if err != nil {
				return err
			}
			return renderAgentResult(deps.Stdout, *format, result)
		},
	}
	flags.bind(command.Flags())
	return command
}

func newAgentSaveCommand(deps Dependencies, format *corecli.OutputFormat, network *agentNetworkFlags) *cobra.Command {
	flags := &agentSaveFlags{}
	command := &cobra.Command{
		Use:   "save",
		Short: "保存接口配置（默认 dry-run）",
		Args:  cobra.NoArgs,
		RunE: func(command *cobra.Command, _ []string) error {
			dryRun, err := flags.mode.dryRunValue()
			if err != nil {
				return err
			}
			if err := flags.validate(); err != nil {
				return err
			}
			options, err := network.resolve(command)
			if err != nil {
				return err
			}
			request, err := flags.request(command, jsoninput.NewLoader(agentStdin(deps)), dryRun)
			if err != nil {
				return err
			}
			credentials, err := loadAgentCredentials(command.Context(), deps)
			if err != nil {
				return err
			}
			options.Credentials = credentials
			result, err := newAgentService(deps).Save(command.Context(), request, options)
			if err != nil {
				return err
			}
			return renderAgentResult(deps.Stdout, *format, result)
		},
	}
	flags.bind(command.Flags())
	return command
}

func newAgentDocCommand(deps Dependencies, format *corecli.OutputFormat, network *agentNetworkFlags) *cobra.Command {
	flags := &agentDocFlags{}
	command := &cobra.Command{
		Use:   "doc",
		Short: "保存接口文档（调用即落库，必须显式 --apply）",
		Args:  cobra.NoArgs,
		RunE: func(command *cobra.Command, _ []string) error {
			if !flags.apply {
				return errors.New("doc 会直接落库，必须显式传 --apply")
			}
			if err := flags.validate(); err != nil {
				return err
			}
			options, err := network.resolve(command)
			if err != nil {
				return err
			}
			request, err := flags.request(command, jsoninput.NewLoader(agentStdin(deps)))
			if err != nil {
				return err
			}
			credentials, err := loadAgentCredentials(command.Context(), deps)
			if err != nil {
				return err
			}
			options.Credentials = credentials
			result, err := newAgentService(deps).Doc(command.Context(), request, options)
			if err != nil {
				return err
			}
			return renderAgentResult(deps.Stdout, *format, result)
		},
	}
	flags.bind(command.Flags())
	return command
}

func newAgentAdvanceCommand(deps Dependencies, format *corecli.OutputFormat, network *agentNetworkFlags) *cobra.Command {
	flags := &agentAdvanceFlags{}
	command := &cobra.Command{
		Use:   "advance-step",
		Short: "预览或推进接口配置步骤（默认 dry-run）",
		Args:  cobra.NoArgs,
		RunE: func(command *cobra.Command, _ []string) error {
			dryRun, err := flags.mode.dryRunValue()
			if err != nil {
				return err
			}
			if err := flags.validate(); err != nil {
				return err
			}
			options, err := network.resolve(command)
			if err != nil {
				return err
			}
			request, err := flags.request(command, jsoninput.NewLoader(agentStdin(deps)), dryRun)
			if err != nil {
				return err
			}
			credentials, err := loadAgentCredentials(command.Context(), deps)
			if err != nil {
				return err
			}
			options.Credentials = credentials
			result, err := newAgentService(deps).AdvanceStep(command.Context(), request, options)
			if err != nil {
				return err
			}
			return renderAgentResult(deps.Stdout, *format, result)
		},
	}
	flags.bind(command.Flags())
	return command
}

func agentStdin(deps Dependencies) io.Reader {
	if deps.Stdin == nil {
		return strings.NewReader("")
	}
	return deps.Stdin
}

func loadAgentCredentials(ctx context.Context, deps Dependencies) (auth.Credentials, error) {
	if deps.Store == nil {
		return auth.Credentials{}, auth.ErrNotLoggedIn
	}
	credentials, err := deps.Store.Load(ctx)
	if err != nil {
		return auth.Credentials{}, err
	}
	now := time.Now
	if deps.Now != nil {
		now = deps.Now
	}
	if !credentials.ExpiresAt.After(now()) {
		return auth.Credentials{}, auth.ErrExpired
	}
	if strings.TrimSpace(credentials.BaseURL) != "" {
		baseURL, validateErr := urlpolicy.ValidateBaseURL(credentials.BaseURL)
		if validateErr != nil {
			return auth.Credentials{}, errors.New("凭据 base_url 无效，请重新登录")
		}
		sameOrigin, originErr := urlpolicy.SameOrigin(baseURL, djtBaseURL)
		if originErr != nil {
			return auth.Credentials{}, errors.New("校验点将台凭据 origin 失败")
		}
		if !sameOrigin {
			return auth.Credentials{}, errors.New("凭据 base_url 与固定点将台 origin 不一致，请重新登录")
		}
	}
	credentials.BaseURL = djtBaseURL
	return credentials, nil
}

func newAgentService(deps Dependencies) *djt.AgentService {
	transport := djt.NewTransport(deps.HTTPClient)
	return djt.NewAgentService(djt.NewAgentInterfaceClient(transport))
}

func renderAgentResult(writer io.Writer, format corecli.OutputFormat, result any) error {
	printer, err := output.New(writer, string(format))
	if err != nil {
		return err
	}
	return writeAgentResult(printer, format, result)
}

func writeAgentResult(printer *output.Printer, _ corecli.OutputFormat, result any) error {
	envelope, current, controls, list := agentResultParts(result)
	if printer.IsJSON() {
		return printer.JSON(agentJSONOutput{Code: envelope.Code, Message: envelope.Message, Data: envelope.Data})
	}
	if current != nil {
		if err := writeAgentCurrent(printer, current, controls); err != nil {
			return err
		}
		return nil
	}
	for _, item := range list {
		if err := writeAgentSummary(printer, item); err != nil {
			return err
		}
	}
	if len(list) == 0 && len(controls) != 0 {
		return printer.Text("%s\n", strings.Join(controls, " "))
	}
	return nil
}

func agentResultParts(result any) (djt.Envelope, *djt.AgentCurrent, []string, []djt.AgentInterfaceSummary) {
	switch value := result.(type) {
	case djt.AgentGetResult:
		return value.Envelope, value.Current, nil, value.List
	case djt.AgentInitResult:
		return value.Envelope, value.Current, nil, nil
	case djt.AgentSaveResult:
		return value.Envelope, value.Current, []string{
			"dryRun=" + formatBool(value.DryRun),
			"applied=" + formatBool(value.Applied),
		}, nil
	case djt.AgentDocResult:
		controls := make([]string, 0, 3)
		if value.Applied != nil {
			controls = append(controls, "applied="+formatBool(*value.Applied))
		}
		if value.AutoFilled != nil {
			controls = append(controls, "autoFilled="+formatBool(*value.AutoFilled))
		}
		if value.TempDocURL != nil {
			controls = append(controls, "tempDocUrl="+*value.TempDocURL)
		}
		return value.Envelope, value.Current, controls, nil
	case djt.AgentAdvanceResult:
		controls := []string{
			"dryRun=" + formatBool(value.DryRun),
			"applied=" + formatBool(value.Applied),
		}
		if value.AuditSubmitted != nil {
			controls = append(controls, "auditSubmitted="+formatBool(*value.AuditSubmitted))
		}
		return value.Envelope, value.Current, controls, nil
	default:
		return djt.Envelope{}, nil, nil, nil
	}
}

func writeAgentCurrent(printer *output.Printer, current *djt.AgentCurrent, controls []string) error {
	fields := []string{
		"interfaceId=" + formatInt64(current.InterfaceID),
		"modifyVersionId=" + formatInt64(current.ModifyVersionID),
	}
	if current.StatusV2 != nil {
		fields = append(fields, "statusV2="+formatInt32(*current.StatusV2))
	}
	if current.ConfigPhase != nil {
		fields = append(fields, "configPhase="+*current.ConfigPhase)
	}
	if current.NextStep != nil {
		fields = append(fields, "nextStep="+*current.NextStep)
	}
	fields = append(fields, controls...)
	return printer.Text("%s\n", strings.Join(fields, " "))
}

func writeAgentSummary(printer *output.Printer, summary djt.AgentInterfaceSummary) error {
	fields := []string{
		"interfaceId=" + formatInt64(summary.InterfaceID),
		"interfaceName=" + summary.InterfaceName,
	}
	if summary.StatusV2 != nil {
		fields = append(fields, "statusV2="+formatInt32(*summary.StatusV2))
	}
	return printer.Text("%s\n", strings.Join(fields, " "))
}

func formatBool(value bool) string {
	if value {
		return "true"
	}
	return "false"
}

func formatInt64(value int64) string {
	return strconv.FormatInt(value, 10)
}

func formatInt32(value int32) string {
	return strconv.FormatInt(int64(value), 10)
}
