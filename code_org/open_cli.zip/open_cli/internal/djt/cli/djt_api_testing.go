package cli

import (
	corecli "code.byted.org/temai/open_cli/internal/core/cli"
	"errors"
	"fmt"
	"strings"

	"code.byted.org/temai/open_cli/internal/core/jsonenc"
	"code.byted.org/temai/open_cli/internal/core/jsoninput"
	"code.byted.org/temai/open_cli/internal/core/output"
	"code.byted.org/temai/open_cli/internal/djt"
	"github.com/spf13/cobra"
)

type apiTestFlags struct {
	interfaceName string
	lane          string
	authID        string
	authType      string
	params        string
	confirmed     bool
}

func newAPITestCommand(deps Dependencies, format *corecli.OutputFormat, network *agentNetworkFlags) *cobra.Command {
	command := &cobra.Command{Use: "test", Short: "使用点将台内部测试应用调用 API"}
	for _, environment := range []string{"boe", "ppe", "prod"} {
		command.AddCommand(newAPITestEnvironmentCommand(deps, format, network, environment))
	}
	command.AddCommand(newAPITestAuthCommand(deps, format, network))
	return command
}

func newAPITestEnvironmentCommand(deps Dependencies, format *corecli.OutputFormat, network *agentNetworkFlags, environment string) *cobra.Command {
	flags := &apiTestFlags{}
	command := &cobra.Command{
		Use:   environment,
		Short: "在 " + strings.ToUpper(environment) + " 环境调用 API",
		Args:  cobra.NoArgs,
		RunE: func(command *cobra.Command, _ []string) error {
			if strings.TrimSpace(flags.interfaceName) == "" {
				return errors.New("--interface-name 不能为空")
			}
			if environment == "prod" && !flags.confirmed {
				return errors.New("PROD 调用可能产生真实业务数据，必须确认后传 --confirmed-by-user")
			}
			parameters, err := jsoninput.NewLoader(agentStdin(deps)).Object(flags.params, "--params")
			if err != nil {
				return err
			}
			options, err := network.resolve(command)
			if err != nil {
				return err
			}
			options.Credentials, err = loadAgentCredentials(command.Context(), deps)
			if err != nil {
				return err
			}
			request := djt.APITestRequest{InterfaceName: strings.TrimSpace(flags.interfaceName), Environment: strings.ToUpper(environment), Parameters: parameters}
			setTrimmedStringPointer(flags.lane, &request.Lane)
			setTrimmedStringPointer(flags.authID, &request.AuthID)
			setTrimmedStringPointer(flags.authType, &request.AuthType)
			result, err := djt.NewAPITestClient(djt.NewTransport(deps.HTTPClient)).Execute(command.Context(), request, options)
			if err != nil {
				return err
			}
			return renderAPITestResult(deps, *format, result.Envelope, result)
		},
	}
	command.Flags().StringVar(&flags.interfaceName, "interface-name", "", "接口路径，例如 /test/zzhTestDDD")
	command.Flags().StringVar(&flags.lane, "lane", "", "被测 API 泳道；PPE 场景按需传入")
	command.Flags().StringVar(&flags.authID, "auth-id", "", "授权主体 ID；需授权接口必须与 --auth-type 同传，免授权接口可省略")
	command.Flags().StringVar(&flags.authType, "auth-type", "", "授权类型；需授权接口必须与 --auth-id 同传，免授权接口可省略")
	command.Flags().StringVar(&flags.params, "params", "{}", "请求参数 JSON 对象：inline、@file 或 @-")
	command.Flags().BoolVar(&flags.confirmed, "confirmed-by-user", false, "确认允许调用 PROD API")
	return command
}

func newAPITestAuthCommand(deps Dependencies, format *corecli.OutputFormat, network *agentNetworkFlags) *cobra.Command {
	command := &cobra.Command{Use: "auth", Short: "管理内部测试应用的授权主体"}
	var environment, authID string
	var authSubjectBizID int64
	add := &cobra.Command{
		Use: "add", Short: "添加或刷新授权主体", Args: cobra.NoArgs,
		RunE: func(command *cobra.Command, _ []string) error {
			env, err := normalizeCLIAPITestEnv(environment)
			if err != nil {
				return err
			}
			if strings.TrimSpace(authID) == "" {
				return errors.New("--auth-id 不能为空")
			}
			if authSubjectBizID < 0 {
				return errors.New("--auth-subject-biz-id 不能小于 0")
			}
			options, err := network.resolve(command)
			if err != nil {
				return err
			}
			options.Credentials, err = loadAgentCredentials(command.Context(), deps)
			if err != nil {
				return err
			}
			result, err := djt.NewAPITestClient(djt.NewTransport(deps.HTTPClient)).AddAuth(command.Context(), djt.APITestAuthRequest{AuthID: strings.TrimSpace(authID), AuthSubjectBizID: authSubjectBizID, Environment: env}, options)
			if err != nil {
				return err
			}
			return renderAPITestResult(deps, *format, result.Envelope, result)
		},
	}
	add.Flags().StringVar(&environment, "env", "", "授权环境：boe、ppe 或 prod")
	add.Flags().StringVar(&authID, "auth-id", "", "授权主体 ID")
	add.Flags().Int64Var(&authSubjectBizID, "auth-subject-biz-id", 0, "授权主体类型；店铺为 0")
	command.AddCommand(add)
	return command
}

func normalizeCLIAPITestEnv(value string) (string, error) {
	normalized := strings.ToUpper(strings.TrimSpace(value))
	switch normalized {
	case "BOE", "PPE", "PROD":
		return normalized, nil
	}
	return "", fmt.Errorf("--env 只接受 boe、ppe 或 prod，收到 %q", value)
}

func setTrimmedStringPointer(value string, target **string) {
	if trimmed := strings.TrimSpace(value); trimmed != "" {
		*target = &trimmed
	}
}

func renderAPITestResult(deps Dependencies, format corecli.OutputFormat, envelope djt.Envelope, result any) error {
	printer, err := output.New(deps.Stdout, string(format))
	if err != nil {
		return err
	}
	if printer.IsJSON() {
		return printer.JSON(agentJSONOutput{Code: envelope.Code, Message: envelope.Message, Data: envelope.Data})
	}
	payload, err := jsonenc.Marshal(result)
	if err != nil {
		return err
	}
	return printer.Text("%s\n", payload)
}
