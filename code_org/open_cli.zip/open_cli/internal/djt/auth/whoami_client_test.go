package auth

import (
	"context"
	"errors"
	"io"
	"net/http"
	"net/http/httptest"
	"reflect"
	"strings"
	"testing"

	"code.byted.org/temai/open_cli/internal/core/ppe"
)

func TestGetLoginUserUsesRealEnvelopeAndCLIHeader(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet || r.URL.Path != "/api/user/getLoginUser" {
			t.Errorf("request=%s %s", r.Method, r.URL.Path)
		}
		if got := r.Header.Get("X-DJT-CLI-Authorization"); got != "Bearer secret" {
			t.Errorf("authorization=%q", got)
		}
		if got := r.Header.Get("Accept"); got != "application/json" {
			t.Errorf("Accept=%q", got)
		}
		if got := r.Header.Get(ppe.UsePPEHeader); got != "" {
			t.Errorf("production x-use-ppe=%q", got)
		}
		if got := r.Header.Get(ppe.EnvironmentHeader); got != "" {
			t.Errorf("production x-tt-env=%q", got)
		}
		io.WriteString(w, `{"code":0,"message":"success","data":{"employee":{"employeeId":"123","employeeName":"吴昊天","email":"u@example.com","headUrl":"avatar"},"userType":1,"authorityList":["interface.read"]}}`)
	}))
	defer srv.Close()

	got, err := NewDeviceClient(srv.Client()).GetLoginUser(context.Background(), srv.URL, "Bearer", "secret")
	if err != nil {
		t.Fatal(err)
	}
	want := User{EmployeeID: "123", EmployeeName: "吴昊天", Email: "u@example.com", HeadURL: "avatar", UserType: 1, AuthorityList: []string{"interface.read"}}
	if !reflect.DeepEqual(got, want) {
		t.Fatalf("got=%+v want=%+v", got, want)
	}
}

func TestGetLoginUserWithPPEUsesLoginLaneHeaders(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if got := r.Header.Get(ppe.UsePPEHeader); got != "1" {
			t.Errorf("x-use-ppe=%q", got)
		}
		if got := r.Header.Get(ppe.EnvironmentHeader); got != "ppe_djt_cli" {
			t.Errorf("x-tt-env=%q", got)
		}
		if got := r.Header.Get("X-DJT-CLI-Authorization"); got != "Bearer token-secret" {
			t.Errorf("authorization=%q", got)
		}
		io.WriteString(w, `{"code":0,"message":"success","data":{"employee":{"employeeId":"123"},"userType":1,"authorityList":[]}}`)
	}))
	defer srv.Close()

	user, err := NewDeviceClient(srv.Client()).GetLoginUserWithPPE(
		context.Background(), srv.URL, "Bearer", "token-secret", ppe.Config{Enabled: true, Env: "ppe_djt_cli"},
	)
	if err != nil {
		t.Fatal(err)
	}
	if user.EmployeeID != "123" {
		t.Fatalf("user=%+v", user)
	}
}

func TestGetLoginUserBusinessErrorDoesNotLeakToken(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		io.WriteString(w, `{"code":403,"message":"无权限","data":{"accessToken":"token-secret"}}`)
	}))
	defer srv.Close()
	_, err := NewDeviceClient(srv.Client()).GetLoginUser(context.Background(), srv.URL, "Bearer", "token-secret")
	if err == nil || !strings.Contains(err.Error(), "无权限") {
		t.Fatalf("err=%v", err)
	}
	assertNoSecrets(t, err, "token-secret")
}

func TestGetLoginUserDoesNotLeakTokenFromBusinessMessage(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		io.WriteString(w, `{"code":403,"message":"token-secret","data":{}}`)
	}))
	defer srv.Close()
	_, err := NewDeviceClient(srv.Client()).GetLoginUser(context.Background(), srv.URL, "Bearer", "token-secret")
	if err == nil {
		t.Fatal("expected error")
	}
	assertNoSecrets(t, err, "token-secret")
}

func TestGetLoginUserRejectsBodyOverOneMiB(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		io.WriteString(w, strings.Repeat("x", (1<<20)+1))
	}))
	defer srv.Close()
	_, err := NewDeviceClient(srv.Client()).GetLoginUser(context.Background(), srv.URL, "Bearer", "token-secret")
	if err == nil || !strings.Contains(err.Error(), "超过 1 MiB") {
		t.Fatalf("err=%v", err)
	}
	assertNoSecrets(t, err, "token-secret")
}

func TestGetLoginUserHTTPErrorDoesNotReadSensitiveBodyIntoError(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		w.WriteHeader(http.StatusUnauthorized)
		io.WriteString(w, `{"access_token":"token-secret"}`)
	}))
	defer srv.Close()
	_, err := NewDeviceClient(srv.Client()).GetLoginUser(context.Background(), srv.URL, "Bearer", "token-secret")
	if err == nil || !strings.Contains(err.Error(), "HTTP 401") {
		t.Fatalf("err=%v", err)
	}
	assertNoSecrets(t, err, "token-secret")
}

func TestGetLoginUserSanitizesRemoteMessageAndToken(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		_, _ = io.WriteString(w, `{"code":403,"message":"denied token-\u001b[31m\u0000secret\nnext","data":{}}`)
	}))
	defer srv.Close()
	_, err := NewDeviceClient(srv.Client()).GetLoginUser(context.Background(), srv.URL, "Bearer", "token-secret")
	if err == nil || strings.Contains(err.Error(), "token-secret") || containsControlCharacter(err.Error()) {
		t.Fatalf("unsafe err=%q", err)
	}
}

func containsControlCharacter(value string) bool {
	for _, r := range value {
		if r < 0x20 || r == 0x7f {
			return true
		}
	}
	return false
}

func TestGetLoginUserReturnsContextErrorFromDoer(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	doer := HTTPDoerFunc(func(req *http.Request) (*http.Response, error) {
		cancel()
		<-req.Context().Done()
		return nil, errors.New("transport error")
	})
	_, err := NewDeviceClient(doer).GetLoginUser(ctx, "https://example.com", "Bearer", "secret")
	if !errors.Is(err, context.Canceled) {
		t.Fatalf("err=%v", err)
	}
}

func TestGetLoginUserRequiresEmployeeID(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		io.WriteString(w, `{"code":0,"message":"success","data":{"employee":{"employeeId":""},"userType":1,"authorityList":[]}}`)
	}))
	defer srv.Close()
	_, err := NewDeviceClient(srv.Client()).GetLoginUser(context.Background(), srv.URL, "Bearer", "secret")
	if err == nil || !strings.Contains(err.Error(), "employeeId") {
		t.Fatalf("err=%v", err)
	}
}
