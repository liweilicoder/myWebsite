package auth

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"

	"code.byted.org/temai/open_cli/internal/core/identity"
	"code.byted.org/temai/open_cli/internal/core/ppe"
	"code.byted.org/temai/open_cli/internal/core/sanitize"
)

type loginUserEnvelope struct {
	Code    int64  `json:"code"`
	Message string `json:"message"`
	Data    struct {
		Employee struct {
			EmployeeID   string `json:"employeeId"`
			EmployeeName string `json:"employeeName"`
			Email        string `json:"email"`
			HeadURL      string `json:"headUrl"`
		} `json:"employee"`
		UserType      int64    `json:"userType"`
		AuthorityList []string `json:"authorityList"`
	} `json:"data"`
}

func (c *DeviceClient) GetLoginUser(ctx context.Context, baseURL, tokenType, accessToken string) (User, error) {
	return c.GetLoginUserWithPPE(ctx, baseURL, tokenType, accessToken, ppe.Config{})
}

func (c *DeviceClient) GetLoginUserWithPPE(ctx context.Context, baseURL, tokenType, accessToken string, ppeConfig ppe.Config) (User, error) {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, endpoint(baseURL, "/api/user/getLoginUser"), nil)
	if err != nil {
		return User{}, errors.New("创建用户查询请求失败")
	}
	req.Header.Set("Accept", "application/json")
	req.Header.Set(cliAuthorizationHeader, tokenType+" "+accessToken)
	identity.Apply(req.Header)
	if err := ppeConfig.Apply(req.Header); err != nil {
		return User{}, err
	}
	resp, err := c.http.Do(req)
	if err != nil {
		if ctxErr := ctx.Err(); ctxErr != nil {
			return User{}, ctxErr
		}
		return User{}, errors.New("用户查询请求失败")
	}
	defer resp.Body.Close()
	data, err := readLimited(resp.Body, maxDeviceResponseBody)
	if err != nil {
		return User{}, fmt.Errorf("用户查询响应无效: %w", err)
	}
	if resp.StatusCode < http.StatusOK || resp.StatusCode >= http.StatusMultipleChoices {
		return User{}, fmt.Errorf("用户查询返回 HTTP %d", resp.StatusCode)
	}
	var body loginUserEnvelope
	if err := json.Unmarshal(data, &body); err != nil {
		return User{}, errors.New("解析用户查询响应失败")
	}
	if body.Code != 0 {
		message := sanitize.RemoteMessage(body.Message, accessToken)
		if message == "" {
			return User{}, errors.New("用户查询失败")
		}
		return User{}, fmt.Errorf("用户查询失败: %s", message)
	}
	if body.Data.Employee.EmployeeID == "" {
		return User{}, errors.New("用户查询响应缺少 employeeId")
	}
	return User{
		EmployeeID:    body.Data.Employee.EmployeeID,
		EmployeeName:  body.Data.Employee.EmployeeName,
		Email:         body.Data.Employee.Email,
		HeadURL:       body.Data.Employee.HeadURL,
		UserType:      body.Data.UserType,
		AuthorityList: body.Data.AuthorityList,
	}, nil
}
