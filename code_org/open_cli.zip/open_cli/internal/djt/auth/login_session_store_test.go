package auth

import (
	"context"
	"errors"
	"os"
	"path/filepath"
	"reflect"
	"runtime"
	"testing"
	"time"

	"code.byted.org/temai/open_cli/internal/core/ppe"
)

func TestLoginSessionFileStoreRoundTripAndDelete(t *testing.T) {
	dir := filepath.Join(t.TempDir(), "opencli")
	store := NewLoginSessionFileStore(dir)
	want := LoginSession{
		BaseURL: "https://djt.bytedance.net", DeviceCode: "device-secret", CodeVerifier: "verifier-secret",
		UserCode: "ABCD", VerificationURL: "https://verify", ExpiresAt: time.Now().Add(time.Minute).UTC(), Interval: 2,
		PPE: ppe.Config{Enabled: true, Env: "ppe_djt_cli"},
	}
	if err := store.Save(context.Background(), want); err != nil {
		t.Fatal(err)
	}
	if runtime.GOOS != "windows" {
		info, err := os.Stat(filepath.Join(dir, "login-session.json"))
		if err != nil {
			t.Fatal(err)
		}
		if info.Mode().Perm() != 0o600 {
			t.Fatalf("权限=%o，期望 600", info.Mode().Perm())
		}
	}
	got, err := store.Load(context.Background())
	if err != nil {
		t.Fatal(err)
	}
	if !reflect.DeepEqual(got, want) {
		t.Fatalf("got=%+v want=%+v", got, want)
	}
	if err := store.Delete(context.Background()); err != nil {
		t.Fatal(err)
	}
	if _, err := store.Load(context.Background()); !errors.Is(err, ErrNoLoginSession) {
		t.Fatalf("error=%v", err)
	}
}

func TestLoginSessionFileStoreRejectsInvalidSession(t *testing.T) {
	store := NewLoginSessionFileStore(t.TempDir())
	for _, session := range []LoginSession{
		{DeviceCode: "d", CodeVerifier: "v", VerificationURL: "https://verify", ExpiresAt: time.Now().Add(time.Minute), Interval: 1},
		{BaseURL: "https://djt.bytedance.net", DeviceCode: "", CodeVerifier: "v", VerificationURL: "https://verify", ExpiresAt: time.Now().Add(time.Minute), Interval: 1},
		{BaseURL: "https://djt.bytedance.net", DeviceCode: "d", CodeVerifier: "", VerificationURL: "https://verify", ExpiresAt: time.Now().Add(time.Minute), Interval: 1},
	} {
		if err := store.Save(context.Background(), session); err == nil {
			t.Fatalf("未拒绝非法会话: %+v", session)
		}
	}
}
