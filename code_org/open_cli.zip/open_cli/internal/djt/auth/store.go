package auth

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"runtime"
	"strings"
)

type FileStore struct {
	dir  string
	path string
}

func NewFileStore(configDir string) *FileStore {
	return &FileStore{
		dir:  configDir,
		path: filepath.Join(configDir, "credentials.json"),
	}
}

func (s *FileStore) Load(ctx context.Context) (Credentials, error) {
	if err := ctx.Err(); err != nil {
		return Credentials{}, err
	}

	f, err := os.Open(s.path)
	if err != nil {
		if errors.Is(err, os.ErrNotExist) {
			return Credentials{}, ErrNotLoggedIn
		}
		return Credentials{}, fmt.Errorf("打开凭据文件: %w", err)
	}
	defer f.Close()

	if runtime.GOOS != "windows" {
		info, err := f.Stat()
		if err != nil {
			return Credentials{}, fmt.Errorf("检查凭据文件权限: %w", err)
		}
		if info.Mode().Perm() != 0o600 {
			return Credentials{}, errors.New("凭据文件权限不安全，应为 0600")
		}
	}

	var c Credentials
	dec := json.NewDecoder(f)
	dec.DisallowUnknownFields()
	if err := dec.Decode(&c); err != nil {
		return Credentials{}, errors.New("解析凭据文件失败：格式错误或包含未知字段")
	}
	if err := ensureJSONEOF(dec); err != nil {
		return Credentials{}, err
	}
	if err := ctx.Err(); err != nil {
		return Credentials{}, err
	}
	if err := validateCredentials(c); err != nil {
		return Credentials{}, err
	}

	return c, nil
}

func ensureJSONEOF(dec *json.Decoder) error {
	var trailing any
	if err := dec.Decode(&trailing); !errors.Is(err, io.EOF) {
		return errors.New("解析凭据文件失败：仅允许单个 JSON 对象")
	}
	return nil
}

func (s *FileStore) Save(ctx context.Context, c Credentials) (err error) {
	if err := ctx.Err(); err != nil {
		return err
	}
	if err := validateCredentials(c); err != nil {
		return err
	}

	if err := os.MkdirAll(s.dir, 0o700); err != nil {
		return fmt.Errorf("创建配置目录: %w", err)
	}
	if runtime.GOOS != "windows" {
		if err := os.Chmod(s.dir, 0o700); err != nil {
			return fmt.Errorf("设置配置目录权限: %w", err)
		}
	}

	f, err := os.CreateTemp(s.dir, ".credentials-*")
	if err != nil {
		return fmt.Errorf("创建临时文件: %w", err)
	}
	tmpName := f.Name()
	defer func() {
		if err != nil {
			_ = f.Close()
			_ = os.Remove(tmpName)
		}
	}()

	if err = f.Chmod(0o600); err != nil {
		return fmt.Errorf("设置临时文件权限: %w", err)
	}

	if err = json.NewEncoder(f).Encode(c); err != nil {
		return errors.New("编码凭据失败")
	}

	if err = f.Sync(); err != nil {
		return fmt.Errorf("同步文件失败: %w", err)
	}

	if err = f.Close(); err != nil {
		return fmt.Errorf("关闭临时文件: %w", err)
	}
	if runtime.GOOS != "windows" {
		info, statErr := os.Stat(tmpName)
		if statErr != nil {
			return fmt.Errorf("检查临时文件权限: %w", statErr)
		}
		if info.Mode().Perm() != 0o600 {
			return errors.New("临时凭据文件权限不安全，应为 0600")
		}
	}
	if err = ctx.Err(); err != nil {
		return err
	}

	if err = os.Rename(tmpName, s.path); err != nil {
		return fmt.Errorf("原子替换凭据文件失败: %w", err)
	}

	return nil
}

func (s *FileStore) Delete(ctx context.Context) error {
	if err := ctx.Err(); err != nil {
		return err
	}
	err := os.Remove(s.path)
	if err != nil && !errors.Is(err, os.ErrNotExist) {
		return fmt.Errorf("删除凭据文件: %w", err)
	}
	return nil
}

func validateCredentials(c Credentials) error {
	if strings.TrimSpace(c.AccessToken) == "" {
		return errors.New("凭据缺少必填字段: access_token")
	}
	if strings.TrimSpace(c.TokenType) == "" {
		return errors.New("凭据缺少必填字段: token_type")
	}
	if strings.TrimSpace(c.User.EmployeeID) == "" {
		return errors.New("凭据缺少必填字段: user.employee_id")
	}
	return nil
}
