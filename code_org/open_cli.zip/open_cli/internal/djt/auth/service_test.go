package auth

import (
	"context"
	"errors"
	"reflect"
	"testing"
	"time"

	"code.byted.org/temai/open_cli/internal/core/ppe"
)

type tokenResult struct {
	token DeviceToken
	err   error
}

type fakeDeviceAPI struct {
	start       DeviceStart
	startErr    error
	tokens      []tokenResult
	tokenCalls  int
	deviceCodes []string
	verifiers   []string
	onToken     func()
}

func (f *fakeDeviceAPI) StartWithPPE(context.Context, string, ppe.Config) (DeviceStart, error) {
	return f.start, f.startErr
}

func (f *fakeDeviceAPI) TokenWithPPE(_ context.Context, _ string, deviceCode, verifier string, _ ppe.Config) (DeviceToken, error) {
	if f.onToken != nil {
		f.onToken()
	}
	f.deviceCodes = append(f.deviceCodes, deviceCode)
	f.verifiers = append(f.verifiers, verifier)
	result := f.tokens[f.tokenCalls]
	f.tokenCalls++
	return result.token, result.err
}

type fakeWhoAmI struct {
	user      User
	err       error
	calls     int
	baseURL   string
	tokenType string
	token     string
	ppeConfig ppe.Config
}

func (f *fakeWhoAmI) GetLoginUserWithPPE(_ context.Context, baseURL, tokenType, token string, ppeConfig ppe.Config) (User, error) {
	f.calls++
	f.baseURL = baseURL
	f.tokenType = tokenType
	f.token = token
	f.ppeConfig = ppeConfig
	return f.user, f.err
}

type fakeStore struct {
	loaded    Credentials
	loadErr   error
	saved     Credentials
	saveErr   error
	deleteErr error
	loadCalls int
	saveCalls int
	deletes   int
}

func (f *fakeStore) Load(context.Context) (Credentials, error) {
	f.loadCalls++
	return f.loaded, f.loadErr
}

func (f *fakeStore) Save(_ context.Context, credentials Credentials) error {
	f.saveCalls++
	f.saved = credentials
	return f.saveErr
}

func (f *fakeStore) Delete(context.Context) error {
	f.deletes++
	return f.deleteErr
}

type fakeBrowser struct {
	err    error
	urls   []string
	onOpen func()
}

func (f *fakeBrowser) Open(url string) error {
	f.urls = append(f.urls, url)
	if f.onOpen != nil {
		f.onOpen()
	}
	return f.err
}

func TestLoginPollsFetchesUserThenSavesUsingReceiptTime(t *testing.T) {
	api := &fakeDeviceAPI{
		start: DeviceStart{DeviceCode: "device-secret", CodeVerifier: "verifier-secret", UserCode: "ABCD", VerificationURI: "https://verify", VerificationURIComplete: "https://verify?code=ABCD", ExpiresIn: 60, Interval: 2},
		tokens: []tokenResult{
			{err: &DeviceProtocolError{Code: "authorization_pending"}},
			{err: &DeviceProtocolError{Code: "slow_down"}},
			{token: DeviceToken{AccessToken: "token-secret", TokenType: "Bearer", ExpiresIn: 3600}},
		},
	}
	who := &fakeWhoAmI{user: User{EmployeeID: "123", EmployeeName: "吴昊天", Email: "u@example.com", AuthorityList: []string{"interface.read"}}}
	store := &fakeStore{}
	browser := &fakeBrowser{err: errors.New("no browser")}
	var waits []time.Duration
	receipt := time.Date(2026, 8, 6, 11, 0, 0, 0, time.UTC)
	svc := NewService(api, who, store, browser, func(_ context.Context, duration time.Duration) error {
		waits = append(waits, duration)
		return nil
	}, func() time.Time { return receipt })

	ppeConfig := ppe.Config{Enabled: true, Env: "ppe_djt_cli"}
	result, err := svc.Login(context.Background(), "https://admin.example.com", ppeConfig, func(prompt LoginPrompt) error {
		if prompt.VerificationURL != "https://verify?code=ABCD" || prompt.UserCode != "ABCD" || prompt.BrowserError == nil {
			t.Fatalf("prompt=%+v", prompt)
		}
		return nil
	})
	if err != nil {
		t.Fatal(err)
	}
	if result.BrowserError == nil || result.OpenURL != "https://verify?code=ABCD" {
		t.Fatalf("result=%+v", result)
	}
	if !reflect.DeepEqual(browser.urls, []string{"https://verify?code=ABCD"}) {
		t.Fatalf("browser urls=%v", browser.urls)
	}
	if !reflect.DeepEqual(waits, []time.Duration{2 * time.Second, 2 * time.Second, 7 * time.Second}) {
		t.Fatalf("waits=%v", waits)
	}
	if who.calls != 1 || who.baseURL != "https://admin.example.com" || who.tokenType != "Bearer" || who.token != "token-secret" || who.ppeConfig != ppeConfig {
		t.Fatalf("who=%+v", who)
	}
	if store.saveCalls != 1 || store.saved.User.EmployeeID != "123" || !store.saved.ExpiresAt.Equal(receipt.Add(time.Hour)) {
		t.Fatalf("saved=%+v calls=%d", store.saved, store.saveCalls)
	}
	if store.saved.BaseURL != "https://admin.example.com" || store.saved.AccessToken != "token-secret" || store.saved.TokenType != "Bearer" {
		t.Fatalf("saved credentials=%+v", store.saved)
	}
	if !reflect.DeepEqual(api.deviceCodes, []string{"device-secret", "device-secret", "device-secret"}) || !reflect.DeepEqual(api.verifiers, []string{"verifier-secret", "verifier-secret", "verifier-secret"}) {
		t.Fatalf("device codes=%v verifiers=%v", api.deviceCodes, api.verifiers)
	}
}

func TestLoginFallsBackToVerificationURI(t *testing.T) {
	api := &fakeDeviceAPI{
		start:  DeviceStart{DeviceCode: "d", CodeVerifier: "v", UserCode: "U", VerificationURI: "https://verify", ExpiresIn: 60, Interval: 1},
		tokens: []tokenResult{{token: DeviceToken{AccessToken: "secret", TokenType: "Bearer", ExpiresIn: 10}}},
	}
	browser := &fakeBrowser{}
	result, err := NewService(api, &fakeWhoAmI{user: User{EmployeeID: "123"}}, &fakeStore{}, browser, noWait, fixedNow).Login(context.Background(), "https://admin.example.com", ppe.Config{}, nil)
	if err != nil {
		t.Fatal(err)
	}
	if result.OpenURL != "https://verify" || !reflect.DeepEqual(browser.urls, []string{"https://verify"}) {
		t.Fatalf("result=%+v urls=%v", result, browser.urls)
	}
}

func TestLoginTerminalProtocolErrorsDoNotSave(t *testing.T) {
	for _, code := range []string{"access_denied", "expired_token", "invalid_grant"} {
		t.Run(code, func(t *testing.T) {
			api := &fakeDeviceAPI{
				start:  DeviceStart{DeviceCode: "d", CodeVerifier: "v", UserCode: "U", VerificationURI: "https://verify", ExpiresIn: 60, Interval: 1},
				tokens: []tokenResult{{err: &DeviceProtocolError{Code: code}}},
			}
			store := &fakeStore{}
			_, err := NewService(api, &fakeWhoAmI{}, store, &fakeBrowser{}, noWait, fixedNow).Login(context.Background(), "https://admin.example.com", ppe.Config{}, nil)
			var protocolErr *DeviceProtocolError
			if !errors.As(err, &protocolErr) || protocolErr.Code != code || store.saveCalls != 0 {
				t.Fatalf("err=%v saveCalls=%d", err, store.saveCalls)
			}
		})
	}
}

func TestLoginDoesNotSaveWhenRemoteUserOrSaveFails(t *testing.T) {
	for _, tt := range []struct {
		name    string
		whoErr  error
		saveErr error
	}{
		{name: "remote user", whoErr: errors.New("用户查询失败")},
		{name: "save", saveErr: errors.New("保存失败")},
	} {
		t.Run(tt.name, func(t *testing.T) {
			api := &fakeDeviceAPI{
				start:  DeviceStart{DeviceCode: "d", CodeVerifier: "v", UserCode: "U", VerificationURI: "https://verify", ExpiresIn: 60, Interval: 1},
				tokens: []tokenResult{{token: DeviceToken{AccessToken: "secret", TokenType: "Bearer", ExpiresIn: 10}}},
			}
			store := &fakeStore{saveErr: tt.saveErr}
			_, err := NewService(api, &fakeWhoAmI{user: User{EmployeeID: "123"}, err: tt.whoErr}, store, &fakeBrowser{}, noWait, fixedNow).Login(context.Background(), "https://admin.example.com", ppe.Config{}, nil)
			if err == nil {
				t.Fatal("expected error")
			}
			wantSaveCalls := 1
			if tt.whoErr != nil {
				wantSaveCalls = 0
			}
			if store.saveCalls != wantSaveCalls {
				t.Fatalf("saveCalls=%d want=%d", store.saveCalls, wantSaveCalls)
			}
		})
	}
}

func TestLoginHonorsContextCancellation(t *testing.T) {
	api := &fakeDeviceAPI{start: DeviceStart{DeviceCode: "d", CodeVerifier: "v", UserCode: "U", VerificationURI: "https://verify", ExpiresIn: 60, Interval: 1}}
	_, err := NewService(api, &fakeWhoAmI{}, &fakeStore{}, &fakeBrowser{}, func(context.Context, time.Duration) error {
		return context.Canceled
	}, fixedNow).Login(context.Background(), "https://admin.example.com", ppe.Config{}, nil)
	if !errors.Is(err, context.Canceled) || api.tokenCalls != 0 {
		t.Fatalf("err=%v tokenCalls=%d", err, api.tokenCalls)
	}
}

func TestLoginChecksContextAgainAfterWait(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	api := &fakeDeviceAPI{start: DeviceStart{DeviceCode: "d", CodeVerifier: "v", UserCode: "U", VerificationURI: "https://verify", ExpiresIn: 60, Interval: 1}}
	_, err := NewService(api, &fakeWhoAmI{}, &fakeStore{}, &fakeBrowser{}, func(context.Context, time.Duration) error {
		cancel()
		return nil
	}, fixedNow).Login(ctx, "https://admin.example.com", ppe.Config{}, nil)
	if !errors.Is(err, context.Canceled) || api.tokenCalls != 0 {
		t.Fatalf("err=%v tokenCalls=%d", err, api.tokenCalls)
	}
}

func TestLoginStopsAtDeviceDeadline(t *testing.T) {
	now := time.Date(2026, 8, 6, 11, 0, 0, 0, time.UTC)
	api := &fakeDeviceAPI{
		start: DeviceStart{DeviceCode: "d", CodeVerifier: "v", UserCode: "U", VerificationURI: "https://verify", ExpiresIn: 2, Interval: 1},
		tokens: []tokenResult{
			{err: &DeviceProtocolError{Code: "authorization_pending"}},
			{err: &DeviceProtocolError{Code: "authorization_pending"}},
		},
	}
	_, err := NewService(api, &fakeWhoAmI{}, &fakeStore{}, &fakeBrowser{}, func(context.Context, time.Duration) error {
		now = now.Add(time.Second)
		return nil
	}, func() time.Time { return now }).Login(context.Background(), "https://admin.example.com", ppe.Config{}, nil)
	if !errors.Is(err, ErrExpired) || api.tokenCalls != 1 {
		t.Fatalf("err=%v tokenCalls=%d", err, api.tokenCalls)
	}
}

func TestLoginPromptsAfterBrowserBeforeFirstWaitAndToken(t *testing.T) {
	var events []string
	api := &fakeDeviceAPI{
		start:   DeviceStart{DeviceCode: "d", CodeVerifier: "v", UserCode: "U", VerificationURI: "https://verify", ExpiresIn: 60, Interval: 1},
		tokens:  []tokenResult{{token: DeviceToken{AccessToken: "secret", TokenType: "Bearer", ExpiresIn: 10}}},
		onToken: func() { events = append(events, "token") },
	}
	browser := &fakeBrowser{onOpen: func() { events = append(events, "browser") }}
	wait := func(context.Context, time.Duration) error {
		events = append(events, "wait")
		return nil
	}

	_, err := NewService(api, &fakeWhoAmI{user: User{EmployeeID: "123"}}, &fakeStore{}, browser, wait, fixedNow).Login(
		context.Background(), "https://admin.example.com", ppe.Config{}, func(prompt LoginPrompt) error {
			events = append(events, "prompt")
			if prompt.VerificationURL != "https://verify" || prompt.UserCode != "U" || prompt.BrowserError != nil {
				t.Fatalf("prompt=%+v", prompt)
			}
			return nil
		},
	)
	if err != nil {
		t.Fatal(err)
	}
	if !reflect.DeepEqual(events, []string{"browser", "prompt", "wait", "token"}) {
		t.Fatalf("events=%v", events)
	}
}

func TestLoginPromptFailureStopsBeforeWaitAndToken(t *testing.T) {
	promptErr := errors.New("提示写入失败")
	api := &fakeDeviceAPI{start: DeviceStart{DeviceCode: "d", CodeVerifier: "v", UserCode: "U", VerificationURI: "https://verify", ExpiresIn: 60, Interval: 1}}
	waitCalls := 0
	_, err := NewService(api, &fakeWhoAmI{}, &fakeStore{}, &fakeBrowser{}, func(context.Context, time.Duration) error {
		waitCalls++
		return nil
	}, fixedNow).Login(context.Background(), "https://admin.example.com", ppe.Config{}, func(LoginPrompt) error { return promptErr })
	if !errors.Is(err, promptErr) || waitCalls != 0 || api.tokenCalls != 0 {
		t.Fatalf("err=%v waitCalls=%d tokenCalls=%d", err, waitCalls, api.tokenCalls)
	}
}

func TestLoginDeadlineIncludesBrowserTime(t *testing.T) {
	now := fixedNow()
	api := &fakeDeviceAPI{start: DeviceStart{DeviceCode: "d", CodeVerifier: "v", UserCode: "U", VerificationURI: "https://verify", ExpiresIn: 2, Interval: 1}}
	browser := &fakeBrowser{onOpen: func() { now = now.Add(2 * time.Second) }}
	waitCalls := 0
	_, err := NewService(api, &fakeWhoAmI{}, &fakeStore{}, browser, func(context.Context, time.Duration) error {
		waitCalls++
		return nil
	}, func() time.Time { return now }).Login(context.Background(), "https://admin.example.com", ppe.Config{}, func(LoginPrompt) error { return nil })
	if !errors.Is(err, ErrExpired) || waitCalls != 0 || api.tokenCalls != 0 {
		t.Fatalf("err=%v waitCalls=%d tokenCalls=%d", err, waitCalls, api.tokenCalls)
	}
}

func TestLoginLogicalBudgetTerminatesWithFixedClockAndImmediateWait(t *testing.T) {
	api := &fakeDeviceAPI{
		start: DeviceStart{DeviceCode: "d", CodeVerifier: "v", UserCode: "U", VerificationURI: "https://verify", ExpiresIn: 3, Interval: 1},
		tokens: []tokenResult{
			{err: &DeviceProtocolError{Code: "authorization_pending"}},
			{err: &DeviceProtocolError{Code: "authorization_pending"}},
		},
	}
	var waits []time.Duration
	_, err := NewService(api, &fakeWhoAmI{}, &fakeStore{}, &fakeBrowser{}, func(_ context.Context, duration time.Duration) error {
		waits = append(waits, duration)
		return nil
	}, fixedNow).Login(context.Background(), "https://admin.example.com", ppe.Config{}, func(LoginPrompt) error { return nil })
	if !errors.Is(err, ErrExpired) || api.tokenCalls != 2 || !reflect.DeepEqual(waits, []time.Duration{time.Second, time.Second, time.Second}) {
		t.Fatalf("err=%v tokenCalls=%d waits=%v", err, api.tokenCalls, waits)
	}
}

func TestLoginClampsWaitToRemainingBudgetAndDoesNotTokenAtExpiry(t *testing.T) {
	api := &fakeDeviceAPI{start: DeviceStart{DeviceCode: "d", CodeVerifier: "v", UserCode: "U", VerificationURI: "https://verify", ExpiresIn: 2, Interval: 5}}
	var waits []time.Duration
	_, err := NewService(api, &fakeWhoAmI{}, &fakeStore{}, &fakeBrowser{}, func(_ context.Context, duration time.Duration) error {
		waits = append(waits, duration)
		return nil
	}, fixedNow).Login(context.Background(), "https://admin.example.com", ppe.Config{}, func(LoginPrompt) error { return nil })
	if !errors.Is(err, ErrExpired) || api.tokenCalls != 0 || !reflect.DeepEqual(waits, []time.Duration{2 * time.Second}) {
		t.Fatalf("err=%v tokenCalls=%d waits=%v", err, api.tokenCalls, waits)
	}
}

func TestLoginRejectsUnsafeDurationBoundsBeforeMultiplication(t *testing.T) {
	starts := []DeviceStart{
		{DeviceCode: "d", UserCode: "u", VerificationURI: "https://verify.example.com", ExpiresIn: 3601, Interval: 5},
		{DeviceCode: "d", UserCode: "u", VerificationURI: "https://verify.example.com", ExpiresIn: 60, Interval: 301},
	}
	for _, start := range starts {
		api := &fakeDeviceAPI{start: start}
		if _, err := NewService(api, &fakeWhoAmI{}, &fakeStore{}, &fakeBrowser{}, noWait, fixedNow).Login(context.Background(), "https://admin.example.com", ppe.Config{}, nil); err == nil {
			t.Fatalf("start=%+v should fail", start)
		}
	}
}

func TestStatusWhoAmIAndLogoutStayLocal(t *testing.T) {
	now := fixedNow()
	credentials := Credentials{BaseURL: "https://admin.example.com", AccessToken: "token-secret", TokenType: "Bearer", ExpiresAt: now.Add(time.Hour), User: User{EmployeeID: "123", EmployeeName: "吴昊天"}}
	store := &fakeStore{loaded: credentials}
	remote := &fakeWhoAmI{err: errors.New("must not call")}
	svc := NewService(nil, remote, store, nil, nil, fixedNow)

	status, err := svc.Status(context.Background())
	if err != nil || !status.Authenticated || status.Expired || status.User.EmployeeID != "123" || !status.ExpiresAt.Equal(credentials.ExpiresAt) {
		t.Fatalf("status=%+v err=%v", status, err)
	}
	identity, err := svc.WhoAmI(context.Background())
	if err != nil || identity.User.EmployeeID != "123" || !identity.ExpiresAt.Equal(credentials.ExpiresAt) {
		t.Fatalf("identity=%+v err=%v", identity, err)
	}
	if err := svc.Logout(context.Background()); err != nil {
		t.Fatal(err)
	}
	if remote.calls != 0 || store.loadCalls != 2 || store.deletes != 1 {
		t.Fatalf("remote calls=%d loadCalls=%d deletes=%d", remote.calls, store.loadCalls, store.deletes)
	}
}

func TestStatusMapsMissingAndExpiredCredentials(t *testing.T) {
	now := fixedNow()
	for _, tt := range []struct {
		name  string
		store *fakeStore
		want  StatusResult
	}{
		{name: "missing", store: &fakeStore{loadErr: ErrNotLoggedIn}, want: StatusResult{}},
		{name: "expired", store: &fakeStore{loaded: Credentials{ExpiresAt: now}}, want: StatusResult{Expired: true}},
	} {
		t.Run(tt.name, func(t *testing.T) {
			got, err := NewService(nil, nil, tt.store, nil, nil, fixedNow).Status(context.Background())
			if err != nil || !reflect.DeepEqual(got, tt.want) {
				t.Fatalf("got=%+v err=%v", got, err)
			}
		})
	}
}

func TestWhoAmIRejectsMissingOrExpiredCredentials(t *testing.T) {
	for _, store := range []*fakeStore{
		{loadErr: ErrNotLoggedIn},
		{loaded: Credentials{ExpiresAt: fixedNow()}},
	} {
		_, err := NewService(nil, nil, store, nil, nil, fixedNow).WhoAmI(context.Background())
		if !errors.Is(err, ErrNotLoggedIn) {
			t.Fatalf("err=%v", err)
		}
	}
}

func TestWaitHonorsContextCancellation(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	if err := Wait(ctx, time.Hour); !errors.Is(err, context.Canceled) {
		t.Fatalf("err=%v", err)
	}
}

func noWait(context.Context, time.Duration) error { return nil }

func fixedNow() time.Time {
	return time.Date(2026, 8, 6, 11, 0, 0, 0, time.UTC)
}

func TestStartLoginReturnsResumableSessionWithoutPolling(t *testing.T) {
	now := fixedNow()
	api := &fakeDeviceAPI{start: DeviceStart{DeviceCode: "device-secret", CodeVerifier: "verifier-secret", UserCode: "ABCD", VerificationURI: "https://verify", ExpiresIn: 60, Interval: 2}}
	store := &fakeStore{}
	result, err := NewService(api, &fakeWhoAmI{}, store, &fakeBrowser{}, noWait, fixedNow).StartLogin(context.Background(), "https://djt.bytedance.net", ppe.Config{}, nil)
	if err != nil {
		t.Fatal(err)
	}
	if result.DeviceCode != "device-secret" || result.CodeVerifier != "verifier-secret" || result.UserCode != "ABCD" || result.VerificationURL != "https://verify" || !result.ExpiresAt.Equal(now.Add(time.Minute)) {
		t.Fatalf("session=%+v", result)
	}
	if api.tokenCalls != 0 || store.saveCalls != 0 {
		t.Fatalf("tokenCalls=%d saveCalls=%d", api.tokenCalls, store.saveCalls)
	}
}

func TestCompleteLoginResumesSessionAndSavesCredentials(t *testing.T) {
	now := fixedNow()
	api := &fakeDeviceAPI{tokens: []tokenResult{{token: DeviceToken{AccessToken: "token-secret", TokenType: "Bearer", ExpiresIn: 3600}}}}
	store := &fakeStore{}
	who := &fakeWhoAmI{user: User{EmployeeID: "123"}}
	session := LoginSession{BaseURL: "https://djt.bytedance.net", DeviceCode: "device-secret", CodeVerifier: "verifier-secret", UserCode: "ABCD", VerificationURL: "https://verify", ExpiresAt: now.Add(time.Minute), Interval: 2}
	result, err := NewService(api, who, store, &fakeBrowser{}, noWait, fixedNow).CompleteLogin(context.Background(), session)
	if err != nil {
		t.Fatal(err)
	}
	if result.Credentials.AccessToken != "token-secret" || store.saveCalls != 1 {
		t.Fatalf("result=%+v store=%+v", result, store)
	}
	if !reflect.DeepEqual(api.deviceCodes, []string{"device-secret"}) || !reflect.DeepEqual(api.verifiers, []string{"verifier-secret"}) {
		t.Fatalf("device=%v verifier=%v", api.deviceCodes, api.verifiers)
	}
}

func TestCompleteLoginRejectsExpiredSessionWithoutPolling(t *testing.T) {
	api := &fakeDeviceAPI{}
	session := LoginSession{BaseURL: "https://djt.bytedance.net", DeviceCode: "d", CodeVerifier: "v", VerificationURL: "https://verify", ExpiresAt: fixedNow().Add(-time.Second), Interval: 1}
	_, err := NewService(api, &fakeWhoAmI{}, &fakeStore{}, &fakeBrowser{}, noWait, fixedNow).CompleteLogin(context.Background(), session)
	if !errors.Is(err, ErrExpired) || api.tokenCalls != 0 {
		t.Fatalf("err=%v calls=%d", err, api.tokenCalls)
	}
}
