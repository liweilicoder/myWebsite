package auth

import (
	"context"
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/http/httptest"
	"reflect"
	"strings"
	"testing"
)

func TestDeviceClientStartAndTokenProtocol(t *testing.T) {
	calls := 0
	var challenge string
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		calls++
		if got := r.Header.Get("Accept"); got != "application/json" {
			t.Errorf("Accept=%q", got)
		}
		if got := r.Header.Get("Content-Type"); got != "application/json" {
			t.Errorf("Content-Type=%q", got)
		}
		switch calls {
		case 1:
			if r.Method != http.MethodPost || r.URL.Path != "/api/djt-cli/device/start" {
				t.Errorf("request=%s %s", r.Method, r.URL.Path)
			}
			var body map[string]string
			if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
				t.Fatal(err)
			}
			if want := map[string]string{"code_challenge": body["code_challenge"], "code_challenge_method": "S256"}; !reflect.DeepEqual(body, want) {
				t.Errorf("start body keys/value=%v", body)
			}
			challenge = body["code_challenge"]
			io.WriteString(w, `{"device_code":"d","user_code":"U","verification_uri":"https://verify.example.com","verification_uri_complete":"https://verify.example.com?code=U","expires_in":600,"interval":5}`)
		case 2:
			if r.Method != http.MethodPost || r.URL.Path != "/api/djt-cli/device/token" {
				t.Errorf("request=%s %s", r.Method, r.URL.Path)
			}
			var body map[string]string
			if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
				t.Fatal(err)
			}
			if want := map[string]string{"device_code": "d", "code_verifier": body["code_verifier"]}; !reflect.DeepEqual(body, want) {
				t.Errorf("token body keys/value=%v", body)
			}
			raw, err := base64.RawURLEncoding.DecodeString(body["code_verifier"])
			if err != nil || len(raw) != 32 {
				t.Errorf("verifier must encode 32 random bytes: len=%d err=%v", len(raw), err)
			}
			sum := sha256.Sum256([]byte(body["code_verifier"]))
			if got := base64.RawURLEncoding.EncodeToString(sum[:]); got != challenge {
				t.Errorf("challenge=%q want=%q", challenge, got)
			}
			io.WriteString(w, `{"access_token":"secret","token_type":"Bearer","expires_in":3600}`)
		default:
			t.Errorf("unexpected call %d", calls)
		}
	}))
	defer srv.Close()

	client := NewDeviceClient(srv.Client())
	start, err := client.Start(context.Background(), srv.URL)
	if err != nil {
		t.Fatal(err)
	}
	if start.CodeVerifier == "" || start.DeviceCode != "d" || start.ExpiresIn != 600 {
		t.Fatalf("start=%+v", start)
	}
	token, err := client.Token(context.Background(), srv.URL, start.DeviceCode, start.CodeVerifier)
	if err != nil {
		t.Fatal(err)
	}
	if token.AccessToken != "secret" || token.TokenType != "Bearer" || token.ExpiresIn != 3600 {
		t.Fatalf("token=%+v", token)
	}
}

func TestDeviceTokenHTTP400IsTypedError(t *testing.T) {
	for _, code := range []string{"authorization_pending", "slow_down", "access_denied", "expired_token", "invalid_grant"} {
		t.Run(code, func(t *testing.T) {
			srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
				w.WriteHeader(http.StatusBadRequest)
				fmt.Fprintf(w, `{"error":%q}`, code)
			}))
			defer srv.Close()
			_, err := NewDeviceClient(srv.Client()).Token(context.Background(), srv.URL, "d", "verifier-secret")
			var protocolErr *DeviceProtocolError
			if !errors.As(err, &protocolErr) || protocolErr.Code != code {
				t.Fatalf("err=%v", err)
			}
			assertNoSecrets(t, err, "verifier-secret")
		})
	}
}

func TestDeviceResponsesTrulyRejectBodiesOverOneMiB(t *testing.T) {
	for _, endpoint := range []string{"start", "token"} {
		t.Run(endpoint, func(t *testing.T) {
			srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
				io.WriteString(w, strings.Repeat("x", (1<<20)+1))
			}))
			defer srv.Close()
			client := NewDeviceClient(srv.Client())
			var err error
			if endpoint == "start" {
				_, err = client.Start(context.Background(), srv.URL)
			} else {
				_, err = client.Token(context.Background(), srv.URL, "device-secret", "verifier-secret")
			}
			if err == nil || !strings.Contains(err.Error(), "超过 1 MiB") {
				t.Fatalf("err=%v", err)
			}
			assertNoSecrets(t, err, "device-secret", "verifier-secret")
		})
	}
}

func TestDeviceClientErrorsDoNotLeakSensitiveBodies(t *testing.T) {
	for _, tt := range []struct {
		name   string
		status int
		body   string
	}{
		{name: "start HTTP error", status: http.StatusInternalServerError, body: `{"code_verifier":"verifier-secret"}`},
		{name: "token HTTP error", status: http.StatusInternalServerError, body: `{"access_token":"token-secret"}`},
		{name: "token malformed 400", status: http.StatusBadRequest, body: `{"error":"","access_token":"token-secret"}`},
	} {
		t.Run(tt.name, func(t *testing.T) {
			srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
				w.WriteHeader(tt.status)
				io.WriteString(w, tt.body)
			}))
			defer srv.Close()
			client := NewDeviceClient(srv.Client())
			var err error
			if strings.HasPrefix(tt.name, "start") {
				_, err = client.Start(context.Background(), srv.URL)
			} else {
				_, err = client.Token(context.Background(), srv.URL, "device-secret", "verifier-secret")
			}
			if err == nil {
				t.Fatal("expected error")
			}
			assertNoSecrets(t, err, "device-secret", "verifier-secret", "token-secret")
		})
	}
}

func TestDeviceClientRejectsInvalidSuccessFields(t *testing.T) {
	for _, tt := range []struct {
		name string
		path string
		body string
	}{
		{name: "start", path: "/api/djt-cli/device/start", body: `{"device_code":"","user_code":"U","verification_uri":"https://verify","expires_in":600,"interval":5}`},
		{name: "token missing expires in", path: "/api/djt-cli/device/token", body: `{"access_token":"token-secret","token_type":"Bearer","expires_in":0}`},
		{name: "token type", path: "/api/djt-cli/device/token", body: `{"access_token":"token-secret","token_type":"MAC","expires_in":60}`},
	} {
		t.Run(tt.name, func(t *testing.T) {
			srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) { io.WriteString(w, tt.body) }))
			defer srv.Close()
			client := NewDeviceClient(srv.Client())
			var err error
			if tt.path == "/api/djt-cli/device/start" {
				_, err = client.Start(context.Background(), srv.URL)
			} else {
				_, err = client.Token(context.Background(), srv.URL, "d", "v")
			}
			if err == nil {
				t.Fatal("expected error")
			}
			assertNoSecrets(t, err, "token-secret")
		})
	}
}

func TestDeviceClientRejectsUnsafeVerificationURIsAndDurationBounds(t *testing.T) {
	tests := []struct {
		name string
		body string
	}{
		{"verification custom scheme", `{"device_code":"d","user_code":"u","verification_uri":"custom://verify","expires_in":60,"interval":5}`},
		{"verification remote http", `{"device_code":"d","user_code":"u","verification_uri":"http://evil.example.com","expires_in":60,"interval":5}`},
		{"verification userinfo", `{"device_code":"d","user_code":"u","verification_uri":"https://u@verify.example.com","expires_in":60,"interval":5}`},
		{"verification query", `{"device_code":"d","user_code":"u","verification_uri":"https://verify.example.com?q=1","expires_in":60,"interval":5}`},
		{"complete file", `{"device_code":"d","user_code":"u","verification_uri":"https://verify.example.com","verification_uri_complete":"file:///tmp/x","expires_in":60,"interval":5}`},
		{"expires too large", `{"device_code":"d","user_code":"u","verification_uri":"https://verify.example.com","expires_in":3601,"interval":5}`},
		{"interval too large", `{"device_code":"d","user_code":"u","verification_uri":"https://verify.example.com","expires_in":60,"interval":301}`},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) { _, _ = io.WriteString(w, tt.body) }))
			defer srv.Close()
			if _, err := NewDeviceClient(srv.Client()).Start(context.Background(), srv.URL); err == nil {
				t.Fatal("expected validation error")
			}
		})
	}
}

func TestDeviceTokenRejectsExpiresOverThirtyDays(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		_, _ = io.WriteString(w, `{"access_token":"secret","token_type":"Bearer","expires_in":2592001}`)
	}))
	defer srv.Close()
	if _, err := NewDeviceClient(srv.Client()).Token(context.Background(), srv.URL, "d", "v"); err == nil {
		t.Fatal("expected validation error")
	}
}

func TestDeviceClientReturnsContextErrorFromDoer(t *testing.T) {
	for _, method := range []string{"start", "token"} {
		t.Run(method, func(t *testing.T) {
			ctx, cancel := context.WithCancel(context.Background())
			doer := HTTPDoerFunc(func(req *http.Request) (*http.Response, error) {
				cancel()
				<-req.Context().Done()
				return nil, errors.New("transport wrapped cancellation")
			})
			var err error
			if method == "start" {
				_, err = NewDeviceClient(doer).Start(ctx, "https://example.com")
			} else {
				_, err = NewDeviceClient(doer).Token(ctx, "https://example.com", "d", "v")
			}
			if !errors.Is(err, context.Canceled) {
				t.Fatalf("err=%v", err)
			}
		})
	}
}

type HTTPDoerFunc func(*http.Request) (*http.Response, error)

func (f HTTPDoerFunc) Do(req *http.Request) (*http.Response, error) { return f(req) }

func assertNoSecrets(t *testing.T, err error, secrets ...string) {
	t.Helper()
	if err == nil {
		return
	}
	for _, secret := range secrets {
		if strings.Contains(err.Error(), secret) {
			t.Fatalf("敏感信息泄漏: %v", err)
		}
	}
}
