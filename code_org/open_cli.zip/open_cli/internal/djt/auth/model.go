package auth

import (
	"context"
	"errors"
	"net/http"
	"time"

	"code.byted.org/temai/open_cli/internal/core/ppe"
)

var ErrNotLoggedIn = errors.New("尚未登录，请先运行 doudian-open-cli djt auth login")
var ErrExpired = errors.New("登录凭据已过期，请重新运行 doudian-open-cli djt auth login")
var ErrNoLoginSession = errors.New("没有待完成的登录会话，请先运行 doudian-open-cli djt auth login start")

type HTTPDoer interface {
	Do(*http.Request) (*http.Response, error)
}

type User struct {
	EmployeeID    string   `json:"employee_id"`
	EmployeeName  string   `json:"employee_name"`
	Email         string   `json:"email"`
	HeadURL       string   `json:"head_url"`
	UserType      int64    `json:"user_type"`
	AuthorityList []string `json:"authority_list"`
}

type Credentials struct {
	BaseURL     string    `json:"base_url"`
	AccessToken string    `json:"access_token"`
	TokenType   string    `json:"token_type"`
	ExpiresAt   time.Time `json:"expires_at"`
	User        User      `json:"user"`
}

type DeviceStart struct {
	DeviceCode              string `json:"device_code"`
	UserCode                string `json:"user_code"`
	VerificationURI         string `json:"verification_uri"`
	VerificationURIComplete string `json:"verification_uri_complete"`
	ExpiresIn               int    `json:"expires_in"`
	Interval                int    `json:"interval"`
	CodeVerifier            string `json:"-"`
}

type LoginSession struct {
	BaseURL         string     `json:"base_url"`
	DeviceCode      string     `json:"device_code"`
	CodeVerifier    string     `json:"code_verifier"`
	UserCode        string     `json:"user_code"`
	VerificationURL string     `json:"verification_url"`
	ExpiresAt       time.Time  `json:"expires_at"`
	Interval        int        `json:"interval"`
	PPE             ppe.Config `json:"ppe"`
}

type LoginSessionStore interface {
	Load(context.Context) (LoginSession, error)
	Save(context.Context, LoginSession) error
	Delete(context.Context) error
}

type DeviceToken struct {
	AccessToken string `json:"access_token"`
	TokenType   string `json:"token_type"`
	ExpiresIn   int    `json:"expires_in"`
}

type DeviceProtocolError struct {
	Code string
}

func (e *DeviceProtocolError) Error() string {
	return "设备授权失败: " + e.Code
}

type CredentialStore interface {
	Load(context.Context) (Credentials, error)
	Save(context.Context, Credentials) error
	Delete(context.Context) error
}

type DeviceAPI interface {
	StartWithPPE(context.Context, string, ppe.Config) (DeviceStart, error)
	TokenWithPPE(context.Context, string, string, string, ppe.Config) (DeviceToken, error)
}

type WhoAmIAPI interface {
	GetLoginUserWithPPE(context.Context, string, string, string, ppe.Config) (User, error)
}

type BrowserOpener interface {
	Open(string) error
}

type WaitFunc func(context.Context, time.Duration) error
