package auth

import (
	"bytes"
	"context"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"strings"

	"code.byted.org/temai/open_cli/internal/core/identity"
	"code.byted.org/temai/open_cli/internal/core/ppe"
	"code.byted.org/temai/open_cli/internal/core/urlpolicy"
)

const maxDeviceResponseBody int64 = 1 << 20

const cliAuthorizationHeader = "X-DJT-CLI-Authorization"

type DeviceClient struct {
	http HTTPDoer
}

func NewDeviceClient(httpClient HTTPDoer) *DeviceClient {
	return &DeviceClient{http: httpClient}
}

func (c *DeviceClient) Start(ctx context.Context, baseURL string) (DeviceStart, error) {
	return c.StartWithPPE(ctx, baseURL, ppe.Config{})
}

func (c *DeviceClient) StartWithPPE(ctx context.Context, baseURL string, ppeConfig ppe.Config) (DeviceStart, error) {
	verifier, challenge, err := newPKCE()
	if err != nil {
		return DeviceStart{}, errors.New("生成 PKCE 参数失败")
	}
	body := struct {
		CodeChallenge string `json:"code_challenge"`
		Method        string `json:"code_challenge_method"`
	}{CodeChallenge: challenge, Method: "S256"}
	status, data, err := c.postLimited(ctx, endpoint(baseURL, "/api/djt-cli/device/start"), body, ppeConfig)
	if err != nil {
		return DeviceStart{}, err
	}
	if status < http.StatusOK || status >= http.StatusMultipleChoices {
		return DeviceStart{}, fmt.Errorf("device start 返回 HTTP %d", status)
	}
	var out DeviceStart
	if err := json.Unmarshal(data, &out); err != nil {
		return DeviceStart{}, errors.New("解析 device start 响应失败")
	}
	if out.DeviceCode == "" || out.UserCode == "" || out.VerificationURI == "" || out.ExpiresIn <= 0 || out.ExpiresIn > 3600 || out.Interval <= 0 || out.Interval > 300 {
		return DeviceStart{}, errors.New("device start 响应字段无效")
	}
	if err := urlpolicy.ValidateVerificationURI(out.VerificationURI, false); err != nil {
		return DeviceStart{}, fmt.Errorf("device start verification_uri 不安全: %w", err)
	}
	if out.VerificationURIComplete != "" {
		if err := urlpolicy.ValidateVerificationURI(out.VerificationURIComplete, true); err != nil {
			return DeviceStart{}, fmt.Errorf("device start verification_uri_complete 不安全: %w", err)
		}
	}
	out.CodeVerifier = verifier
	return out, nil
}

func (c *DeviceClient) Token(ctx context.Context, baseURL, deviceCode, verifier string) (DeviceToken, error) {
	return c.TokenWithPPE(ctx, baseURL, deviceCode, verifier, ppe.Config{})
}

func (c *DeviceClient) TokenWithPPE(ctx context.Context, baseURL, deviceCode, verifier string, ppeConfig ppe.Config) (DeviceToken, error) {
	body := struct {
		DeviceCode   string `json:"device_code"`
		CodeVerifier string `json:"code_verifier"`
	}{DeviceCode: deviceCode, CodeVerifier: verifier}
	status, data, err := c.postLimited(ctx, endpoint(baseURL, "/api/djt-cli/device/token"), body, ppeConfig)
	if err != nil {
		return DeviceToken{}, err
	}
	if status == http.StatusBadRequest {
		var body struct {
			Error string `json:"error"`
		}
		if err := json.Unmarshal(data, &body); err != nil || !knownDeviceError(body.Error) {
			return DeviceToken{}, errors.New("device token 返回非法 HTTP 400")
		}
		return DeviceToken{}, &DeviceProtocolError{Code: body.Error}
	}
	if status != http.StatusOK {
		return DeviceToken{}, fmt.Errorf("device token 返回 HTTP %d", status)
	}
	var out DeviceToken
	if err := json.Unmarshal(data, &out); err != nil {
		return DeviceToken{}, errors.New("解析 device token 响应失败")
	}
	if out.AccessToken == "" || out.TokenType != "Bearer" || out.ExpiresIn <= 0 || out.ExpiresIn > 30*24*60*60 {
		return DeviceToken{}, errors.New("device token 响应字段无效")
	}
	return out, nil
}

func (c *DeviceClient) postLimited(ctx context.Context, requestURL string, body any, ppeConfig ppe.Config) (int, []byte, error) {
	payload, err := json.Marshal(body)
	if err != nil {
		return 0, nil, errors.New("编码 device 请求失败")
	}
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, requestURL, bytes.NewReader(payload))
	if err != nil {
		return 0, nil, errors.New("创建 device 请求失败")
	}
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Accept", "application/json")
	identity.Apply(req.Header)
	if err := ppeConfig.Apply(req.Header); err != nil {
		return 0, nil, err
	}
	resp, err := c.http.Do(req)
	if err != nil {
		if ctxErr := ctx.Err(); ctxErr != nil {
			return 0, nil, ctxErr
		}
		return 0, nil, errors.New("device 请求失败")
	}
	defer resp.Body.Close()
	data, err := readLimited(resp.Body, maxDeviceResponseBody)
	if err != nil {
		return 0, nil, err
	}
	return resp.StatusCode, data, nil
}

func newPKCE() (verifier string, challenge string, err error) {
	raw := make([]byte, 32)
	if _, err := io.ReadFull(rand.Reader, raw); err != nil {
		return "", "", err
	}
	verifier = base64.RawURLEncoding.EncodeToString(raw)
	sum := sha256.Sum256([]byte(verifier))
	return verifier, base64.RawURLEncoding.EncodeToString(sum[:]), nil
}

func readLimited(reader io.Reader, limit int64) ([]byte, error) {
	data, err := io.ReadAll(io.LimitReader(reader, limit+1))
	if err != nil {
		return nil, errors.New("读取响应失败")
	}
	if int64(len(data)) > limit {
		return nil, errors.New("响应体超过 1 MiB")
	}
	return data, nil
}

func endpoint(baseURL, path string) string {
	return strings.TrimRight(baseURL, "/") + path
}

func knownDeviceError(code string) bool {
	switch code {
	case "authorization_pending", "slow_down", "access_denied", "expired_token", "invalid_grant":
		return true
	default:
		return false
	}
}
