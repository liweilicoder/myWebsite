package auth

import (
	"context"
	"errors"
	"os"
	"path/filepath"
	"reflect"
	"runtime"
	"strings"
	"testing"
	"time"
)

func testCredentials() Credentials {
	return Credentials{
		BaseURL:     "https://admin.example.com",
		AccessToken: "secret-token",
		TokenType:   "Bearer",
		ExpiresAt:   time.Date(2026, 8, 6, 12, 0, 0, 0, time.UTC),
		User: User{
			EmployeeID:    "123",
			EmployeeName:  "吴昊天",
			Email:         "wuhaotian@example.com",
			HeadURL:       "https://example.com/avatar",
			UserType:      1,
			AuthorityList: []string{"interface.read"},
		},
	}
}

func TestFileStoreSaveLoadAndDelete(t *testing.T) {
	dir := filepath.Join(t.TempDir(), "opencli")
	store := NewFileStore(dir)
	want := testCredentials()
	if err := store.Save(context.Background(), want); err != nil {
		t.Fatal(err)
	}
	if runtime.GOOS != "windows" {
		dirInfo, err := os.Stat(dir)
		if err != nil {
			t.Fatal(err)
		}
		if got := dirInfo.Mode().Perm(); got != 0o700 {
			t.Fatalf("配置目录权限=%o，期望 700", got)
		}
		fileInfo, err := os.Stat(filepath.Join(dir, "credentials.json"))
		if err != nil {
			t.Fatal(err)
		}
		if got := fileInfo.Mode().Perm(); got != 0o600 {
			t.Fatalf("凭据文件权限=%o，期望 600", got)
		}
	}
	got, err := store.Load(context.Background())
	if err != nil {
		t.Fatal(err)
	}
	if !reflect.DeepEqual(got, want) {
		t.Fatal("Load() 返回的凭据与保存值不一致")
	}
	if err := store.Delete(context.Background()); err != nil {
		t.Fatal(err)
	}
	if err := store.Delete(context.Background()); err != nil {
		t.Fatalf("重复删除应幂等: %v", err)
	}
	if _, err := store.Load(context.Background()); !errors.Is(err, ErrNotLoggedIn) {
		t.Fatalf("删除后 Load() error=%v，期望 ErrNotLoggedIn", err)
	}
}

func TestFileStoreSaveAtomicallyReplacesCredentials(t *testing.T) {
	dir := t.TempDir()
	store := NewFileStore(dir)
	first := testCredentials()
	if err := store.Save(context.Background(), first); err != nil {
		t.Fatal(err)
	}
	second := first
	second.AccessToken = "replacement-token"
	if err := store.Save(context.Background(), second); err != nil {
		t.Fatal(err)
	}
	got, err := store.Load(context.Background())
	if err != nil {
		t.Fatal(err)
	}
	if !reflect.DeepEqual(got, second) {
		t.Fatal("Load() 未返回替换后的凭据")
	}
	matches, err := filepath.Glob(filepath.Join(dir, ".credentials-*"))
	if err != nil {
		t.Fatal(err)
	}
	if len(matches) != 0 {
		t.Fatalf("残留临时文件: %v", matches)
	}
}

func TestFileStoreRejectsWidePermission(t *testing.T) {
	if runtime.GOOS == "windows" {
		t.Skip("POSIX permission test")
	}
	dir := t.TempDir()
	path := filepath.Join(dir, "credentials.json")
	data := `{"base_url":"https://admin.example.com","access_token":"secret-token","token_type":"Bearer","expires_at":"2026-08-06T12:00:00Z","user":{"employee_id":"123","employee_name":"n","email":"","head_url":"","user_type":1,"authority_list":[]}}`
	if err := os.WriteFile(path, []byte(data), 0o644); err != nil {
		t.Fatal(err)
	}
	_, err := NewFileStore(dir).Load(context.Background())
	if err == nil || !strings.Contains(err.Error(), "0600") {
		t.Fatalf("error=%v，期望拒绝过宽权限", err)
	}
	if strings.Contains(err.Error(), "secret-token") {
		t.Fatal("错误泄漏 token")
	}
}

func TestFileStoreLoadRequiresStrictJSON(t *testing.T) {
	valid := `{"base_url":"https://admin.example.com","access_token":"secret-token","token_type":"Bearer","expires_at":"2026-08-06T12:00:00Z","user":{"employee_id":"123","employee_name":"n","email":"","head_url":"","user_type":1,"authority_list":[]}}`
	tests := []struct {
		name string
		data string
	}{
		{name: "未知字段", data: strings.TrimSuffix(valid, "}") + `,"unexpected":true}`},
		{name: "尾随 JSON", data: valid + `{}`},
		{name: "缺少 token", data: strings.Replace(valid, `"secret-token"`, `""`, 1)},
		{name: "缺少员工 ID", data: strings.Replace(valid, `"123"`, `""`, 1)},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			dir := t.TempDir()
			if err := os.WriteFile(filepath.Join(dir, "credentials.json"), []byte(tt.data), 0o600); err != nil {
				t.Fatal(err)
			}
			_, err := NewFileStore(dir).Load(context.Background())
			if err == nil {
				t.Fatal("Load() 未拒绝非法凭据")
			}
			if strings.Contains(err.Error(), "secret-token") {
				t.Fatal("错误泄漏 token")
			}
		})
	}
}

func TestFileStoreHonorsCanceledContext(t *testing.T) {
	dir := t.TempDir()
	store := NewFileStore(dir)
	if err := store.Save(context.Background(), testCredentials()); err != nil {
		t.Fatal(err)
	}
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	if _, err := store.Load(ctx); !errors.Is(err, context.Canceled) {
		t.Fatalf("Load() error=%v，期望 context.Canceled", err)
	}
	if err := store.Save(ctx, testCredentials()); !errors.Is(err, context.Canceled) {
		t.Fatalf("Save() error=%v，期望 context.Canceled", err)
	}
	if err := store.Delete(ctx); !errors.Is(err, context.Canceled) {
		t.Fatalf("Delete() error=%v，期望 context.Canceled", err)
	}
	if _, err := os.Stat(filepath.Join(dir, "credentials.json")); err != nil {
		t.Fatalf("取消的 Delete 不应删除凭据: %v", err)
	}
}

func TestFileStoreLoadIgnoresLegacyBaseURLValidation(t *testing.T) {
	tests := []struct {
		name    string
		baseURL string
		data    string
	}{
		{
			name:    "空 base_url",
			baseURL: "",
			data:    `{"base_url":"","access_token":"secret","token_type":"Bearer","expires_at":"2099-01-01T00:00:00Z","user":{"employee_id":"123"}}`,
		},
		{
			name:    "非法 base_url",
			baseURL: "http://evil.example.com",
			data:    `{"base_url":"http://evil.example.com","access_token":"secret","token_type":"Bearer","expires_at":"2099-01-01T00:00:00Z","user":{"employee_id":"123"}}`,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			dir := t.TempDir()
			if err := os.WriteFile(filepath.Join(dir, "credentials.json"), []byte(tt.data), 0o600); err != nil {
				t.Fatal(err)
			}
			got, err := NewFileStore(dir).Load(context.Background())
			if err != nil {
				t.Fatalf("Load() error=%v", err)
			}
			if got.BaseURL != tt.baseURL {
				t.Fatalf("Load() base_url=%q，期望 %q", got.BaseURL, tt.baseURL)
			}
		})
	}
}

func TestFileStoreSaveRejectsInvalidCredentialsWithoutLeakingToken(t *testing.T) {
	credentials := testCredentials()
	credentials.TokenType = ""
	err := NewFileStore(t.TempDir()).Save(context.Background(), credentials)
	if err == nil {
		t.Fatal("Save() 未拒绝缺少必填字段的凭据")
	}
	if strings.Contains(err.Error(), credentials.AccessToken) {
		t.Fatal("错误泄漏 token")
	}
}

func TestFileStoreSaveTightensExistingDirectoryPermission(t *testing.T) {
	if runtime.GOOS == "windows" {
		t.Skip("POSIX permission test")
	}
	dir := filepath.Join(t.TempDir(), "opencli")
	if err := os.Mkdir(dir, 0o755); err != nil {
		t.Fatal(err)
	}
	if err := NewFileStore(dir).Save(context.Background(), testCredentials()); err != nil {
		t.Fatal(err)
	}
	info, err := os.Stat(dir)
	if err != nil {
		t.Fatal(err)
	}
	if got := info.Mode().Perm(); got != 0o700 {
		t.Fatalf("配置目录权限=%o，期望 700", got)
	}
}

type cancelBeforeCommitContext struct {
	context.Context
	errCalls int
}

func (c *cancelBeforeCommitContext) Err() error {
	c.errCalls++
	if c.errCalls > 1 {
		return context.Canceled
	}
	return nil
}

func TestFileStoreSaveCanceledBeforeCommitPreservesOldCredentialsAndCleansTemp(t *testing.T) {
	dir := t.TempDir()
	store := NewFileStore(dir)
	oldCredentials := testCredentials()
	if err := store.Save(context.Background(), oldCredentials); err != nil {
		t.Fatal(err)
	}
	newCredentials := oldCredentials
	newCredentials.AccessToken = "new-secret-token"
	ctx := &cancelBeforeCommitContext{Context: context.Background()}

	err := store.Save(ctx, newCredentials)
	if !errors.Is(err, context.Canceled) {
		t.Fatalf("Save() error=%v，期望 context.Canceled", err)
	}
	got, err := store.Load(context.Background())
	if err != nil {
		t.Fatal(err)
	}
	if !reflect.DeepEqual(got, oldCredentials) {
		t.Fatal("取消的 Save 覆盖了旧凭据")
	}
	matches, err := filepath.Glob(filepath.Join(dir, ".credentials-*"))
	if err != nil {
		t.Fatal(err)
	}
	if len(matches) != 0 {
		t.Fatalf("取消后残留 %d 个临时文件", len(matches))
	}
}

func TestFileStoreHasNoChmodInjectionHook(t *testing.T) {
	storeType := reflect.TypeOf(*NewFileStore(t.TempDir()))
	for i := 0; i < storeType.NumField(); i++ {
		if storeType.Field(i).Type.Kind() == reflect.Func {
			t.Fatalf("FileStore 不应保留函数注入字段: %s", storeType.Field(i).Name)
		}
	}
}

func TestFileStoreLoadFailuresDoNotLeakToken(t *testing.T) {
	const token = "token-must-never-leak"
	tests := []struct {
		name string
		data string
		mode os.FileMode
	}{
		{name: "损坏文件", data: `{"access_token":"` + token + `"`, mode: 0o600},
		{name: "过宽权限", data: `{"access_token":"` + token + `"}`, mode: 0o644},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if tt.mode == 0o644 && runtime.GOOS == "windows" {
				t.Skip("POSIX permission test")
			}
			dir := t.TempDir()
			if err := os.WriteFile(filepath.Join(dir, "credentials.json"), []byte(tt.data), tt.mode); err != nil {
				t.Fatal(err)
			}
			_, err := NewFileStore(dir).Load(context.Background())
			if err == nil {
				t.Fatal("Load() 应拒绝不安全的凭据文件")
			}
			if strings.Contains(err.Error(), token) {
				t.Fatal("Load() 错误泄漏 token")
			}
		})
	}
}
