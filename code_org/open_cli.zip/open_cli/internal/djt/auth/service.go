package auth

import (
	"context"
	"errors"
	"fmt"
	"os"
	"time"

	"code.byted.org/temai/open_cli/internal/core/ppe"
)

type Service struct {
	device  DeviceAPI
	who     WhoAmIAPI
	store   CredentialStore
	browser BrowserOpener
	wait    WaitFunc
	now     func() time.Time
}

type LoginResult struct {
	Credentials  Credentials
	Start        DeviceStart
	OpenURL      string
	BrowserError error
}

type LoginPrompt struct {
	VerificationURL string
	UserCode        string
	BrowserError    error
}

type PromptFunc func(LoginPrompt) error

type StatusResult struct {
	Authenticated bool      `json:"authenticated"`
	Expired       bool      `json:"expired,omitempty"`
	User          User      `json:"user,omitempty"`
	ExpiresAt     time.Time `json:"expires_at,omitempty"`
}

type WhoAmIResult struct {
	User      User      `json:"user"`
	ExpiresAt time.Time `json:"expires_at"`
}

func NewService(device DeviceAPI, who WhoAmIAPI, store CredentialStore, browser BrowserOpener, wait WaitFunc, now func() time.Time) *Service {
	return &Service{device: device, who: who, store: store, browser: browser, wait: wait, now: now}
}

func (s *Service) StartLogin(ctx context.Context, baseURL string, ppeConfig ppe.Config, prompt PromptFunc) (LoginSession, error) {
	start, err := s.device.StartWithPPE(ctx, baseURL, ppeConfig)
	if err != nil {
		return LoginSession{}, err
	}
	if start.ExpiresIn <= 0 || start.ExpiresIn > 3600 || start.Interval <= 0 || start.Interval > 300 {
		return LoginSession{}, errors.New("device start 响应时长字段无效")
	}
	openURL := start.VerificationURIComplete
	if openURL == "" {
		openURL = start.VerificationURI
	}
	browserErr := s.browser.Open(openURL)
	if prompt != nil {
		if err := prompt(LoginPrompt{VerificationURL: openURL, UserCode: start.UserCode, BrowserError: browserErr}); err != nil {
			return LoginSession{}, err
		}
	}
	return LoginSession{
		BaseURL: baseURL, DeviceCode: start.DeviceCode, CodeVerifier: start.CodeVerifier,
		UserCode: start.UserCode, VerificationURL: openURL,
		ExpiresAt: s.now().Add(time.Duration(start.ExpiresIn) * time.Second), Interval: start.Interval, PPE: ppeConfig,
	}, nil
}

func (s *Service) CompleteLogin(ctx context.Context, session LoginSession) (LoginResult, error) {
	if !s.now().Before(session.ExpiresAt) {
		return LoginResult{}, ErrExpired
	}
	interval := time.Duration(session.Interval) * time.Second
	for {
		token, err := s.device.TokenWithPPE(ctx, session.BaseURL, session.DeviceCode, session.CodeVerifier, session.PPE)
		if err == nil {
			receivedAt := s.now()
			if token.ExpiresIn <= 0 || token.ExpiresIn > 30*24*60*60 {
				return LoginResult{}, errors.New("device token 响应时长字段无效")
			}
			user, err := s.who.GetLoginUserWithPPE(ctx, session.BaseURL, token.TokenType, token.AccessToken, session.PPE)
			if err != nil {
				return LoginResult{}, err
			}
			credentials := Credentials{BaseURL: session.BaseURL, AccessToken: token.AccessToken, TokenType: token.TokenType, ExpiresAt: receivedAt.Add(time.Duration(token.ExpiresIn) * time.Second), User: user}
			if err := s.store.Save(ctx, credentials); err != nil {
				return LoginResult{}, err
			}
			return LoginResult{Credentials: credentials, OpenURL: session.VerificationURL}, nil
		}
		var protocolErr *DeviceProtocolError
		if !errors.As(err, &protocolErr) {
			return LoginResult{}, err
		}
		switch protocolErr.Code {
		case "authorization_pending":
		case "slow_down":
			interval += 5 * time.Second
		case "access_denied", "expired_token", "invalid_grant":
			return LoginResult{}, protocolErr
		default:
			return LoginResult{}, fmt.Errorf("未知设备授权错误 %q", protocolErr.Code)
		}
		remaining := session.ExpiresAt.Sub(s.now())
		if remaining <= 0 {
			return LoginResult{}, ErrExpired
		}
		waitDuration := interval
		if waitDuration > remaining {
			waitDuration = remaining
		}
		if err := s.wait(ctx, waitDuration); err != nil {
			return LoginResult{}, err
		}
	}
}

func (s *Service) Login(ctx context.Context, baseURL string, ppeConfig ppe.Config, prompt PromptFunc) (LoginResult, error) {
	start, err := s.device.StartWithPPE(ctx, baseURL, ppeConfig)
	if err != nil {
		return LoginResult{}, err
	}
	if start.ExpiresIn <= 0 || start.ExpiresIn > 3600 || start.Interval <= 0 || start.Interval > 300 {
		return LoginResult{}, errors.New("device start 响应时长字段无效")
	}
	budget := time.Duration(start.ExpiresIn) * time.Second
	deadline := s.now().Add(budget)
	openURL := start.VerificationURIComplete
	if openURL == "" {
		openURL = start.VerificationURI
	}
	browserErr := s.browser.Open(openURL)
	result := LoginResult{Start: start, OpenURL: openURL, BrowserError: browserErr}

	if prompt != nil {
		if err := prompt(LoginPrompt{
			VerificationURL: openURL,
			UserCode:        start.UserCode,
			BrowserError:    browserErr,
		}); err != nil {
			return result, err
		}
	}

	interval := time.Duration(start.Interval) * time.Second

	for {
		now := s.now()
		if !now.Before(deadline) || budget <= 0 {
			break
		}

		waitDuration := interval
		if waitDuration > budget {
			waitDuration = budget
		}
		wallRemaining := deadline.Sub(now)
		if waitDuration > wallRemaining {
			waitDuration = wallRemaining
		}

		if err := s.wait(ctx, waitDuration); err != nil {
			return result, err
		}
		if err := ctx.Err(); err != nil {
			return result, err
		}
		budget -= waitDuration

		if budget <= 0 || !s.now().Before(deadline) {
			break
		}

		token, err := s.device.TokenWithPPE(ctx, baseURL, start.DeviceCode, start.CodeVerifier, ppeConfig)
		if err != nil {
			var protocolErr *DeviceProtocolError
			if !errors.As(err, &protocolErr) {
				return result, err
			}
			switch protocolErr.Code {
			case "authorization_pending":
				continue
			case "slow_down":
				interval += 5 * time.Second
				continue
			case "access_denied", "expired_token", "invalid_grant":
				return result, protocolErr
			default:
				return result, fmt.Errorf("未知设备授权错误 %q", protocolErr.Code)
			}
		}

		receivedAt := s.now()
		if token.ExpiresIn <= 0 || token.ExpiresIn > 30*24*60*60 {
			return result, errors.New("device token 响应时长字段无效")
		}
		user, err := s.who.GetLoginUserWithPPE(ctx, baseURL, token.TokenType, token.AccessToken, ppeConfig)
		if err != nil {
			return result, err
		}
		credentials := Credentials{
			BaseURL:     baseURL,
			AccessToken: token.AccessToken,
			TokenType:   token.TokenType,
			ExpiresAt:   receivedAt.Add(time.Duration(token.ExpiresIn) * time.Second),
			User:        user,
		}
		if err := s.store.Save(ctx, credentials); err != nil {
			return result, err
		}
		result.Credentials = credentials
		return result, nil
	}
	return result, ErrExpired
}

func (s *Service) Status(ctx context.Context) (StatusResult, error) {
	credentials, err := s.store.Load(ctx)
	if err != nil {
		if errors.Is(err, ErrNotLoggedIn) || errors.Is(err, os.ErrNotExist) {
			return StatusResult{}, nil
		}
		return StatusResult{}, err
	}
	if !credentials.ExpiresAt.After(s.now()) {
		return StatusResult{Expired: true}, nil
	}
	return StatusResult{Authenticated: true, User: credentials.User, ExpiresAt: credentials.ExpiresAt}, nil
}

func (s *Service) WhoAmI(ctx context.Context) (WhoAmIResult, error) {
	credentials, err := s.store.Load(ctx)
	if err != nil {
		if errors.Is(err, ErrNotLoggedIn) || errors.Is(err, os.ErrNotExist) {
			return WhoAmIResult{}, ErrNotLoggedIn
		}
		return WhoAmIResult{}, err
	}
	if !credentials.ExpiresAt.After(s.now()) {
		return WhoAmIResult{}, ErrNotLoggedIn
	}
	return WhoAmIResult{User: credentials.User, ExpiresAt: credentials.ExpiresAt}, nil
}

func (s *Service) Logout(ctx context.Context) error {
	return s.store.Delete(ctx)
}

func Wait(ctx context.Context, duration time.Duration) error {
	timer := time.NewTimer(duration)
	defer timer.Stop()
	select {
	case <-ctx.Done():
		return ctx.Err()
	case <-timer.C:
		return nil
	}
}
