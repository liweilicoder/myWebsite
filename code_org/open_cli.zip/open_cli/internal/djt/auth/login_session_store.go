package auth

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"runtime"
	"strings"
)

type LoginSessionFileStore struct {
	dir  string
	path string
}

func NewLoginSessionFileStore(configDir string) *LoginSessionFileStore {
	return &LoginSessionFileStore{dir: configDir, path: filepath.Join(configDir, "login-session.json")}
}

func (s *LoginSessionFileStore) Load(ctx context.Context) (LoginSession, error) {
	if err := ctx.Err(); err != nil {
		return LoginSession{}, err
	}
	file, err := os.Open(s.path)
	if err != nil {
		if errors.Is(err, os.ErrNotExist) {
			return LoginSession{}, ErrNoLoginSession
		}
		return LoginSession{}, fmt.Errorf("打开登录会话文件: %w", err)
	}
	defer file.Close()
	if runtime.GOOS != "windows" {
		info, err := file.Stat()
		if err != nil {
			return LoginSession{}, fmt.Errorf("检查登录会话文件权限: %w", err)
		}
		if info.Mode().Perm() != 0o600 {
			return LoginSession{}, errors.New("登录会话文件权限不安全，应为 0600")
		}
	}
	var session LoginSession
	decoder := json.NewDecoder(file)
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(&session); err != nil {
		return LoginSession{}, errors.New("解析登录会话文件失败")
	}
	if err := ensureJSONEOF(decoder); err != nil {
		return LoginSession{}, err
	}
	if err := validateLoginSession(session); err != nil {
		return LoginSession{}, err
	}
	return session, nil
}

func (s *LoginSessionFileStore) Save(ctx context.Context, session LoginSession) (err error) {
	if err := ctx.Err(); err != nil {
		return err
	}
	if err := validateLoginSession(session); err != nil {
		return err
	}
	if err := os.MkdirAll(s.dir, 0o700); err != nil {
		return fmt.Errorf("创建配置目录: %w", err)
	}
	if runtime.GOOS != "windows" {
		if err := os.Chmod(s.dir, 0o700); err != nil {
			return fmt.Errorf("设置配置目录权限: %w", err)
		}
	}
	file, err := os.CreateTemp(s.dir, ".login-session-*")
	if err != nil {
		return fmt.Errorf("创建登录会话临时文件: %w", err)
	}
	temporaryPath := file.Name()
	defer func() {
		if err != nil {
			_ = file.Close()
			_ = os.Remove(temporaryPath)
		}
	}()
	if err = file.Chmod(0o600); err != nil {
		return fmt.Errorf("设置登录会话文件权限: %w", err)
	}
	if err = json.NewEncoder(file).Encode(session); err != nil {
		return errors.New("编码登录会话失败")
	}
	if err = file.Sync(); err != nil {
		return fmt.Errorf("同步登录会话文件: %w", err)
	}
	if err = file.Close(); err != nil {
		return fmt.Errorf("关闭登录会话文件: %w", err)
	}
	if err = os.Rename(temporaryPath, s.path); err != nil {
		return fmt.Errorf("原子替换登录会话文件失败: %w", err)
	}
	return nil
}

func (s *LoginSessionFileStore) Delete(ctx context.Context) error {
	if err := ctx.Err(); err != nil {
		return err
	}
	if err := os.Remove(s.path); err != nil && !errors.Is(err, os.ErrNotExist) {
		return fmt.Errorf("删除登录会话文件: %w", err)
	}
	return nil
}

func validateLoginSession(session LoginSession) error {
	if strings.TrimSpace(session.BaseURL) == "" || strings.TrimSpace(session.DeviceCode) == "" || strings.TrimSpace(session.CodeVerifier) == "" || strings.TrimSpace(session.VerificationURL) == "" || session.ExpiresAt.IsZero() || session.Interval <= 0 || session.Interval > 300 {
		return errors.New("登录会话缺少必填字段或字段无效")
	}
	return nil
}
