package djt

import (
	"context"
	"encoding/json"
	"errors"
	"net/http"
	"net/url"
	"strconv"
)

const (
	agentInterfaceGetPath     = "/api/djt-cli/agent/interface/get"
	agentInterfaceInitPath    = "/api/djt-cli/agent/interface/init"
	agentInterfaceSavePath    = "/api/djt-cli/agent/interface/save"
	agentInterfaceDocPath     = "/api/djt-cli/agent/interface/doc"
	agentInterfaceAdvancePath = "/api/djt-cli/agent/interface/advanceStep"
)

type AgentInterfaceAPI interface {
	Get(context.Context, AgentGetRequest, RequestOptions) (AgentGetResult, error)
	Init(context.Context, AgentInitRequest, RequestOptions) (AgentInitResult, error)
	Save(context.Context, AgentSaveRequest, RequestOptions) (AgentSaveResult, error)
	Doc(context.Context, AgentDocRequest, RequestOptions) (AgentDocResult, error)
	AdvanceStep(context.Context, AgentAdvanceRequest, RequestOptions) (AgentAdvanceResult, error)
}

type AgentInterfaceClient struct {
	transport *Transport
}

func NewAgentInterfaceClient(transport *Transport) *AgentInterfaceClient {
	return &AgentInterfaceClient{transport: transport}
}

type AgentGetRequest struct {
	InterfaceID       *int64  `json:"interfaceId,omitempty"`
	InterfaceName     *string `json:"interfaceName,omitempty"`
	InterfaceNameLike *string `json:"interfaceNameLike,omitempty"`
}

type AgentInitRequest struct {
	InterfaceID     *int64          `json:"interfaceId,omitempty"`
	PSM             string          `json:"psm"`
	MethodName      string          `json:"methodName"`
	BAMVersionID    string          `json:"bamVersionId"`
	InterfaceName   *string         `json:"interfaceName,omitempty"`
	BizDomainID     *int64          `json:"bizDomainId,omitempty"`
	Desc            *string         `json:"desc,omitempty"`
	SceneDesc       *string         `json:"sceneDesc,omitempty"`
	OwnerList       json.RawMessage `json:"ownerList,omitempty"`
	InterfaceCateID *int64          `json:"interfaceCateId,omitempty"`
	SkipAuth        *bool           `json:"skipAuth,omitempty"`
}

type AgentPayload struct {
	BAMVersionID    *string         `json:"bamVersionId,omitempty"`
	RequestInfo     json.RawMessage `json:"requestInfo,omitempty"`
	ResponseInfo    json.RawMessage `json:"responseInfo,omitempty"`
	ErrConfigList   json.RawMessage `json:"errConfigList,omitempty"`
	InterfaceName   *string         `json:"interfaceName,omitempty"`
	MethodName      *string         `json:"methodName,omitempty"`
	PSM             *string         `json:"psm,omitempty"`
	Desc            *string         `json:"desc,omitempty"`
	SceneDesc       *string         `json:"sceneDesc,omitempty"`
	OwnerList       json.RawMessage `json:"ownerList,omitempty"`
	InterfaceCateID *int64          `json:"interfaceCateId,omitempty"`
	AuthSubjectIDs  json.RawMessage `json:"authSubjectId,omitempty"`
	SkipAuth        *bool           `json:"skipAuth,omitempty"`
	SLART           *int32          `json:"slaRt,omitempty"`
	SLAAva          *string         `json:"slaAva,omitempty"`
	QPS             *int32          `json:"qps,omitempty"`
	Timeout         *int32          `json:"timeout,omitempty"`
	CallType        *int32          `json:"callType,omitempty"`
	BizSuccErrCode  *string         `json:"bizSuccErrCode,omitempty"`
	ErrCode         *string         `json:"errCode,omitempty"`
	ErrMsg          *string         `json:"errMsg,omitempty"`
	StylePatches    json.RawMessage `json:"stylePatches,omitempty"`
	ReleaseNote     *string         `json:"releaseNote,omitempty"`
}

type AgentDocPayload struct {
	Desc           *string         `json:"desc,omitempty"`
	SceneDesc      *string         `json:"sceneDesc,omitempty"`
	ReleaseNote    *string         `json:"releaseNote,omitempty"`
	RequestInfo    json.RawMessage `json:"requestInfo,omitempty"`
	ResponseInfo   json.RawMessage `json:"responseInfo,omitempty"`
	ErrConfigList  json.RawMessage `json:"errConfigList,omitempty"`
	BizSuccErrCode *string         `json:"bizSuccErrCode,omitempty"`
	ErrCode        *string         `json:"errCode,omitempty"`
	ErrMsg         *string         `json:"errMsg,omitempty"`
}

type AgentSaveRequest struct {
	InterfaceID     int64    `json:"interfaceId"`
	ModifyVersionID int64    `json:"modifyVersionId"`
	Sections        []string `json:"sections"`
	DryRun          *bool    `json:"dryRun,omitempty"`
	AgentPayload
}

type AgentDocRequest struct {
	InterfaceID     int64 `json:"interfaceId"`
	ModifyVersionID int64 `json:"modifyVersionId"`
	AutoFill        *bool `json:"autoFill,omitempty"`
	WithPreviewURL  *bool `json:"withPreviewUrl,omitempty"`
	AgentDocPayload
}

type AgentAdvanceRequest struct {
	InterfaceID     int64   `json:"interfaceId"`
	ModifyVersionID int64   `json:"modifyVersionId"`
	Step            string  `json:"step"`
	DryRun          bool    `json:"dryRun"`
	AuditReason     *string `json:"auditReason,omitempty"`
	AuditMeego      *string `json:"auditMeego,omitempty"`
	SkipReason      *string `json:"skipReason,omitempty"`
	AgentPayload
}

type AgentInterfaceSummary struct {
	InterfaceID   int64  `json:"interfaceId"`
	InterfaceName string `json:"interfaceName"`
	PSM           string `json:"psm"`
	MethodName    string `json:"methodName"`
	StatusV2      *int32 `json:"statusV2,omitempty"`
	ConfigURL     string `json:"configUrl"`
}

type AgentInterfaceErrType struct {
	ErrTypeID   int64  `json:"errTypeId"`
	ErrTypeDesc string `json:"errTypeDesc"`
}

type AgentStyleConstantEntry struct {
	Path          string  `json:"path"`
	ConstantValue *string `json:"constantValue,omitempty"`
}

type AgentRequestStyleIndex struct {
	External []string                  `json:"external"`
	Variable []string                  `json:"variable"`
	Constant []AgentStyleConstantEntry `json:"constant"`
}

type AgentFromBAM struct {
	RequestInfo  json.RawMessage `json:"requestInfo"`
	ResponseInfo json.RawMessage `json:"responseInfo"`
}

type AgentWarning struct {
	Kind    string `json:"kind"`
	ToName  string `json:"toName"`
	Message string `json:"message"`
}

type AgentTreeDiff struct {
	Added   []string `json:"added"`
	Removed []string `json:"removed"`
	Changed []string `json:"changed"`
}

type AgentSaveDiff struct {
	RequestInfo  *AgentTreeDiff `json:"requestInfo,omitempty"`
	ResponseInfo *AgentTreeDiff `json:"responseInfo,omitempty"`
}

type AgentGetResult struct {
	Envelope    Envelope
	Current     *AgentCurrent           `json:"current,omitempty"`
	List        []AgentInterfaceSummary `json:"list,omitempty"`
	ErrTypeList []AgentInterfaceErrType `json:"errTypeList,omitempty"`
	Errors      []AgentFieldError       `json:"errors,omitempty"`
}

type AgentInitResult struct {
	Envelope     Envelope
	BAMVersionID string            `json:"bamVersionId"`
	PSM          string            `json:"psm"`
	MethodName   string            `json:"methodName"`
	FromBAM      *AgentFromBAM     `json:"fromBam,omitempty"`
	Current      *AgentCurrent     `json:"current,omitempty"`
	Warnings     []AgentWarning    `json:"warnings,omitempty"`
	Errors       []AgentFieldError `json:"errors,omitempty"`
}

type AgentSaveResult struct {
	Envelope Envelope
	DryRun   bool              `json:"dryRun"`
	Applied  bool              `json:"applied"`
	Current  *AgentCurrent     `json:"current,omitempty"`
	Preview  *AgentCurrent     `json:"preview,omitempty"`
	Diff     *AgentSaveDiff    `json:"diff,omitempty"`
	Errors   []AgentFieldError `json:"errors,omitempty"`
}

type AgentDocResult struct {
	Envelope     Envelope
	Applied      *bool             `json:"applied,omitempty"`
	AutoFilled   *bool             `json:"autoFilled,omitempty"`
	Current      *AgentCurrent     `json:"current,omitempty"`
	TempDocURL   *string           `json:"tempDocUrl,omitempty"`
	RequestInfo  json.RawMessage   `json:"requestInfo,omitempty"`
	ResponseInfo json.RawMessage   `json:"responseInfo,omitempty"`
	Errors       []AgentFieldError `json:"errors,omitempty"`
}

type AgentAdvanceResult struct {
	Envelope       Envelope
	DryRun         bool              `json:"dryRun"`
	Applied        bool              `json:"applied"`
	Current        *AgentCurrent     `json:"current,omitempty"`
	Preview        *AgentCurrent     `json:"preview,omitempty"`
	Diff           *AgentSaveDiff    `json:"diff,omitempty"`
	StatusSteps    []string          `json:"statusSteps,omitempty"`
	AuditSubmitted *bool             `json:"auditSubmitted,omitempty"`
	Errors         []AgentFieldError `json:"errors,omitempty"`
}

func (c *AgentInterfaceClient) Get(
	ctx context.Context,
	request AgentGetRequest,
	options RequestOptions,
) (AgentGetResult, error) {
	query := make(url.Values, 3)
	if request.InterfaceID != nil {
		query.Set("interfaceId", strconv.FormatInt(*request.InterfaceID, 10))
	}
	if request.InterfaceName != nil {
		query.Set("interfaceName", *request.InterfaceName)
	}
	if request.InterfaceNameLike != nil {
		query.Set("interfaceNameLike", *request.InterfaceNameLike)
	}
	envelope, err := c.do(ctx, http.MethodGet, agentInterfaceGetPath, query, nil, options)
	return decodeAgentResult[AgentGetResult](envelope, err)
}

func (c *AgentInterfaceClient) Init(
	ctx context.Context,
	request AgentInitRequest,
	options RequestOptions,
) (AgentInitResult, error) {
	envelope, err := c.do(ctx, http.MethodPost, agentInterfaceInitPath, nil, request, options)
	return decodeAgentResult[AgentInitResult](envelope, err)
}

func (c *AgentInterfaceClient) Save(
	ctx context.Context,
	request AgentSaveRequest,
	options RequestOptions,
) (AgentSaveResult, error) {
	envelope, err := c.do(ctx, http.MethodPost, agentInterfaceSavePath, nil, request, options)
	return decodeAgentResult[AgentSaveResult](envelope, err)
}

func (c *AgentInterfaceClient) Doc(
	ctx context.Context,
	request AgentDocRequest,
	options RequestOptions,
) (AgentDocResult, error) {
	envelope, err := c.do(ctx, http.MethodPost, agentInterfaceDocPath, nil, request, options)
	return decodeAgentResult[AgentDocResult](envelope, err)
}

func (c *AgentInterfaceClient) AdvanceStep(
	ctx context.Context,
	request AgentAdvanceRequest,
	options RequestOptions,
) (AgentAdvanceResult, error) {
	envelope, err := c.do(ctx, http.MethodPost, agentInterfaceAdvancePath, nil, request, options)
	return decodeAgentResult[AgentAdvanceResult](envelope, err)
}

func (c *AgentInterfaceClient) do(
	ctx context.Context,
	method string,
	path string,
	query url.Values,
	body any,
	options RequestOptions,
) (Envelope, error) {
	return c.transport.Do(ctx, method, path, query, body, options)
}

func decodeAgentResult[T any](envelope Envelope, requestErr error) (T, error) {
	var result T
	if requestErr != nil {
		return result, requestErr
	}
	if len(envelope.Data) != 0 && string(envelope.Data) != "null" {
		if err := json.Unmarshal(envelope.Data, &result); err != nil {
			return result, errors.New("解析 Agent 响应失败")
		}
	}
	setAgentResultEnvelope(&result, envelope)
	return result, nil
}

func setAgentResultEnvelope(result any, envelope Envelope) {
	switch typed := result.(type) {
	case *AgentGetResult:
		typed.Envelope = envelope
	case *AgentInitResult:
		typed.Envelope = envelope
	case *AgentSaveResult:
		typed.Envelope = envelope
	case *AgentDocResult:
		typed.Envelope = envelope
	case *AgentAdvanceResult:
		typed.Envelope = envelope
	}
}
