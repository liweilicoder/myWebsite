package djt

import (
	"context"
	"io"
	"net/http"
	"strings"
	"testing"

	"code.byted.org/temai/open_cli/internal/djt/auth"
)

func TestApplyBizDomainAuthRequiresDomainIDs(t *testing.T) {
	client := NewClient(http.DefaultClient)
	_, err := client.ApplyBizDomainAuth(context.Background(), RequestOptions{
		Credentials: auth.Credentials{AccessToken: "token"},
	}, nil)
	if err == nil || !strings.Contains(err.Error(), "domainIds") {
		t.Fatalf("err=%v", err)
	}
}

func TestApplyBizDomainAuthPOST(t *testing.T) {
	var request *http.Request
	client := NewClient(httpDoerFunc(func(got *http.Request) (*http.Response, error) {
		request = got
		return jsonResponse(http.StatusOK, `{"code":0,"message":"success","data":{"auditManageUrl":"https://djt.bytedance.net/auditManage/task?type=domainPerm"}}`), nil
	}))
	result, err := client.ApplyBizDomainAuth(context.Background(), RequestOptions{
		Credentials: auth.Credentials{AccessToken: "token-secret"},
	}, []int64{8})
	if err != nil {
		t.Fatal(err)
	}
	if request.Method != http.MethodPost || request.URL.Path != "/api/djt-cli/domain/apply" {
		t.Fatalf("request=%s %s", request.Method, request.URL.String())
	}
	body, _ := io.ReadAll(request.Body)
	if !strings.Contains(string(body), `"domainIds":[8]`) {
		t.Fatalf("body=%s", body)
	}
	if result.Data.AuditManageURL == "" {
		t.Fatalf("result=%+v", result)
	}
}
