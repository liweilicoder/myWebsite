package djt

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
	"testing"

	"code.byted.org/temai/open_cli/internal/djt/auth"
)

type httpDoerFunc func(*http.Request) (*http.Response, error)

func (f httpDoerFunc) Do(request *http.Request) (*http.Response, error) {
	return f(request)
}

func TestTransportUsesFixedOriginAndHeaders(t *testing.T) {
	doer := httpDoerFunc(func(request *http.Request) (*http.Response, error) {
		if got := request.URL.String(); got != "https://djt.bytedance.net/api/djt-cli/agent/interface/get?interfaceId=2846" {
			t.Fatalf("url=%s", got)
		}
		if got := request.Header.Get(AuthorizationHeader); got != "Bearer "+testToken {
			t.Fatalf("authorization=%q", got)
		}
		if got := request.Header.Get("Accept"); got != "application/json" {
			t.Fatalf("accept=%q", got)
		}
		if request.Header.Get("x-use-ppe") != "1" || request.Header.Get("x-tt-env") != "ppe_djt_cli" {
			t.Fatalf("headers=%v", request.Header)
		}
		return jsonResponse(http.StatusOK, `{"code":0,"message":"success","data":{"current":{}}}`), nil
	})

	query := url.Values{"interfaceId": {"2846"}}
	got, err := NewTransport(doer).Do(
		context.Background(),
		http.MethodGet,
		"/api/djt-cli/agent/interface/get",
		query,
		nil,
		RequestOptions{
			Credentials: testCredentials(),
			PPE:         PPEConfig{Enabled: true, Env: "ppe_djt_cli"},
		},
	)
	if err != nil || got.Code != 0 || string(got.Data) != `{"current":{}}` {
		t.Fatalf("got=%+v err=%v", got, err)
	}
}

func TestTransportRedactsOnlyCurrentTokenFromSuccessfulData(t *testing.T) {
	response := `{"code":0,"message":"success\n\t` + testToken + `\u001b[31m","data":{"` + testToken + `-key":"line 1\n\tline 2\u001b[31m","nested":["prefix ` + testToken + ` suffix",{"token":"` + testToken + `"}]}}`
	envelope, err := NewTransport(responseDoer(http.StatusOK, response)).Do(
		context.Background(),
		http.MethodGet,
		"/api/djt-cli/agent/interface/get",
		nil,
		nil,
		RequestOptions{Credentials: testCredentials()},
	)
	if err != nil {
		t.Fatal(err)
	}
	if envelope.Message != "success  [REDACTED]" {
		t.Fatalf("message=%q", envelope.Message)
	}
	if !json.Valid(envelope.Data) || bytes.Contains(envelope.Data, []byte(testToken)) {
		t.Fatalf("data 必须是合法且不泄漏 token 的 JSON: %s", envelope.Data)
	}

	var data map[string]any
	if err := json.Unmarshal(envelope.Data, &data); err != nil {
		t.Fatal(err)
	}
	if got := data["[REDACTED]-key"]; got != "line 1\n\tline 2\x1b[31m" {
		t.Fatalf("业务字符串语义被改变: %q", got)
	}
	nested, ok := data["nested"].([]any)
	if !ok || len(nested) != 2 || nested[0] != "prefix [REDACTED] suffix" {
		t.Fatalf("nested=%#v", data["nested"])
	}
	nestedObject, ok := nested[1].(map[string]any)
	if !ok || nestedObject["token"] != "[REDACTED]" {
		t.Fatalf("nested object=%#v", nested[1])
	}
}

func TestTransportMarshalsPOSTBody(t *testing.T) {
	doer := httpDoerFunc(func(request *http.Request) (*http.Response, error) {
		if request.Method != http.MethodPost {
			t.Fatalf("method=%q", request.Method)
		}
		if got := request.Header.Get("Content-Type"); got != "application/json" {
			t.Fatalf("content-type=%q", got)
		}
		payload, err := io.ReadAll(request.Body)
		if err != nil {
			t.Fatal(err)
		}
		if got := string(payload); got != `{"dryRun":true}` {
			t.Fatalf("body=%s", got)
		}
		return jsonResponse(http.StatusOK, `{"code":0,"message":"success","data":{}}`), nil
	})

	_, err := NewTransport(doer).Do(
		context.Background(),
		http.MethodPost,
		"/api/djt-cli/agent/interface/save",
		nil,
		map[string]any{"dryRun": true},
		RequestOptions{Credentials: testCredentials()},
	)
	if err != nil {
		t.Fatal(err)
	}
}

func TestTransportReturnsStructuredRemoteError(t *testing.T) {
	doer := httpDoerFunc(func(*http.Request) (*http.Response, error) {
		return jsonResponse(http.StatusOK, `{"code":8000037,"message":"版本冲突 `+testToken+`\u001b[31m","errors":[{"field":"modifyVersionId","reason":"落后","fix":"重试","suggestedValue":"43"}],"data":{"current":{"interfaceId":2846,"modifyVersionId":43,"statusV2":110}}}`), nil
	})

	_, err := NewTransport(doer).Do(
		context.Background(),
		http.MethodPost,
		"/api/djt-cli/agent/interface/save",
		nil,
		map[string]any{"dryRun": true},
		RequestOptions{Credentials: testCredentials()},
	)
	var remote *RemoteError
	if !errors.As(err, &remote) {
		t.Fatalf("err=%T %v", err, err)
	}
	if remote.HTTPStatus != http.StatusOK || remote.Code != 8000037 {
		t.Fatalf("remote=%+v", remote)
	}
	if len(remote.Errors) != 1 || remote.Errors[0].SuggestedValue == nil || *remote.Errors[0].SuggestedValue != "43" {
		t.Fatalf("errors=%+v", remote.Errors)
	}
	if remote.Current == nil || remote.Current.ModifyVersionID != 43 || remote.Current.StatusV2 == nil || *remote.Current.StatusV2 != 110 {
		t.Fatalf("current=%+v", remote.Current)
	}
	want := "点将台请求失败: code=8000037 message=版本冲突 [REDACTED]\n" +
		"- field=modifyVersionId reason=落后 fix=重试 suggestedValue=43\n" +
		"- current.interfaceId=2846 current.modifyVersionId=43 current.statusV2=110"
	if got := err.Error(); got != want {
		t.Fatalf("error=\n%s\nwant=\n%s", got, want)
	}
	assertDoesNotContainSensitiveResponse(t, err)
}

func TestTransportSanitizesAllRemoteErrorCurrentStringsAndRawJSON(t *testing.T) {
	const injected = "token-\\u001b[31msecret\\u0007"
	response := `{"code":40000,"message":"failed","data":{"current":{` +
		`"interfaceId":2846,` +
		`"interfaceName":"` + injected + `","psm":"` + injected + `","methodName":"` + injected + `",` +
		`"boundBamVersionId":"` + injected + `","modifyVersionId":43,"configUrl":"` + injected + `",` +
		`"requestInfo":{"` + injected + `":"` + injected + `"},` +
		`"responseInfo":["` + injected + `"],"errConfigList":[{"message":"` + injected + `"}],` +
		`"owners":["` + injected + `"],"reservedInnerVarNames":["` + injected + `"],` +
		`"requestStyleIndex":{"external":["` + injected + `"],"variable":["` + injected + `"],` +
		`"constant":[{"path":"` + injected + `","constantValue":"` + injected + `"}]},` +
		`"configPhase":"` + injected + `","errCode":"` + injected + `","errMsg":"` + injected + `",` +
		`"bizSuccErrCode":"` + injected + `","desc":"` + injected + `","sceneDesc":"` + injected + `",` +
		`"releaseNote":"` + injected + `","nextStep":"` + injected + `"}}}`

	_, err := NewTransport(responseDoer(http.StatusOK, response)).Do(
		context.Background(),
		http.MethodGet,
		"/api/djt-cli/agent/interface/get",
		nil,
		nil,
		RequestOptions{Credentials: testCredentials()},
	)
	var remote *RemoteError
	if !errors.As(err, &remote) || remote.Current == nil {
		t.Fatalf("err=%T %v", err, err)
	}

	encoded, marshalErr := json.Marshal(remote.Current)
	if marshalErr != nil {
		t.Fatal(marshalErr)
	}
	assertSanitizedJSONStrings(t, encoded)
	for name, raw := range map[string]json.RawMessage{
		"requestInfo":   remote.Current.RequestInfo,
		"responseInfo":  remote.Current.ResponseInfo,
		"errConfigList": remote.Current.ErrConfigList,
	} {
		if !json.Valid(raw) {
			t.Fatalf("%s 脱敏后不是合法 JSON: %q", name, raw)
		}
	}
	if diagnostic := remote.Error(); strings.Contains(diagnostic, testToken) || strings.ContainsAny(diagnostic, "\x00\x07\x1b\r") {
		t.Fatalf("RemoteError.Error() 泄漏敏感内容: %q", diagnostic)
	}
}

func assertSanitizedJSONStrings(t *testing.T, data []byte) {
	t.Helper()
	var value any
	if err := json.Unmarshal(data, &value); err != nil {
		t.Fatalf("解码公开错误对象: %v; JSON=%q", err, data)
	}
	var visit func(any)
	visit = func(current any) {
		switch typed := current.(type) {
		case string:
			if strings.Contains(typed, testToken) || strings.ContainsAny(typed, "\x00\x07\x1b\r\n\t") {
				t.Fatalf("公开错误对象泄漏敏感字符串: %q", typed)
			}
		case []any:
			for _, item := range typed {
				visit(item)
			}
		case map[string]any:
			for key, item := range typed {
				visit(key)
				visit(item)
			}
		}
	}
	visit(value)
}

func TestTransportAgentResponseLimitEightMiB(t *testing.T) {
	if MaxResponseBytes != 8<<20 {
		t.Fatalf("MaxResponseBytes=%d want=%d", MaxResponseBytes, 8<<20)
	}

	t.Run("larger than one MiB and at most eight MiB succeeds", func(t *testing.T) {
		body := `{"code":0,"message":"success","data":{"payload":"` + strings.Repeat("x", (1<<20)+1) + `"}}`
		envelope, err := NewTransport(responseDoer(http.StatusOK, body)).Do(
			context.Background(),
			http.MethodGet,
			"/api/djt-cli/agent/interface/get",
			nil,
			nil,
			RequestOptions{Credentials: testCredentials()},
		)
		if err != nil || envelope.Code != 0 {
			t.Fatalf("envelope=%+v err=%v", envelope, err)
		}
	})

	t.Run("larger than eight MiB fails", func(t *testing.T) {
		_, err := NewTransport(responseDoer(http.StatusOK, strings.Repeat("x", (8<<20)+1))).Do(
			context.Background(),
			http.MethodGet,
			"/api/djt-cli/agent/interface/get",
			nil,
			nil,
			RequestOptions{Credentials: testCredentials()},
		)
		if err == nil || !strings.Contains(err.Error(), "超过 8 MiB") {
			t.Fatalf("err=%v", err)
		}
		assertDoesNotContainSensitiveResponse(t, err)
	})
}

func TestTransportFailureMatrix(t *testing.T) {
	tests := []struct {
		name        string
		doer        auth.HTTPDoer
		options     RequestOptions
		wantError   string
		wantContext error
	}{
		{
			name:      "HTTP 302",
			doer:      responseDoer(http.StatusFound, `redirect-body-`+testToken),
			options:   RequestOptions{Credentials: testCredentials()},
			wantError: "HTTP 302",
		},
		{
			name:      "HTTP 401",
			doer:      responseDoer(http.StatusUnauthorized, `unauthorized-body-`+testToken),
			options:   RequestOptions{Credentials: testCredentials()},
			wantError: "HTTP 401",
		},
		{
			name:      "HTTP 500",
			doer:      responseDoer(http.StatusInternalServerError, `server-body-`+testToken),
			options:   RequestOptions{Credentials: testCredentials()},
			wantError: "HTTP 500",
		},
		{
			name:      "missing code",
			doer:      responseDoer(http.StatusOK, `{"message":"body-`+testToken+`","data":{}}`),
			options:   RequestOptions{Credentials: testCredentials()},
			wantError: "缺少 code",
		},
		{
			name:      "invalid JSON",
			doer:      responseDoer(http.StatusOK, `invalid-json-`+testToken),
			options:   RequestOptions{Credentials: testCredentials()},
			wantError: "解析点将台响应失败",
		},
		{
			name:      "over MaxResponseBytes",
			doer:      responseDoer(http.StatusOK, strings.Repeat("x", MaxResponseBytes)+testToken),
			options:   RequestOptions{Credentials: testCredentials()},
			wantError: "超过 8 MiB",
		},
		{
			name: "PPE disabled",
			doer: httpDoerFunc(func(request *http.Request) (*http.Response, error) {
				if got := request.Header.Get("x-use-ppe"); got != "" {
					t.Fatalf("x-use-ppe=%q", got)
				}
				if got := request.Header.Get("x-tt-env"); got != "" {
					t.Fatalf("x-tt-env=%q", got)
				}
				return jsonResponse(http.StatusOK, `{"code":0,"message":"success","data":{}}`), nil
			}),
			options: RequestOptions{Credentials: testCredentials(), PPE: PPEConfig{Env: "ignored"}},
		},
		{
			name: "context canceled",
			doer: httpDoerFunc(func(request *http.Request) (*http.Response, error) {
				return nil, fmt.Errorf("upstream %s: %w", testToken, request.Context().Err())
			}),
			options:     RequestOptions{Credentials: testCredentials()},
			wantError:   context.Canceled.Error(),
			wantContext: context.Canceled,
		},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			ctx := context.Background()
			if test.wantContext != nil {
				var cancel context.CancelFunc
				ctx, cancel = context.WithCancel(ctx)
				cancel()
			}
			_, err := NewTransport(test.doer).Do(ctx, http.MethodGet, "/api/test", nil, nil, test.options)
			if test.wantError == "" {
				if err != nil {
					t.Fatal(err)
				}
				return
			}
			if err == nil || !strings.Contains(err.Error(), test.wantError) {
				t.Fatalf("err=%v want substring=%q", err, test.wantError)
			}
			if test.wantContext != nil && !errors.Is(err, test.wantContext) {
				t.Fatalf("err=%v want errors.Is(%v)", err, test.wantContext)
			}
			assertDoesNotContainSensitiveResponse(t, err)
		})
	}
}

func TestTransportRejectsUnsafeInputsBeforeHTTP(t *testing.T) {
	tests := []struct {
		name    string
		method  string
		path    string
		body    any
		options RequestOptions
		want    string
	}{
		{name: "absolute path", method: http.MethodGet, path: "https://evil.example/api/test", want: "path"},
		{name: "non API path", method: http.MethodGet, path: "/health", want: "path"},
		{name: "GET body", method: http.MethodGet, path: "/api/test", body: map[string]any{}, want: "GET"},
		{name: "invalid PPE env", method: http.MethodGet, path: "/api/test", options: RequestOptions{PPE: PPEConfig{Enabled: true, Env: "ppe\r\ninjected"}}, want: "PPE"},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			called := false
			doer := httpDoerFunc(func(*http.Request) (*http.Response, error) {
				called = true
				return nil, errors.New("unexpected HTTP call")
			})
			options := test.options
			options.Credentials = testCredentials()
			_, err := NewTransport(doer).Do(context.Background(), test.method, test.path, nil, test.body, options)
			if err == nil || !strings.Contains(err.Error(), test.want) {
				t.Fatalf("err=%v want substring=%q", err, test.want)
			}
			if called {
				t.Fatal("unsafe input reached HTTP doer")
			}
			assertDoesNotContainSensitiveResponse(t, err)
		})
	}
}

func responseDoer(status int, body string) auth.HTTPDoer {
	return httpDoerFunc(func(*http.Request) (*http.Response, error) {
		return jsonResponse(status, body), nil
	})
}

func jsonResponse(status int, body string) *http.Response {
	return &http.Response{
		StatusCode: status,
		Body:       io.NopCloser(strings.NewReader(body)),
		Header:     make(http.Header),
	}
}

func testCredentials() auth.Credentials {
	return auth.Credentials{
		BaseURL:     "https://credential-origin-must-be-ignored.example",
		AccessToken: testToken,
		TokenType:   "Bearer",
	}
}

func TestRedactTokenFromJSONKeepsAmpersandInURL(t *testing.T) {
	in := json.RawMessage(`{"auditManageUrl":"https://djt.bytedance.net/auditManage/task?type=domainPerm&recordId=1","token":"secret"}`)
	got, err := redactTokenFromJSON(in, "secret")
	if err != nil {
		t.Fatal(err)
	}
	if bytes.Contains(got, []byte(`\u0026`)) {
		t.Fatalf("%s", got)
	}
	if !bytes.Contains(got, []byte(`type=domainPerm&recordId=1`)) {
		t.Fatalf("%s", got)
	}
	if bytes.Contains(got, []byte("secret")) {
		t.Fatalf("token leaked: %s", got)
	}
}

func TestSanitizeRawMessageKeepsAmpersandInURL(t *testing.T) {
	in := json.RawMessage(`{"href":"https://example.test/x?a=1&b=2"}`)
	got := sanitizeRawMessage(in, "secret")
	if bytes.Contains(got, []byte(`\u0026`)) {
		t.Fatalf("%s", got)
	}
	if !bytes.Contains(got, []byte(`a=1&b=2`)) {
		t.Fatalf("%s", got)
	}
}

func assertDoesNotContainSensitiveResponse(t *testing.T, err error) {
	t.Helper()
	if err == nil {
		return
	}
	for _, forbidden := range []string{testToken, "redirect-body", "unauthorized-body", "server-body", "invalid-json", "\x1b"} {
		if strings.Contains(err.Error(), forbidden) {
			t.Fatalf("unsafe error=%q contains %q", err, forbidden)
		}
	}
}
