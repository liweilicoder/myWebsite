package djt

import (
	"context"
	"errors"
	"fmt"
)

const agentSpiStatusWaitCommit int64 = 201

type AgentSPIService struct {
	api AgentSPIAPI
}

func NewAgentSPIService(api AgentSPIAPI) *AgentSPIService {
	return &AgentSPIService{api: api}
}

func (s *AgentSPIService) GetInterface(ctx context.Context, request AgentSpiGetInterfaceRequest, options RequestOptions) (AgentSpiGetInterfaceResult, error) {
	return s.api.GetInterface(ctx, request, options)
}

func (s *AgentSPIService) ListInterface(ctx context.Context, request AgentSpiListInterfaceRequest, options RequestOptions) (AgentSpiListInterfaceResult, error) {
	return s.api.ListInterface(ctx, request, options)
}

func (s *AgentSPIService) SaveInterface(ctx context.Context, request AgentSpiSaveInterfaceRequest, options RequestOptions) (AgentSpiSaveInterfaceResult, error) {
	return s.api.SaveInterface(ctx, request, options)
}

func (s *AgentSPIService) SubmitReview(ctx context.Context, request AgentSpiSubmitReviewRequest, options RequestOptions) (AgentSpiSubmitReviewResult, error) {
	if request.DryRun {
		return s.api.SubmitReview(ctx, request, options)
	}

	getResult, err := s.api.GetInterface(ctx, AgentSpiGetInterfaceRequest{InterfaceID: &request.InterfaceID}, options)
	if err != nil {
		return AgentSpiSubmitReviewResult{}, fmt.Errorf("提交审核前获取接口失败: %w", err)
	}
	if getResult.Current == nil {
		return AgentSpiSubmitReviewResult{}, errors.New("提交审核前响应缺少 current")
	}
	if getResult.Current.Status != agentSpiStatusWaitCommit {
		return AgentSpiSubmitReviewResult{}, fmt.Errorf("status=%d 不允许提交审核，当前必须为 201", getResult.Current.Status)
	}
	if getResult.Current.ModifyVersionID != 0 && getResult.Current.ModifyVersionID != request.ModifyVersionID {
		return AgentSpiSubmitReviewResult{}, fmt.Errorf(
			"modifyVersionId 冲突: 请求=%d 当前=%d，请重新 get",
			request.ModifyVersionID,
			getResult.Current.ModifyVersionID,
		)
	}
	return s.api.SubmitReview(ctx, request, options)
}

func (s *AgentSPIService) SceneList(ctx context.Context, request AgentSpiSceneListRequest, options RequestOptions) (AgentSpiSceneListResult, error) {
	return s.api.SceneList(ctx, request, options)
}

func (s *AgentSPIService) SceneGet(ctx context.Context, request AgentSpiSceneGetRequest, options RequestOptions) (AgentSpiSceneGetResult, error) {
	return s.api.SceneGet(ctx, request, options)
}

func (s *AgentSPIService) SceneSave(ctx context.Context, request AgentSpiSceneSaveRequest, options RequestOptions) (AgentSpiSceneSaveResult, error) {
	return s.api.SceneSave(ctx, request, options)
}

func (s *AgentSPIService) SyncBoe(ctx context.Context, request AgentSpiSceneSyncBoeRequest, options RequestOptions) (AgentSpiSceneSyncBoeResult, error) {
	return s.api.SyncBoe(ctx, request, options)
}

func (s *AgentSPIService) AccessAppList(ctx context.Context, request AgentSpiAccessAppListRequest, options RequestOptions) (AgentSpiAccessAppListResult, error) {
	return s.api.AccessAppList(ctx, request, options)
}

func (s *AgentSPIService) AccessAppGet(ctx context.Context, request AgentSpiAccessAppGetRequest, options RequestOptions) (AgentSpiAccessAppGetResult, error) {
	return s.api.AccessAppGet(ctx, request, options)
}

func (s *AgentSPIService) AccessAppSave(ctx context.Context, request AgentSpiAccessAppSaveRequest, options RequestOptions) (AgentSpiAccessAppSaveResult, error) {
	return s.api.AccessAppSave(ctx, request, options)
}

func (s *AgentSPIService) AccessAppEnable(ctx context.Context, request AgentSpiAccessAppEnableRequest, options RequestOptions) (AgentSpiAccessAppEnableResult, error) {
	return s.api.AccessAppEnable(ctx, request, options)
}

func (s *AgentSPIService) CancelUpgrade(ctx context.Context, request AgentSpiCancelUpgradeRequest, options RequestOptions) (AgentSpiCancelUpgradeResult, error) {
	return s.api.CancelUpgrade(ctx, request, options)
}
