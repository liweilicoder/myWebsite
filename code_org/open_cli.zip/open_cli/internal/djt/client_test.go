package djt

import (
	"context"
	"errors"
	"net/http"
	"reflect"
	"strings"
	"testing"

	"code.byted.org/temai/open_cli/internal/djt/auth"
)

const testToken = "token-must-not-leak"

func TestListBizDomainsSendsGETWithoutQueryOrBodyAndDecodesCamelCase(t *testing.T) {
	doer := httpDoerFunc(func(request *http.Request) (*http.Response, error) {
		if request.Method != http.MethodGet || request.URL.Path != "/api/domain/list" || request.URL.RawQuery != "" {
			t.Fatalf("request=%s %s", request.Method, request.URL.String())
		}
		if request.Body != nil {
			t.Fatal("GET /api/domain/list must not contain body")
		}
		if request.Header.Get("x-use-ppe") != "1" || request.Header.Get("x-tt-env") != "ppe_djt_cli" {
			t.Fatalf("PPE headers=%v", request.Header)
		}
		return jsonResponse(http.StatusOK, `{"code":0,"message":"success","data":{"total":2,"domainInfoList":[{"domainId":8,"domainName":"订单","suffixList":["order"]}],"ownerdomainInfoList":[{"domainId":8,"domainName":"订单","suffixList":["order"]}]}}`), nil
	})

	got, err := NewClient(doer).ListBizDomains(context.Background(), RequestOptions{
		Credentials: testCredentials(),
		PPE:         PPEConfig{Enabled: true, Env: "ppe_djt_cli"},
	})
	if err != nil {
		t.Fatal(err)
	}
	if got.Envelope.Code != 0 || got.Envelope.Message != "success" || got.Data.Total != 2 {
		t.Fatalf("result=%+v", got)
	}
	wantDomains := []DomainInfo{{DomainID: 8, DomainName: "订单", SuffixList: []string{"order"}}}
	if !reflect.DeepEqual(got.Data.DomainInfoList, wantDomains) || !reflect.DeepEqual(got.Data.OwnerdomainInfoList, wantDomains) {
		t.Fatalf("data=%+v want=%+v", got.Data, wantDomains)
	}
}

func TestListBizDomainsReturnsBusinessError(t *testing.T) {
	_, err := NewClient(responseDoer(http.StatusOK, `{"code":4001,"message":"无权限","data":{}}`)).ListBizDomains(
		context.Background(),
		RequestOptions{Credentials: testCredentials()},
	)
	var remote *RemoteError
	if !errors.As(err, &remote) || remote.Code != 4001 || remote.Message != "无权限" {
		t.Fatalf("err=%T %v remote=%+v", err, err, remote)
	}
}

func TestListBizDomainsRejectsResponseLargerThanOneMiB(t *testing.T) {
	_, err := NewClient(responseDoer(http.StatusOK, strings.Repeat("x", maxResponseBytes+1))).ListBizDomains(
		context.Background(),
		RequestOptions{Credentials: testCredentials()},
	)
	assertSafeError(t, err, "超过 1 MiB")
}

func containsControlCharacter(value string) bool {
	for _, r := range value {
		if r < 0x20 || r == 0x7f {
			return true
		}
	}
	return false
}

func credentials(baseURL string) auth.Credentials {
	return auth.Credentials{BaseURL: baseURL, AccessToken: testToken, TokenType: "Bearer"}
}

func assertSafeError(t *testing.T, err error, contains string) {
	t.Helper()
	if err == nil {
		t.Fatal("expected error")
	}
	if !strings.Contains(err.Error(), contains) {
		t.Fatalf("err=%v want substring %q", err, contains)
	}
	if strings.Contains(err.Error(), testToken) {
		t.Fatalf("error leaked token: %v", err)
	}
}
