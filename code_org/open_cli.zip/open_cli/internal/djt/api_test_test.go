package djt

import (
	"context"
	"encoding/json"
	"io"
	"net/http"
	"testing"
)

func TestAPITestClientEndpoints(t *testing.T) {
	var gotMethod, gotPath string
	doer := httpDoerFunc(func(request *http.Request) (*http.Response, error) {
		gotMethod, gotPath = request.Method, request.URL.Path
		_, _ = io.ReadAll(request.Body)
		return jsonResponse(http.StatusOK, `{"code":0,"message":"success","data":{"interfaceId":2684,"interfaceName":"/test/zzhTestDDD","env":"PPE","resultJson":"{\"code\":10000}","state":2}}`), nil
	})
	client := NewAPITestClient(NewTransport(doer))
	result, err := client.Execute(context.Background(), APITestRequest{
		InterfaceName: "/test/zzhTestDDD",
		Environment:   "PPE",
		Lane:          apiTestStringPointer("ppe_djt_cli"),
		Parameters:    json.RawMessage(`{"shop_id":1}`),
	}, RequestOptions{Credentials: testCredentials()})
	if err != nil {
		t.Fatal(err)
	}
	if gotMethod != http.MethodPost || gotPath != "/api/djt-cli/agent/api-test/execute" {
		t.Fatalf("request = %s %s", gotMethod, gotPath)
	}
	if result.State != 2 || result.InterfaceName != "/test/zzhTestDDD" {
		t.Fatalf("result = %+v", result)
	}
}

func TestAPITestAddAuthEndpoint(t *testing.T) {
	var gotMethod, gotPath string
	doer := httpDoerFunc(func(request *http.Request) (*http.Response, error) {
		gotMethod, gotPath = request.Method, request.URL.Path
		return jsonResponse(http.StatusOK, `{"code":0,"message":"success","data":{"authId":"90419","authSubjectBizId":0,"env":"PPE"}}`), nil
	})
	client := NewAPITestClient(NewTransport(doer))
	_, err := client.AddAuth(context.Background(), APITestAuthRequest{AuthID: "90419", AuthSubjectBizID: 0, Environment: "PPE"}, RequestOptions{Credentials: testCredentials()})
	if err != nil {
		t.Fatal(err)
	}
	if gotMethod != http.MethodPost || gotPath != "/api/djt-cli/agent/api-test/auth/add" {
		t.Fatalf("request = %s %s", gotMethod, gotPath)
	}
}

func apiTestStringPointer(value string) *string { return &value }
