package skill

import (
	"os"
	"path/filepath"
	"testing"

	coreskill "code.byted.org/temai/open_cli/internal/core/skill"
)

func TestBundleMatchesCanonicalSkillDirectory(t *testing.T) {
	root := filepath.Join("..", "..", "..", "skills", "djt")
	want := map[string][]byte{}
	err := filepath.WalkDir(root, func(path string, entry os.DirEntry, err error) error {
		if err != nil {
			return err
		}
		if entry.IsDir() {
			return nil
		}
		relative, err := filepath.Rel(root, path)
		if err != nil {
			return err
		}
		content, err := os.ReadFile(path)
		if err != nil {
			return err
		}
		want[filepath.ToSlash(relative)] = content
		return nil
	})
	if err != nil {
		t.Fatal(err)
	}
	got := Bundle()
	if got.Name != "djt" {
		t.Fatalf("name=%q", got.Name)
	}
	if len(got.Files) != len(want) {
		t.Fatalf("embed 文件数=%d want=%d", len(got.Files), len(want))
	}
	for _, file := range got.Files {
		content, exists := want[file.Path]
		if !exists || string(file.Content) != string(content) {
			t.Fatalf("embed 文件不一致: %s", file.Path)
		}
	}
	got.Files[0].Content[0] ^= 0xff
	fresh := Bundle()
	if string(fresh.Files[0].Content) != string(want[fresh.Files[0].Path]) {
		t.Fatal("Bundle 应返回独立副本")
	}
	_ = coreskill.Bundle{}
}
