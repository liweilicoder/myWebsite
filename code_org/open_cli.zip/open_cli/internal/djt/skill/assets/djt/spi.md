# SPI Agent 手册

与 [`api.md`](api.md) 同级，专用于 `doudian-open-cli djt spi`。**共享登录、业务域、PPE、JSON source** 见 [`SKILL.md`](SKILL.md)。

## 命令树

```text
doudian-open-cli djt spi
├── scene
│   ├── list
│   ├── get
│   ├── save
│   ├── sync-boe
│   └── access-app
│       ├── list
│       ├── get
│       ├── save
│       └── enable
└── interface
    ├── list
    ├── get
    ├── save
    ├── submit-review
    └── cancel-upgrade
```

父命令 `spi` 不执行操作；leaf 不接受位置参数。PPE 泳道挂在 **`djt spi` 父命令**：

```bash
doudian-open-cli djt spi --use-ppe --ppe-env ppe_你的泳道 scene list --output json
```

## 能力边界（与网页对齐）

| 能做 | 不能做 |
|------|--------|
| 创建场景（name + desc + bizDomainId） | 场景改名、改描述、绑已有接口、上线/下线 |
| 模糊搜索/列表/查看 SPI 接口 | 任意改 status、发布 |
| 创建/更新 SPI 接口草稿、提审到 301 | 审核结论 |
| 撤销升级（仅 status=201） | 取消审核 |
| 接入：列表/详情（含 impl URL）/新建/启用 | 接入禁用、删除 |
| 同步 BOE（可选） | Mock、压测 |

更新接口时 **不允许改名**（CLI 与服务端均强制使用库中 `interfaceName`）。

## 必须执行的完整流程

```text
login/status → biz-domain list（展示给用户，禁止自动选域）→
scene save --dry-run → scene save --apply →
（可选）interface list 定位接口 / access-app list|get 查看接入 →
json_to_spi_param_tree.py → 补必填/加密/Map/Header →
interface save --dry-run → 检查 preview/errors →
interface save --apply（新建加 --confirmed-by-user）→
interface get（记录 modifyVersionId）→
submit-review --dry-run → submit-review --apply →
网页审核（CLI 停止）
```

可选：`access-app save` → `access-app enable --apply`；`scene sync-boe --dry-run/--apply`。

## 校验阶段

与 open-config 前端一致，分两阶段：

| 阶段 | 命令 | 校验内容 |
|------|------|----------|
| config | `scene save`、`interface save` | `desc`、`userSceneDesc`、`httpMethod`、`timeout`、非空 request/response、headers、errorInfoList 等 |
| doc | `submit-review` | 参数 `example`/`description`（Struct 除外）、`errorInfoList[].desc` 等 |

失败时 `data.errors[]` 含 `field`、`reason`、`fix`——逐项修正后重试 dry-run，不要猜。

## 1. 场景

### 查询

```bash
doudian-open-cli djt spi scene list --scene-name ppe --page 1 --page-size 20 --output json

doudian-open-cli djt spi scene get --scene-id 248 --output json
# 或精确名称（二选一）：
doudian-open-cli djt spi scene get --scene-name your_scene --output json
```

### 创建

```bash
doudian-open-cli djt biz-domain list --output json

doudian-open-cli djt spi scene save \
  --scene-name your_scene --scene-desc '场景描述' --biz-domain-id 8 \
  --dry-run --output json

doudian-open-cli djt spi scene save \
  --scene-name your_scene --scene-desc '场景描述' --biz-domain-id 8 \
  --apply --output json
```

`--biz-domain-id` 必填且 > 0；`sceneDesc` 必填。仅创建，不支持更新已有场景。

### 同步 BOE（可选）

```bash
doudian-open-cli djt spi scene sync-boe \
  --scene-id 248 --app-ids '[12345,67890]' \
  --dry-run --output json

doudian-open-cli djt spi scene sync-boe \
  --scene-id 248 --app-ids @app-ids.json \
  --apply --output json
```

`--app-ids` 必须是 **JSON 整数数组**（inline、`@file` 或 `@-`），不能传单个裸数字。

## 2. 接口草稿

### 本地 JSON → 字段树

```bash
python3 scripts/json_to_spi_param_tree.py \
  --kind request --in request-example.json --out request-info.json
python3 scripts/json_to_spi_param_tree.py \
  --kind response --in response-example.json --out response-info.json
```

只做本地转换，**不得联网**；通过后仍须 CLI dry-run。

### 新建接口

```bash
doudian-open-cli djt biz-domain list --output json
# 确认 sceneId 存在、interfaceName = 业务域前缀/名称

doudian-open-cli djt spi interface save \
  --scene-id 248 --interface-name prefix/name --biz-domain-id 8 \
  --desc '接口描述' --user-scene-desc '详细' \
  --http-method GET --timeout 100 \
  --request-info @request-info.json --response-info @response-info.json \
  --dry-run --output json

doudian-open-cli djt spi interface save \
  --scene-id 248 --interface-name prefix/name --biz-domain-id 8 \
  --desc '接口描述' --user-scene-desc '详细' \
  --http-method GET --timeout 100 \
  --request-info @request-info.json --response-info @response-info.json \
  --confirmed-by-user --apply --output json
```

### 更新接口

```bash
doudian-open-cli djt spi interface get --interface-id 11525 --output json

doudian-open-cli djt spi interface save \
  --interface-id 11525 --modify-version-id 2 \
  --interface-name test/existing_name \
  --scene-id 248 --biz-domain-id 15 \
  --desc '...' --user-scene-desc '详细' --http-method GET --timeout 100 \
  --request-info @request-info.json --response-info @response-info.json \
  --dry-run --output json
```

更新时 `--interface-id` 与 `--modify-version-id` 必填；`interfaceName` 即使传错也会被规范化为库中名称（**禁止改名**）。

复杂参数也可用单一 `--input @save-body.json` 传完整对象，但不要与拆分 flags 混用。

## 3. 接口查询与提审

### 列表与模糊搜索

```bash
doudian-open-cli djt spi interface list --name-like trade --page 1 --page-size 20 --output json

doudian-open-cli djt spi interface list --scene-id 248 --name-like order --output json

doudian-open-cli djt spi interface list --biz-domain-id 8 --name-like prefix --output json
```

`list` 返回 `list[]` 摘要：`interfaceId`、`interfaceName`、`status`、`desc`、`userSceneDesc`、`sceneId`、`sceneName`、`bizDomainId`、`ownerList`、`configUrl`、`createTime`。定位到目标接口后用 `get` 拉完整配置树。

### 详情

```bash
doudian-open-cli djt spi interface get --interface-id 11525 --output json
# 或精确名称（二选一）：
doudian-open-cli djt spi interface get --interface-name prefix/name --output json
```

`--interface-id` 与 `--interface-name` 互斥。

```bash
doudian-open-cli djt spi interface submit-review \
  --interface-id 11525 --modify-version-id 2 \
  --reason '首次发布' --meego 'https://meego.bytedance.net/xxx' \
  --dry-run --output json

doudian-open-cli djt spi interface submit-review \
  --interface-id 11525 --modify-version-id 2 \
  --reason '首次发布' --meego 'https://meego.bytedance.net/xxx' \
  --apply --output json
```

`reason`、`meego` 必填。提审后到网页完成审核；**301 待审核态 CLI 停止**。

## 4. 撤销升级（仅 status=201）

```bash
doudian-open-cli djt spi interface cancel-upgrade \
  --interface-id 11525 --dry-run --output json

doudian-open-cli djt spi interface cancel-upgrade \
  --interface-id 11525 --apply --output json
```

也可用 `--interface-name prefix/name`（与 `--interface-id` 互斥）。**不提供**取消审核。

## 5. 接入应用（可选）

### 列表

```bash
doudian-open-cli djt spi scene access-app list --scene-id 248 --output json
```

每条含 `authId`、`appId`、`appName`、`enable`、`totalCount`（场景接口总数）、`implCount`（已实现数）、`status`（接入进度）。

### 详情

```bash
doudian-open-cli djt spi scene access-app get --auth-id 99 --output json
# 或
doudian-open-cli djt spi scene access-app get --scene-id 248 --app-id 12345 --output json
```

`get` 返回 `implList[]`：`interfaceId`、`interfaceName`、`interfaceDesc`、`userSceneDesc`、`interfaceImplUrl`、`status`，与网页接入详情一致。

### 新建与启用

```bash
doudian-open-cli djt spi scene access-app save \
  --scene-id 248 --app-id 12345 --dry-run --output json

doudian-open-cli djt spi scene access-app save \
  --scene-id 248 --app-id 12345 --apply --output json
```

`save` 后应用为**未启用**；需要对外可见时：

```bash
doudian-open-cli djt spi scene access-app enable \
  --auth-id 99 --dry-run --output json

doudian-open-cli djt spi scene access-app enable \
  --auth-id 99 --apply --output json
```

写操作权限与网页一致（底层走 `CreateSceneAuth` / `EnableSceneAuth`）；列表保持全可见。

## 状态边界

| status | 含义 | Agent 动作 |
|---:|---|---|
| 201 | 待提交草稿 | save、cancel-upgrade |
| 301 | 待审核 | **停止**，等网页 |
| 已发布 | 全量发布 | **停止**，升级需网页发起新草稿 |

## 错误恢复

| 现象 | 动作 |
|------|------|
| `sceneDesc` / `bizDomainId` 校验失败 | 补全参数后重试 dry-run |
| save dry-run 有 `errors[]` | 按 `field`/`fix` 逐项修正 |
| `modifyVersionId` 冲突 | 重新 `interface get` |
| submit-review 报 example 缺失 | 补 doc 阶段字段后重试 |
| `unknown method`（PPE 首请求） | 部署滚动中，重试 |
| 无权限（接入/写操作） | 确认用户是场景创建者或域权限 |

## JSON source 速查

与 API 相同语法，适用于：`--request-info`、`--response-info`、`--headers`、`--error-info-list`、`--biz-use-cases`、`--owner-list`、`--app-ids`。

```bash
# SPI sync-boe 的 app-ids 示例
echo '[12345]' > app-ids.json
doudian-open-cli djt spi scene sync-boe --scene-id 1 --app-ids @app-ids.json --dry-run --output json
```
