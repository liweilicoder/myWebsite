# 点将台 CLI Skill 包结构

本目录是 `@ecom-open-cli/opencli` npm 包随发的 **Agent Skill 唯一手工维护源**。`internal/djt/skill/assets/djt/` 为 Go embed 镜像，由 `node scripts/sync-skill.mjs` 确定性同步，不得手改镜像。

## 分发路径

```text
npm install @ecom-open-cli/opencli
  ├── bin/doudian-open-cli.js          # Node 启动器
  ├── binaries/doudian-open-cli-*        # 四平台 Go 二进制
  ├── scripts/postinstall.cjs            # best-effort → djt self skill install
  └── skills/djt/                      # 本目录（完整拷贝）
        ├── SKILL.md                   # Agent 入口：原则、共享基础、命令总览
        ├── api.md                     # OpenAPI Agent Interface 完整手册
        ├── spi.md                     # SPI Agent 完整手册（与 api 同级）
        ├── README.md                  # 本文件：结构说明
        ├── .skillignore
        └── scripts/
              ├── apply_style_patches.py      # API requestInfo 本地 patch（含中间节点提升）
              ├── validate_style_tree.py      # API style/path 本地预检
              ├── request_style.py            # 中间节点 style=2 提升/校验（被上两个脚本引用）
              └── json_to_spi_param_tree.py   # SPI 示例 JSON → 字段树
```

安装后 `doudian-open-cli djt self skill install` 会把 **整个 `skills/djt/`** 同步到：

| Agent | 路径 |
|-------|------|
| universal | `~/.agents/skills/djt/` |
| claude | `$CLAUDE_CONFIG_DIR/skills/djt/`（Agent 根已存在时） |
| codex | `$CODEX_HOME/skills/djt/`（Agent 根已存在时） |

## Agent 怎么读

1. 始终先读 [`SKILL.md`](SKILL.md)：登录、业务域、PPE、输出契约、命令总览。
2. 配置 **OpenAPI 接口** → 读 [`api.md`](api.md)，按 `get → init → 补 style/example/description → save → doc → advance-step` 执行。
3. 配置 **SPI 场景/接口** → 读 [`spi.md`](spi.md)，按 `scene → interface list|get → save → submit-review` 执行；查接入用 `access-app list|get`。
4. 本地树处理只用 `scripts/` 下脚本；**不得联网**，脚本结果不能替代 CLI `--dry-run`。

## 维护约定

- 行为或契约变更遵循 **spec coding**：先更新 `docs/spec/` 中对应设计规格，再改本目录与代码。
- 改 `skills/djt/` 后运行 `node scripts/sync-skill.mjs`，再 `node scripts/sync-skill.mjs --check`。
- 对内 npm 包 `files` 包含整个 `skills/djt/`，新增顶层 markdown 会自动进对内包。
- `scripts/verify-npm-package.mjs` 的 allowlist 需与 tarball 文件清单保持同步。
