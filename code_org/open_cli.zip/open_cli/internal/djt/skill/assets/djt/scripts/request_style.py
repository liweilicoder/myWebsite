#!/usr/bin/env python3
"""requestInfo 中间节点 style 规则，对齐网页 Split 特殊情况 1 + Merge 重建。

网页保存：若某节点 style != 3，且全部子节点 style 为 2 或 3（内部变量/常量），
Split 会摘除该中间节点，Merge 再按 path 重建为 style=2。
fromBam 默认把 struct 标成 style=1；只给叶子打补丁会留下对外父节点，
运行时 FetchValue 跳过缺失 struct、嵌套内部变量注入失败。
"""

from __future__ import annotations

from typing import Any, Dict, List

Node = Dict[str, Any]


def node_style(node: Node) -> int:
    style = node.get("style")
    if style is None:
        return 1
    return int(style)


def children_of(node: Node) -> List[Node]:
    kids = node.get("children") or []
    return [child for child in kids if isinstance(child, dict)]


def all_children_inner_or_const(children: List[Node]) -> bool:
    if not children:
        return False
    return all(node_style(child) in (2, 3) for child in children)


def promote_stripped_intermediates(nodes: List[Node]) -> None:
    """自底向上把「会被网页摘除再重建」的中间节点标成 style=2。"""
    for node in nodes or []:
        kids = children_of(node)
        if kids:
            promote_stripped_intermediates(kids)
        if kids and node_style(node) != 3 and all_children_inner_or_const(kids):
            node["style"] = 2


def leftover_stripped_parent_issues(node: Node) -> List[str]:
    path = node.get("path") or node.get("toName") or ""
    kids = children_of(node)
    if node_style(node) != 1 or not all_children_inner_or_const(kids):
        return []
    return [
        "中间节点 path={} style=1，但全部子节点均为内部变量/常量(style=2/3)；"
        "网页 Split 会摘除该节点并由 Merge 重建为 style=2。"
        "请先 apply_style_patches（叶子 style=2/3 后会自动提升父节点），"
        "或把该中间节点标为 style=2".format(path)
    ]
