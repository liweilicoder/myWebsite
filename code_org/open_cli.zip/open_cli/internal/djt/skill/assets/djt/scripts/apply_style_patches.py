#!/usr/bin/env python3
"""在本地 requestInfo 树上应用按 path 指定的样式补丁。"""

from __future__ import annotations

import argparse
import copy
import json
import sys
from typing import Any, Callable, Dict, List, Optional

from request_style import promote_stripped_intermediates

Node = Dict[str, Any]


def walk(nodes: List[Node], visit: Callable[[Node], None]) -> None:
    for node in nodes or []:
        visit(node)
        walk(node.get("children") or [], visit)


def find_by_path(nodes: List[Node], path: str) -> Optional[Node]:
    found = []  # type: List[Node]

    def visit(node: Node) -> None:
        if node.get("path") == path:
            found.append(node)

    walk(nodes, visit)
    return found[0] if found else None


def apply_patches(tree: List[Node], patches: List[Node]) -> List[Node]:
    output = copy.deepcopy(tree)
    missing = []  # type: List[str]
    for patch in patches:
        path = patch.get("path")
        if not isinstance(path, str) or not path:
            raise ValueError("patch 缺少非空 path")
        node = find_by_path(output, path)
        if node is None:
            missing.append(path)
            continue
        if "style" in patch:
            node["style"] = int(patch["style"])
        for field in ("constantValue", "mustNeed", "example", "description"):
            if field in patch:
                node[field] = patch[field]
    if missing:
        raise ValueError(
            "以下 path 不在树上（不能凭空造字段，只能修改 IDL 已有 path）：\n  "
            + "\n  ".join(missing)
        )
    # 对齐网页：全部子节点为内部变量/常量时，中间节点重建为 style=2（含常量子树）
    promote_stripped_intermediates(output)
    return output


def load_array(path: str, option: str) -> List[Node]:
    with open(path, "r", encoding="utf-8") as handle:
        value = json.load(handle)
    if not isinstance(value, list):
        raise ValueError("{} 必须是 JSON 数组".format(option))
    if any(not isinstance(item, dict) for item in value):
        raise ValueError("{} 数组元素必须是 JSON 对象".format(option))
    return value


def main() -> int:
    parser = argparse.ArgumentParser(
        description="本地转换 requestInfo 完整树；不发起网络请求，也不替代 doudian-open-cli dry-run。"
    )
    parser.add_argument("--in", dest="in_file", required=True, help="requestInfo JSON 数组文件")
    parser.add_argument("--patches", required=True, help="style patches JSON 数组文件")
    parser.add_argument("--out", required=True, help="输出 patched requestInfo 文件")
    args = parser.parse_args()

    try:
        tree = load_array(args.in_file, "--in")
        patches = load_array(args.patches, "--patches")
        patched = apply_patches(tree, patches)
        with open(args.out, "w", encoding="utf-8") as handle:
            json.dump(patched, handle, ensure_ascii=False, indent=2)
            handle.write("\n")
    except (OSError, ValueError, TypeError, json.JSONDecodeError) as error:
        print("apply_style_patches: {}".format(error), file=sys.stderr)
        return 1

    print("patched {} path(s) -> {}".format(len(patches), args.out), file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
