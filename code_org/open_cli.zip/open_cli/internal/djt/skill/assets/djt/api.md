# OpenAPI Agent Interface 手册

与 [`spi.md`](spi.md) 同级，专用于 `doudian-open-cli djt api`。**共享登录、业务域、PPE、JSON source** 见 [`SKILL.md`](SKILL.md)。

## 五个正式命令

```text
doudian-open-cli djt api get
doudian-open-cli djt api init
doudian-open-cli djt api save
doudian-open-cli djt api doc
doudian-open-cli djt api advance-step
```

- `get`：查询配置、版本、状态、内部变量字典或模糊搜索。
- `init`：从 BAM 新建或 `--interface-id` 重绑；**无 dry-run**，须 `--confirmed-by-user --apply`。
- `save`：保存草稿，不推进状态；默认 `--dry-run`。
- `doc`：保存并自动补文档；**无 dry-run**，须 `--apply`。
- `advance-step`：保存可选 payload 并推进；默认 `--dry-run`，POST 前先 get 预检。

## BAM 元数据发现

`init` 必须显式提供 `PSM`、`methodName`、`bamVersionId`。DJT CLI 不维护 PSM/方法/版本列表。

```bash
bytedcli --json bam psm search '<PSM 或服务关键词>'
bytedcli --json bam method list --psm '<PSM>' --name '<方法名或路径>' --count 20
bytedcli --json bam version list '<PSM>'
```

- `psm search`、`version list` 不支持 `--count`。
- 多候选无法消歧时必须让用户选择。
- 用户确认前不得执行 `init`。

## 必须执行的完整流程

```text
login/status → biz-domain list → 展示 init 确认清单并等待明确答复 →
init --confirmed-by-user --apply → 保存 init.fromBam 树 → get →
stylePatches + 补 example/description → validate →
save --dry-run → 检查 preview/diff/errors → save --apply → get 核对叶子元数据 →
advance-step request/response/errcode 各自 --dry-run/--apply → statusV2=110 →
doc --apply → 重新 get →
submit-audit dry-run/apply → get 确认 statusV2=310 →
cancel-audit dry-run/apply → get 确认 statusV2=200
```

`biz-domain list → 用户明确确认 → init` 不可跳过。禁止 Agent 自行选择默认测试域或伪造 `--confirmed-by-user`。此门禁**只约束 init**，不扩展到 `save`/`doc`/`advance-step`。

禁止推进到 330+；审核通过与发布只能由用户在网页完成。

### 1. 初始化并保存 BAM 树

```bash
doudian-open-cli djt biz-domain list --output json

doudian-open-cli djt api init \
  --psm your.psm.name \
  --method-name TestTemplateInterface \
  --bam-version-id 1.0.340 \
  --biz-domain-id 8 \
  --confirmed-by-user --apply --output json
```

init 确认清单：新建/重绑、`PSM`、`methodName`、`bamVersionId`、`interfaceName`、`bizDomainId`（用户从 list 选择）、`ownerList`、`skipAuth`、`desc`、`sceneDesc`、`interfaceCateId`。

从成功 stdout 保存：`data.current.interfaceId`、`modifyVersionId`；`data.fromBam.requestInfo/responseInfo` 到本地 JSON。新建时树必须来自 `init.fromBam`，不能用空的 `get.current`。**不能把 fromBam 原样当网页文档**：BAM 会带 `path`/`type`/`mustNeed`，但 `example` 经常为空，`description` 也常只有部分字段。

### 2. 获取控制字段

```bash
doudian-open-cli djt api get --interface-id 2846 --output json
```

selector 三选一：`--interface-id` / `--interface-name` / `--interface-name-like`。

每次操作前保留：`modifyVersionId`、`statusV2`、`configPhase`、`nextStep`、`reservedInnerVarNames`、`isOldInterface`、`errTypeList`。

### 3. 配置 style 与参数元数据

CLI 没有单独的 `--example` / `--description` flag。网页「示例值」「描述」「必填」都写在 `--request-info` / `--response-info` 完整树的节点上，随 `save` 落库。只打 style、不补元数据，网页入参表会是空的。

| style | 含义 |
|---:|---|
| 1 | 对外开放入参 |
| 2 | 内部变量（`requestName` 来自 `reservedInnerVarNames`） |
| 3 | 内部常量（需 `constantValue` + `description`） |

ArgType：`1/2/3/4/5/6/7/8/9/11/99`（Int64、String、List、Bool、Struct、Map 等）。

#### 3a. style（必做）

典型：下游 `shopId` 默认 style=1 且 `requestName=shop_id`，会和内部变量字典冲突，必须改成 style=2。

嵌套 struct（如 `account.shopId`）只给叶子打 style=2/3 **不够**：fromBam 父节点默认 style=1，网页保存会 Split 摘除该父节点再 Merge 重建为 **style=2**（内部变量与常量同样如此）。`apply_style_patches.py` 会在叶子补丁后自动提升这类中间节点；`validate_style_tree.py` 若仍看到「子节点全是 2/3、父节点 style=1」会报错。重建后的中间节点 `requestName` 可以是 `account` 这类 toName，不必出现在内部变量字典里。

#### 3b. example / description / mustNeed（首次 save request/response 前必做）

遍历 **style=1** 简单类型叶子（非 Struct/List/Map）：

| 字段 | 怎么填 |
|---|---|
| `mustNeed` | 跟 IDL：无 `optional` → `true`；标了 `optional` → `false`。`fromBam` 已映射时不要改反。style=2/3 保持 `false`。中间节点不勾必填。 |
| `description` | 优先 BAM/IDL 已有注释（勿覆盖成更差文案）；没有则写短中文业务语义。style=3 **不能空**。 |
| `example` | 优先 IDL `@example` / 默认值；否则按类型占位（字符串 `"示例"`，数值 `"123"`，布尔 `"true"`）。Struct/List/Map 留空。style=2/3 通常不填。 |

response 树同样补。禁止编造 IDL 不存在的 `path`。

本地脚本（在 Skill 目录执行，**不得联网**）。patches 可同时含 `style`、`mustNeed`、`example`、`description`、`constantValue`：

```bash
python3 scripts/apply_style_patches.py \
  --in request.json --patches style-patches.json --out patched-request.json

python3 scripts/validate_style_tree.py \
  --in patched-request.json --get-json get-result.json --strict
```

脚本通过后仍必须以 `api save --dry-run` 为准。dry-run 的 `preview` **未必回显** `example`/`description`；`--apply` 后必须 `get`，按 path 核对叶子，不要只看 diff 的 added/changed。

**落库一致性**：网页保存与 CLI `api save` 最终都应得到「子节点全是内部变量/常量时，中间 struct 为 style=2」的树。CLI 侧由 `apply_style_patches.py` 在本地先提升；服务端 Agent save 会再做与网页相同的 Split → Merge（见 open_admin `PrepareRequestInfoForSave`，仅 DJT Agent 链路）。

#### 3c. 开放网关（open_gw）运行时限制

点将台能把内部变量/常量写进 request 树，但**开放网关入参转换**并不支持所有嵌套形态。配置前请对照 IDL，避免「网页/CLI 能保存、线上网关不注入或转换错误」。

| 场景 | 网关行为（要点） | Agent 配置建议 |
|------|------------------|----------------|
| **struct 下 style=2/3** | 商家未传该 struct 时，仅当父节点按内部结构落库（style=2 中间 struct，与 3a 提升一致）才会下钻注入子字段；父节点仍为 style=1 且未传对象时，子级内部变量**不会**注入 | 嵌套内部变量/常量务必走完 3a 脚本提升；不要只改叶子 |
| **顶层 / struct 内 Map** | 老链路对 Map **整体透传**，不做 map 内字段映射与子树转换（`open_gw/pkg/req/map_conv.go`） | 不要把依赖网关注入的 style=2 叶子配在 Map value 的 struct 里并指望自动映射 |
| **map value = struct / list** | 新链路（`pkg2/req2`）可递归转换 map 内 struct、list | 仍受「Map 老链路透传」与接口是否走 pkg2 影响；优先 struct 嵌套 |
| **map value = map（嵌套 Map）** | `mapConvert` 对 `MapValueType=Map` **无展开逻辑**（空分支） | **不要**在点将台为嵌套 map 配置内部变量/常量 |
| **list 元素 = map / 嵌套 list** | `listConvert` 中对应分支仍为 **todo** | **不要**把内部变量配在「list of map」或「list of list」子树下 |
| **style=2 叶子类型** | 内部变量按标量注入；非 int/string/bool 等会报「不支持的内部参数类型」 | 内部变量节点保持简单类型 |

以上依据 `open_gw` 当前实现；若 IDL 仅有 map/list 嵌套且业务必须用内部变量，需与网关/平台确认，或改为对外 struct 入参。

### 4. 保存并推进 request / response / errcode

```bash
doudian-open-cli djt api save \
  --interface-id 2846 --modify-version-id 42 --sections request \
  --request-info @request.json --dry-run --output json

doudian-open-cli djt api advance-step \
  --interface-id 2846 --modify-version-id 43 --step request \
  --dry-run --output json
```

错误码：`--err-config-list` 不含成功码；成功码用 `--biz-succ-err-code`。`errcode` 目标状态 **110**（不是 100）。

### 5. 文档与提审

```bash
doudian-open-cli djt api doc \
  --interface-id 2846 --modify-version-id 47 \
  --desc '查询订单' --scene-desc '商家查询单笔订单' \
  --release-note '首次发布' --auto-fill=true \
  --apply --output json

doudian-open-cli djt api advance-step \
  --interface-id 2846 --modify-version-id 48 \
  --step submit-audit --audit-reason '首次发布' \
  --audit-meego 'https://meego.bytedance.net/xxx' \
  --dry-run --output json
```

审核闭环：`submit-audit` → get 确认 310 → `cancel-audit` → get 确认 200。

## 状态边界

| statusV2 | Agent 动作 |
|---:|---|
| 30–50 | request/response/errcode save + advance |
| 100/110 | doc、提审 |
| 310 | 等待或 cancel-audit |
| 330+ | **立即停止**，发布交网页 |

## API 测试

```bash
doudian-open-cli djt api test auth add --env ppe --auth-id 90419 --auth-subject-biz-id 0 --output json

doudian-open-cli djt api test ppe \
  --interface-name /test/zzhTestDDD \
  --lane ppe_djt_cli \
  --auth-id 90419 --auth-type 0 \
  --params '{}' --output json
```

- `skipAuth=false` 时必须同时传 `auth-id` 与 `auth-type`。
- `--lane` 是被测 API 泳道；`djt api --use-ppe --ppe-env` 是访问点将台 BFF 的泳道，二者不可混用。
- PROD 须用户明确同意后加 `--confirmed-by-user`。

## 错误恢复

| 现象 | 动作 |
|------|------|
| dry-run 返回 `errors` | 按 `errors[].fix` 修正 |
| `code=8000037` | 重新 get，更新 `modifyVersionId` |
| 网页入参缺示例/描述 | 在树上补 `example`/`description` 后 `save --sections request`，不要另找 flag |
| doc 后提审冲突 | 重新 get 再 submit-audit |
| `statusV2 >= 330` | 停止 advance，交网页发布 |
| init 缺 `--confirmed-by-user` | 展示清单等待用户确认 |
