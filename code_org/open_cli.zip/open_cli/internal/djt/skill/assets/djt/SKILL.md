---
name: djt
description: Use when an Agent works with 点将台 via doudian-open-cli. Read api.md for OpenAPI interface configuration (get/init/save/doc/advance-step) and spi.md for SPI configuration (scene/interface/submit-review). Covers auth, biz-domain, PPE lanes, dry-run/apply, and offline scripts.
---

# 点将台 CLI

## 核心原则

只通过正式 `doudian-open-cli djt` 命令操作点将台。npm 包为 `@ecom-open-cli/opencli`，**唯一可执行命令**是 `doudian-open-cli`（不是 `opencli`）。Agent 默认 `--output json`：先检查退出码，成功再解析 stdout；stderr 仅用于登录提示与错误诊断。

所有 DJT 请求固定连接 `https://djt.bytedance.net`。不得覆盖 origin、发送 raw API、或调用未公开的网页配置接口。

## Skill 包结构（npm 随发）

```text
skills/djt/
├── SKILL.md          ← 本文件：入口、共享基础、命令总览
├── api.md            ← OpenAPI Agent Interface 完整 SOP
├── spi.md            ← SPI Agent 完整 SOP（与 api 同级）
├── README.md         ← 分发与维护说明
└── scripts/          ← 离线辅助脚本（API + SPI）
```

`npm install` 后 postinstall 会 best-effort 执行 `djt self skill install`，将**整个目录**安装到 `~/.agents/skills/djt/`。修复或确认：

```bash
doudian-open-cli djt self skill install --output json
doudian-open-cli djt self skill status --output json
doudian-open-cli djt self skill update --output json
```

## 前置检查

```bash
command -v doudian-open-cli
doudian-open-cli --version
doudian-open-cli djt version
doudian-open-cli djt auth status --output json
```

未安装（Node.js 18+，darwin/linux amd64/arm64，不支持 Windows）：

```bash
npm install --global @ecom-open-cli/opencli --registry=https://bnpm.byted.org
```

## 命令总览（API 与 SPI 同级）

两条产品线共用登录、业务域与 PPE；**具体 SOP 分别见 [`api.md`](api.md) 与 [`spi.md`](spi.md)**。

### OpenAPI Agent Interface — [`api.md`](api.md)

```text
doudian-open-cli djt api get
doudian-open-cli djt api init
doudian-open-cli djt api save
doudian-open-cli djt api doc
doudian-open-cli djt api advance-step
doudian-open-cli djt api test {boe|ppe|prod}
doudian-open-cli djt api test auth add
```

最短路径：`login → biz-domain list → init --confirmed-by-user --apply → apply_style_patches + validate_style_tree（嵌套内部变量/常量须提升父 struct，见 api.md 3a/3c）→ save/advance-step → doc → submit-audit → 网页审核（CLI 止于 310）`。`example`/`description` 写在 `--request-info` 树上，没有单独 flag；细则见 [`api.md`](api.md) 第 3 节。

### SPI Agent — [`spi.md`](spi.md)

```text
doudian-open-cli djt spi scene list|get|save|sync-boe
doudian-open-cli djt spi scene access-app list|get|save|enable
doudian-open-cli djt spi interface list|get|save|submit-review|cancel-upgrade
```

最短路径：`scene save --apply → json_to_spi_param_tree.py → interface save --dry-run/--apply → submit-review → 网页审核（CLI 止于 301）`。查接口用 `interface list|get`；查场景接入与 impl URL 用 `access-app list|get`。

PPE 联调时，在 **`djt spi` 或 `djt api` 父命令**上挂泳道（不是 leaf 子命令）：

```bash
doudian-open-cli djt spi --use-ppe --ppe-env <你的PPE泳道> scene list --output json
doudian-open-cli djt api --use-ppe --ppe-env <你的PPE泳道> get --interface-id 1 --output json
```

`--use-ppe` 与 `--ppe-env` 必须同时启用；`--ppe-env` 不能单独使用。`api test --lane` 指**被测开放 API** 的泳道，与上述 BFF 泳道含义不同。

## 共享基础

### 登录（两段式，Agent 必用）

```bash
doudian-open-cli djt auth login start --output json
# 把 verification_url（授权 URL）与 user_code（用户代码）原样给用户；用户完成后：
doudian-open-cli djt auth login complete --output json
```

已有待完成会话时**不需要**重新开始授权；待完成会话有效期间**不得重复创建登录会话**（不要再次 `start`）。`auth status` / `auth whoami` 只读本地缓存，不发远端。

```bash
doudian-open-cli djt auth logout --output json
```

### 业务域

```bash
doudian-open-cli djt biz-domain list --output json
```

JSON 为 `{code,message,data}`，`data` 含 `domainInfoList`、`ownerdomainInfoList`（`domainId`、`domainName`、`suffixList`）。**禁止硬编码业务域 ID**；`ownerdomainInfoList` 表示当前用户可操作的域。

申请域权限（无 dry-run，调用即提交）：

```bash
doudian-open-cli djt biz-domain apply --domain-ids 8,15 --output json
```

成功 `data` 含 `auditManageUrl`，交给用户在网页审批。

### BAM 元数据（仅 API init 需要）

`api init` 的 `PSM`、`methodName`、`bamVersionId` 必须来自 BAM Skill 或 `bytedcli`，不得猜测。详见 [`api.md`](api.md#bam-元数据发现)。

### 写操作门禁（API 与 SPI 对照）

| 能力 | API | SPI |
|------|-----|-----|
| 默认模式 | `save`/`advance-step` 默认 dry-run | 所有写命令默认 dry-run |
| 显式预览 | `--dry-run` | `--dry-run` |
| 落库 | `--apply` | `--apply` |
| 新建确认 | `init` 需 `--confirmed-by-user --apply` | `interface save` 新建需 `--confirmed-by-user --apply` |
| 无 dry-run | `init`、`doc` 调用即落库 | 无（均有 dry-run） |

两者都不传模式参数时仍是 dry-run，但 **工作流必须显式写出 `--dry-run`**，检查 `preview`/`diff`/`errors` 后再 `--apply`。

### JSON source（数组参数）

适用于 API 的 `--request-info`、`--response-info`、`--err-config-list`、`--style-patches` 等，以及 SPI 的 `--request-info`、`--response-info`、`--headers`、`--error-info-list`、`--app-ids` 等：

- inline：`'[...]'`
- `@file`：`@path/to.json`
- `@-`：stdin（每命令最多一个 flag 使用 `@-`）

每项 ≤ 8 MiB，顶层必须是数组。传 `requestInfo`/`responseInfo` 为**整区替换**，不是增量 patch。

### 输出契约

成功 stdout 为一行 JSON：

```json
{"code":0,"message":"success","data":{}}
```

失败时 stdout 为空、stderr 有一次错误描述、退出码为 1。SPI 校验失败时 `data.errors[]` 含 `field`、`reason`、`fix`。

## 错误恢复（摘要）

| 现象 | 动作 |
|------|------|
| 未登录 / 凭据过期 | `auth login start` → 用户授权 → `complete` |
| `--biz-domain-id` 无效 | `biz-domain list`，让用户选择 |
| dry-run 有 `errors` | 按 `errors[].fix` 修正后重试 dry-run |
| `code=8000037` 版本冲突 | 重新 get，用最新 `modifyVersionId` |
| API `statusV2 >= 330` | 停止 CLI，发布交网页 |
| SPI 提审后（301+） | 停止 CLI，审核交网页 |
| `unknown method`（PPE） | 滚动发布中，稍后重试同一命令 |

完整分场景表见 [`api.md`](api.md#错误恢复) 与 [`spi.md`](spi.md#错误恢复)。

## 安全禁止项

- 不得读取、打印或回传 `credentials.json` 中的 token。
- 不得把认证头发往 `https://djt.bytedance.net` 之外。
- 不得调用未公开网页 API、不得伪造状态跳转。
- 不得编造 IDL/BAM 不存在的 path。
- API：不得推进到 330+；SPI：不得代审、不得发布。

---

**下一步**：配置 OpenAPI → 打开 [`api.md`](api.md)；配置 SPI → 打开 [`spi.md`](spi.md)。
