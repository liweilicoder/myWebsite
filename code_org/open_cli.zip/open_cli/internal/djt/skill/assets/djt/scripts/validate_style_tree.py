#!/usr/bin/env python3
"""离线预检 requestInfo 的 style、path 和内部变量约束。"""

from __future__ import annotations

import argparse
import json
import sys
from typing import Any, Callable, Dict, List, Tuple

from request_style import leftover_stripped_parent_issues

Node = Dict[str, Any]
Visitor = Callable[[Node, List[Node]], None]


def walk(nodes: List[Node], visit: Visitor, chain: List[Node] = None) -> None:
    ancestors = chain or []
    for node in nodes or []:
        visit(node, ancestors)
        walk(node.get("children") or [], visit, ancestors + [node])


def path_last(path: str) -> str:
    value = (path or "").strip()
    return value.rsplit(".", 1)[-1] if value else ""


def inner_var_set(names: List[str]) -> Dict[str, str]:
    output = {}  # type: Dict[str, str]
    for name in names:
        key = (name or "").strip().lower()
        if key:
            output[key] = name
    return output


def validate(
    tree: List[Node],
    *,
    inner_names: List[str],
    is_old_interface: bool,
) -> List[str]:
    issues = []  # type: List[str]
    paths = []  # type: List[str]
    inner = inner_var_set(inner_names)

    def visit(node: Node, _chain: List[Node]) -> None:
        path = node.get("path")
        if not isinstance(path, str) or not path.strip():
            issues.append("空 path: toName={}".format(node.get("toName")))
            path = ""
        else:
            paths.append(path)

        style = node.get("style") or 1
        if style not in (1, 2, 3):
            issues.append("未知 style={}: path={}".format(style, path))
        if style == 3 and node.get("constantValue") is None:
            issues.append("style=3 缺 constantValue: path={}".format(path))

        children = node.get("children") or []
        issues.extend(leftover_stripped_parent_issues(node))
        if style == 2 and children and node.get("type") == 5:
            for child in children:
                if (child.get("style") or 1) == 1:
                    issues.append(
                        "style=2 中间节点 {} 含 style=1 子节点 {}；"
                        "Split 不会摘除该中间节点，若期望平铺请把子节点也标为 2/3".format(
                            path, child.get("path")
                        )
                    )

        to_name = (node.get("toName") or "").strip()
        last = path_last(path)
        if last and to_name and last != to_name:
            issues.append(
                "path/toName 不一致: path={} toName={} 期望={}".format(path, to_name, last)
            )

        request_name = (node.get("requestName") or "").strip()
        # Merge 重建的 style=2 struct 中间节点 requestName 常为 toName（如 account），
        # 不在内部变量字典中；只校验叶子 style=2。
        is_style2_intermediate = style == 2 and bool(children)
        if style == 1:
            key = request_name.lower()
            if inner and not is_old_interface and key in inner:
                issues.append(
                    "style=1 对外参数 requestName={!r} 与内部变量 {!r} 冲突 "
                    "(path={} toName={})；应标 style=2 或更换对外名".format(
                        request_name, inner[key], path, node.get("toName")
                    )
                )
        elif style == 2 and inner and not is_style2_intermediate:
            if not request_name:
                issues.append(
                    "style=2 缺 requestName: path={} toName={}".format(
                        path, node.get("toName")
                    )
                )
            elif request_name.lower() not in inner:
                issues.append(
                    "style=2 requestName={!r} 不在内部变量字典；"
                    "请从 get.current.reservedInnerVarNames 选择".format(request_name)
                )

    walk(tree, visit)
    counts = {}  # type: Dict[str, int]
    for path in paths:
        counts[path] = counts.get(path, 0) + 1
    for path in sorted(value for value, count in counts.items() if count > 1):
        issues.append("重复 path: {}".format(path))
    return issues


def load_tree(path: str) -> List[Node]:
    with open(path, "r", encoding="utf-8") as handle:
        tree = json.load(handle)
    if not isinstance(tree, list) or any(not isinstance(node, dict) for node in tree):
        raise ValueError("--in 必须是 JSON 对象数组")
    return tree


def load_hints_from_get(path: str) -> Tuple[List[str], bool]:
    with open(path, "r", encoding="utf-8") as handle:
        document = json.load(handle)
    if not isinstance(document, dict):
        raise ValueError("--get-json 必须是 JSON 对象")
    current = (document.get("data") or {}).get("current") or document.get("current") or {}
    if not isinstance(current, dict):
        raise ValueError("--get-json 的 current 必须是 JSON 对象")
    names = current.get("reservedInnerVarNames") or []
    if not isinstance(names, list) or any(not isinstance(name, str) for name in names):
        raise ValueError("reservedInnerVarNames 必须是字符串数组")
    return names, bool(current.get("isOldInterface"))


def main() -> int:
    parser = argparse.ArgumentParser(
        description="离线预检 requestInfo；只读取本地 JSON，权威校验仍以 doudian-open-cli dry-run 为准。"
    )
    parser.add_argument("--in", dest="in_file", required=True, help="requestInfo JSON 数组文件")
    source = parser.add_mutually_exclusive_group()
    source.add_argument(
        "--get-json", dest="get_json", help="doudian-open-cli get 成功 JSON，读取内部变量字典和存量标志"
    )
    source.add_argument("--inner-var-names", help="显式传入的逗号分隔内部变量名")
    parser.add_argument("--is-old-interface", action="store_true", help="仅与显式内部变量名配合")
    parser.add_argument("--strict", action="store_true", help="发现问题时退出码为 1")
    args = parser.parse_args()

    try:
        tree = load_tree(args.in_file)
        inner_names = []  # type: List[str]
        is_old = args.is_old_interface
        if args.get_json:
            inner_names, is_old = load_hints_from_get(args.get_json)
        elif args.inner_var_names:
            inner_names = [value.strip() for value in args.inner_var_names.split(",") if value.strip()]

        if not inner_names:
            print(
                "WARN: 未提供内部变量字典（--get-json 或 --inner-var-names），跳过名称冲突校验",
                file=sys.stderr,
            )
        issues = validate(tree, inner_names=inner_names, is_old_interface=is_old)
    except (OSError, ValueError, TypeError, json.JSONDecodeError) as error:
        print("validate_style_tree: {}".format(error), file=sys.stderr)
        return 2

    if not issues:
        print("OK: no request/style/path issues")
        return 0
    print("request/style/path issues:")
    for issue in issues:
        print("  - {}".format(issue))
    return 1 if args.strict else 0


if __name__ == "__main__":
    raise SystemExit(main())
