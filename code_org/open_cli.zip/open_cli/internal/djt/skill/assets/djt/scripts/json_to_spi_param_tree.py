#!/usr/bin/env python3
"""将示例 JSON 转为 SPI 参数字段树；仅本地转换，不联网，不替代 doudian-open-cli dry-run。"""

from __future__ import annotations

import argparse
import json
import sys
from typing import Any, Dict, List, Optional

TYPE = {"boolean": 4, "number": 1, "object": 5, "array": 3}
NAME_KEY = {"request": "requestName", "response": "responseName"}


def js_typeof(value: Any) -> str:
    if value is None:
        raise ValueError("null value is not supported")
    if isinstance(value, bool):
        return "boolean"
    if isinstance(value, (int, float)):
        return "number"
    if isinstance(value, dict):
        return "object"
    if isinstance(value, list):
        return "array"
    return "string"


def parse_type(js_type: Optional[str]) -> Optional[int]:
    if not js_type:
        return None
    return TYPE.get(js_type, 2)


def parse_object(obj: Dict[str, Any]) -> List[Dict[str, Any]]:
    result = []  # type: List[Dict[str, Any]]
    for key, value in obj.items():
        if value is None:
            raise ValueError("null value is not supported at key {!r}".format(key))
        if isinstance(value, list):
            first = value[0] if value else None
            if first is None and value:
                raise ValueError("null value is not supported in array at key {!r}".format(key))
            if isinstance(first, dict):
                result.append({
                    "name": key,
                    "js_type": ["array", "object"],
                    "value": json.dumps(value, ensure_ascii=False),
                    "children": parse_object(first),
                })
            else:
                if first is not None:
                    js_typeof(first)
                result.append({
                    "name": key,
                    "js_type": ["array", js_typeof(first) if first is not None else "undefined"],
                    "value": json.dumps(value, ensure_ascii=False),
                })
        elif isinstance(value, dict):
            result.append({
                "name": key,
                "js_type": ["object"],
                "value": json.dumps(value, ensure_ascii=False),
                "children": parse_object(value),
            })
        else:
            result.append({
                "name": key,
                "js_type": [js_typeof(value)],
                "value": json.dumps(value, ensure_ascii=False),
            })
    return result


def to_tree(items: List[Dict[str, Any]], kind: str) -> List[Dict[str, Any]]:
    out = []  # type: List[Dict[str, Any]]
    for item in items:
        node = {
            NAME_KEY[kind]: item["name"],
            "example": "" if "object" in item["js_type"] else item["value"],
            "type": parse_type(item["js_type"][0]),
        }
        if len(item["js_type"]) > 1:
            node["subType"] = parse_type(item["js_type"][1])
        if item.get("children"):
            node["children"] = to_tree(item["children"], kind)
        out.append(node)
    return out


def convert(payload: Any, kind: str) -> List[Dict[str, Any]]:
    if kind not in NAME_KEY:
        raise ValueError("kind must be request or response")
    if not isinstance(payload, dict):
        raise ValueError("top-level JSON must be an object")
    return to_tree(parse_object(payload), kind)


def main() -> int:
    parser = argparse.ArgumentParser(
        description="将示例 JSON 转为 SPI 参数字段树；仅本地转换，不联网，不替代 doudian-open-cli dry-run。"
    )
    parser.add_argument("--kind", required=True, choices=["request", "response"], help="request 或 response 字段名键")
    parser.add_argument("--in", dest="in_file", required=True, help="输入示例 JSON 文件")
    parser.add_argument("--out", dest="out_file", required=True, help="输出字段树 JSON 文件")
    args = parser.parse_args()

    try:
        with open(args.in_file, "r", encoding="utf-8") as handle:
            payload = json.load(handle)
        tree = convert(payload, args.kind)
        with open(args.out_file, "w", encoding="utf-8") as handle:
            json.dump(tree, handle, ensure_ascii=False, indent=2)
            handle.write("\n")
    except (OSError, ValueError, TypeError, json.JSONDecodeError) as error:
        print("json_to_spi_param_tree: {}".format(error), file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
