package skill

import (
	"embed"
	"io/fs"
	"path"

	coreskill "code.byted.org/temai/open_cli/internal/core/skill"
)

//go:generate node ../../../scripts/sync-skill.mjs --check

//go:embed assets/djt assets/djt/.skillignore
var bundled embed.FS

func Bundle() coreskill.Bundle {
	return coreskill.Bundle{Name: "djt", Files: builtinFiles()}
}

func builtinFiles() []coreskill.BundledFile {
	const root = "assets/djt"
	files := make([]coreskill.BundledFile, 0)
	err := fs.WalkDir(bundled, root, func(name string, entry fs.DirEntry, walkErr error) error {
		if walkErr != nil {
			return walkErr
		}
		if entry.IsDir() {
			return nil
		}
		content, err := bundled.ReadFile(name)
		if err != nil {
			return err
		}
		files = append(files, coreskill.BundledFile{
			Path:    path.Clean(name[len(root)+1:]),
			Content: append([]byte(nil), content...),
		})
		return nil
	})
	if err != nil {
		panic("内嵌 djt Skill 不可用: " + err.Error())
	}
	return files
}
