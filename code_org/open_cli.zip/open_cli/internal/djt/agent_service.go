package djt

import (
	"context"
	"errors"
	"fmt"
)

type AgentService struct {
	api AgentInterfaceAPI
}

func NewAgentService(api AgentInterfaceAPI) *AgentService {
	return &AgentService{api: api}
}

func (s *AgentService) Get(ctx context.Context, request AgentGetRequest, options RequestOptions) (AgentGetResult, error) {
	return s.api.Get(ctx, request, options)
}

func (s *AgentService) Init(ctx context.Context, request AgentInitRequest, options RequestOptions) (AgentInitResult, error) {
	return s.api.Init(ctx, request, options)
}

func (s *AgentService) Save(ctx context.Context, request AgentSaveRequest, options RequestOptions) (AgentSaveResult, error) {
	return s.api.Save(ctx, request, options)
}

func (s *AgentService) Doc(ctx context.Context, request AgentDocRequest, options RequestOptions) (AgentDocResult, error) {
	return s.api.Doc(ctx, request, options)
}

func (s *AgentService) AdvanceStep(ctx context.Context, request AgentAdvanceRequest, options RequestOptions) (AgentAdvanceResult, error) {
	if !isAllowedAgentAdvanceStep(request.Step) {
		return AgentAdvanceResult{}, errors.New("不支持的 advance step；允许 basic|request|response|errcode|ppe|submit-audit|cancel-audit，文档请使用 doc")
	}

	current, err := s.api.Get(ctx, AgentGetRequest{InterfaceID: &request.InterfaceID}, options)
	if err != nil {
		return AgentAdvanceResult{}, fmt.Errorf("推进前获取接口失败: %w", err)
	}
	if current.Current == nil {
		return AgentAdvanceResult{}, errors.New("推进前响应缺少 current")
	}
	if current.Current.StatusV2 != nil && *current.Current.StatusV2 >= 330 {
		return AgentAdvanceResult{}, fmt.Errorf("statusV2=%d 已进入 330 及以上阶段，330 及以上只能在网页发布", *current.Current.StatusV2)
	}
	if current.Current.ModifyVersionID != 0 && current.Current.ModifyVersionID != request.ModifyVersionID {
		return AgentAdvanceResult{}, fmt.Errorf(
			"modifyVersionId 冲突: 请求=%d 当前=%d，请重新 get",
			request.ModifyVersionID,
			current.Current.ModifyVersionID,
		)
	}
	return s.api.AdvanceStep(ctx, request, options)
}

func isAllowedAgentAdvanceStep(step string) bool {
	switch step {
	case "basic", "request", "response", "errcode", "ppe", "submit-audit", "cancel-audit":
		return true
	default:
		return false
	}
}
