package djt

import (
	"context"
	"encoding/json"
	"net/http"
	"net/url"
	"strconv"
)

const (
	agentSpiInterfaceGetPath    = "/api/djt-cli/agent/spi/interface/get"
	agentSpiInterfaceListPath   = "/api/djt-cli/agent/spi/interface/list"
	agentSpiInterfaceSavePath   = "/api/djt-cli/agent/spi/interface/save"
	agentSpiInterfaceSubmitPath = "/api/djt-cli/agent/spi/interface/submit-review"
	agentSpiSceneListPath       = "/api/djt-cli/agent/spi/scene/list"
	agentSpiSceneGetPath        = "/api/djt-cli/agent/spi/scene/get"
	agentSpiSceneSavePath       = "/api/djt-cli/agent/spi/scene/save"
	agentSpiSceneSyncBoePath    = "/api/djt-cli/agent/spi/scene/sync-boe"
	agentSpiAccessAppListPath   = "/api/djt-cli/agent/spi/scene/access-app/list"
	agentSpiAccessAppGetPath    = "/api/djt-cli/agent/spi/scene/access-app/get"
	agentSpiAccessAppSavePath   = "/api/djt-cli/agent/spi/scene/access-app/save"
	agentSpiAccessAppEnablePath = "/api/djt-cli/agent/spi/scene/access-app/enable"
	agentSpiCancelUpgradePath   = "/api/djt-cli/agent/spi/interface/cancel-upgrade"
)

type AgentSPIAPI interface {
	GetInterface(context.Context, AgentSpiGetInterfaceRequest, RequestOptions) (AgentSpiGetInterfaceResult, error)
	ListInterface(context.Context, AgentSpiListInterfaceRequest, RequestOptions) (AgentSpiListInterfaceResult, error)
	SaveInterface(context.Context, AgentSpiSaveInterfaceRequest, RequestOptions) (AgentSpiSaveInterfaceResult, error)
	SubmitReview(context.Context, AgentSpiSubmitReviewRequest, RequestOptions) (AgentSpiSubmitReviewResult, error)
	SceneList(context.Context, AgentSpiSceneListRequest, RequestOptions) (AgentSpiSceneListResult, error)
	SceneGet(context.Context, AgentSpiSceneGetRequest, RequestOptions) (AgentSpiSceneGetResult, error)
	SceneSave(context.Context, AgentSpiSceneSaveRequest, RequestOptions) (AgentSpiSceneSaveResult, error)
	SyncBoe(context.Context, AgentSpiSceneSyncBoeRequest, RequestOptions) (AgentSpiSceneSyncBoeResult, error)
	AccessAppList(context.Context, AgentSpiAccessAppListRequest, RequestOptions) (AgentSpiAccessAppListResult, error)
	AccessAppGet(context.Context, AgentSpiAccessAppGetRequest, RequestOptions) (AgentSpiAccessAppGetResult, error)
	AccessAppSave(context.Context, AgentSpiAccessAppSaveRequest, RequestOptions) (AgentSpiAccessAppSaveResult, error)
	AccessAppEnable(context.Context, AgentSpiAccessAppEnableRequest, RequestOptions) (AgentSpiAccessAppEnableResult, error)
	CancelUpgrade(context.Context, AgentSpiCancelUpgradeRequest, RequestOptions) (AgentSpiCancelUpgradeResult, error)
}

type AgentSPIClient struct {
	transport *Transport
}

func NewAgentSPIClient(transport *Transport) *AgentSPIClient {
	return &AgentSPIClient{transport: transport}
}

type AgentSpiCurrent struct {
	InterfaceID     int64           `json:"interfaceId"`
	InterfaceName   string          `json:"interfaceName"`
	ModifyVersionID int64           `json:"modifyVersionId"`
	Status          int64           `json:"status"`
	SceneID         int64           `json:"sceneId"`
	BizDomainID     int64           `json:"bizDomainId"`
	Desc            *string         `json:"desc,omitempty"`
	UserSceneDesc   *string         `json:"userSceneDesc,omitempty"`
	OwnerList       []string        `json:"ownerList,omitempty"`
	HTTPMethod      *string         `json:"httpMethod,omitempty"`
	Timeout         *int64          `json:"timeout,omitempty"`
	RequestInfo     json.RawMessage `json:"requestInfo,omitempty"`
	ResponseInfo    json.RawMessage `json:"responseInfo,omitempty"`
	Headers         json.RawMessage `json:"headers,omitempty"`
	ErrorInfoList   json.RawMessage `json:"errorInfoList,omitempty"`
	BizUseCases     json.RawMessage `json:"bizUseCases,omitempty"`
	ConfigURL       string          `json:"configUrl"`
}

type AgentSpiSaveDiff struct {
	RequestInfo   *AgentTreeDiff `json:"requestInfo,omitempty"`
	ResponseInfo  *AgentTreeDiff `json:"responseInfo,omitempty"`
	Headers       *AgentTreeDiff `json:"headers,omitempty"`
	ErrorInfoList *AgentTreeDiff `json:"errorInfoList,omitempty"`
}

type AgentSpiGetInterfaceRequest struct {
	InterfaceID   *int64  `json:"interfaceId,omitempty"`
	InterfaceName *string `json:"interfaceName,omitempty"`
}

type AgentSpiInterfaceSummary struct {
	InterfaceID     int64    `json:"interfaceId"`
	InterfaceName   string   `json:"interfaceName"`
	Status          int64    `json:"status"`
	Desc            *string  `json:"desc,omitempty"`
	UserSceneDesc   *string  `json:"userSceneDesc,omitempty"`
	SceneID         *int64   `json:"sceneId,omitempty"`
	SceneName       *string  `json:"sceneName,omitempty"`
	BizDomainID     *int64   `json:"bizDomainId,omitempty"`
	OwnerList       []string `json:"ownerList,omitempty"`
	ModifyVersionID *int64   `json:"modifyVersionId,omitempty"`
	ConfigURL       string   `json:"configUrl"`
	CreateTime      *int64   `json:"createTime,omitempty"`
}

type AgentSpiListInterfaceRequest struct {
	NameLike    *string `json:"nameLike,omitempty"`
	SceneID     *int64  `json:"sceneId,omitempty"`
	BizDomainID *int64  `json:"bizDomainId,omitempty"`
	Page        *int32  `json:"page,omitempty"`
	PageSize    *int32  `json:"pageSize,omitempty"`
}

type AgentSpiListInterfaceResult struct {
	Envelope Envelope
	List     []AgentSpiInterfaceSummary `json:"list"`
	Total    int64                      `json:"total"`
	Errors   []AgentFieldError          `json:"errors,omitempty"`
}

type AgentSpiSaveInterfaceRequest struct {
	InterfaceID     *int64          `json:"interfaceId,omitempty"`
	ModifyVersionID *int64          `json:"modifyVersionId,omitempty"`
	DryRun          bool            `json:"dryRun"`
	InterfaceName   *string         `json:"interfaceName,omitempty"`
	SceneID         *int64          `json:"sceneId,omitempty"`
	BizDomainID     *int64          `json:"bizDomainId,omitempty"`
	Desc            *string         `json:"desc,omitempty"`
	UserSceneDesc   *string         `json:"userSceneDesc,omitempty"`
	OwnerList       []string        `json:"ownerList,omitempty"`
	HTTPMethod      *string         `json:"httpMethod,omitempty"`
	Timeout         *int64          `json:"timeout,omitempty"`
	RequestInfo     json.RawMessage `json:"requestInfo,omitempty"`
	ResponseInfo    json.RawMessage `json:"responseInfo,omitempty"`
	Headers         json.RawMessage `json:"headers,omitempty"`
	ErrorInfoList   json.RawMessage `json:"errorInfoList,omitempty"`
	BizUseCases     json.RawMessage `json:"bizUseCases,omitempty"`
}

type AgentSpiSubmitReviewRequest struct {
	InterfaceID     int64   `json:"interfaceId"`
	ModifyVersionID int64   `json:"modifyVersionId"`
	DryRun          bool    `json:"dryRun"`
	Reason          string  `json:"reason"`
	Meego           *string `json:"meego,omitempty"`
}

type AgentSpiCancelUpgradeRequest struct {
	DryRun        bool    `json:"dryRun"`
	InterfaceID   *int64  `json:"interfaceId,omitempty"`
	InterfaceName *string `json:"interfaceName,omitempty"`
}

type AgentSpiScene struct {
	SceneID   int64  `json:"sceneId"`
	SceneName string `json:"sceneName"`
	SceneDesc string `json:"sceneDesc"`
	Status    int64  `json:"status"`
}

type AgentSpiSceneListRequest struct {
	SceneName *string `json:"sceneName,omitempty"`
	Page      *int32  `json:"page,omitempty"`
	PageSize  *int32  `json:"pageSize,omitempty"`
}

type AgentSpiSceneGetRequest struct {
	SceneID   *int64  `json:"sceneId,omitempty"`
	SceneName *string `json:"sceneName,omitempty"`
}

type AgentSpiSceneSaveRequest struct {
	DryRun      bool   `json:"dryRun"`
	SceneName   string `json:"sceneName"`
	SceneDesc   string `json:"sceneDesc"`
	BizDomainID int64  `json:"bizDomainId"`
}

type AgentSpiSceneSyncBoeRequest struct {
	DryRun  bool    `json:"dryRun"`
	SceneID int64   `json:"sceneId"`
	AppIDs  []int64 `json:"appIds,omitempty"`
}

type AgentSpiImplInfo struct {
	InterfaceID      int64   `json:"interfaceId"`
	InterfaceName    string  `json:"interfaceName"`
	InterfaceDesc    *string `json:"interfaceDesc,omitempty"`
	UserSceneDesc    *string `json:"userSceneDesc,omitempty"`
	InterfaceImplURL *string `json:"interfaceImplUrl,omitempty"`
	Status           int64   `json:"status"`
}

type AgentSpiAccessApp struct {
	AuthID     int64              `json:"authId"`
	SceneID    int64              `json:"sceneId"`
	AppID      int64              `json:"appId"`
	AppName    string             `json:"appName"`
	Enable     int8               `json:"enable"`
	TotalCount *int64             `json:"totalCount,omitempty"`
	ImplCount  *int64             `json:"implCount,omitempty"`
	Status     *int64             `json:"status,omitempty"`
	ImplList   []AgentSpiImplInfo `json:"implList,omitempty"`
}

type AgentSpiAccessAppListRequest struct {
	SceneID  int64  `json:"sceneId"`
	Page     *int32 `json:"page,omitempty"`
	PageSize *int32 `json:"pageSize,omitempty"`
}

type AgentSpiAccessAppGetRequest struct {
	AuthID  *int64 `json:"authId,omitempty"`
	SceneID *int64 `json:"sceneId,omitempty"`
	AppID   *int64 `json:"appId,omitempty"`
}

type AgentSpiAccessAppSaveRequest struct {
	DryRun  bool  `json:"dryRun"`
	SceneID int64 `json:"sceneId"`
	AppID   int64 `json:"appId"`
}

type AgentSpiAccessAppEnableRequest struct {
	DryRun bool  `json:"dryRun"`
	AuthID int64 `json:"authId"`
}

type AgentSpiGetInterfaceResult struct {
	Envelope Envelope
	Current  *AgentSpiCurrent  `json:"current,omitempty"`
	Errors   []AgentFieldError `json:"errors,omitempty"`
}

type AgentSpiSaveInterfaceResult struct {
	Envelope Envelope
	DryRun   bool              `json:"dryRun"`
	Applied  bool              `json:"applied"`
	Current  *AgentSpiCurrent  `json:"current,omitempty"`
	Preview  *AgentSpiCurrent  `json:"preview,omitempty"`
	Diff     *AgentSpiSaveDiff `json:"diff,omitempty"`
	Errors   []AgentFieldError `json:"errors,omitempty"`
}

type AgentSpiSubmitReviewResult struct {
	Envelope Envelope
	DryRun   bool              `json:"dryRun"`
	Applied  bool              `json:"applied"`
	Current  *AgentSpiCurrent  `json:"current,omitempty"`
	Preview  *AgentSpiCurrent  `json:"preview,omitempty"`
	Errors   []AgentFieldError `json:"errors,omitempty"`
}

type AgentSpiCancelUpgradeResult struct {
	Envelope Envelope
	DryRun   bool              `json:"dryRun"`
	Applied  bool              `json:"applied"`
	Errors   []AgentFieldError `json:"errors,omitempty"`
}

type AgentSpiSceneListResult struct {
	Envelope Envelope
	List     []AgentSpiScene   `json:"list"`
	Total    int64             `json:"total"`
	Errors   []AgentFieldError `json:"errors,omitempty"`
}

type AgentSpiSceneGetResult struct {
	Envelope Envelope
	Scene    *AgentSpiScene    `json:"scene,omitempty"`
	Errors   []AgentFieldError `json:"errors,omitempty"`
}

type AgentSpiSceneSaveResult struct {
	Envelope Envelope
	DryRun   bool              `json:"dryRun"`
	Applied  bool              `json:"applied"`
	Preview  *AgentSpiScene    `json:"preview,omitempty"`
	Scene    *AgentSpiScene    `json:"scene,omitempty"`
	Errors   []AgentFieldError `json:"errors,omitempty"`
}

type AgentSpiSceneSyncBoeResult struct {
	Envelope Envelope
	DryRun   bool              `json:"dryRun"`
	Applied  bool              `json:"applied"`
	Errors   []AgentFieldError `json:"errors,omitempty"`
}

type AgentSpiAccessAppListResult struct {
	Envelope Envelope
	List     []AgentSpiAccessApp `json:"list"`
	Total    int64               `json:"total"`
	Errors   []AgentFieldError   `json:"errors,omitempty"`
}

type AgentSpiAccessAppGetResult struct {
	Envelope  Envelope
	AccessApp *AgentSpiAccessApp `json:"accessApp,omitempty"`
	Errors    []AgentFieldError  `json:"errors,omitempty"`
}

type AgentSpiAccessAppSaveResult struct {
	Envelope  Envelope
	DryRun    bool               `json:"dryRun"`
	Applied   bool               `json:"applied"`
	Preview   *AgentSpiAccessApp `json:"preview,omitempty"`
	AccessApp *AgentSpiAccessApp `json:"accessApp,omitempty"`
	Errors    []AgentFieldError  `json:"errors,omitempty"`
}

type AgentSpiAccessAppEnableResult struct {
	Envelope  Envelope
	DryRun    bool               `json:"dryRun"`
	Applied   bool               `json:"applied"`
	Preview   *AgentSpiAccessApp `json:"preview,omitempty"`
	AccessApp *AgentSpiAccessApp `json:"accessApp,omitempty"`
	Errors    []AgentFieldError  `json:"errors,omitempty"`
}

func (c *AgentSPIClient) GetInterface(ctx context.Context, request AgentSpiGetInterfaceRequest, options RequestOptions) (AgentSpiGetInterfaceResult, error) {
	query := make(url.Values, 2)
	setOptionalInt64(query, "interfaceId", request.InterfaceID)
	setOptionalString(query, "interfaceName", request.InterfaceName)
	envelope, err := c.transport.Do(ctx, http.MethodGet, agentSpiInterfaceGetPath, query, nil, options)
	return decodeAgentSPIResult[AgentSpiGetInterfaceResult](envelope, err)
}

func (c *AgentSPIClient) ListInterface(ctx context.Context, request AgentSpiListInterfaceRequest, options RequestOptions) (AgentSpiListInterfaceResult, error) {
	query := make(url.Values, 5)
	setOptionalString(query, "nameLike", request.NameLike)
	setOptionalInt64(query, "sceneId", request.SceneID)
	setOptionalInt64(query, "bizDomainId", request.BizDomainID)
	setOptionalInt32(query, "page", request.Page)
	setOptionalInt32(query, "pageSize", request.PageSize)
	envelope, err := c.transport.Do(ctx, http.MethodGet, agentSpiInterfaceListPath, query, nil, options)
	return decodeAgentSPIResult[AgentSpiListInterfaceResult](envelope, err)
}

func (c *AgentSPIClient) SaveInterface(ctx context.Context, request AgentSpiSaveInterfaceRequest, options RequestOptions) (AgentSpiSaveInterfaceResult, error) {
	envelope, err := c.transport.Do(ctx, http.MethodPost, agentSpiInterfaceSavePath, nil, request, options)
	return decodeAgentSPIResult[AgentSpiSaveInterfaceResult](envelope, err)
}

func (c *AgentSPIClient) SubmitReview(ctx context.Context, request AgentSpiSubmitReviewRequest, options RequestOptions) (AgentSpiSubmitReviewResult, error) {
	envelope, err := c.transport.Do(ctx, http.MethodPost, agentSpiInterfaceSubmitPath, nil, request, options)
	return decodeAgentSPIResult[AgentSpiSubmitReviewResult](envelope, err)
}

func (c *AgentSPIClient) SceneList(ctx context.Context, request AgentSpiSceneListRequest, options RequestOptions) (AgentSpiSceneListResult, error) {
	query := make(url.Values, 3)
	setOptionalString(query, "sceneName", request.SceneName)
	setOptionalInt32(query, "page", request.Page)
	setOptionalInt32(query, "pageSize", request.PageSize)
	envelope, err := c.transport.Do(ctx, http.MethodGet, agentSpiSceneListPath, query, nil, options)
	return decodeAgentSPIResult[AgentSpiSceneListResult](envelope, err)
}

func (c *AgentSPIClient) SceneGet(ctx context.Context, request AgentSpiSceneGetRequest, options RequestOptions) (AgentSpiSceneGetResult, error) {
	query := make(url.Values, 2)
	setOptionalInt64(query, "sceneId", request.SceneID)
	setOptionalString(query, "sceneName", request.SceneName)
	envelope, err := c.transport.Do(ctx, http.MethodGet, agentSpiSceneGetPath, query, nil, options)
	return decodeAgentSPIResult[AgentSpiSceneGetResult](envelope, err)
}

func (c *AgentSPIClient) SceneSave(ctx context.Context, request AgentSpiSceneSaveRequest, options RequestOptions) (AgentSpiSceneSaveResult, error) {
	envelope, err := c.transport.Do(ctx, http.MethodPost, agentSpiSceneSavePath, nil, request, options)
	return decodeAgentSPIResult[AgentSpiSceneSaveResult](envelope, err)
}

func (c *AgentSPIClient) SyncBoe(ctx context.Context, request AgentSpiSceneSyncBoeRequest, options RequestOptions) (AgentSpiSceneSyncBoeResult, error) {
	envelope, err := c.transport.Do(ctx, http.MethodPost, agentSpiSceneSyncBoePath, nil, request, options)
	return decodeAgentSPIResult[AgentSpiSceneSyncBoeResult](envelope, err)
}

func (c *AgentSPIClient) AccessAppList(ctx context.Context, request AgentSpiAccessAppListRequest, options RequestOptions) (AgentSpiAccessAppListResult, error) {
	query := make(url.Values, 3)
	query.Set("sceneId", strconv.FormatInt(request.SceneID, 10))
	setOptionalInt32(query, "page", request.Page)
	setOptionalInt32(query, "pageSize", request.PageSize)
	envelope, err := c.transport.Do(ctx, http.MethodGet, agentSpiAccessAppListPath, query, nil, options)
	return decodeAgentSPIResult[AgentSpiAccessAppListResult](envelope, err)
}

func (c *AgentSPIClient) AccessAppGet(ctx context.Context, request AgentSpiAccessAppGetRequest, options RequestOptions) (AgentSpiAccessAppGetResult, error) {
	query := make(url.Values, 3)
	setOptionalInt64(query, "authId", request.AuthID)
	setOptionalInt64(query, "sceneId", request.SceneID)
	setOptionalInt64(query, "appId", request.AppID)
	envelope, err := c.transport.Do(ctx, http.MethodGet, agentSpiAccessAppGetPath, query, nil, options)
	return decodeAgentSPIResult[AgentSpiAccessAppGetResult](envelope, err)
}

func (c *AgentSPIClient) AccessAppSave(ctx context.Context, request AgentSpiAccessAppSaveRequest, options RequestOptions) (AgentSpiAccessAppSaveResult, error) {
	envelope, err := c.transport.Do(ctx, http.MethodPost, agentSpiAccessAppSavePath, nil, request, options)
	return decodeAgentSPIResult[AgentSpiAccessAppSaveResult](envelope, err)
}

func (c *AgentSPIClient) AccessAppEnable(ctx context.Context, request AgentSpiAccessAppEnableRequest, options RequestOptions) (AgentSpiAccessAppEnableResult, error) {
	envelope, err := c.transport.Do(ctx, http.MethodPost, agentSpiAccessAppEnablePath, nil, request, options)
	return decodeAgentSPIResult[AgentSpiAccessAppEnableResult](envelope, err)
}

func (c *AgentSPIClient) CancelUpgrade(ctx context.Context, request AgentSpiCancelUpgradeRequest, options RequestOptions) (AgentSpiCancelUpgradeResult, error) {
	envelope, err := c.transport.Do(ctx, http.MethodPost, agentSpiCancelUpgradePath, nil, request, options)
	return decodeAgentSPIResult[AgentSpiCancelUpgradeResult](envelope, err)
}

func decodeAgentSPIResult[T any](envelope Envelope, requestErr error) (T, error) {
	result, err := decodeAgentResult[T](envelope, requestErr)
	if err == nil {
		setAgentSPIResultEnvelope(&result, envelope)
	}
	return result, err
}

func setAgentSPIResultEnvelope(result any, envelope Envelope) {
	switch typed := result.(type) {
	case *AgentSpiGetInterfaceResult:
		typed.Envelope = envelope
	case *AgentSpiListInterfaceResult:
		typed.Envelope = envelope
	case *AgentSpiSaveInterfaceResult:
		typed.Envelope = envelope
	case *AgentSpiSubmitReviewResult:
		typed.Envelope = envelope
	case *AgentSpiSceneListResult:
		typed.Envelope = envelope
	case *AgentSpiSceneGetResult:
		typed.Envelope = envelope
	case *AgentSpiSceneSaveResult:
		typed.Envelope = envelope
	case *AgentSpiSceneSyncBoeResult:
		typed.Envelope = envelope
	case *AgentSpiAccessAppListResult:
		typed.Envelope = envelope
	case *AgentSpiAccessAppGetResult:
		typed.Envelope = envelope
	case *AgentSpiAccessAppSaveResult:
		typed.Envelope = envelope
	case *AgentSpiAccessAppEnableResult:
		typed.Envelope = envelope
	case *AgentSpiCancelUpgradeResult:
		typed.Envelope = envelope
	}
}

func setOptionalInt64(query url.Values, name string, value *int64) {
	if value != nil {
		query.Set(name, strconv.FormatInt(*value, 10))
	}
}

func setOptionalInt32(query url.Values, name string, value *int32) {
	if value != nil {
		query.Set(name, strconv.FormatInt(int64(*value), 10))
	}
}

func setOptionalString(query url.Values, name string, value *string) {
	if value != nil {
		query.Set(name, *value)
	}
}
