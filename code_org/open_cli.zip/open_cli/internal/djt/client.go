package djt

import (
	"context"
	"encoding/json"
	"errors"
	"net/http"

	"code.byted.org/temai/open_cli/internal/djt/auth"
)

type Client struct {
	transport *Transport
}

const maxResponseBytes = 1 << 20

type DomainInfo struct {
	DomainID   int64    `json:"domainId"`
	DomainName string   `json:"domainName"`
	SuffixList []string `json:"suffixList"`
}

type BizDomainListData struct {
	Total               int64        `json:"total"`
	DomainInfoList      []DomainInfo `json:"domainInfoList"`
	OwnerdomainInfoList []DomainInfo `json:"ownerdomainInfoList"`
}

type BizDomainListResult struct {
	Envelope Envelope
	Data     BizDomainListData
}

func NewClient(httpClient auth.HTTPDoer) *Client {
	return &Client{transport: newTransport(httpClient, maxResponseBytes)}
}

func (c *Client) ListBizDomains(ctx context.Context, options RequestOptions) (BizDomainListResult, error) {
	envelope, err := c.transport.Do(
		ctx,
		http.MethodGet,
		"/api/domain/list",
		nil,
		nil,
		options,
	)
	if err != nil {
		return BizDomainListResult{}, err
	}

	result := BizDomainListResult{Envelope: envelope}
	if err := json.Unmarshal(envelope.Data, &result.Data); err != nil {
		return BizDomainListResult{}, errors.New("解析业务域响应失败")
	}
	if result.Data.DomainInfoList == nil {
		result.Data.DomainInfoList = []DomainInfo{}
	}
	if result.Data.OwnerdomainInfoList == nil {
		result.Data.OwnerdomainInfoList = []DomainInfo{}
	}
	return result, nil
}
