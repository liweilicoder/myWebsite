package djt

import (
	"context"
	"errors"
	"reflect"
	"strings"
	"testing"
)

type recordingAgentInterfaceAPI struct {
	calls []string

	getResult     AgentGetResult
	getErr        error
	initResult    AgentInitResult
	initErr       error
	saveResult    AgentSaveResult
	saveErr       error
	docResult     AgentDocResult
	docErr        error
	advanceResult AgentAdvanceResult
	advanceErr    error

	getRequest     AgentGetRequest
	advanceRequest AgentAdvanceRequest
}

func (f *recordingAgentInterfaceAPI) Get(_ context.Context, request AgentGetRequest, _ RequestOptions) (AgentGetResult, error) {
	f.calls = append(f.calls, "get")
	f.getRequest = request
	return f.getResult, f.getErr
}

func (f *recordingAgentInterfaceAPI) Init(_ context.Context, _ AgentInitRequest, _ RequestOptions) (AgentInitResult, error) {
	f.calls = append(f.calls, "init")
	return f.initResult, f.initErr
}

func (f *recordingAgentInterfaceAPI) Save(_ context.Context, _ AgentSaveRequest, _ RequestOptions) (AgentSaveResult, error) {
	f.calls = append(f.calls, "save")
	return f.saveResult, f.saveErr
}

func (f *recordingAgentInterfaceAPI) Doc(_ context.Context, _ AgentDocRequest, _ RequestOptions) (AgentDocResult, error) {
	f.calls = append(f.calls, "doc")
	return f.docResult, f.docErr
}

func (f *recordingAgentInterfaceAPI) AdvanceStep(_ context.Context, request AgentAdvanceRequest, _ RequestOptions) (AgentAdvanceResult, error) {
	f.calls = append(f.calls, "advance")
	f.advanceRequest = request
	return f.advanceResult, f.advanceErr
}

func TestAgentServiceDelegatesNonAdvanceMethods(t *testing.T) {
	ctx := context.Background()
	options := RequestOptions{}

	t.Run("get", func(t *testing.T) {
		want := AgentGetResult{Current: &AgentCurrent{InterfaceID: 1}}
		api := &recordingAgentInterfaceAPI{getResult: want}
		got, err := NewAgentService(api).Get(ctx, AgentGetRequest{InterfaceID: agentInt64Pointer(1)}, options)
		if err != nil {
			t.Fatal(err)
		}
		if !reflect.DeepEqual(got, want) || !reflect.DeepEqual(api.calls, []string{"get"}) {
			t.Fatalf("got=%+v calls=%v", got, api.calls)
		}
	})

	t.Run("init", func(t *testing.T) {
		want := AgentInitResult{MethodName: "Get"}
		api := &recordingAgentInterfaceAPI{initResult: want}
		got, err := NewAgentService(api).Init(ctx, AgentInitRequest{}, options)
		if err != nil {
			t.Fatal(err)
		}
		if !reflect.DeepEqual(got, want) || !reflect.DeepEqual(api.calls, []string{"init"}) {
			t.Fatalf("got=%+v calls=%v", got, api.calls)
		}
	})

	t.Run("save", func(t *testing.T) {
		want := AgentSaveResult{Applied: true}
		api := &recordingAgentInterfaceAPI{saveResult: want}
		got, err := NewAgentService(api).Save(ctx, AgentSaveRequest{}, options)
		if err != nil {
			t.Fatal(err)
		}
		if !reflect.DeepEqual(got, want) || !reflect.DeepEqual(api.calls, []string{"save"}) {
			t.Fatalf("got=%+v calls=%v", got, api.calls)
		}
	})

	t.Run("doc", func(t *testing.T) {
		applied := true
		want := AgentDocResult{Applied: &applied}
		api := &recordingAgentInterfaceAPI{docResult: want}
		got, err := NewAgentService(api).Doc(ctx, AgentDocRequest{}, options)
		if err != nil {
			t.Fatal(err)
		}
		if !reflect.DeepEqual(got, want) || !reflect.DeepEqual(api.calls, []string{"doc"}) {
			t.Fatalf("got=%+v calls=%v", got, api.calls)
		}
	})
}

func TestAgentServiceAdvanceAllowsEverySupportedStep(t *testing.T) {
	steps := []string{"basic", "request", "response", "errcode", "ppe", "submit-audit", "cancel-audit"}
	status := int32(110)
	for _, step := range steps {
		t.Run(step, func(t *testing.T) {
			api := &recordingAgentInterfaceAPI{
				getResult: AgentGetResult{Current: &AgentCurrent{InterfaceID: 2846, ModifyVersionID: 42, StatusV2: &status}},
			}

			_, err := NewAgentService(api).AdvanceStep(context.Background(), AgentAdvanceRequest{
				InterfaceID:     2846,
				ModifyVersionID: 42,
				Step:            step,
			}, RequestOptions{})

			if err != nil {
				t.Fatalf("step=%q err=%v", step, err)
			}
			if !reflect.DeepEqual(api.calls, []string{"get", "advance"}) {
				t.Fatalf("step=%q calls=%v", step, api.calls)
			}
		})
	}
}

func TestAgentServiceAdvanceRejectsUnsupportedStepWithoutCalls(t *testing.T) {
	api := &recordingAgentInterfaceAPI{}

	_, err := NewAgentService(api).AdvanceStep(context.Background(), AgentAdvanceRequest{
		InterfaceID:     2846,
		ModifyVersionID: 42,
		Step:            "publish",
	}, RequestOptions{})

	if err == nil || !strings.Contains(err.Error(), "basic|request|response|errcode|ppe|submit-audit|cancel-audit") {
		t.Fatalf("err=%v", err)
	}
	if len(api.calls) != 0 {
		t.Fatalf("calls=%v, want no calls", api.calls)
	}
}

func TestAgentServiceAdvanceRejectsStatus330WithoutPost(t *testing.T) {
	status := int32(330)
	api := &recordingAgentInterfaceAPI{
		getResult: AgentGetResult{Current: &AgentCurrent{InterfaceID: 2846, ModifyVersionID: 42, StatusV2: &status}},
	}

	_, err := NewAgentService(api).AdvanceStep(context.Background(), AgentAdvanceRequest{
		InterfaceID:     2846,
		ModifyVersionID: 42,
		Step:            "submit-audit",
	}, RequestOptions{})

	if err == nil || !strings.Contains(err.Error(), "330 及以上只能在网页发布") {
		t.Fatalf("err=%v", err)
	}
	if !reflect.DeepEqual(api.calls, []string{"get"}) {
		t.Fatalf("calls=%v", api.calls)
	}
}

func TestAgentServiceAdvanceRejectsVersionMismatchWithoutPost(t *testing.T) {
	status := int32(110)
	api := &recordingAgentInterfaceAPI{
		getResult: AgentGetResult{Current: &AgentCurrent{InterfaceID: 2846, ModifyVersionID: 43, StatusV2: &status}},
	}

	_, err := NewAgentService(api).AdvanceStep(context.Background(), AgentAdvanceRequest{
		InterfaceID:     2846,
		ModifyVersionID: 42,
		Step:            "submit-audit",
	}, RequestOptions{})

	if err == nil || !strings.Contains(err.Error(), "42") || !strings.Contains(err.Error(), "43") {
		t.Fatalf("err=%v", err)
	}
	if !reflect.DeepEqual(api.calls, []string{"get"}) {
		t.Fatalf("calls=%v", api.calls)
	}
}

func TestAgentServiceAdvanceRejectsMissingCurrentWithoutPost(t *testing.T) {
	api := &recordingAgentInterfaceAPI{getResult: AgentGetResult{}}

	_, err := NewAgentService(api).AdvanceStep(context.Background(), AgentAdvanceRequest{
		InterfaceID:     2846,
		ModifyVersionID: 42,
		Step:            "request",
	}, RequestOptions{})

	if err == nil || !strings.Contains(err.Error(), "推进前响应缺少 current") {
		t.Fatalf("err=%v", err)
	}
	if !reflect.DeepEqual(api.calls, []string{"get"}) {
		t.Fatalf("calls=%v", api.calls)
	}
}

func TestAgentServiceAdvanceGetsThenPosts(t *testing.T) {
	status := int32(110)
	request := AgentAdvanceRequest{
		InterfaceID:     2846,
		ModifyVersionID: 42,
		Step:            "submit-audit",
		DryRun:          true,
	}
	want := AgentAdvanceResult{DryRun: true, Current: &AgentCurrent{InterfaceID: 2846, ModifyVersionID: 42, StatusV2: &status}}
	api := &recordingAgentInterfaceAPI{
		getResult:     AgentGetResult{Current: &AgentCurrent{InterfaceID: 2846, ModifyVersionID: 42, StatusV2: &status}},
		advanceResult: want,
	}

	got, err := NewAgentService(api).AdvanceStep(context.Background(), request, RequestOptions{})
	if err != nil {
		t.Fatal(err)
	}
	if !reflect.DeepEqual(got, want) {
		t.Fatalf("got=%+v want=%+v", got, want)
	}
	if !reflect.DeepEqual(api.calls, []string{"get", "advance"}) {
		t.Fatalf("calls=%v", api.calls)
	}
	if api.getRequest.InterfaceID == nil || *api.getRequest.InterfaceID != request.InterfaceID {
		t.Fatalf("get request=%+v", api.getRequest)
	}
	if !reflect.DeepEqual(api.advanceRequest, request) {
		t.Fatalf("advance request=%+v want=%+v", api.advanceRequest, request)
	}
}

func TestAgentServiceAdvanceReturnsRemoteRaceError(t *testing.T) {
	status := int32(110)
	remote := &RemoteError{
		Code:    8000037,
		Message: "版本冲突",
		Current: &AgentCurrent{InterfaceID: 2846, ModifyVersionID: 43, StatusV2: &status},
	}
	api := &recordingAgentInterfaceAPI{
		getResult:  AgentGetResult{Current: &AgentCurrent{InterfaceID: 2846, ModifyVersionID: 42, StatusV2: &status}},
		advanceErr: remote,
	}

	_, err := NewAgentService(api).AdvanceStep(context.Background(), AgentAdvanceRequest{
		InterfaceID:     2846,
		ModifyVersionID: 42,
		Step:            "submit-audit",
	}, RequestOptions{})

	if !errors.Is(err, remote) {
		t.Fatalf("errors.Is(%v, remote)=false", err)
	}
	var got *RemoteError
	if !errors.As(err, &got) || got != remote {
		t.Fatalf("errors.As=%v got=%p want=%p", errors.As(err, &got), got, remote)
	}
	if !reflect.DeepEqual(api.calls, []string{"get", "advance"}) {
		t.Fatalf("calls=%v", api.calls)
	}
}
