package djt

import (
	"context"
	"encoding/json"
	"errors"
	"net/http"
)

type ApplyBizDomainAuthRequest struct {
	DomainIDs []int64 `json:"domainIds"`
}

type ApplyBizDomainAuthData struct {
	AuditManageURL string `json:"auditManageUrl"`
}

type ApplyBizDomainAuthResult struct {
	Envelope Envelope
	Data     ApplyBizDomainAuthData
}

func (c *Client) ApplyBizDomainAuth(ctx context.Context, options RequestOptions, domainIDs []int64) (ApplyBizDomainAuthResult, error) {
	if len(domainIDs) == 0 {
		return ApplyBizDomainAuthResult{}, errors.New("domainIds 不能为空")
	}
	envelope, err := c.transport.Do(
		ctx,
		http.MethodPost,
		"/api/djt-cli/domain/apply",
		nil,
		ApplyBizDomainAuthRequest{DomainIDs: domainIDs},
		options,
	)
	if err != nil {
		return ApplyBizDomainAuthResult{}, err
	}
	result := ApplyBizDomainAuthResult{Envelope: envelope}
	if err := json.Unmarshal(envelope.Data, &result.Data); err != nil {
		return ApplyBizDomainAuthResult{}, errors.New("解析域权限申请响应失败")
	}
	return result, nil
}
