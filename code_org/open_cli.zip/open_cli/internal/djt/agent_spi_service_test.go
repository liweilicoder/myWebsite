package djt

import (
	"context"
	"errors"
	"reflect"
	"strings"
	"testing"
)

type recordingAgentSPIAPI struct {
	calls         []string
	getResult     AgentSpiGetInterfaceResult
	getErr        error
	submitResult  AgentSpiSubmitReviewResult
	submitErr     error
	getRequest    AgentSpiGetInterfaceRequest
	submitRequest AgentSpiSubmitReviewRequest
}

func (f *recordingAgentSPIAPI) GetInterface(_ context.Context, request AgentSpiGetInterfaceRequest, _ RequestOptions) (AgentSpiGetInterfaceResult, error) {
	f.calls = append(f.calls, "get")
	f.getRequest = request
	return f.getResult, f.getErr
}

func (f *recordingAgentSPIAPI) ListInterface(context.Context, AgentSpiListInterfaceRequest, RequestOptions) (AgentSpiListInterfaceResult, error) {
	f.calls = append(f.calls, "list")
	return AgentSpiListInterfaceResult{}, nil
}

func (f *recordingAgentSPIAPI) SaveInterface(context.Context, AgentSpiSaveInterfaceRequest, RequestOptions) (AgentSpiSaveInterfaceResult, error) {
	f.calls = append(f.calls, "save")
	return AgentSpiSaveInterfaceResult{}, nil
}

func (f *recordingAgentSPIAPI) SubmitReview(_ context.Context, request AgentSpiSubmitReviewRequest, _ RequestOptions) (AgentSpiSubmitReviewResult, error) {
	f.calls = append(f.calls, "submit")
	f.submitRequest = request
	return f.submitResult, f.submitErr
}

func (f *recordingAgentSPIAPI) SceneList(context.Context, AgentSpiSceneListRequest, RequestOptions) (AgentSpiSceneListResult, error) {
	return AgentSpiSceneListResult{}, nil
}

func (f *recordingAgentSPIAPI) SceneGet(context.Context, AgentSpiSceneGetRequest, RequestOptions) (AgentSpiSceneGetResult, error) {
	return AgentSpiSceneGetResult{}, nil
}

func (f *recordingAgentSPIAPI) SceneSave(context.Context, AgentSpiSceneSaveRequest, RequestOptions) (AgentSpiSceneSaveResult, error) {
	return AgentSpiSceneSaveResult{}, nil
}

func (f *recordingAgentSPIAPI) SyncBoe(context.Context, AgentSpiSceneSyncBoeRequest, RequestOptions) (AgentSpiSceneSyncBoeResult, error) {
	return AgentSpiSceneSyncBoeResult{}, nil
}

func (f *recordingAgentSPIAPI) AccessAppList(context.Context, AgentSpiAccessAppListRequest, RequestOptions) (AgentSpiAccessAppListResult, error) {
	return AgentSpiAccessAppListResult{}, nil
}

func (f *recordingAgentSPIAPI) AccessAppGet(context.Context, AgentSpiAccessAppGetRequest, RequestOptions) (AgentSpiAccessAppGetResult, error) {
	return AgentSpiAccessAppGetResult{}, nil
}

func (f *recordingAgentSPIAPI) AccessAppSave(context.Context, AgentSpiAccessAppSaveRequest, RequestOptions) (AgentSpiAccessAppSaveResult, error) {
	return AgentSpiAccessAppSaveResult{}, nil
}

func (f *recordingAgentSPIAPI) AccessAppEnable(context.Context, AgentSpiAccessAppEnableRequest, RequestOptions) (AgentSpiAccessAppEnableResult, error) {
	return AgentSpiAccessAppEnableResult{}, nil
}

func (f *recordingAgentSPIAPI) CancelUpgrade(context.Context, AgentSpiCancelUpgradeRequest, RequestOptions) (AgentSpiCancelUpgradeResult, error) {
	f.calls = append(f.calls, "cancel-upgrade")
	return AgentSpiCancelUpgradeResult{}, nil
}

func TestAgentSPIServiceSubmitReviewDryRunSkipsPreflight(t *testing.T) {
	want := AgentSpiSubmitReviewResult{DryRun: true}
	api := &recordingAgentSPIAPI{submitResult: want}
	request := AgentSpiSubmitReviewRequest{InterfaceID: 2846, ModifyVersionID: 42, DryRun: true, Reason: "ready"}

	got, err := NewAgentSPIService(api).SubmitReview(context.Background(), request, RequestOptions{})
	if err != nil {
		t.Fatal(err)
	}
	if !reflect.DeepEqual(got, want) || !reflect.DeepEqual(api.calls, []string{"submit"}) {
		t.Fatalf("got=%+v calls=%v", got, api.calls)
	}
}

func TestAgentSPIServiceSubmitReviewApplyGetsThenPosts(t *testing.T) {
	request := AgentSpiSubmitReviewRequest{InterfaceID: 2846, ModifyVersionID: 42, Reason: "ready"}
	want := AgentSpiSubmitReviewResult{Applied: true}
	api := &recordingAgentSPIAPI{
		getResult:    AgentSpiGetInterfaceResult{Current: &AgentSpiCurrent{InterfaceID: 2846, ModifyVersionID: 42, Status: 201}},
		submitResult: want,
	}

	got, err := NewAgentSPIService(api).SubmitReview(context.Background(), request, RequestOptions{})
	if err != nil {
		t.Fatal(err)
	}
	if !reflect.DeepEqual(got, want) || !reflect.DeepEqual(api.calls, []string{"get", "submit"}) {
		t.Fatalf("got=%+v calls=%v", got, api.calls)
	}
	if api.getRequest.InterfaceID == nil || *api.getRequest.InterfaceID != request.InterfaceID {
		t.Fatalf("get request=%+v", api.getRequest)
	}
	if !reflect.DeepEqual(api.submitRequest, request) {
		t.Fatalf("submit request=%+v", api.submitRequest)
	}
}

func TestAgentSPIServiceSubmitReviewApplyRejectsLocalConflictWithoutPost(t *testing.T) {
	tests := []struct {
		name    string
		current *AgentSpiCurrent
		want    string
	}{
		{name: "missing current", want: "current"},
		{name: "wrong status", current: &AgentSpiCurrent{ModifyVersionID: 42, Status: 301}, want: "status=301"},
		{name: "version changed", current: &AgentSpiCurrent{ModifyVersionID: 43, Status: 201}, want: "请求=42 当前=43"},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			api := &recordingAgentSPIAPI{getResult: AgentSpiGetInterfaceResult{Current: test.current}}
			_, err := NewAgentSPIService(api).SubmitReview(context.Background(), AgentSpiSubmitReviewRequest{
				InterfaceID: 2846, ModifyVersionID: 42, Reason: "ready",
			}, RequestOptions{})
			if err == nil || !strings.Contains(err.Error(), test.want) {
				t.Fatalf("err=%v want substring %q", err, test.want)
			}
			if !reflect.DeepEqual(api.calls, []string{"get"}) {
				t.Fatalf("calls=%v", api.calls)
			}
		})
	}
}

func TestAgentSPIServiceSubmitReviewSkipsVersionCheckWhenCurrentMissing(t *testing.T) {
	api := &recordingAgentSPIAPI{
		getResult: AgentSpiGetInterfaceResult{Current: &AgentSpiCurrent{ModifyVersionID: 0, Status: 201}},
	}
	got, err := NewAgentSPIService(api).SubmitReview(context.Background(), AgentSpiSubmitReviewRequest{
		InterfaceID: 2846, ModifyVersionID: 42, Reason: "ready",
	}, RequestOptions{})
	if err != nil {
		t.Fatalf("err=%v", err)
	}
	if !reflect.DeepEqual(api.calls, []string{"get", "submit"}) {
		t.Fatalf("calls=%v", api.calls)
	}
	if got.DryRun {
		t.Fatalf("got=%+v", got)
	}
}

func TestAgentSPIServiceSubmitReviewPreservesRemoteError(t *testing.T) {
	remote := errors.New("remote race")
	api := &recordingAgentSPIAPI{
		getResult: AgentSpiGetInterfaceResult{Current: &AgentSpiCurrent{ModifyVersionID: 42, Status: 201}},
		submitErr: remote,
	}
	_, err := NewAgentSPIService(api).SubmitReview(context.Background(), AgentSpiSubmitReviewRequest{
		InterfaceID: 2846, ModifyVersionID: 42, Reason: "ready",
	}, RequestOptions{})
	if !errors.Is(err, remote) {
		t.Fatalf("err=%v", err)
	}
}
