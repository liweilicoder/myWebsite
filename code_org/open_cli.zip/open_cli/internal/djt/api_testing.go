package djt

import (
	"context"
	"encoding/json"
	"net/http"
)

const (
	apiTestExecutePath = "/api/djt-cli/agent/api-test/execute"
	apiTestAddAuthPath = "/api/djt-cli/agent/api-test/auth/add"
)

type APITestClient struct {
	transport *Transport
}

func NewAPITestClient(transport *Transport) *APITestClient {
	return &APITestClient{transport: transport}
}

type APITestRequest struct {
	InterfaceName string          `json:"interfaceName"`
	Environment   string          `json:"env"`
	Lane          *string         `json:"lane,omitempty"`
	AuthID        *string         `json:"authId,omitempty"`
	AuthType      *string         `json:"authType,omitempty"`
	Parameters    json.RawMessage `json:"params"`
}

type APITestResult struct {
	Envelope
	InterfaceID   int64  `json:"interfaceId"`
	InterfaceName string `json:"interfaceName"`
	Environment   string `json:"env"`
	ResultJSON    string `json:"resultJson"`
	State         int16  `json:"state"`
	LogID         string `json:"logId,omitempty"`
}

type APITestAuthRequest struct {
	AuthID           string `json:"authId"`
	AuthSubjectBizID int64  `json:"authSubjectBizId"`
	Environment      string `json:"env"`
}

type APITestAuthResult struct {
	Envelope
	AuthID           string `json:"authId"`
	AuthSubjectBizID int64  `json:"authSubjectBizId"`
	Environment      string `json:"env"`
}

func (c *APITestClient) Execute(ctx context.Context, request APITestRequest, options RequestOptions) (APITestResult, error) {
	envelope, err := c.transport.Do(ctx, http.MethodPost, apiTestExecutePath, nil, request, options)
	return decodeAPITestResult[APITestResult](envelope, err)
}

func (c *APITestClient) AddAuth(ctx context.Context, request APITestAuthRequest, options RequestOptions) (APITestAuthResult, error) {
	envelope, err := c.transport.Do(ctx, http.MethodPost, apiTestAddAuthPath, nil, request, options)
	return decodeAPITestResult[APITestAuthResult](envelope, err)
}

func decodeAPITestResult[T any](envelope Envelope, requestErr error) (T, error) {
	var result T
	if requestErr != nil {
		return result, requestErr
	}
	if len(envelope.Data) != 0 && string(envelope.Data) != "null" {
		if err := json.Unmarshal(envelope.Data, &result); err != nil {
			return result, err
		}
	}
	switch typed := any(&result).(type) {
	case *APITestResult:
		typed.Envelope = envelope
	case *APITestAuthResult:
		typed.Envelope = envelope
	}
	return result, nil
}
