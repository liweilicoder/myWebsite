package config

import "testing"

func TestProductionDeviceEndpoints(t *testing.T) {
	p := Production()
	if p.GatewayBase != "https://openapi-fxg.jinritemai.com" {
		t.Fatalf("gateway=%s", p.GatewayBase)
	}
	if p.DeviceStart != "https://openapi-fxg.jinritemai.com/auth/cli/device/start" {
		t.Fatalf("start=%s", p.DeviceStart)
	}
	if p.DeviceToken != "https://openapi-fxg.jinritemai.com/auth/cli/device/token" {
		t.Fatalf("token=%s", p.DeviceToken)
	}
	if p.VerificationURI != "https://openapi-fxg.jinritemai.com/auth/cli" {
		t.Fatalf("verify=%s", p.VerificationURI)
	}
}
