package config

import "code.byted.org/temai/open_cli/internal/core/identity"

type Endpoints struct {
	GatewayBase     string
	DeviceStart     string
	DeviceToken     string
	VerificationURI string
}

func Production() Endpoints {
	return Endpoints{
		GatewayBase:     "https://openapi-fxg.jinritemai.com",
		DeviceStart:     "https://openapi-fxg.jinritemai.com/auth/cli/device/start",
		DeviceToken:     "https://openapi-fxg.jinritemai.com/auth/cli/device/token",
		VerificationURI: "https://openapi-fxg.jinritemai.com/auth/cli",
	}
}

const (
	HeaderSource  = identity.HeaderSource
	HeaderFrom    = identity.HeaderFrom
	HeaderVersion = identity.HeaderVersion
	HeaderKind    = "X-Doudian-Open-Cli-Auth-Kind"
	HeaderToken   = "X-Doudian-Open-Cli-Access-Token"
	SourceValue   = identity.SourceValue
	FromValue     = identity.DefaultFrom
)
