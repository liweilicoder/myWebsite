package skill

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestBizSkillLayout(t *testing.T) {
	root := filepath.Join("..", "..", "..", "skills", "biz")
	entries, err := os.ReadDir(root)
	if err != nil {
		t.Fatal(err)
	}
	catalog := documentsByName(t)
	for _, entry := range entries {
		name := entry.Name()
		if !entry.IsDir() {
			if name != "README.md" {
				t.Fatalf("skills/biz 根上只允许 README.md，发现 %s", name)
			}
			continue
		}
		files := readBizTree(t, filepath.Join(root, name))
		if err := validateBizFiles(name, files); err != nil {
			t.Fatal(err)
		}
		frontmatterName, _ := parseFrontmatter(files["SKILL.md"])
		doc, ok := catalog[frontmatterName]
		if !ok {
			t.Fatalf("内嵌 catalog 缺少业务 Skill %s：先运行 node scripts/sync-skill.mjs", frontmatterName)
		}
		if doc.Directory != name {
			t.Fatalf("业务 Skill %s 的目录键=%q", frontmatterName, doc.Directory)
		}
		if string(doc.Markdown) != string(files["SKILL.md"]) {
			t.Fatalf("%s 的内嵌 SKILL.md 与手工源不一致", name)
		}
		if doc.Description == "" {
			t.Fatalf("%s 进入 catalog 时 description 为空", name)
		}
	}
}

func TestDocumentsCatalogContract(t *testing.T) {
	bundles := Bundles()
	docs := Documents()
	if len(docs) == 0 || docs[0].Name != OpenCLIBundleName {
		t.Fatalf("第一项必须是 open: %+v", docs)
	}
	if len(docs) != len(bundles) {
		t.Fatalf("catalog 条数=%d bundles=%d", len(docs), len(bundles))
	}
	seen := map[string]struct{}{}
	for _, doc := range docs {
		if _, dup := seen[doc.Name]; dup {
			t.Fatalf("catalog 重名：%s", doc.Name)
		}
		seen[doc.Name] = struct{}{}
		if doc.Name == "djt" || strings.Contains(doc.Name, "djt") {
			t.Fatalf("对外 Skill 目录不得出现 djt: %s", doc.Name)
		}
		if doc.Description == "" {
			t.Fatalf("%s 缺少 description：skills 目录无法匹配", doc.Name)
		}
		if strings.ContainsAny(doc.Description, "\t\n\r") {
			t.Fatalf("%s 的 description 含制表符或换行", doc.Name)
		}
		name, description := parseFrontmatter(doc.Markdown)
		if name != doc.Name {
			t.Fatalf("frontmatter name=%q 与 catalog 名 %q 不一致", name, doc.Name)
		}
		if description != doc.Description {
			t.Fatalf("%s catalog description 与 frontmatter 解析结果不一致", doc.Name)
		}
		got, err := Lookup(doc.Name)
		if err != nil {
			t.Fatal(err)
		}
		if string(got.Markdown) != string(doc.Markdown) {
			t.Fatalf("Lookup(%s) 必须返回同一份 SKILL.md", doc.Name)
		}
		legacy, err := Lookup(doc.Directory)
		if err != nil || string(legacy.Markdown) != string(doc.Markdown) {
			t.Fatalf("Lookup(%s) 必须保留目录名兼容：%v", doc.Directory, err)
		}
	}
	for _, bundle := range bundles {
		found := false
		for _, doc := range docs {
			if doc.Directory == bundle.Name {
				found = true
				break
			}
		}
		if !found {
			t.Fatalf("bundle %s 未出现在 catalog", bundle.Name)
		}
	}
}

func TestValidateBizFiles(t *testing.T) {
	valid := map[string][]byte{
		"SKILL.md": []byte(`---
name: 内容投稿
description: >-
  内容投稿：组稿、上传素材、按顺序调开放接口发稿。
  当用户提到内容投稿、图文发稿时使用。
---

# 内容投稿

` + "```bash\n" + `doudian-open-cli api POST --path '/material/uploadImageSync' --data '{"folder_id":"1"}' --output json
` + "```\n"),
	}
	if err := validateBizFiles("content-aigc", valid); err != nil {
		t.Fatal(err)
	}

	cases := []struct {
		name    string
		dir     string
		files   map[string][]byte
		wantErr string
	}{
		{name: "缺少 SKILL.md", dir: "content-aigc", files: map[string][]byte{}, wantErr: "缺少 SKILL.md"},
		{name: "保留名", dir: "djt", files: valid, wantErr: "不能命名为 djt"},
		{name: "非法目录名", dir: "Content_AIGC", files: valid, wantErr: "必须匹配"},
		{
			name:    "空 description",
			dir:     "content-aigc",
			files:   map[string][]byte{"SKILL.md": []byte("---\nname: content-aigc\ndescription:\n---\n")},
			wantErr: "description 不能为空",
		},
		{
			name:    "description 含制表符",
			dir:     "content-aigc",
			files:   map[string][]byte{"SKILL.md": []byte("---\nname: content-aigc\ndescription: 左\t右\n---\n")},
			wantErr: "不能含制表符或换行",
		},
		{
			name:    "嵌套 SKILL.md",
			dir:     "content-aigc",
			files:   map[string][]byte{"SKILL.md": valid["SKILL.md"], "nested/SKILL.md": []byte("# nested\n")},
			wantErr: "只允许 SKILL.md",
		},
		{
			name:    "含 --dry-run",
			dir:     "content-aigc",
			files:   map[string][]byte{"SKILL.md": []byte("---\nname: content-aigc\ndescription: 内容投稿。\n---\n先 --dry-run\n")},
			wantErr: "--dry-run",
		},
		{
			name:    "含点将台",
			dir:     "content-aigc",
			files:   map[string][]byte{"SKILL.md": []byte("---\nname: content-aigc\ndescription: 内容投稿。\n---\n点将台配置\n")},
			wantErr: "点将台",
		},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			err := validateBizFiles(tc.dir, tc.files)
			if err == nil || !strings.Contains(err.Error(), tc.wantErr) {
				t.Fatalf("err=%v want 含 %q", err, tc.wantErr)
			}
		})
	}
}

func documentsByName(t *testing.T) map[string]Document {
	t.Helper()
	out := map[string]Document{}
	for _, doc := range Documents() {
		out[doc.Name] = doc
	}
	return out
}

func readBizTree(t *testing.T, dir string) map[string][]byte {
	t.Helper()
	files := map[string][]byte{}
	err := filepath.WalkDir(dir, func(path string, entry os.DirEntry, walkErr error) error {
		if walkErr != nil {
			return walkErr
		}
		if entry.IsDir() {
			return nil
		}
		rel, err := filepath.Rel(dir, path)
		if err != nil {
			return err
		}
		body, err := os.ReadFile(path)
		if err != nil {
			return err
		}
		files[filepath.ToSlash(rel)] = body
		return nil
	})
	if err != nil {
		t.Fatal(err)
	}
	return files
}
