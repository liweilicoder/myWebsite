package skill

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestOpenBundleMatchesCanonicalSkillDirectory(t *testing.T) {
	root := filepath.Join("..", "..", "..", "skills", "open_cli_skill")
	want := map[string][]byte{}
	err := filepath.WalkDir(root, func(path string, entry os.DirEntry, err error) error {
		if err != nil {
			return err
		}
		if entry.IsDir() {
			return nil
		}
		relative, err := filepath.Rel(root, path)
		if err != nil {
			return err
		}
		content, err := os.ReadFile(path)
		if err != nil {
			return err
		}
		want[filepath.ToSlash(relative)] = content
		return nil
	})
	if err != nil {
		t.Fatal(err)
	}
	got := Bundle()
	if got.Name != OpenCLIBundleName {
		t.Fatalf("name=%q", got.Name)
	}
	if len(got.Files) != len(want) {
		t.Fatalf("embed 文件数=%d want=%d", len(got.Files), len(want))
	}
	for _, file := range got.Files {
		content, exists := want[file.Path]
		if !exists || string(file.Content) != string(content) {
			t.Fatalf("embed 文件不一致: %s", file.Path)
		}
		text := string(file.Content)
		for _, forbidden := range []string{"点将台", "djt", "djt.bytedance.net", "doudian-open-cli djt", "--use-ppe", "--ppe-env", "PPE"} {
			if strings.Contains(text, forbidden) {
				t.Fatalf("open skill 不得包含 %q", forbidden)
			}
		}
	}
}
