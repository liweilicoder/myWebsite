package skill

import (
	"fmt"
	"regexp"
	"strings"
)

// 目录名支持下划线和连字符，作为稳定的 Bundle 与 embed 子目录名。
var bizNamePattern = regexp.MustCompile(`^[a-z][a-z0-9_-]{0,40}$`)

// references 与 scripts 的查找名，不含后缀。
var partNamePattern = regexp.MustCompile(`^[a-z][a-z0-9_-]{0,40}$`)

var reservedBizNames = map[string]struct{}{
	"open":           {},
	"open_cli_skill": {},
	"djt":            {},
	"biz":            {},
}

// 业务 Skill 禁止写这些：Agent 应从 `doudian-open-cli skills open_cli_skill` 读取通用 CLI 规则。
var bizForbiddenSubstrings = []string{
	"init --kind", "--no-wait", "--complete", "--device-code", "verification_url", "device_code",
	"auth status", "auth logout", "--app-key", "--app-secret", "--access-token",
	"--dry-run", "sign_method", "签名算法",
	"doudian-open-cli djt", "djt.bytedance.net", "--use-ppe", "--ppe-env",
	"点将台", "PPE",
}

func validateBizName(name string) error {
	if _, reserved := reservedBizNames[name]; reserved {
		return fmt.Errorf("业务目录不能命名为 %s", name)
	}
	if !bizNamePattern.MatchString(name) {
		return fmt.Errorf("业务目录名必须匹配 %s：%s", bizNamePattern.String(), name)
	}
	return nil
}

func validateBizMarkdown(dirName string, markdown []byte) error {
	name, description := parseFrontmatter(markdown)
	if name == "" || strings.TrimSpace(name) != name || strings.ContainsAny(name, "\t\n\r") {
		return fmt.Errorf("%s 的 frontmatter name 必须是非空单行名称", dirName)
	}
	if _, reserved := reservedBizNames[name]; reserved {
		return fmt.Errorf("业务 Skill 不能命名为 %s", name)
	}
	if description == "" {
		return fmt.Errorf("%s 的 description 不能为空：doudian-open-cli skills 用它做目录匹配", dirName)
	}
	if strings.ContainsAny(description, "\t\n\r") {
		return fmt.Errorf("%s 的 description 不能含制表符或换行：会破坏 skills 目录的「名称<TAB>description」一行格式", dirName)
	}
	return rejectBizForbidden("SKILL.md", string(markdown))
}

func validateBizFiles(dirName string, files map[string][]byte) error {
	if err := validateBizName(dirName); err != nil {
		return err
	}
	markdown, ok := files["SKILL.md"]
	if !ok {
		return fmt.Errorf("%s 缺少 SKILL.md", dirName)
	}
	if err := validateBizMarkdown(dirName, markdown); err != nil {
		return err
	}
	for rel, body := range files {
		if err := validateBizPath(rel); err != nil {
			return err
		}
		if err := rejectBizForbidden(rel, string(body)); err != nil {
			return err
		}
	}
	return nil
}

func validateBizPath(rel string) error {
	if rel == "SKILL.md" {
		return nil
	}
	dir, file, ok := strings.Cut(rel, "/")
	if !ok || strings.Contains(file, "/") || file == "" {
		return fmt.Errorf("业务 Skill 只允许 SKILL.md、references/<name>.md、scripts/<name>.sh|py：%s", rel)
	}
	switch dir {
	case "references":
		name, isMD := strings.CutSuffix(file, ".md")
		if !isMD || strings.Contains(name, ".") || !partNamePattern.MatchString(name) {
			return fmt.Errorf("references 只允许 <name>.md，name 为小写字母、数字、下划线或连字符：%s", rel)
		}
	case "scripts":
		name, ext, hasExt := strings.Cut(file, ".")
		if !hasExt || ext == "" || strings.Contains(ext, ".") || !partNamePattern.MatchString(name) {
			return fmt.Errorf("scripts 只允许一层 <name>.sh 或 <name>.py：%s", rel)
		}
		if ext != "sh" && ext != "py" {
			return fmt.Errorf("scripts 只允许 .sh 或 .py：%s", rel)
		}
	default:
		return fmt.Errorf("业务 Skill 只允许 SKILL.md、references/、scripts/：%s", rel)
	}
	return nil
}

func rejectBizForbidden(rel, text string) error {
	for _, word := range bizForbiddenSubstrings {
		if strings.Contains(text, word) {
			if rel == "" {
				return fmt.Errorf("含有通用 CLI 内容 %q，应改到 skills/open_cli_skill", word)
			}
			return fmt.Errorf("%s 含有通用 CLI 内容 %q，应改到 skills/open_cli_skill", rel, word)
		}
	}
	return nil
}
