package skill

import (
	"fmt"
	"sort"
	"strings"

	coreskill "code.byted.org/temai/open_cli/internal/core/skill"
)

type Document struct {
	Name        string
	Directory   string
	Description string
	Markdown    []byte
}

func Documents() []Document {
	bundles := Bundles()
	out := make([]Document, 0, len(bundles))
	for _, bundle := range bundles {
		markdown := skillMarkdown(bundle.Name, bundle.Files)
		name, description := parseFrontmatter(markdown)
		out = append(out, Document{Name: name, Directory: bundle.Name, Description: description, Markdown: markdown})
	}
	sort.Slice(out, func(i, j int) bool {
		if out[i].Name == OpenCLIBundleName {
			return true
		}
		if out[j].Name == OpenCLIBundleName {
			return false
		}
		return out[i].Name < out[j].Name
	})
	return out
}

func Lookup(name string) (Document, error) {
	docs := Documents()
	for _, doc := range docs {
		if doc.Name == name || doc.Directory == name {
			return doc, nil
		}
	}
	names := make([]string, 0, len(docs))
	for _, doc := range docs {
		names = append(names, doc.Name)
	}
	return Document{}, fmt.Errorf("未知 Skill：%s。可用：%s", name, strings.Join(names, "、"))
}

func LookupPart(skillName, kind, id string) ([]byte, error) {
	if !partNamePattern.MatchString(id) {
		return nil, fmt.Errorf("名称无效：%s", id)
	}
	var bundleFiles []coreskill.BundledFile
	found := false
	for _, bundle := range Bundles() {
		if bundle.Name == skillName {
			bundleFiles = bundle.Files
			found = true
			break
		}
	}
	if !found {
		return nil, fmt.Errorf("未知 Skill：%s", skillName)
	}
	switch kind {
	case "ref":
		want := "references/" + id + ".md"
		for _, file := range bundleFiles {
			if file.Path == want {
				return append([]byte(nil), file.Content...), nil
			}
		}
		return nil, fmt.Errorf("未知 reference：%s", id)
	case "script":
		prefix := "scripts/" + id + "."
		var matched []coreskill.BundledFile
		for _, file := range bundleFiles {
			if strings.HasPrefix(file.Path, prefix) && !strings.Contains(strings.TrimPrefix(file.Path, prefix), "/") {
				matched = append(matched, file)
			}
		}
		if len(matched) != 1 {
			return nil, fmt.Errorf("未知 script：%s", id)
		}
		return append([]byte(nil), matched[0].Content...), nil
	default:
		return nil, fmt.Errorf("未知章节类型：%s", kind)
	}
}

func Names() []string {
	docs := Documents()
	names := make([]string, 0, len(docs))
	for _, doc := range docs {
		names = append(names, doc.Name)
	}
	return names
}

func skillMarkdown(bundle string, files []coreskill.BundledFile) []byte {
	for _, file := range files {
		if file.Path == "SKILL.md" {
			return append([]byte(nil), file.Content...)
		}
	}
	panic("内嵌 Skill 缺少 SKILL.md: " + bundle)
}

func parseFrontmatter(md []byte) (name, description string) {
	text := string(md)
	rest, ok := strings.CutPrefix(text, "---\n")
	if !ok {
		rest, ok = strings.CutPrefix(text, "---\r\n")
		if !ok {
			return "", ""
		}
	}
	end := strings.Index(rest, "\n---")
	if end < 0 {
		return "", ""
	}
	lines := strings.Split(rest[:end], "\n")
	for i := 0; i < len(lines); i++ {
		line := strings.TrimRight(lines[i], "\r")
		switch {
		case strings.HasPrefix(line, "name:"):
			name = trimYAMLScalar(strings.TrimSpace(line[len("name:"):]))
		case strings.HasPrefix(line, "description:"):
			raw := strings.TrimSpace(line[len("description:"):])
			if raw == ">" || raw == ">-" || raw == "|" || raw == "|-" {
				var parts []string
				for j := i + 1; j < len(lines); j++ {
					next := strings.TrimRight(lines[j], "\r")
					if next == "" || next[0] == ' ' || next[0] == '\t' {
						if trimmed := strings.TrimSpace(next); trimmed != "" {
							parts = append(parts, trimmed)
						}
						i = j
						continue
					}
					break
				}
				description = strings.Join(parts, " ")
			} else {
				description = trimYAMLScalar(raw)
			}
		}
	}
	return name, description
}

func trimYAMLScalar(value string) string {
	value = strings.TrimSpace(value)
	if len(value) >= 2 {
		if q := value[0]; (q == '"' || q == '\'') && value[len(value)-1] == q {
			return value[1 : len(value)-1]
		}
	}
	return value
}
