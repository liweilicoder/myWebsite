---
name: open_cli_skill
description: >-
  抖店开放平台 CLI（doudian-open-cli）的用法：skills 列出内嵌 Skill，skills open_cli_skill 打印 CLI 说明，skills <业务名> 打印业务 Skill；init 完成商家授权或写入开发者凭据，auth status / logout 查看或清除登录态，api 按路径调用开放接口（含 --dry-run）。
  当用户提到 doudian-open-cli、抖店开放平台、商家授权、登录抖店、查看是否已登录、退出、更换应用、app_key、app_secret、access_token、按 path 调开放接口（如 /product/detail）、或 --dry-run 预览请求时使用。
---

# doudian-open-cli

`doudian-open-cli` 是抖店开放平台的命令行工具，供人和 Agent 调用开放接口。

调用方式是通用的：用 `init` 在本机完成初始化授权保存凭据，再用 `api` 按路径发请求，例如 `/product/detail`。不为每个接口单独提供子命令。

下文命令均需加上 `doudian-open-cli` 前缀。参数以各命令的 `--help` 为准。

## 能力

1. **登录。** 支持两种身份，保存在同一份本地凭据中，以 `kind` 区分。`authorized` 是商家在浏览器中完成授权；`generic` 是开发者填入自己的 app_key、app_secret 和 access_token。
2. **调用接口。** `api` 使用当前凭据请求开放网关。`--dry-run` 只生成预览，不发送请求。

更换应用或切换身份时，先执行 `auth logout`，再重新 `init`。本地已有凭据时，再次 `init` 会失败。

## 命令

| 命令 | 作用 |
|---|---|
| `--help`、`-h` | 查看该命令的用法和参数。根命令以及 `init`、`auth`、`api`、`skills` 均支持 |
| `version`、`--version` | 在 stdout 打印一行版本号 |
| `skills` | 列出内嵌 Skill（`open` 以及 `skills/biz` 下的业务）。给 Agent 阅读，不写入本机目录 |
| `skills <name>` | 打印名为 `<name>` 的 Skill 全文（SKILL.md） |
| `init --kind authorized` | 发起商家授权并等待结束。适合人在终端前持续等待 |
| `init --kind authorized --no-wait` | 只发起授权并返回 `verification_url`，不保存凭据，不打开浏览器 |
| `init --kind authorized --complete` | 用本机未完成的授权换取凭据，按间隔查询直到成功或超时 |
| `init --kind generic --app-key --app-secret --access-token` | 写入开发者凭据。这三个参数都必填 |
| `auth status` | 读取本地登录状态，不请求远端，不输出 token 或 secret |
| `auth logout` | 删除本地凭据 |
| `api [GET\|POST] --path <path> --data <json>` | 按当前凭据调用开放网关。`--path` 必填，省略方法时为 POST |
| `api … --dry-run` | 预览方法、URL、query 参数名和 body，不发送请求，不输出 token 或 secret |

`auth` 与 `api` 对两种身份使用同一套命令，凭据来自最近一次成功的 `init`。

## 输出

默认 `--output json`（也可显式 `-o json`）。人眼可读短摘要时用 `-o text`（成功时不会打印 `data` / `log_id`）。

成功时 stdout 只有一个 JSON 对象，以换行结束，`ok` 为 true。`identity` 包含 `kind`、完整的 `app_key` 和 `expires_at`。

失败时 stdout 为空，错误写在 stderr，字段为 `type`、`message`、`hint`，可能还有 `log_id`、`code`。开放网关返回其标准失败 JSON 时 `body` 是那份原文；CLI 不会打印 HTTP 响应头或对端整页。`api` 若对端不是该 JSON（任意 HTTP 状态），`message` 为 `网关 HTTP ` 加上状态行（例如 `网关 HTTP 502 Bad Gateway`）。授权 `init` 则为 `授权 start 返回 HTTP 502` / `授权 token 返回 HTTP 502`（只有数字）。连不上或超过 30s 为 `type=network`。授权 `init` 的 `device/start`、`device/token` 若响应头有 `x-tt-logid`，成功时写入 `meta.log_id`，失败时写入错误 JSON 的 `log_id`。以进程退出码判断结果。

| 退出码 | `type` | 含义 |
|---|---|---|
| 0 | — | 成功 |
| 1 | `api` | 网关或业务返回失败 |
| 2 | `validation` | 参数不合法 |
| 3 | `auth` | 未登录、凭据过期或授权失败。根据 `hint` 重新 `init` |
| 4 | `network` | 网络错误 |
| 5 | `internal` | CLI 内部错误 |

未初始化时，`auth status` 仍以退出码 0 结束，`data.authenticated` 为 false。

## 使用流程

调用接口前先确认登录状态：

```bash
doudian-open-cli auth status --output json
```

出现以下任一情况时重新登录：`authenticated` 为 false，`expires_at` 已过期，或 `api` 返回 `type` 为 `auth`。通用型未填写 `--expires-at` 时，CLI 不在本地判断过期，等网关返回过期后再 `init`。

业务 Skill 指定商家在线授权时，身份检查必须先于业务调用和信息收集。未登录、过期或认证错误时先引导下方商家授权；成功前不询问商品、成片目标或参数。已知信息保留，成功后复用。不得向商家索要 app_key、app_secret、access_token，不将开发者凭据作为登录备选方案。授权链接获取失败时报告实际错误并暂停，不编造链接或改走开发者身份。已有身份不符合业务要求时说明阻塞，不自动清除或覆盖凭据。

### 商家授权

```bash
doudian-open-cli init --kind authorized --no-wait --output json
```

把 stdout 中的 `verification_url` 原样交给用户，保留 query，不单独摘出其中的授权码。stderr 会再打印一次「请在浏览器打开」及同一链接。此时尚未写入凭据。

会话仍有效时，重复执行 `--no-wait` 会沿用这次授权，不会重新发起。

展示链接后，等待方式任选其一：

- 立即执行 `doudian-open-cli init --kind authorized --complete --output json`。命令会按返回的 `interval` 查询授权结果，直到成功或超时。
- 等用户确认已在浏览器中完成授权，再执行同一条 `--complete` 命令。

`--complete` 由 Agent 执行。若本机没有未完成的授权，命令会失败，并提示先执行 `--no-wait`。

人在终端前等待时，可以不拆成两步，直接执行 `init --kind authorized`。该命令发起授权后会在同一次调用中等到结束。

### 开发者凭据

仅适用于用户明确要求使用自有应用进行开发者接入的场景，不适用于商家在线授权业务。不得因商家未登录而进入本节或向商家索要凭据。

`app_key`、`app_secret`、`access_token` 都需要用户在本地安全录入，且不能为空。这些值只写入本地凭据，不进入对话或日志。

```bash
doudian-open-cli init --kind generic --app-key "$APP_KEY" --app-secret "$APP_SECRET" --access-token "$ACCESS_TOKEN" --output json
```

授权型凭据不含 `app_secret`。两种身份都由 CLI 填写 `sign` / `sign_method`（通用型用 `app_secret` 算 HMAC）。调用方不附加 `sign`。

### 发送请求

路径必须通过 `--path` 提供并以 `/` 开头，不要生成位置 path 命令。若传入完整 URL，CLI 只保留路径。POST 必须提供 `--data`；GET 省略时按 `{}` 发送。`--data` 接受 JSON 原文、`@文件路径` 或 `@-`（从标准输入读取），且必须是一个 JSON 对象。

```bash
doudian-open-cli api POST --path '/product/detail' --data '{}' --dry-run --output json
```

预览字段包括 `http_method`、`path`、网关 `method`、`url`、`query_keys` 和 `body`。写操作先把关键参数交给用户确认，再去掉 `--dry-run` 发送同一请求。未登录时 `--dry-run` 也会失败。

## 限制

- token、secret 和 `--device-code` 的值只留在本机
- 不支持以 `+` 开头的快捷命令，也不支持 `--appkey`、`api invoke`、`auth login`

## 附录：参数

以下参数在所有子命令上可用。

| 参数 | 说明 |
|---|---|
| `-h`、`--help` | 打印帮助并退出 |
| `-o`、`--output` | 输出格式：`text`（默认）或 `json`。Agent 使用 `json` |
| `--version` | 仅根命令。打印版本号 |

### init

没有位置参数。

| 参数 | 说明 |
|---|---|
| `--kind` | `authorized` 或 `generic`。单独执行 `init` 时必填。使用 `--no-wait` 或 `--complete` 时可以省略，省略后按 `authorized` 处理 |
| `--no-wait` | 发起授权并返回 `verification_url`、`user_code`、`expires_in`、`interval`、`hint`。有 `x-tt-logid` 时另有 `meta.log_id`。不能与 `--complete`、`--device-code` 同时使用，也不能用于 `generic` |
| `--complete` | 查询本机未完成的授权，成功后写入凭据并删除该会话。不能用于 `generic` |
| `--device-code` | 可选。传入时必须与本机未完成会话一致，否则报参数错误。一般不必传入，也不要把它写入对话 |
| `--app-key` | 通用型必填 |
| `--app-secret` | 通用型必填。授权结果中若带有该字段，CLI 会丢弃，不写入文件 |
| `--access-token` | 通用型必填 |
| `--expires-at` | 可选，RFC3339。授权型的过期时间来自授权结果，不使用此参数 |

`--no-wait` 成功后还没有凭据文件。`--complete` 或 `init --kind authorized` 成功后，`auth status` 中的 `kind` 为 `authorized`。

### auth

`auth` 单独执行没有动作。子命令没有位置参数，也没有专属参数。

| 命令 | 说明 |
|---|---|
| `auth status` | 已登录时 `data.authenticated` 为 true，并包含 `identity`。未登录时 `authenticated` 为 false，退出码为 0 |
| `auth logout` | 删除全部本地凭据。成功时 `authenticated` 为 false |

### api

用法：`api [GET|POST] --path <path>`。

METHOD 是唯一可选位置参数，省略时为 POST。`--path` 必填，不接受 path 位置参数。

| 参数 | 说明 |
|---|---|
| `--path` | 必填。开放平台接口路径，或可提取 path 的完整 URL |
| `--data` | 请求体，必须是 JSON 对象。POST 必填；GET 可省略，省略后为 `{}`。支持原文、`@文件路径`、`@-` |
| `--dry-run` | 只生成预览，不访问网关。未登录时同样失败 |

方法只支持 GET 和 POST。PUT、PATCH、DELETE 会返回参数错误。路径中不能包含 `+`。

### skills

不受 `--output` 影响。stdout 是文本，不是 JSON。

无参数时列出本二进制内嵌的 Skill：先是 `open`，然后是 `skills/biz/<业务>/` 里的业务，一行一个，`名称` 和 `description` 用制表符分隔。对内专用的配置 Skill 不会出现在这个列表里。

```bash
doudian-open-cli skills
doudian-open-cli skills open_cli_skill_cli_skill
doudian-open-cli skills <业务名>
```

Agent 先跑无参数的 `skills`，按 description 判断要不要读某一份，再带名称打印全文。不要把文件安装到本机 Skill 目录。业务 Skill 只写接口组合，登录和 `api` 通用规则以 `skills open_cli_skill` 为准。
