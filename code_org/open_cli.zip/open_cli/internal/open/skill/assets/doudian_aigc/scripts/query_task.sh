#!/usr/bin/env bash
# 每隔 30 秒查询同一成片任务，最多等待 30 分钟。
set -euo pipefail

if [[ $# -lt 2 || $1 != '--task-id' || -z $2 ]]; then
  printf '用法：bash %s --task-id TASK_ID [-- CLI全局参数...]\n' "$0" >&2
  exit 2
fi
task_id=$2
shift 2
cli_args=()
if (( $# > 0 )); then
  if [[ $1 != '--' ]]; then
    printf 'CLI 全局参数前必须使用 -- 分隔。\n' >&2
    exit 2
  fi
  shift
  cli_args=("$@")
fi
for dependency in doudian-open-cli jq; do
  if ! command -v "$dependency" >/dev/null 2>&1; then
    printf '缺少依赖：%s，请安装后重新运行。\n' "$dependency" >&2
    exit 1
  fi
done
request=$(jq -cn --arg id "$task_id" '{task_ids: [$id]}')
# 临时文件仅承接 CLI 响应，退出时清理。
response_file=$(mktemp)
query_pid=''
cleanup() {
  if [[ -n "$query_pid" ]]; then
    kill "$query_pid" 2>/dev/null || true
    wait "$query_pid" 2>/dev/null || true
  fi
  rm -f "$response_file"
}
trap cleanup EXIT
trap 'printf "已停止等待，任务 ID：%s\n" "$task_id" >&2; exit 130' INT
trap 'printf "已停止等待，任务 ID：%s\n" "$task_id" >&2; exit 143' TERM

# 使用 Bash 计时器计算本次查询的总等待时间。
deadline=$((SECONDS + 1800))
stop_on_timeout() {
  printf '等待已达 30 分钟，停止查询。任务 ID：%s，可稍后继续查询。\n' "$task_id" >&2
  exit 124
}

while true; do
  (( SECONDS < deadline )) || stop_on_timeout
  doudian-open-cli ${cli_args[@]+"${cli_args[@]}"} api POST \
    --path '/contentAIGC/getAIVideoTaskListOpen' \
    --data "$request" --output json > "$response_file" &
  query_pid=$!
  # 同时检查请求耗时，避免单次查询阻塞而越过总等待上限。
  while kill -0 "$query_pid" 2>/dev/null; do
    (( SECONDS < deadline )) || stop_on_timeout
    sleep 1
  done
  if ! wait "$query_pid"; then
    query_pid=''
    (( SECONDS < deadline )) || stop_on_timeout
    printf '查询失败，可使用任务 ID %s 重新查询。\n' "$task_id" >&2
    exit 1
  fi
  query_pid=''
  (( SECONDS < deadline )) || stop_on_timeout
  result=$(cat "$response_file")
  if ! task=$(jq -ce --arg id "$task_id" '
    if .ok != true then error("查询接口未返回成功结果")
    elif (.data.tasks | type) != "array" then error("缺少 tasks 列表")
    elif any(.data.tasks[]; type != "object") then error("任务格式异常")
    else [.data.tasks[] | select(.task_id == $id)]
      | if length == 1 then .[0] else error("未取得唯一匹配的任务") end
    end
  ' <<< "$result"); then
    printf '查询结果异常，可使用任务 ID %s 重新查询。\n' "$task_id" >&2
    exit 1
  fi
  if ! status=$(jq -er '.status | numbers' <<< "$task"); then
    printf '任务 %s 缺少有效状态，停止等待。\n' "$task_id" >&2
    exit 1
  fi
  case "$status" in
    0|1)
      remaining=$((deadline - SECONDS))
      (( remaining > 0 )) || stop_on_timeout
      if (( remaining < 30 )); then
        sleep "$remaining"
      else
        sleep 30
      fi
      ;;
    2|3|9|10)
      printf '%s\n' "$task"
      break
      ;;
    *)
      printf '任务 %s 返回未知状态：%s，停止等待。\n' "$task_id" "$status" >&2
      exit 1
      ;;
  esac
done
