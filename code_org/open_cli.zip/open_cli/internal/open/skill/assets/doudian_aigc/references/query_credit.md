# 查询成片积分

调用 `POST /contentAIGC/getAIVideoCreditOpen`，获取当前商家的剩余积分和充值地址。

## 完成标准

- 查询余额：展示 `available_credits`。
- 获取充值入口：展示 `recharge_url`；未取得入口时如实说明。
- 充值后继续成片：回到创建流程，重新预校验是否可成片及本次费用。

## 组合参数

无需业务入参，使用空 JSON 对象。

## 调用示例

```bash
doudian-open-cli api POST --path '/contentAIGC/getAIVideoCreditOpen' \
  --data '{}' \
  --output json
```

## 解读结果

| 字段 | 展示规则 |
|---|---|
| `available_credits` | 成功时必返的剩余可用积分；`0` 是有效余额，缺失不能按 `0` 处理，也不用于推算本次成片费用 |
| `recharge_url` | 可选的充值页面地址；用户希望充值或创建时积分不足时展示，不自行拼接或修改 |

接口调用失败时说明未取得查询结果，不把查询失败当作余额为零。未返回充值地址时说明当前未取得入口，不代用户充值，不承诺扣费或退款状态。

## 充值后继续成片

从创建流程进入充值且用户完成充值后，回到 [create_video.md](create_video.md)，重新调用 `PreviewAIVideoTaskOpen`。

- 以预校验结果确认是否可成片、本次消耗积分和当前余额，不假定积分已经到账。
- 方案或费用发生变化时，重新向用户确认后再创建。

## 展示样式

接口结果使用 [接口结果展示预设](display_presets.md) 中对应接口的卡片；本文件负责调用与业务流程，展示预设负责结果排版。
