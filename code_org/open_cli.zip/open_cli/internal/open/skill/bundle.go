package skill

import (
	"embed"
	"io/fs"
	"path"

	coreskill "code.byted.org/temai/open_cli/internal/core/skill"
)

//go:generate node ../../../scripts/sync-skill.mjs --check

//go:embed all:assets
var bundled embed.FS

func Bundles() []coreskill.Bundle {
	entries, err := fs.ReadDir(bundled, "assets")
	if err != nil {
		panic("内嵌 open Skill 不可用: " + err.Error())
	}
	out := make([]coreskill.Bundle, 0, len(entries))
	for _, entry := range entries {
		if entry.IsDir() {
			out = append(out, bundleNamed(entry.Name()))
		}
	}
	if len(out) == 0 {
		panic("内嵌 open Skill 为空")
	}
	return out
}

func Markdown() []byte {
	doc, err := Lookup(OpenCLIBundleName)
	if err != nil {
		panic("内嵌 open Skill 不可用: " + err.Error())
	}
	return append([]byte(nil), doc.Markdown...)
}

func Bundle() coreskill.Bundle {
	for _, bundle := range Bundles() {
		if bundle.Name == OpenCLIBundleName {
			return bundle
		}
	}
	panic("内嵌 open Skill 缺少 " + OpenCLIBundleName)
}

func bundleNamed(name string) coreskill.Bundle {
	root := path.Join("assets", name)
	files := make([]coreskill.BundledFile, 0)
	err := fs.WalkDir(bundled, root, func(fileName string, entry fs.DirEntry, walkErr error) error {
		if walkErr != nil {
			return walkErr
		}
		if entry.IsDir() {
			return nil
		}
		content, err := bundled.ReadFile(fileName)
		if err != nil {
			return err
		}
		files = append(files, coreskill.BundledFile{
			Path:    path.Clean(fileName[len(root)+1:]),
			Content: append([]byte(nil), content...),
		})
		return nil
	})
	if err != nil {
		panic("内嵌 open Skill 不可用: " + err.Error())
	}
	return coreskill.Bundle{Name: name, Files: files}
}
