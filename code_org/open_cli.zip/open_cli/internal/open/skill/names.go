package skill

// OpenCLIBundleName 是开放 CLI 通用 Skill 的目录名、embed 子目录名与 skills 查找键。
const OpenCLIBundleName = "open_cli_skill"
