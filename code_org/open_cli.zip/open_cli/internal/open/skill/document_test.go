package skill

import (
	"strings"
	"testing"
)

func TestParseFrontmatterFoldedDescription(t *testing.T) {
	name, description := parseFrontmatter([]byte(`---
name: open_cli_skill
description: >-
  第一行。
  第二行。
---

# body
`))
	if name != OpenCLIBundleName {
		t.Fatalf("name=%q", name)
	}
	if description != "第一行。 第二行。" {
		t.Fatalf("description=%q", description)
	}
}

func TestDocumentsOpenFirstWithoutDJT(t *testing.T) {
	docs := Documents()
	if len(docs) == 0 || docs[0].Name != OpenCLIBundleName {
		t.Fatalf("第一项必须是 %s: %+v", OpenCLIBundleName, docs)
	}
	if string(docs[0].Markdown) != string(Markdown()) {
		t.Fatal("open_cli_skill 文档必须与 SKILL.md 一致")
	}
}

func TestLookupDoudianAIGCRef(t *testing.T) {
	body, err := LookupPart("doudian_aigc", "ref", "check_permission")
	if err != nil {
		t.Fatal(err)
	}
	if !strings.Contains(string(body), "getAIVideoPermissionOpen") {
		t.Fatalf("reference 正文不对：%s", body)
	}
	if _, err := LookupPart("doudian_aigc", "ref", "missing"); err == nil {
		t.Fatal("缺少的 reference 应失败")
	}
}
