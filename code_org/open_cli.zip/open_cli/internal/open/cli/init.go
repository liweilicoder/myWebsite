package cli

import (
	"errors"
	"fmt"
	"os"
	"strings"
	"time"

	"github.com/spf13/cobra"

	corecli "code.byted.org/temai/open_cli/internal/core/cli"
	"code.byted.org/temai/open_cli/internal/core/errs"
	"code.byted.org/temai/open_cli/internal/core/factory"
	"code.byted.org/temai/open_cli/internal/core/output"
	"code.byted.org/temai/open_cli/internal/core/ppe"
	"code.byted.org/temai/open_cli/internal/open/auth"
)

type initFlags struct {
	kind        string
	appKey      string
	appSecret   string
	accessToken string
	expiresAt   string
	noWait      bool
	complete    bool
	deviceCode  string
}

func NewCmdInit(f *factory.Factory, opts CLIOptions) *cobra.Command {
	flags := &initFlags{}
	cmd := &cobra.Command{
		Use:   "init",
		Short: "初始化开放凭据（授权型或通用型）",
		Args:  cobra.NoArgs,
		RunE: func(cmd *cobra.Command, _ []string) error {
			return runInit(cmd, f, opts, flags)
		},
	}
	cmd.Flags().StringVar(&flags.kind, "kind", "", "authorized 或 generic")
	cmd.Flags().StringVar(&flags.appKey, "app-key", "", "通用型 app_key")
	cmd.Flags().StringVar(&flags.appSecret, "app-secret", "", "通用型 app_secret")
	cmd.Flags().StringVar(&flags.accessToken, "access-token", "", "通用型 access_token")
	cmd.Flags().StringVar(&flags.expiresAt, "expires-at", "", "过期时间 RFC3339，可选")
	cmd.Flags().BoolVar(&flags.noWait, "no-wait", false, "只发起授权并立即返回 verification_url；再用 --complete 兑票")
	cmd.Flags().BoolVar(&flags.complete, "complete", false, "用本机待完成会话兑票（阻塞直到授权完成或超时）")
	cmd.Flags().StringVar(&flags.deviceCode, "device-code", "", "可选，必须与本机待完成会话的 device_code 一致")
	return cmd
}

func runInit(cmd *cobra.Command, f *factory.Factory, opts CLIOptions, flags *initFlags) error {
	p, err := printerOf(cmd, f)
	if err != nil {
		return err
	}
	kind, err := resolveInitKind(flags)
	if err != nil {
		return fail(p, f, err)
	}
	if auth.Exists(f.ConfigDir) {
		return fail(p, f, errs.Auth("已初始化", "先运行 doudian-open-cli auth logout 再 init"))
	}
	switch kind {
	case auth.KindGeneric:
		creds := auth.Credentials{
			Kind:        auth.KindGeneric,
			AppKey:      strings.TrimSpace(flags.appKey),
			AppSecret:   flags.appSecret,
			AccessToken: strings.TrimSpace(flags.accessToken),
			ExpiresAt:   strings.TrimSpace(flags.expiresAt),
		}
		if err := auth.Save(cmd.Context(), f.ConfigDir, creds); err != nil {
			return fail(p, f, err)
		}
		ident := auth.PublicIdentity(creds)
		return p.Success(output.Envelope{OK: true, Identity: &ident, Data: map[string]any{"kind": string(creds.Kind), "authenticated": true}})
	case auth.KindAuthorized:
		return runInitAuthorized(cmd, f, opts, flags, p)
	default:
		return fail(p, f, errs.Validation("--kind 必须是 authorized 或 generic"))
	}
}

func resolveInitKind(flags *initFlags) (auth.Kind, error) {
	kind := auth.Kind(strings.TrimSpace(flags.kind))
	code := strings.TrimSpace(flags.deviceCode)
	twoStep := flags.noWait || flags.complete || code != ""
	if flags.noWait && (flags.complete || code != "") {
		return "", errs.Validation("--no-wait 不能与 --complete / --device-code 同时使用")
	}
	if twoStep {
		if kind == auth.KindGeneric {
			return "", errs.Validation("两段式授权仅支持 --kind authorized")
		}
		if kind != "" && kind != auth.KindAuthorized {
			return "", errs.Validation("--kind 必须是 authorized 或 generic")
		}
		return auth.KindAuthorized, nil
	}
	return kind, nil
}

func runInitAuthorized(cmd *cobra.Command, f *factory.Factory, opts CLIOptions, flags *initFlags, p *output.Printer) error {
	client, err := f.HttpClient()
	if err != nil {
		return fail(p, f, err)
	}
	dc := auth.DeviceClient{HTTP: client, Endpoints: opts.Endpoints, Now: opts.Now, Wait: opts.Wait}
	if cmd != nil {
		lane, err := ppe.Resolve(corecli.PPEInput(cmd))
		if err != nil {
			return fail(p, f, errs.Validation(err.Error()))
		}
		dc.PPE = lane
	}
	if flags.complete || strings.TrimSpace(flags.deviceCode) != "" {
		return finishAuthorized(cmd, f, dc, p, strings.TrimSpace(flags.deviceCode))
	}
	pending, startLogID, err := startOrReusePending(cmd, f, opts, dc)
	if err != nil {
		return fail(p, f, err)
	}
	_, _ = fmt.Fprintf(f.IOStreams.ErrOut, "请在浏览器打开: %s\n", pending.VerificationURL)
	if flags.noWait {
		now := time.Now()
		if opts.Now != nil {
			now = opts.Now()
		}
		env := output.Envelope{OK: true, Data: map[string]any{
			"kind":             string(auth.KindAuthorized),
			"authenticated":    false,
			"verification_url": pending.VerificationURL,
			"user_code":        pending.UserCode,
			"expires_in":       auth.PendingExpiresIn(pending, now),
			"interval":         pending.Interval,
			"hint":             "请把 verification_url 原样交给用户。你可以立即执行 doudian-open-cli init --kind authorized --complete --output json 等待授权结束，也可以等用户确认完成后再执行。不要让用户自己运行这条命令。",
		}}
		if startLogID != "" {
			env.Meta = &output.Meta{LogID: startLogID}
		}
		return p.Success(env)
	}
	if opts.OpenBrowser != nil {
		if err := opts.OpenBrowser(pending.VerificationURL); err != nil {
			return fail(p, f, err)
		}
	}
	return finishAuthorized(cmd, f, dc, p, pending.DeviceCode)
}

func startOrReusePending(cmd *cobra.Command, f *factory.Factory, opts CLIOptions, dc auth.DeviceClient) (auth.PendingSession, string, error) {
	now := time.Now()
	if opts.Now != nil {
		now = opts.Now()
	}
	existing, err := auth.LoadPending(cmd.Context(), f.ConfigDir)
	if err == nil {
		if !auth.PendingExpired(existing, now) {
			return existing, "", nil
		}
	} else if !errors.Is(err, os.ErrNotExist) {
		return auth.PendingSession{}, "", err
	}
	start, err := dc.Start(cmd.Context())
	if err != nil {
		return auth.PendingSession{}, "", err
	}
	pending := auth.PendingSession{
		DeviceCode:      start.DeviceCode,
		UserCode:        start.UserCode,
		VerificationURL: start.VerificationURIComplete,
		ExpiresAt:       now.Add(time.Duration(start.ExpiresIn) * time.Second).UTC().Format(time.RFC3339),
		Interval:        start.Interval,
	}
	if err := auth.SavePending(cmd.Context(), f.ConfigDir, pending); err != nil {
		return auth.PendingSession{}, start.LogID, err
	}
	return pending, start.LogID, nil
}

func finishAuthorized(cmd *cobra.Command, f *factory.Factory, dc auth.DeviceClient, p *output.Printer, deviceCode string) error {
	pending, err := auth.LoadPending(cmd.Context(), f.ConfigDir)
	if err != nil {
		if errors.Is(err, os.ErrNotExist) {
			return fail(p, f, errs.Auth("没有待完成的授权会话", "先运行 doudian-open-cli init --kind authorized --no-wait"))
		}
		return fail(p, f, err)
	}
	now := dc.Now
	if now == nil {
		now = time.Now
	}
	if auth.PendingExpired(pending, now()) {
		_ = auth.DeletePending(f.ConfigDir)
		return fail(p, f, errs.Auth("授权超时", auth.InitHint))
	}
	if deviceCode != "" && deviceCode != pending.DeviceCode {
		return fail(p, f, errs.Validation("--device-code 与本机待完成会话不一致"))
	}
	creds, logID, err := dc.Poll(cmd.Context(), pending)
	if err != nil {
		return fail(p, f, err)
	}
	if err := auth.Save(cmd.Context(), f.ConfigDir, creds); err != nil {
		return fail(p, f, err)
	}
	_ = auth.DeletePending(f.ConfigDir)
	ident := auth.PublicIdentity(creds)
	env := output.Envelope{OK: true, Identity: &ident, Data: map[string]any{"kind": string(creds.Kind), "authenticated": true}}
	if logID != "" {
		env.Meta = &output.Meta{LogID: logID}
	}
	return p.Success(env)
}
