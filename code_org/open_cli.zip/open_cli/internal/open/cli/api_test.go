package cli

import (
	"context"
	"encoding/json"
	"net/url"
	"strings"
	"testing"

	corecli "code.byted.org/temai/open_cli/internal/core/cli"
	"code.byted.org/temai/open_cli/internal/core/errs"
	"code.byted.org/temai/open_cli/internal/core/factory"
	"code.byted.org/temai/open_cli/internal/core/httpmock"
	"code.byted.org/temai/open_cli/internal/core/identity"
	"code.byted.org/temai/open_cli/internal/open/auth"
	"github.com/spf13/cobra"
)

func testRoot(t *testing.T, f *factory.Factory) *cobra.Command {
	t.Helper()
	root, _ := corecli.Build(f, corecli.RootOptions{Version: "test", ShowPPE: false}, Register)
	root.SetOut(f.IOStreams.Out)
	root.SetErr(f.IOStreams.ErrOut)
	return root
}

func testAPIRoot(t *testing.T, f *factory.Factory, runF func(*APIOptions) error) *cobra.Command {
	t.Helper()
	root, _ := corecli.Build(f, corecli.RootOptions{Version: "test", ShowPPE: false})
	root.AddCommand(NewCmdAPI(f, runF))
	root.SetOut(f.IOStreams.Out)
	root.SetErr(f.IOStreams.ErrOut)
	return root
}

func TestSkillsAcceptsDisplayNameAndDirectoryAlias(t *testing.T) {
	for _, name := range []string{"抖店AI视频创作", "doudian_aigc"} {
		t.Run(name, func(t *testing.T) {
			f, stdout, _, _ := factory.TestFactory(t)
			root := testRoot(t, f)
			root.SetArgs([]string{"skills", name})
			if err := root.Execute(); err != nil {
				t.Fatal(err)
			}
			if !strings.Contains(stdout.String(), "name: 抖店AI视频创作") {
				t.Fatalf("skills output missing display name: %s", stdout.String())
			}
		})
	}
}

func TestAPIUnauthenticatedDryRun(t *testing.T) {
	f, stdout, stderr, _ := factory.TestFactory(t)
	root := testRoot(t, f)
	root.SetArgs([]string{"api", "--path", "/product/detail", "--data", "{}", "--dry-run", "--output", "json"})
	err := root.Execute()
	if errs.ExitCode(err) != errs.ExitAuth {
		t.Fatalf("err=%v", err)
	}
	if stdout.Len() != 0 {
		t.Fatalf("stdout=%s", stdout.String())
	}
	if !strings.Contains(stderr.String(), `"type":"auth"`) {
		t.Fatalf("stderr=%s", stderr.String())
	}
	if !strings.Contains(stderr.String(), "init") {
		t.Fatalf("hint should point to init: %s", stderr.String())
	}
}

func TestAPIDryRunPreview(t *testing.T) {
	f, stdout, stderr, _ := factory.TestFactory(t)
	if err := auth.Save(context.Background(), f.ConfigDir, auth.Credentials{Kind: auth.KindGeneric, AppKey: "123456", AppSecret: "sk-secret", ShopID: "s1", AccessToken: "sess-xyz"}); err != nil {
		t.Fatal(err)
	}
	root := testRoot(t, f)
	root.SetArgs([]string{"api", "--path", "/product/detail", "--data", `{"id":1}`, "--dry-run", "--output", "json"})
	if err := root.Execute(); err != nil {
		t.Fatal(err)
	}
	if stderr.Len() != 0 {
		t.Fatalf("stderr=%s", stderr.String())
	}
	if !strings.Contains(stdout.String(), `"dry_run":true`) || !strings.Contains(stdout.String(), "product.detail") {
		t.Fatalf("stdout=%s", stdout.String())
	}
	if !strings.Contains(stdout.String(), `"app_key":"123456"`) {
		t.Fatalf("stdout=%s", stdout.String())
	}
	if strings.Contains(stdout.String(), "sess-xyz") || strings.Contains(stdout.String(), "sk-secret") {
		t.Fatalf("leaked secret: %s", stdout.String())
	}
}

func TestAPIRejectsPUT(t *testing.T) {
	f, _, _, _ := factory.TestFactory(t)
	root := testRoot(t, f)
	root.SetArgs([]string{"api", "PUT", "--path", "/x", "--data", "{}"})
	err := root.Execute()
	if errs.ExitCode(err) != errs.ExitValidation {
		t.Fatalf("err=%v", err)
	}
}

func TestAPIHelpOmitsForbiddenFlags(t *testing.T) {
	f, stdout, _, _ := factory.TestFactory(t)
	root := testRoot(t, f)
	root.SetOut(stdout)
	root.SetArgs([]string{"api", "--help"})
	if err := root.Execute(); err != nil {
		t.Fatal(err)
	}
	out := stdout.String()
	if !strings.Contains(out, "api [method] --path <path>") || !strings.Contains(out, "--path") {
		t.Fatalf("help 缺少 --path 用法:\n%s", out)
	}
	for _, forbidden := range []string{"--appkey", "invoke", "+product"} {
		if strings.Contains(out, forbidden) {
			t.Fatalf("help contains %q:\n%s", forbidden, out)
		}
	}
}

func TestAPIParsesMethodAndPath(t *testing.T) {
	cases := []struct {
		name       string
		args       []string
		wantMethod string
		wantPath   string
	}{
		{name: "默认 POST", args: []string{"api", "--path", "/product/detail"}, wantPath: "/product/detail"},
		{name: "显式 GET", args: []string{"api", "GET", "--path", "/product/list"}, wantMethod: "GET", wantPath: "/product/list"},
		{name: "显式 POST", args: []string{"api", "--path", "/product/detail", "POST"}, wantMethod: "POST", wantPath: "/product/detail"},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			f, stdout, stderr, _ := factory.TestFactory(t)
			called := 0
			root := testAPIRoot(t, f, func(opts *APIOptions) error {
				called++
				if opts.Method != tc.wantMethod || opts.Path != tc.wantPath {
					t.Fatalf("method=%q path=%q", opts.Method, opts.Path)
				}
				return nil
			})
			root.SetArgs(tc.args)
			if err := root.Execute(); err != nil {
				t.Fatal(err)
			}
			if called != 1 {
				t.Fatalf("runF called=%d", called)
			}
			if stdout.Len() != 0 || stderr.Len() != 0 {
				t.Fatalf("stdout=%q stderr=%q", stdout.String(), stderr.String())
			}
		})
	}
}

func TestAPIRejectsMissingPathAndLegacyPositionals(t *testing.T) {
	cases := []struct {
		name string
		args []string
	}{
		{name: "没有参数", args: []string{"api"}},
		{name: "只有方法", args: []string{"api", "POST"}},
		{name: "空 path", args: []string{"api", "--path", "  "}},
		{name: "旧单位置 path", args: []string{"api", "/product/detail"}},
		{name: "旧方法和位置 path", args: []string{"api", "POST", "/product/detail"}},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			f, stdout, stderr, _ := factory.TestFactory(t)
			called := false
			root := testAPIRoot(t, f, func(*APIOptions) error {
				called = true
				return nil
			})
			root.SetArgs(tc.args)
			err := root.Execute()
			if errs.ExitCode(err) != errs.ExitValidation {
				t.Fatalf("err=%v", err)
			}
			if called {
				t.Fatal("参数非法时不应调用 runF")
			}
			if stdout.Len() != 0 {
				t.Fatalf("stdout=%s", stdout.String())
			}
			if !strings.Contains(stderr.String(), "--path") {
				t.Fatalf("stderr=%s", stderr.String())
			}
		})
	}
}

func TestAuthStatusLoggedOut(t *testing.T) {
	f, stdout, _, _ := factory.TestFactory(t)
	root := testRoot(t, f)
	root.SetArgs([]string{"auth", "status", "--output", "json"})
	if err := root.Execute(); err != nil {
		t.Fatal(err)
	}
	var payload map[string]any
	if err := json.Unmarshal(stdout.Bytes(), &payload); err != nil {
		t.Fatal(err)
	}
	data, _ := payload["data"].(map[string]any)
	if data["authenticated"] != false {
		t.Fatalf("%s", stdout.String())
	}
}

func TestAuthLogoutRemovesFile(t *testing.T) {
	f, _, _, _ := factory.TestFactory(t)
	if err := auth.Save(context.Background(), f.ConfigDir, auth.Credentials{Kind: auth.KindGeneric, AppKey: "abcdef", AppSecret: "sk", ShopID: "s1", AccessToken: "tok"}); err != nil {
		t.Fatal(err)
	}
	root := testRoot(t, f)
	root.SetArgs([]string{"auth", "logout", "--output", "json"})
	if err := root.Execute(); err != nil {
		t.Fatal(err)
	}
	if _, err := auth.Load(context.Background(), f.ConfigDir); errs.ExitCode(err) != errs.ExitAuth {
		t.Fatalf("err=%v", err)
	}
}

func TestAuthHelpHasNoLogin(t *testing.T) {
	f, stdout, _, _ := factory.TestFactory(t)
	root := testRoot(t, f)
	root.SetOut(stdout)
	root.SetArgs([]string{"auth", "--help"})
	if err := root.Execute(); err != nil {
		t.Fatal(err)
	}
	if strings.Contains(stdout.String(), "login") {
		t.Fatalf("login must not be registered yet:\n%s", stdout.String())
	}
}

func TestAPIGenericSendsSignAndCLIHeaders(t *testing.T) {
	f, stdout, stderr, reg := factory.TestFactory(t)
	if err := auth.Save(context.Background(), f.ConfigDir, auth.Credentials{Kind: auth.KindGeneric, AppKey: "123", AppSecret: "sk", AccessToken: "real-tok"}); err != nil {
		t.Fatal(err)
	}
	stub := &httpmock.Stub{Method: "POST", URL: "/product/detail", Body: map[string]any{"code": 10000, "data": map[string]any{"product_id": "1"}, "log_id": "L9"}}
	reg.Register(stub)
	root := testRoot(t, f)
	root.SetArgs([]string{"api", "--path", "/product/detail", "--data", "{}", "--output", "json"})
	if err := root.Execute(); err != nil {
		t.Fatal(err)
	}
	if stderr.Len() != 0 {
		t.Fatalf("stderr=%s", stderr.String())
	}
	if strings.Contains(stdout.String(), "real-tok") {
		t.Fatalf("stdout leaked %s", stdout.String())
	}
	u, err := url.Parse(stub.CapturedURL)
	if err != nil {
		t.Fatal(err)
	}
	q := u.Query()
	if q.Get("sign") == "" || q.Get("access_token") != "real-tok" || q.Get("app_key") != "123" || q.Get("v") != "2" {
		t.Fatalf("query=%s", stub.CapturedURL)
	}
	if stub.CapturedHeaders.Get("X-Doudian-Open-Cli-Auth-Kind") != "generic" {
		t.Fatalf("headers=%v", stub.CapturedHeaders)
	}
	if stub.CapturedHeaders.Get("X-Cli-Source") != "doudian-open-cli" {
		t.Fatalf("source=%v", stub.CapturedHeaders)
	}
	if stub.CapturedHeaders.Get("X-Doudian-Open-Cli-Version") != identity.Version() {
		t.Fatalf("version=%v", stub.CapturedHeaders)
	}
	if stub.CapturedHeaders.Get("X-Doudian-Open-Cli-Access-Token") != "" {
		t.Fatalf("generic must not send CLI token header: %v", stub.CapturedHeaders)
	}
}

func TestAPIAuthorizedSendsSign(t *testing.T) {
	f, _, _, reg := factory.TestFactory(t)
	if err := auth.Save(context.Background(), f.ConfigDir, auth.Credentials{Kind: auth.KindAuthorized, AppKey: "123", AccessToken: testFakeToken}); err != nil {
		t.Fatal(err)
	}
	stub := &httpmock.Stub{Method: "POST", URL: "/product/detail", Body: map[string]any{"code": 10000, "data": map[string]any{}}}
	reg.Register(stub)
	root := testRoot(t, f)
	root.SetArgs([]string{"api", "--path", "/product/detail", "--data", "{}", "--output", "json"})
	if err := root.Execute(); err != nil {
		t.Fatal(err)
	}
	parsed, err := url.Parse(stub.CapturedURL)
	if err != nil {
		t.Fatal(err)
	}
	if parsed.Query().Get("sign") == "" || parsed.Query().Get("sign_method") != "hmac-sha256" || parsed.Query().Get("access_token") != testFakeToken {
		t.Fatalf("%s", stub.CapturedURL)
	}
	if stub.CapturedHeaders.Get("X-Doudian-Open-Cli-Auth-Kind") != "authorized" {
		t.Fatalf("%v", stub.CapturedHeaders)
	}
	if stub.CapturedHeaders.Get("X-Cli-Source") != "doudian-open-cli" {
		t.Fatalf("source=%v", stub.CapturedHeaders)
	}
	if stub.CapturedHeaders.Get("X-Doudian-Open-Cli-Version") != identity.Version() {
		t.Fatalf("version=%v", stub.CapturedHeaders)
	}
}

func TestAPIDryRunHidesCLIHeaders(t *testing.T) {
	f, stdout, _, _ := factory.TestFactory(t)
	if err := auth.Save(context.Background(), f.ConfigDir, auth.Credentials{Kind: auth.KindGeneric, AppKey: "123", AppSecret: "sk", AccessToken: "real-tok"}); err != nil {
		t.Fatal(err)
	}
	root := testRoot(t, f)
	root.SetArgs([]string{"api", "--path", "/product/detail", "--data", `{"id":1}`, "--dry-run", "--output", "json"})
	if err := root.Execute(); err != nil {
		t.Fatal(err)
	}
	out := stdout.String()
	for _, leak := range []string{"X-Cli-Source", "X-Doudian-Open-Cli-From", "X-Doudian-Open-Cli-Auth-Kind", "X-Doudian-Open-Cli-Version", "real-tok"} {
		if strings.Contains(out, leak) {
			t.Fatalf("leaked %s: %s", leak, out)
		}
	}
}

func TestAPILocalExpiredNoHTTP(t *testing.T) {
	f, _, stderr, _ := factory.TestFactory(t)
	if err := auth.Save(context.Background(), f.ConfigDir, auth.Credentials{Kind: auth.KindGeneric, AppKey: "123", AppSecret: "sk", AccessToken: "real-tok", ExpiresAt: "2020-01-01T00:00:00Z"}); err != nil {
		t.Fatal(err)
	}
	root := testRoot(t, f)
	root.SetArgs([]string{"api", "--path", "/product/detail", "--data", "{}", "--output", "json"})
	err := root.Execute()
	if errs.ExitCode(err) != errs.ExitAuth {
		t.Fatalf("err=%v", err)
	}
	if !strings.Contains(stderr.String(), "init") {
		t.Fatalf("%s", stderr.String())
	}
}

func TestAPIGatewayExpiredHintsInit(t *testing.T) {
	f, stdout, stderr, reg := factory.TestFactory(t)
	if err := auth.Save(context.Background(), f.ConfigDir, auth.Credentials{Kind: auth.KindAuthorized, AppKey: "123", AccessToken: testFakeToken}); err != nil {
		t.Fatal(err)
	}
	reg.Register(&httpmock.Stub{Method: "POST", URL: "/product/detail", Body: map[string]any{"code": 40003, "sub_code": "isv.access-token-expired", "msg": "expired"}})
	root := testRoot(t, f)
	root.SetArgs([]string{"api", "--path", "/product/detail", "--data", "{}", "--output", "json"})
	err := root.Execute()
	if errs.ExitCode(err) != errs.ExitAuth {
		t.Fatalf("err=%v", err)
	}
	if stdout.Len() != 0 {
		t.Fatalf("stdout=%s", stdout.String())
	}
	if strings.Contains(stderr.String(), testFakeToken) {
		t.Fatalf("%s", stderr.String())
	}
}
