package cli

import (
	"github.com/spf13/cobra"

	"code.byted.org/temai/open_cli/internal/core/errs"
	"code.byted.org/temai/open_cli/internal/core/factory"
	"code.byted.org/temai/open_cli/internal/core/output"
	"code.byted.org/temai/open_cli/internal/open/auth"
)

func NewCmdAuth(f *factory.Factory) *cobra.Command {
	cmd := &cobra.Command{Use: "auth", Short: "商家开放授权"}
	cmd.AddCommand(newAuthStatus(f), newAuthLogout(f))
	return cmd
}

func newAuthStatus(f *factory.Factory) *cobra.Command {
	return &cobra.Command{
		Use:   "status",
		Short: "查看当前商家登录态",
		Args:  cobra.NoArgs,
		RunE: func(cmd *cobra.Command, _ []string) error {
			p, err := printerOf(cmd, f)
			if err != nil {
				return err
			}
			creds, err := auth.Load(cmd.Context(), f.ConfigDir)
			if errs.ExitCode(err) == errs.ExitAuth {
				return p.Success(output.Envelope{OK: true, Data: map[string]any{"authenticated": false}})
			}
			if err != nil {
				return fail(p, f, err)
			}
			ident := auth.PublicIdentity(creds)
			return p.Success(output.Envelope{OK: true, Identity: &ident, Data: map[string]any{"authenticated": true}})
		},
	}
}

func newAuthLogout(f *factory.Factory) *cobra.Command {
	return &cobra.Command{
		Use:   "logout",
		Short: "删除本地开放凭据",
		Args:  cobra.NoArgs,
		RunE: func(cmd *cobra.Command, _ []string) error {
			p, err := printerOf(cmd, f)
			if err != nil {
				return err
			}
			if err := auth.Logout(f.ConfigDir); err != nil {
				return fail(p, f, err)
			}
			return p.Success(output.Envelope{OK: true, Data: map[string]any{"authenticated": false}})
		},
	}
}
