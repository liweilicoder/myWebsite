package cli

import (
	"bytes"
	"strings"
	"testing"

	"code.byted.org/temai/open_cli/internal/core/errs"
)

func TestSkillsPrintsReference(t *testing.T) {
	var stdout, stderr bytes.Buffer
	cmd := NewCmdSkills(&stdout)
	cmd.SetErr(&stderr)
	cmd.SetArgs([]string{"doudian_aigc", "--ref", "create_video"})
	if err := cmd.Execute(); err != nil {
		t.Fatal(err)
	}
	if !strings.Contains(stdout.String(), "createAIVideoTaskOpen") {
		t.Fatalf("stdout=%s", stdout.String())
	}
	if strings.Contains(stdout.String(), "name: doudian_aigc") {
		t.Fatal("reference 不应是 SKILL.md")
	}
}

func TestSkillsRejectsUnknownScript(t *testing.T) {
	var stdout bytes.Buffer
	cmd := NewCmdSkills(&stdout)
	cmd.SetErr(&bytes.Buffer{})
	cmd.SetArgs([]string{"doudian_aigc", "--script", "no_such"})
	err := cmd.Execute()
	if errs.ExitCode(err) != errs.ExitValidation || !strings.Contains(err.Error(), "未知 script") {
		t.Fatalf("err=%v", err)
	}
	if stdout.Len() != 0 {
		t.Fatalf("stdout=%s", stdout.String())
	}
}

func TestSkillsRefRequiresName(t *testing.T) {
	cmd := NewCmdSkills(&bytes.Buffer{})
	cmd.SetErr(&bytes.Buffer{})
	cmd.SetArgs([]string{"--ref", "create_video"})
	err := cmd.Execute()
	if errs.ExitCode(err) != errs.ExitValidation {
		t.Fatalf("err=%v", err)
	}
}
