package cli

import (
	"fmt"
	"io"
	"strings"

	"github.com/spf13/cobra"

	"code.byted.org/temai/open_cli/internal/core/errs"
	"code.byted.org/temai/open_cli/internal/core/factory"
	openskill "code.byted.org/temai/open_cli/internal/open/skill"
)

const rootHelpLong = `抖店开放平台命令行。

Agent 请先运行：

  doudian-open-cli skills

列出本工具内嵌的 Skill。需要 CLI 用法时再运行：

  doudian-open-cli skills open_cli_skill

需要某个业务时：

  doudian-open-cli skills <业务名>
`

func NewCmdSkills(stdout io.Writer) *cobra.Command {
	command := &cobra.Command{
		Use:   "skills [name]",
		Short: "列出或打印内嵌 Skill",
		Long:  "无参数时列出 open_cli_skill 与业务 Skill 的目录名和 description。带名称时向 stdout 打印该 Skill 的 SKILL.md 原文。--ref 打印 references/<name>.md，--script 打印 scripts/<name>.sh 或 .py。不写入本机目录，不受 --output 影响。",
		Args:  cobra.MaximumNArgs(1),
		ValidArgsFunction: func(*cobra.Command, []string, string) ([]string, cobra.ShellCompDirective) {
			return openskill.Names(), cobra.ShellCompDirectiveNoFileComp
		},
		RunE: func(cmd *cobra.Command, args []string) error {
			if stdout == nil {
				return fmt.Errorf("stdout 未配置")
			}
			refName, _ := cmd.Flags().GetString("ref")
			scriptName, _ := cmd.Flags().GetString("script")
			if refName != "" && scriptName != "" {
				return errs.Validation("--ref 与 --script 不能同时使用")
			}
			docs := openskill.Documents()
			if len(args) == 0 {
				if refName != "" || scriptName != "" {
					return errs.Validation("读取 reference 或 script 时必须指定 Skill 名")
				}
				_, err := io.WriteString(stdout, formatCatalog(docs))
				return err
			}
			kind, id := "", ""
			if refName != "" {
				kind, id = "ref", refName
			} else if scriptName != "" {
				kind, id = "script", scriptName
			}
			if kind != "" {
				body, err := openskill.LookupPart(args[0], kind, id)
				if err != nil {
					return errs.Validation(err.Error())
				}
				_, err = stdout.Write(body)
				return err
			}
			doc, lookupErr := openskill.Lookup(args[0])
			if lookupErr == nil {
				_, err := stdout.Write(doc.Markdown)
				return err
			}
			err := errs.Validation("未知 Skill：" + args[0])
			err.Hint = "可用：" + strings.Join(openskill.Names(), "、") + "。阅读：doudian-open-cli skills <name>"
			return err
		},
	}
	command.Flags().String("ref", "", "打印 references 下同名 .md，不含后缀")
	command.Flags().String("script", "", "打印 scripts 下同名 .sh 或 .py，不含后缀")
	return command
}

func formatCatalog(docs []openskill.Document) string {
	var b strings.Builder
	for _, doc := range docs {
		b.WriteString(doc.Name)
		if doc.Description != "" {
			b.WriteByte('\t')
			b.WriteString(doc.Description)
		}
		b.WriteByte('\n')
	}
	b.WriteString("打印全文：doudian-open-cli skills <name>\n")
	return b.String()
}

func applyRootHelp(root *cobra.Command) {
	if root.Short == "" {
		root.Short = "抖店开放平台命令行"
	}
	if root.Long == "" {
		root.Long = rootHelpLong
	}
}

func skillsStdout(f *factory.Factory) io.Writer {
	if f != nil && f.IOStreams != nil && f.IOStreams.Out != nil {
		return f.IOStreams.Out
	}
	return nil
}
