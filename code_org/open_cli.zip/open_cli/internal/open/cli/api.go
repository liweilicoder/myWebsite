package cli

import (
	"encoding/json"
	"net/http"
	"strings"
	"time"

	"github.com/spf13/cobra"

	corecli "code.byted.org/temai/open_cli/internal/core/cli"
	"code.byted.org/temai/open_cli/internal/core/errs"
	"code.byted.org/temai/open_cli/internal/core/factory"
	"code.byted.org/temai/open_cli/internal/core/jsoninput"
	"code.byted.org/temai/open_cli/internal/core/output"
	"code.byted.org/temai/open_cli/internal/core/ppe"
	"code.byted.org/temai/open_cli/internal/open/auth"
	"code.byted.org/temai/open_cli/internal/open/invoke"
)

type APIOptions struct {
	Factory *factory.Factory
	Cmd     *cobra.Command
	Method  string
	Path    string
	Data    string
	DryRun  bool
}

func NewCmdAPI(f *factory.Factory, runF func(*APIOptions) error) *cobra.Command {
	opts := &APIOptions{Factory: f}
	cmd := &cobra.Command{
		Use:   "api [method] --path <path>",
		Short: "调用开放平台 API",
		Args: func(cmd *cobra.Command, args []string) error {
			if err := validateAPIArgs(args, opts.Path); err != nil {
				p, printerErr := printerOf(cmd, f)
				if printerErr != nil {
					return printerErr
				}
				return fail(p, f, err)
			}
			return nil
		},
		RunE: func(cmd *cobra.Command, args []string) error {
			opts.Cmd = cmd
			if len(args) == 1 {
				opts.Method = args[0]
			}
			if runF != nil {
				return runF(opts)
			}
			return apiRun(opts)
		},
	}
	cmd.Flags().StringVar(&opts.Path, "path", "", "开放平台接口路径")
	cmd.Flags().StringVar(&opts.Data, "data", "", "请求 JSON（inline / @file / @-）")
	cmd.Flags().BoolVar(&opts.DryRun, "dry-run", false, "只预览请求，不访问网关")
	return cmd
}

func validateAPIArgs(args []string, path string) error {
	if len(args) > 1 {
		return errs.Validation("path 必须通过 --path 传入；用法：api [method] --path <path>")
	}
	if len(args) == 1 && strings.HasPrefix(strings.TrimSpace(args[0]), "/") {
		return errs.Validation("path 必须通过 --path 传入；用法：api [method] --path <path>")
	}
	if strings.TrimSpace(path) == "" {
		return errs.Validation("--path 不能为空")
	}
	return nil
}

func printerOf(cmd *cobra.Command, f *factory.Factory) (*output.Printer, error) {
	format := "json"
	if cmd != nil {
		if flag := cmd.Flags().Lookup("output"); flag != nil && flag.Value.String() != "" {
			format = flag.Value.String()
		} else if flag := cmd.InheritedFlags().Lookup("output"); flag != nil && flag.Value.String() != "" {
			format = flag.Value.String()
		}
	}
	return output.New(f.IOStreams.Out, format)
}

func fail(p *output.Printer, f *factory.Factory, err error) error {
	_ = p.Failure(f.IOStreams.ErrOut, err)
	return err
}

func apiRun(opts *APIOptions) error {
	p, err := printerOf(opts.Cmd, opts.Factory)
	if err != nil {
		return err
	}
	method, path, err := invoke.Normalize(opts.Method, opts.Path)
	if err != nil {
		return fail(p, opts.Factory, err)
	}
	source := opts.Data
	if source == "" {
		if method == http.MethodGet {
			source = "{}"
		} else {
			return fail(p, opts.Factory, errs.Validation("--data 不能为空"))
		}
	}
	body, err := jsoninput.NewLoader(opts.Factory.IOStreams.In).Object(source, "--data")
	if err != nil {
		return fail(p, opts.Factory, errs.Validation(err.Error()))
	}
	creds, err := auth.Load(opts.Cmd.Context(), opts.Factory.ConfigDir)
	if err != nil {
		return fail(p, opts.Factory, err)
	}
	now := time.Now()
	if err := auth.EnsureFresh(creds, now); err != nil {
		return fail(p, opts.Factory, err)
	}
	if opts.DryRun {
		env, err := invoke.Preview(creds, method, path, json.RawMessage(body), now)
		if err != nil {
			return fail(p, opts.Factory, err)
		}
		return p.Success(env)
	}
	client, err := opts.Factory.HttpClient()
	if err != nil {
		return fail(p, opts.Factory, err)
	}
	lane, err := ppe.Resolve(corecli.PPEInput(opts.Cmd))
	if err != nil {
		return fail(p, opts.Factory, errs.Validation(err.Error()))
	}
	req, err := invoke.BuildRequest(creds, method, path, json.RawMessage(body), now, lane)
	if err != nil {
		return fail(p, opts.Factory, err)
	}
	data, logID, err := invoke.Send(opts.Cmd.Context(), client, req)
	if err != nil {
		return fail(p, opts.Factory, err)
	}
	ident := auth.PublicIdentity(creds)
	env := output.Envelope{OK: true, Identity: &ident, Data: json.RawMessage(data)}
	if logID != "" {
		env.Meta = &output.Meta{LogID: logID}
	}
	return p.Success(env)
}
