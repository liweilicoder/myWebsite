package cli

import (
	"context"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	corecli "code.byted.org/temai/open_cli/internal/core/cli"
	"code.byted.org/temai/open_cli/internal/core/errs"
	"code.byted.org/temai/open_cli/internal/core/factory"
	"code.byted.org/temai/open_cli/internal/core/httpmock"
	"code.byted.org/temai/open_cli/internal/open/auth"
	"code.byted.org/temai/open_cli/internal/open/config"
	"github.com/spf13/cobra"
)

func testRootWith(t *testing.T, f *factory.Factory, opts CLIOptions) *cobra.Command {
	t.Helper()
	root, _ := corecli.Build(f, corecli.RootOptions{Version: "test", ShowPPE: false}, func(root *cobra.Command, fac *factory.Factory) {
		RegisterWith(root, fac, opts)
	})
	root.SetOut(f.IOStreams.Out)
	root.SetErr(f.IOStreams.ErrOut)
	return root
}

func testDeviceOpts(open func(string) error) CLIOptions {
	return CLIOptions{
		Endpoints: config.Endpoints{
			DeviceStart: "https://open.test/device/start", DeviceToken: "https://open.test/device/token",
			VerificationURI: "https://shop.auth.example/cli",
		},
		OpenBrowser: open,
		Now:         func() time.Time { return time.Unix(1, 0).UTC() },
		Wait:        func(ctx context.Context, d time.Duration) error { return nil },
	}
}

const (
	testUserCode   = "u.abc+def/ghi="
	testDeviceCode = "d.opaque-device-code-not-for-stdout"
	testFakeToken  = "ft.v1.opaque-fake-token"
)

func testVerificationURL() string {
	return "https://shop.auth.example/cli?user_code=" + url.QueryEscape(testUserCode) + "&from=open_cli"
}

func deviceStartBody() map[string]any {
	return map[string]any{
		"device_code": testDeviceCode, "user_code": testUserCode,
		"verification_uri":          "https://shop.auth.example/cli",
		"verification_uri_complete": testVerificationURL(),
		"expires_in":                900, "interval": 5,
	}
}

func deviceTokenBody() map[string]any {
	return map[string]any{
		"access_token": testFakeToken, "app_key": "123", "expires_time": "2099-01-01T00:00:00Z", "app_secret": "leak-sk",
	}
}

func logidHeader(id string) http.Header {
	h := make(http.Header)
	h.Set("x-tt-logid", id)
	return h
}

func TestInitGenericWritesFile(t *testing.T) {
	f, stdout, stderr, _ := factory.TestFactory(t)
	root := testRootWith(t, f, CLIOptions{Now: func() time.Time { return time.Unix(1, 0) }})
	root.SetArgs([]string{"init", "--kind", "generic", "--app-key", "123", "--app-secret", "sk-secret", "--access-token", "tok-secret", "--output", "json"})
	if err := root.Execute(); err != nil {
		t.Fatal(err)
	}
	if stderr.Len() != 0 {
		t.Fatalf("stderr=%s", stderr.String())
	}
	if strings.Contains(stdout.String(), "sk-secret") || strings.Contains(stdout.String(), "tok-secret") {
		t.Fatalf("leaked: %s", stdout.String())
	}
	got, err := auth.Load(context.Background(), f.ConfigDir)
	if err != nil || got.Kind != auth.KindGeneric || got.AppSecret != "sk-secret" {
		t.Fatalf("%+v %v", got, err)
	}
}

func TestInitGenericMissingSecret(t *testing.T) {
	f, _, _, _ := factory.TestFactory(t)
	root := testRootWith(t, f, CLIOptions{})
	root.SetArgs([]string{"init", "--kind", "generic", "--app-key", "123", "--access-token", "tok"})
	err := root.Execute()
	if errs.ExitCode(err) != errs.ExitValidation {
		t.Fatalf("err=%v", err)
	}
}

func TestInitRefusesOverwrite(t *testing.T) {
	f, _, stderr, _ := factory.TestFactory(t)
	if err := auth.Save(context.Background(), f.ConfigDir, auth.Credentials{Kind: auth.KindGeneric, AppKey: "123", AppSecret: "sk", AccessToken: "t"}); err != nil {
		t.Fatal(err)
	}
	root := testRootWith(t, f, CLIOptions{})
	root.SetArgs([]string{"init", "--kind", "generic", "--app-key", "9", "--app-secret", "x", "--access-token", "y", "--output", "json"})
	err := root.Execute()
	if errs.ExitCode(err) != errs.ExitAuth {
		t.Fatalf("err=%v", err)
	}
	if !strings.Contains(stderr.String(), "logout") {
		t.Fatalf("stderr=%s", stderr.String())
	}
}

func TestInitAuthorizedPollDropsSK(t *testing.T) {
	f, stdout, stderr, reg := factory.TestFactory(t)
	reg.Register(&httpmock.Stub{Method: "POST", URL: "/device/start", Body: deviceStartBody()})
	reg.Register(&httpmock.Stub{Method: "POST", URL: "/device/token", Body: deviceTokenBody()})
	opened := ""
	root := testRootWith(t, f, testDeviceOpts(func(u string) error { opened = u; return nil }))
	root.SetArgs([]string{"init", "--kind", "authorized", "--output", "json"})
	if err := root.Execute(); err != nil {
		t.Fatal(err)
	}
	wantURL := testVerificationURL()
	if opened != wantURL {
		t.Fatalf("opened=%s", opened)
	}
	if !strings.Contains(stderr.String(), wantURL) {
		t.Fatalf("stderr should show url: %s", stderr.String())
	}
	if strings.Contains(stdout.String(), testFakeToken) || strings.Contains(stdout.String(), "leak-sk") || strings.Contains(stdout.String(), testDeviceCode) {
		t.Fatalf("stdout leaked: %s", stdout.String())
	}
	got, err := auth.Load(context.Background(), f.ConfigDir)
	if err != nil || got.AppSecret != "" || got.AccessToken != testFakeToken || got.Kind != auth.KindAuthorized || got.ExpiresAt != "2099-01-01T00:00:00Z" {
		t.Fatalf("%+v %v", got, err)
	}
}

func TestInitAuthorizedNoWaitIncludesStartLogID(t *testing.T) {
	f, stdout, _, reg := factory.TestFactory(t)
	reg.Register(&httpmock.Stub{
		Method: "POST", URL: "/device/start", Headers: logidHeader("start-log-init"),
		Body: deviceStartBody(),
	})
	root := testRootWith(t, f, testDeviceOpts(nil))
	root.SetArgs([]string{"init", "--kind", "authorized", "--no-wait", "--output", "json"})
	if err := root.Execute(); err != nil {
		t.Fatal(err)
	}
	if !strings.Contains(stdout.String(), `"log_id":"start-log-init"`) {
		t.Fatalf("stdout=%s", stdout.String())
	}
}

func TestInitAuthorizedCompleteIncludesTokenLogID(t *testing.T) {
	f, stdout, _, reg := factory.TestFactory(t)
	reg.Register(&httpmock.Stub{Method: "POST", URL: "/device/start", Body: deviceStartBody()})
	reg.Register(&httpmock.Stub{
		Method: "POST", URL: "/device/token", Headers: logidHeader("token-log-init"),
		Body: deviceTokenBody(),
	})
	opts := testDeviceOpts(nil)
	root := testRootWith(t, f, opts)
	root.SetArgs([]string{"init", "--kind", "authorized", "--no-wait", "--output", "json"})
	if err := root.Execute(); err != nil {
		t.Fatal(err)
	}
	stdout.Reset()
	root = testRootWith(t, f, opts)
	root.SetArgs([]string{"init", "--kind", "authorized", "--complete", "--output", "json"})
	if err := root.Execute(); err != nil {
		t.Fatal(err)
	}
	if !strings.Contains(stdout.String(), `"log_id":"token-log-init"`) {
		t.Fatalf("stdout=%s", stdout.String())
	}
}

func TestInitPPEHeaders(t *testing.T) {
	f, _, _, reg := factory.TestFactory(t)
	startStub := &httpmock.Stub{Method: "POST", URL: "/device/start", Body: deviceStartBody()}
	reg.Register(startStub)
	root := testRootWith(t, f, testDeviceOpts(func(string) error { return nil }))
	root.SetArgs([]string{"--use-ppe", "--ppe-env", "ppe_7373101510", "init", "--kind", "authorized", "--no-wait", "--output", "json"})
	if err := root.Execute(); err != nil {
		t.Fatal(err)
	}
	if startStub.CapturedHeaders.Get("x-use-ppe") != "1" || startStub.CapturedHeaders.Get("x-tt-env") != "ppe_7373101510" {
		t.Fatalf("headers=%v", startStub.CapturedHeaders)
	}
}

func TestInitAuthorizedNoWaitThenComplete(t *testing.T) {
	f, stdout, stderr, reg := factory.TestFactory(t)
	reg.Register(&httpmock.Stub{Method: "POST", URL: "/device/start", Body: deviceStartBody()})
	reg.Register(&httpmock.Stub{Method: "POST", URL: "/device/token", Body: deviceTokenBody()})
	opened := ""
	opts := testDeviceOpts(func(u string) error { opened = u; return nil })
	root := testRootWith(t, f, opts)
	root.SetArgs([]string{"init", "--kind", "authorized", "--no-wait", "--output", "json"})
	if err := root.Execute(); err != nil {
		t.Fatal(err)
	}
	if opened != "" {
		t.Fatalf("no-wait must not open browser: %s", opened)
	}
	out := stdout.String()
	if !strings.Contains(out, `"verification_url":"`+testVerificationURL()+`"`) || !strings.Contains(out, `"user_code":"`+testUserCode+`"`) {
		t.Fatalf("stdout=%s", out)
	}
	if strings.Contains(out, testDeviceCode) || strings.Contains(out, testFakeToken) || strings.Contains(out, "leak-sk") {
		t.Fatalf("leaked: %s", out)
	}
	if strings.Contains(stderr.String(), testDeviceCode) || strings.Contains(stderr.String(), testFakeToken) || strings.Contains(stderr.String(), "leak-sk") {
		t.Fatalf("stderr leaked: %s", stderr.String())
	}
	if auth.Exists(f.ConfigDir) {
		t.Fatal("credentials must not exist after --no-wait")
	}
	pending, err := auth.LoadPending(context.Background(), f.ConfigDir)
	if err != nil || pending.DeviceCode != testDeviceCode {
		t.Fatalf("%+v %v", pending, err)
	}

	stdout.Reset()
	stderr.Reset()
	root = testRootWith(t, f, opts)
	root.SetArgs([]string{"init", "--kind", "authorized", "--no-wait", "--output", "json"})
	if err := root.Execute(); err != nil {
		t.Fatal(err)
	}
	if strings.Contains(stdout.String(), testDeviceCode) || !strings.Contains(stdout.String(), `"user_code":"`+testUserCode+`"`) {
		t.Fatalf("reuse stdout=%s", stdout.String())
	}

	stdout.Reset()
	stderr.Reset()
	root = testRootWith(t, f, opts)
	root.SetArgs([]string{"init", "--kind", "authorized", "--complete", "--output", "json"})
	if err := root.Execute(); err != nil {
		t.Fatal(err)
	}
	if strings.Contains(stdout.String(), testFakeToken) || strings.Contains(stdout.String(), "leak-sk") || strings.Contains(stdout.String(), testDeviceCode) {
		t.Fatalf("leaked: %s", stdout.String())
	}
	got, err := auth.Load(context.Background(), f.ConfigDir)
	if err != nil || got.AppSecret != "" || got.AccessToken != testFakeToken || got.Kind != auth.KindAuthorized {
		t.Fatalf("%+v %v", got, err)
	}
	if _, err := auth.LoadPending(context.Background(), f.ConfigDir); err == nil {
		t.Fatal("pending should be deleted")
	}
}

func TestInitNoWaitRejectsGeneric(t *testing.T) {
	f, _, _, _ := factory.TestFactory(t)
	root := testRootWith(t, f, CLIOptions{})
	root.SetArgs([]string{"init", "--kind", "generic", "--no-wait", "--app-key", "123", "--app-secret", "sk", "--access-token", "tok"})
	err := root.Execute()
	if errs.ExitCode(err) != errs.ExitValidation {
		t.Fatalf("err=%v", err)
	}
}

func TestInitNoWaitAndDeviceCodeConflict(t *testing.T) {
	f, _, _, _ := factory.TestFactory(t)
	root := testRootWith(t, f, CLIOptions{})
	root.SetArgs([]string{"init", "--kind", "authorized", "--no-wait", "--device-code", "c1"})
	err := root.Execute()
	if errs.ExitCode(err) != errs.ExitValidation {
		t.Fatalf("err=%v", err)
	}
}

func TestInitHelpHasKind(t *testing.T) {
	f, stdout, _, _ := factory.TestFactory(t)
	root := testRoot(t, f)
	root.SetOut(stdout)
	root.SetArgs([]string{"init", "--help"})
	if err := root.Execute(); err != nil {
		t.Fatal(err)
	}
	help := stdout.String()
	if !strings.Contains(help, "--kind") || !strings.Contains(help, "--no-wait") || !strings.Contains(help, "--complete") {
		t.Fatalf("%s", help)
	}
}

func TestRootHelpHasInit(t *testing.T) {
	f, stdout, _, _ := factory.TestFactory(t)
	root := testRoot(t, f)
	root.SetOut(stdout)
	root.SetArgs([]string{"--help"})
	if err := root.Execute(); err != nil {
		t.Fatal(err)
	}
	if !strings.Contains(stdout.String(), "init") {
		t.Fatalf("%s", stdout.String())
	}
}

func TestAuthStatusShowsKindNotSecret(t *testing.T) {
	f, stdout, _, _ := factory.TestFactory(t)
	if err := auth.Save(context.Background(), f.ConfigDir, auth.Credentials{Kind: auth.KindGeneric, AppKey: "abcdef", AppSecret: "sk-secret", AccessToken: "tok-xyz"}); err != nil {
		t.Fatal(err)
	}
	root := testRoot(t, f)
	root.SetArgs([]string{"auth", "status", "--output", "json"})
	if err := root.Execute(); err != nil {
		t.Fatal(err)
	}
	if strings.Contains(stdout.String(), "sk-secret") || strings.Contains(stdout.String(), "tok-xyz") {
		t.Fatalf("%s", stdout.String())
	}
	if !strings.Contains(stdout.String(), `"app_key":"abcdef"`) || !strings.Contains(stdout.String(), `"kind":"generic"`) {
		t.Fatalf("%s", stdout.String())
	}
}

func TestInitNoWaitCorruptPendingFails(t *testing.T) {
	f, _, _, _ := factory.TestFactory(t)
	dir := filepath.Join(f.ConfigDir, "open")
	if err := os.MkdirAll(dir, 0o700); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(dir, "login-session.json"), []byte(`{"not":"a-session"}`), 0o600); err != nil {
		t.Fatal(err)
	}
	root := testRootWith(t, f, testDeviceOpts(nil))
	root.SetArgs([]string{"init", "--kind", "authorized", "--no-wait", "--output", "json"})
	if err := root.Execute(); err == nil {
		t.Fatal("corrupt pending must fail instead of starting a new session")
	}
}
