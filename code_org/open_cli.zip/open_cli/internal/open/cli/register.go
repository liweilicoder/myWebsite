package cli

import (
	"context"
	"time"

	"github.com/spf13/cobra"

	"code.byted.org/temai/open_cli/internal/core/factory"
	"code.byted.org/temai/open_cli/internal/open/config"
)

type CLIOptions struct {
	Endpoints   config.Endpoints
	OpenBrowser func(string) error
	Now         func() time.Time
	Wait        func(ctx context.Context, d time.Duration) error
}

func Register(root *cobra.Command, f *factory.Factory) {
	RegisterWith(root, f, CLIOptions{
		Endpoints: config.Production(),
		Now:       time.Now,
	})
}

func RegisterWith(root *cobra.Command, f *factory.Factory, opts CLIOptions) {
	if opts.Now == nil {
		opts.Now = time.Now
	}
	root.AddCommand(NewCmdSkills(skillsStdout(f)), NewCmdInit(f, opts), NewCmdAuth(f), NewCmdAPI(f, nil))
	applyRootHelp(root)
}
