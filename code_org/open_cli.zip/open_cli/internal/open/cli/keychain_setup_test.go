package cli

import (
	"os"
	"testing"

	"code.byted.org/temai/open_cli/internal/core/keychain"
	"code.byted.org/temai/open_cli/internal/open/auth"
)

func TestMain(m *testing.M) {
	restore := auth.SetKeychainForTest(keychain.NewMemory())
	code := m.Run()
	restore()
	os.Exit(code)
}
