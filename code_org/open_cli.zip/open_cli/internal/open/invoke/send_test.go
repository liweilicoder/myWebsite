package invoke

import (
	"context"
	"encoding/json"
	"strings"
	"testing"
	"time"

	"code.byted.org/temai/open_cli/internal/core/errs"
	"code.byted.org/temai/open_cli/internal/core/httpmock"
	"code.byted.org/temai/open_cli/internal/core/ppe"
	"code.byted.org/temai/open_cli/internal/open/auth"
)

func TestSendSuccess(t *testing.T) {
	reg := &httpmock.Registry{}
	reg.Register(&httpmock.Stub{Method: "POST", URL: "/product/detail", Body: map[string]any{"code": 10000, "data": map[string]any{"ok": true}, "log_id": "L1"}})
	client := httpmock.NewClient(reg)
	creds := auth.Credentials{Kind: auth.KindGeneric, AppKey: "123", AppSecret: "sk", AccessToken: "real-tok"}
	req, err := BuildRequest(creds, "POST", "/product/detail", json.RawMessage(`{}`), time.Unix(1, 0), ppe.Config{})
	if err != nil {
		t.Fatal(err)
	}
	data, logID, err := Send(context.Background(), client, req)
	if err != nil {
		t.Fatal(err)
	}
	if logID != "L1" || !strings.Contains(string(data), "ok") {
		t.Fatalf("data=%s log=%s", data, logID)
	}
	reg.Verify(t)
}

func TestSendTokenExpiredIsAuth(t *testing.T) {
	reg := &httpmock.Registry{}
	reg.Register(&httpmock.Stub{Method: "POST", URL: "/product/detail", Body: map[string]any{
		"code": 40003, "msg": "非法的参数", "sub_code": "isv.access-token-expired", "sub_msg": "access_token已过期",
	}})
	client := httpmock.NewClient(reg)
	creds := auth.Credentials{Kind: auth.KindAuthorized, AppKey: "123", AccessToken: "fake-tok"}
	req, err := BuildRequest(creds, "POST", "/product/detail", json.RawMessage(`{}`), time.Unix(1, 0), ppe.Config{})
	if err != nil {
		t.Fatal(err)
	}
	_, _, err = Send(context.Background(), client, req)
	if errs.ExitCode(err) != errs.ExitAuth {
		t.Fatalf("err=%v", err)
	}
	if strings.Contains(err.Error(), "fake-tok") {
		t.Fatalf("leaked token: %v", err)
	}
	typed := err.(*errs.Error)
	if typed.Hint != auth.InitHint || typed.Code != "isv.access-token-expired" {
		t.Fatalf("hint=%s code=%s", typed.Hint, typed.Code)
	}
	if !strings.Contains(string(typed.Body), `"sub_code":"isv.access-token-expired"`) || !strings.Contains(string(typed.Body), `"code":40003`) {
		t.Fatalf("body=%s", typed.Body)
	}
	reg.Verify(t)
}

func TestSendNilRequest(t *testing.T) {
	_, _, err := Send(context.Background(), httpmock.NewClient(&httpmock.Registry{}), nil)
	if errs.ExitCode(err) != errs.ExitInternal {
		t.Fatalf("err=%v", err)
	}
	_, _, err = Send(context.Background(), httpmock.NewClient(&httpmock.Registry{}), &Request{})
	if errs.ExitCode(err) != errs.ExitInternal {
		t.Fatalf("err=%v", err)
	}
}

func TestSendCliTokenMissingIsAuth(t *testing.T) {
	reg := &httpmock.Registry{}
	reg.Register(&httpmock.Stub{Method: "POST", URL: "/product/detail", Body: map[string]any{
		"code": 40003, "msg": "token错误", "sub_code": "isv.cli-access-token-missing", "sub_msg": "token错误，请重新授权后发起请求。",
	}})
	client := httpmock.NewClient(reg)
	creds := auth.Credentials{Kind: auth.KindAuthorized, AppKey: "123", AccessToken: "fake-tok"}
	req, err := BuildRequest(creds, "POST", "/product/detail", json.RawMessage(`{}`), time.Unix(1, 0), ppe.Config{})
	if err != nil {
		t.Fatal(err)
	}
	_, _, err = Send(context.Background(), client, req)
	if errs.ExitCode(err) != errs.ExitAuth {
		t.Fatalf("err=%v", err)
	}
	typed := err.(*errs.Error)
	if typed.Hint != auth.InitHint || typed.Code != "isv.cli-access-token-missing" {
		t.Fatalf("hint=%s code=%s", typed.Hint, typed.Code)
	}
	reg.Verify(t)
}

func TestSendBizErrorIsAPI(t *testing.T) {
	reg := &httpmock.Registry{}
	reg.Register(&httpmock.Stub{Method: "POST", URL: "/product/detail", Body: map[string]any{"code": 50002, "msg": "内部错误", "sub_code": "isp.service-error"}})
	client := httpmock.NewClient(reg)
	creds := auth.Credentials{Kind: auth.KindGeneric, AppKey: "123", AppSecret: "sk", AccessToken: "real-tok"}
	req, err := BuildRequest(creds, "POST", "/product/detail", json.RawMessage(`{}`), time.Unix(1, 0), ppe.Config{})
	if err != nil {
		t.Fatal(err)
	}
	_, _, err = Send(context.Background(), client, req)
	if errs.ExitCode(err) != errs.ExitAPI {
		t.Fatalf("err=%v", err)
	}
	typed := err.(*errs.Error)
	if typed.Code != "isp.service-error" || !strings.Contains(string(typed.Body), `"msg":"内部错误"`) || !strings.Contains(string(typed.Body), `"code":50002`) {
		t.Fatalf("body=%s code=%s", typed.Body, typed.Code)
	}
	reg.Verify(t)
}
