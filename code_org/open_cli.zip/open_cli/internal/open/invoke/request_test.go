package invoke

import (
	"encoding/json"
	"net/url"
	"strings"
	"testing"
	"time"

	"code.byted.org/temai/open_cli/internal/core/identity"
	"code.byted.org/temai/open_cli/internal/core/ppe"
	"code.byted.org/temai/open_cli/internal/open/auth"
	"code.byted.org/temai/open_cli/internal/open/config"
)

func TestBuildGenericSigns(t *testing.T) {
	t.Setenv(identity.EnvOfficeAgentName, "")
	now := time.Unix(1, 0)
	creds := auth.Credentials{Kind: auth.KindGeneric, AppKey: "123", AppSecret: "sk", AccessToken: "real-tok"}
	req, err := BuildRequest(creds, "POST", "/product/detail", json.RawMessage(`{}`), now, ppe.Config{})
	if err != nil {
		t.Fatal(err)
	}
	q := req.URL.Query()
	if q.Get("sign") != "cb95d928a6168586fc73d0752ebd1bc7f6bcab0258f6c7ca254c1adcaa4dffd8" {
		t.Fatalf("sign=%s query=%s", q.Get("sign"), req.URL.RawQuery)
	}
	if q.Get("sign_method") != "hmac-sha256" || q.Get("access_token") != "real-tok" || q.Get("v") != "2" {
		t.Fatalf("%s", req.URL.RawQuery)
	}
	if req.Header.Get(config.HeaderKind) != "generic" || req.Header.Get(config.HeaderFrom) != "cli" || req.Header.Get(config.HeaderSource) != "doudian-open-cli" || req.Header.Get(config.HeaderVersion) != identity.Version() {
		t.Fatalf("%v", req.Header)
	}
	if req.Header.Get(config.HeaderToken) != "" {
		t.Fatalf("generic must not set CLI token header: %s", req.Header.Get(config.HeaderToken))
	}
}

func TestBuildFromUsesOfficeAgentName(t *testing.T) {
	t.Setenv(identity.EnvOfficeAgentName, "doubao_moa")
	creds := auth.Credentials{Kind: auth.KindAuthorized, AppKey: "123", AccessToken: "fake-tok"}
	req, err := BuildRequest(creds, "POST", "/product/detail", json.RawMessage(`{}`), time.Unix(1, 0), ppe.Config{})
	if err != nil {
		t.Fatal(err)
	}
	if req.Header.Get(config.HeaderFrom) != "doubao_moa" {
		t.Fatalf("from=%s", req.Header.Get(config.HeaderFrom))
	}
}

func TestBuildFromIgnoresInvalidAgentName(t *testing.T) {
	t.Setenv(identity.EnvOfficeAgentName, "not a header")
	creds := auth.Credentials{Kind: auth.KindGeneric, AppKey: "123", AppSecret: "sk", AccessToken: "tok"}
	req, err := BuildRequest(creds, "POST", "/product/detail", json.RawMessage(`{}`), time.Unix(1, 0), ppe.Config{})
	if err != nil {
		t.Fatal(err)
	}
	if req.Header.Get(config.HeaderFrom) != identity.DefaultFrom {
		t.Fatalf("from=%s", req.Header.Get(config.HeaderFrom))
	}
}

func TestBuildAuthorizedSignsLikeGeneric(t *testing.T) {
	t.Setenv(identity.EnvOfficeAgentName, "")
	creds := auth.Credentials{Kind: auth.KindAuthorized, AppKey: "123", AccessToken: "fake-tok"}
	req, err := BuildRequest(creds, "POST", "/product/detail", json.RawMessage(`{"id":1}`), time.Unix(1, 0), ppe.Config{Enabled: true, Env: "ppe_x"})
	if err != nil {
		t.Fatal(err)
	}
	q := req.URL.Query()
	want, err := signHMAC("123", "fake-tok", "product.detail", `{"id":1}`, "1")
	if err != nil {
		t.Fatal(err)
	}
	if q.Get("sign") != want || q.Get("sign_method") != "hmac-sha256" {
		t.Fatalf("authorized must sign: %s", req.URL.RawQuery)
	}
	if q.Get("access_token") != "fake-tok" {
		t.Fatalf("%s", req.URL.RawQuery)
	}
	if req.Header.Get(config.HeaderKind) != "authorized" {
		t.Fatalf("%v", req.Header)
	}
	if req.Header.Get(config.HeaderToken) != "fake-tok" || q.Get("access_token") != req.Header.Get(config.HeaderToken) {
		t.Fatalf("header token=%s query=%s", req.Header.Get(config.HeaderToken), q.Get("access_token"))
	}
	if req.Header.Get("x-use-ppe") != "1" || req.Header.Get("x-tt-env") != "ppe_x" {
		t.Fatalf("%v", req.Header)
	}
	if req.Header.Get(auth.HeaderSandboxContext) != "" {
		t.Fatalf("context=%s", req.Header.Get(auth.HeaderSandboxContext))
	}
	if strings.HasPrefix(req.Header.Get(config.HeaderToken), "Bearer ") {
		t.Fatalf("token=%s", req.Header.Get(config.HeaderToken))
	}
}

func TestBuildAuthorizedCarriesSandboxContextOnlyInSaaS(t *testing.T) {
	t.Setenv(auth.EnvDoubaoSandboxType, auth.DoubaoSandboxTypeSaaS)
	t.Setenv(auth.EnvDoubaoSandboxContextToken, "ctx-raw")
	creds := auth.Credentials{Kind: auth.KindAuthorized, AppKey: "123", AccessToken: "fake-tok"}
	req, err := BuildRequest(creds, "POST", "/product/detail", json.RawMessage(`{}`), time.Unix(1, 0), ppe.Config{})
	if err != nil {
		t.Fatal(err)
	}
	if got := req.Header.Get(auth.HeaderSandboxContext); got != "ctx-raw" || strings.Contains(got, "Bearer") {
		t.Fatalf("context=%q", got)
	}
	if req.Header.Get(config.HeaderToken) != "fake-tok" || strings.HasPrefix(req.Header.Get(config.HeaderToken), "Bearer ") {
		t.Fatalf("token=%s", req.Header.Get(config.HeaderToken))
	}

	generic := auth.Credentials{Kind: auth.KindGeneric, AppKey: "123", AppSecret: "sk", AccessToken: "real-tok"}
	genReq, err := BuildRequest(generic, "POST", "/product/detail", json.RawMessage(`{}`), time.Unix(1, 0), ppe.Config{})
	if err != nil {
		t.Fatal(err)
	}
	if genReq.Header.Get(auth.HeaderSandboxContext) != "" || genReq.Header.Get(config.HeaderToken) != "" {
		t.Fatalf("generic headers=%v", genReq.Header)
	}

	t.Setenv(auth.EnvDoubaoSandboxContextToken, "  ")
	empty, err := BuildRequest(creds, "POST", "/product/detail", json.RawMessage(`{}`), time.Unix(1, 0), ppe.Config{})
	if err != nil {
		t.Fatal(err)
	}
	if empty.Header.Get(auth.HeaderSandboxContext) != "" {
		t.Fatalf("blank context=%q", empty.Header.Get(auth.HeaderSandboxContext))
	}
}

func TestPreviewHidesCLIHeadersAndSecrets(t *testing.T) {
	t.Setenv(identity.EnvOfficeAgentName, "")
	creds := auth.Credentials{Kind: auth.KindGeneric, AppKey: "123", AppSecret: "sk", AccessToken: "real-tok"}
	env, err := Preview(creds, "POST", "/product/detail", json.RawMessage(`{"id":1}`), time.Unix(1, 0))
	if err != nil {
		t.Fatal(err)
	}
	raw, _ := json.Marshal(env)
	s := string(raw)
	for _, leak := range []string{"real-tok", "sk", "X-Cli-Source", "X-Doudian-Open-Cli-From", "X-Doudian-Open-Cli-Auth-Kind", "X-Doudian-Open-Cli-Access-Token", "X-Doudian-Open-Cli-Version", "cb95d928"} {
		if strings.Contains(s, leak) {
			t.Fatalf("preview leaked %q: %s", leak, s)
		}
	}
	data := env.Data.(map[string]any)
	if data["url"] != "https://openapi-fxg.jinritemai.com/product/detail" {
		t.Fatalf("url=%v", data["url"])
	}
	joined := strings.Join(toStringSlice(data["query_keys"]), ",")
	if !strings.Contains(joined, "access_token") || !strings.Contains(joined, "sign") {
		t.Fatalf("query_keys=%v", data["query_keys"])
	}
}

func toStringSlice(v any) []string {
	switch typed := v.(type) {
	case []string:
		return typed
	case []any:
		out := make([]string, 0, len(typed))
		for _, x := range typed {
			out = append(out, x.(string))
		}
		return out
	default:
		return nil
	}
}

func TestBuildDoesNotPutTokenInPath(t *testing.T) {
	creds := auth.Credentials{Kind: auth.KindGeneric, AppKey: "123", AppSecret: "sk", AccessToken: "real-tok"}
	req, err := BuildRequest(creds, "POST", "/product/detail", json.RawMessage(`{}`), time.Unix(1, 0), ppe.Config{})
	if err != nil {
		t.Fatal(err)
	}
	if _, err := url.Parse(req.URL.String()); err != nil {
		t.Fatal(err)
	}
}

func TestCanonicalJSONPreservesLargeIntegers(t *testing.T) {
	got, err := canonicalJSON(json.RawMessage(`{"id":9007199254740993}`))
	if err != nil {
		t.Fatal(err)
	}
	if got != `{"id":9007199254740993}` {
		t.Fatalf("got=%s", got)
	}
}

func TestCanonicalJSONRejectsTrailingValue(t *testing.T) {
	if _, err := canonicalJSON(json.RawMessage(`{"id":1}{"id":2}`)); err == nil {
		t.Fatal("expected trailing value to fail")
	}
}

func TestCanonicalJSONEscapesHTMLLikeGateway(t *testing.T) {
	got, err := canonicalJSON(json.RawMessage(`{"b":2,"a":"x&y"}`))
	if err != nil {
		t.Fatal(err)
	}
	if got != `{"a":"x\u0026y","b":2}` {
		t.Fatalf("got=%s", got)
	}
}

func TestSignHMACKnownVector(t *testing.T) {
	got, err := signHMAC("123", "sk", "product.detail", `{}`, "1")
	if err != nil {
		t.Fatal(err)
	}
	if got != "cb95d928a6168586fc73d0752ebd1bc7f6bcab0258f6c7ca254c1adcaa4dffd8" {
		t.Fatalf("sign=%s", got)
	}
}
