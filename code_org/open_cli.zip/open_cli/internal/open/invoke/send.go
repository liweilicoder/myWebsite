package invoke

import (
	"bytes"
	"context"
	"encoding/json"
	"io"
	"net/http"
	"strings"

	"code.byted.org/temai/open_cli/internal/core/errs"
	"code.byted.org/temai/open_cli/internal/open/auth"
)

var authSubCodes = map[string]struct{}{
	"isv.access-token-no-existed":  {},
	"isv.access-token-expired":     {},
	"isv.access-token-missing":     {},
	"isv.cli-access-token-missing": {},
	"isv.access-token-invalid":     {},
	"dop.authorization-no-existed": {},
	"dop.authorization-closed":     {},
}

type gatewayResp struct {
	Code    json.Number     `json:"code"`
	Msg     string          `json:"msg"`
	SubCode string          `json:"sub_code"`
	SubMsg  string          `json:"sub_msg"`
	LogID   string          `json:"log_id"`
	Data    json.RawMessage `json:"data"`
}

func Send(ctx context.Context, client *http.Client, req *Request) (json.RawMessage, string, error) {
	if client == nil {
		return nil, "", errs.Internal("HTTP client 未配置")
	}
	if req == nil || req.URL == nil {
		return nil, "", errs.Internal("请求未构建")
	}
	httpReq, err := http.NewRequestWithContext(ctx, req.HTTPMethod, req.URL.String(), bytes.NewReader(req.Body))
	if err != nil {
		return nil, "", errs.Internal(err.Error())
	}
	httpReq.Header = req.Header.Clone()
	resp, err := client.Do(httpReq)
	if err != nil {
		return nil, "", errs.Network(err.Error())
	}
	defer resp.Body.Close()
	raw, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, "", errs.Network(err.Error())
	}
	logID := resp.Header.Get("x-tt-logid")
	var parsed gatewayResp
	if err := json.Unmarshal(raw, &parsed); err != nil {
		if resp.StatusCode < 200 || resp.StatusCode >= 300 {
			return nil, logID, errs.API("网关 HTTP "+resp.Status, logID)
		}
		return nil, logID, errs.API("网关响应不是 JSON", logID)
	}
	if parsed.LogID != "" {
		logID = parsed.LogID
	}
	code, _ := parsed.Code.Int64()
	if code == 10000 {
		data := parsed.Data
		if len(data) == 0 {
			data = json.RawMessage(`{}`)
		}
		return data, logID, nil
	}
	msg := parsed.SubMsg
	if strings.TrimSpace(msg) == "" {
		msg = parsed.Msg
	}
	if msg == "" {
		msg = "开放网关调用失败"
	}
	var typed *errs.Error
	if _, ok := authSubCodes[parsed.SubCode]; ok {
		typed = errs.Auth(msg, auth.InitHint)
		typed.LogID = logID
	} else {
		typed = errs.API(msg, logID)
	}
	typed.Code = parsed.SubCode
	if len(raw) > 0 {
		typed.Body = append(json.RawMessage(nil), raw...)
	}
	return nil, logID, typed
}
