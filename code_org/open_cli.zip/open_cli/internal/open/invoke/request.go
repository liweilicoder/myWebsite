package invoke

import (
	"bytes"
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"net/http"
	"net/url"
	"strconv"
	"time"

	"code.byted.org/temai/open_cli/internal/core/errs"
	"code.byted.org/temai/open_cli/internal/core/identity"
	"code.byted.org/temai/open_cli/internal/core/ppe"
	"code.byted.org/temai/open_cli/internal/open/auth"
	"code.byted.org/temai/open_cli/internal/open/config"
)

type Request struct {
	HTTPMethod string
	URL        *url.URL
	Header     http.Header
	Body       []byte
}

func BuildRequest(creds auth.Credentials, httpMethod, path string, body json.RawMessage, now time.Time, lane ppe.Config) (*Request, error) {
	httpMethod, path, err := Normalize(httpMethod, path)
	if err != nil {
		return nil, err
	}
	method := GatewayMethod(path)
	if body == nil {
		body = json.RawMessage(`{}`)
	}
	paramJSON, err := canonicalJSON(body)
	if err != nil {
		return nil, err
	}
	ts := strconv.FormatInt(now.Unix(), 10)
	u, err := url.Parse(config.Production().GatewayBase + path)
	if err != nil {
		return nil, errs.Internal(err.Error())
	}
	q := u.Query()
	q.Set("method", method)
	q.Set("app_key", creds.AppKey)
	q.Set("access_token", creds.AccessToken)
	q.Set("timestamp", ts)
	q.Set("v", "2")
	secret := creds.AppSecret
	if creds.Kind == auth.KindAuthorized {
		secret = creds.AccessToken
	}
	sign, err := signHMAC(creds.AppKey, secret, method, paramJSON, ts)
	if err != nil {
		return nil, err
	}
	q.Set("sign", sign)
	q.Set("sign_method", "hmac-sha256")
	u.RawQuery = q.Encode()
	h := make(http.Header)
	identity.Apply(h)
	h.Set(config.HeaderKind, string(creds.Kind))
	if creds.Kind == auth.KindAuthorized {
		h.Set(config.HeaderToken, creds.AccessToken)
		auth.ApplySandboxContext(h)
	}
	h.Set("Content-Type", "application/json")
	if err := lane.Apply(h); err != nil {
		return nil, errs.Validation(err.Error())
	}
	return &Request{HTTPMethod: httpMethod, URL: u, Header: h, Body: []byte(paramJSON)}, nil
}

func canonicalJSON(body json.RawMessage) (string, error) {
	dec := json.NewDecoder(bytes.NewReader(body))
	dec.UseNumber()
	var v any
	if err := dec.Decode(&v); err != nil {
		return "", errs.Validation("param_json 不是 JSON")
	}
	if dec.More() {
		return "", errs.Validation("param_json 不是单个 JSON 值")
	}
	b, err := json.Marshal(v)
	if err != nil {
		return "", errs.Validation("param_json 无法序列化")
	}
	return string(b), nil
}

// signHMAC 与 open_gw HashEQ(hmac-sha256) 同一套：crypto/hmac SHA256、hex 小写、
// before = secret + "app_key" + appId + "method" + method + "param_json" + paramJSON + "timestamp" + ts + "v" + "2" + secret。
func signHMAC(appKey, secret, method, paramJSON, ts string) (string, error) {
	id, err := strconv.ParseInt(appKey, 10, 64)
	if err != nil {
		return "", errs.Validation("app_key 必须是数字")
	}
	plain := fmt.Sprintf("%sapp_key%dmethod%sparam_json%stimestamp%sv%s%s", secret, id, method, paramJSON, ts, "2", secret)
	mac := hmac.New(sha256.New, []byte(secret))
	_, _ = mac.Write([]byte(plain))
	return hex.EncodeToString(mac.Sum(nil)), nil
}
