package invoke

import (
	"encoding/json"
	"net/http"
	"regexp"
	"sort"
	"strings"
	"time"

	"code.byted.org/temai/open_cli/internal/core/errs"
	"code.byted.org/temai/open_cli/internal/core/output"
	"code.byted.org/temai/open_cli/internal/core/ppe"
	"code.byted.org/temai/open_cli/internal/open/auth"
)

var urlPrefixRe = regexp.MustCompile(`(?i)^https?://[^/]+(/.*)$`)

func Normalize(method, path string) (string, string, error) {
	method = strings.ToUpper(strings.TrimSpace(method))
	if method == "" {
		method = http.MethodPost
	}
	if method != http.MethodGet && method != http.MethodPost {
		return "", "", errs.Validation("仅支持 GET 或 POST")
	}
	path = strings.TrimSpace(path)
	if matches := urlPrefixRe.FindStringSubmatch(path); len(matches) == 2 {
		path = matches[1]
	}
	if path == "" || !strings.HasPrefix(path, "/") {
		return "", "", errs.Validation("path 必须以 / 开头")
	}
	if strings.Contains(path, "+") {
		return "", "", errs.Validation("第一期不得使用 +shortcut")
	}
	return method, path, nil
}

func GatewayMethod(path string) string {
	return strings.ReplaceAll(strings.Trim(path, "/"), "/", ".")
}

func Preview(creds auth.Credentials, method, path string, body json.RawMessage, now time.Time) (output.Envelope, error) {
	req, err := BuildRequest(creds, method, path, body, now, ppe.Config{})
	if err != nil {
		return output.Envelope{}, err
	}
	keys := make([]string, 0, len(req.URL.Query()))
	for k := range req.URL.Query() {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	bare := *req.URL
	bare.RawQuery = ""
	data := map[string]any{
		"http_method": req.HTTPMethod,
		"path":        req.URL.Path,
		"method":      GatewayMethod(req.URL.Path),
		"url":         strings.TrimRight(bare.String(), "?"),
		"query_keys":  keys,
	}
	if len(body) > 0 {
		data["body"] = json.RawMessage(body)
	}
	ident := auth.PublicIdentity(creds)
	return output.Envelope{OK: true, DryRun: true, Identity: &ident, Data: data}, nil
}
