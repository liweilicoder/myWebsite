package invoke

import (
	"encoding/json"
	"testing"
	"time"

	"code.byted.org/temai/open_cli/internal/core/errs"
	"code.byted.org/temai/open_cli/internal/open/auth"
)

func TestNormalizeDefaultPOST(t *testing.T) {
	method, path, err := Normalize("", "/product/detail")
	if err != nil {
		t.Fatal(err)
	}
	if method != "POST" || path != "/product/detail" {
		t.Fatalf("%s %s", method, path)
	}
}

func TestNormalizeLowerGET(t *testing.T) {
	method, path, err := Normalize("get", "/product/list")
	if err != nil {
		t.Fatal(err)
	}
	if method != "GET" || path != "/product/list" {
		t.Fatalf("%s %s", method, path)
	}
}

func TestNormalizeRejectsPUT(t *testing.T) {
	_, _, err := Normalize("PUT", "/x")
	if errs.ExitCode(err) != errs.ExitValidation {
		t.Fatalf("err=%v", err)
	}
}

func TestNormalizeStripsHost(t *testing.T) {
	_, path, err := Normalize("POST", "https://openapi-fxg.jinritemai.com/product/detail")
	if err != nil {
		t.Fatal(err)
	}
	if path != "/product/detail" {
		t.Fatalf("path=%s", path)
	}
}

func TestNormalizeRequiresSlash(t *testing.T) {
	_, _, err := Normalize("POST", "product/detail")
	if errs.ExitCode(err) != errs.ExitValidation {
		t.Fatalf("err=%v", err)
	}
}

func TestGatewayMethod(t *testing.T) {
	if got := GatewayMethod("/product/detail"); got != "product.detail" {
		t.Fatalf("%s", got)
	}
}

func TestPreviewDryRun(t *testing.T) {
	creds := auth.Credentials{Kind: auth.KindGeneric, AppKey: "123456", AppSecret: "sk", AccessToken: "tok", ShopID: "s1"}
	env, err := Preview(creds, "POST", "/product/detail", json.RawMessage(`{"id":1}`), time.Unix(1, 0))
	if err != nil {
		t.Fatal(err)
	}
	if !env.DryRun || !env.OK {
		t.Fatalf("%+v", env)
	}
	data, ok := env.Data.(map[string]any)
	if !ok {
		t.Fatalf("%T", env.Data)
	}
	if data["method"] != "product.detail" || data["http_method"] != "POST" {
		t.Fatalf("%v", data)
	}
}
