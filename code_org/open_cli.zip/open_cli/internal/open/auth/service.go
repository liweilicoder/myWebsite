package auth

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"io"
	"os"
	"path/filepath"
	"strings"
	"time"

	"code.byted.org/temai/open_cli/internal/core/credstore"
	"code.byted.org/temai/open_cli/internal/core/errs"
	"code.byted.org/temai/open_cli/internal/core/keychain"
	"code.byted.org/temai/open_cli/internal/core/output"
)

type Kind string

const (
	KindAuthorized Kind = "authorized"
	KindGeneric    Kind = "generic"
	InitHint            = "先运行 doudian-open-cli init"
)

type Credentials struct {
	Kind        Kind   `json:"kind"`
	AppKey      string `json:"app_key"`
	AppSecret   string `json:"app_secret,omitempty"`
	AccessToken string `json:"access_token"`
	ExpiresAt   string `json:"expires_at,omitempty"`
	ShopID      string `json:"shop_id,omitempty"`
	ShopName    string `json:"shop_name,omitempty"`
}

func Dir(configDir string) string {
	return filepath.Join(configDir, "open")
}

func store(configDir string) credstore.Store {
	return credstore.Store{Path: credentialsPath(configDir)}
}

func credentialsPath(configDir string) string {
	return filepath.Join(Dir(configDir), "credentials.json")
}

var secrets keychain.KeychainAccess = keychain.Default()

// SetKeychainForTest 替换凭据钥匙串。仅测试使用。
func SetKeychainForTest(k keychain.KeychainAccess) func() {
	prev := secrets
	secrets = k
	return func() { secrets = prev }
}

func secretAccount(configDir string) (string, error) {
	return scopedAccount(configDir, "open-credentials-")
}

func pendingAccount(configDir string) (string, error) {
	return scopedAccount(configDir, "open-pending-")
}

func scopedAccount(configDir, prefix string) (string, error) {
	abs, err := filepath.Abs(configDir)
	if err != nil {
		return "", err
	}
	sum := sha256.Sum256([]byte(filepath.Clean(abs)))
	return prefix + hex.EncodeToString(sum[:]), nil
}

func Exists(configDir string) bool {
	if CloudSandbox() {
		_, err := os.Stat(credentialsPath(configDir))
		return err == nil
	}
	if raw, err := readSecret(configDir); err == nil && strings.TrimSpace(raw) != "" {
		return true
	}
	_, err := os.Stat(credentialsPath(configDir))
	return err == nil
}

func Load(ctx context.Context, configDir string) (Credentials, error) {
	if err := ctx.Err(); err != nil {
		return Credentials{}, err
	}
	if CloudSandbox() {
		return loadFile(ctx, configDir)
	}
	raw, err := readSecret(configDir)
	if err == nil && strings.TrimSpace(raw) != "" {
		c, decErr := decodeCredentials(raw)
		if decErr != nil {
			return Credentials{}, decErr
		}
		if err := validate(c); err != nil {
			return Credentials{}, err
		}
		_ = store(configDir).Remove()
		return c, nil
	}
	if err != nil && !errors.Is(err, keychain.ErrNotFound) {
		return Credentials{}, errs.Internal(err.Error())
	}
	var c Credentials
	fileErr := store(configDir).Load(ctx, &c)
	if errors.Is(fileErr, os.ErrNotExist) {
		return Credentials{}, errs.Auth("未初始化", InitHint)
	}
	if fileErr != nil {
		return Credentials{}, fileErr
	}
	if err := validate(c); err != nil {
		return Credentials{}, err
	}
	if err := writeSecret(configDir, c); err != nil {
		return Credentials{}, errs.Internal(err.Error())
	}
	if err := store(configDir).Remove(); err != nil {
		return Credentials{}, errs.Internal(err.Error())
	}
	return c, nil
}

func Save(ctx context.Context, configDir string, c Credentials) error {
	if err := ctx.Err(); err != nil {
		return err
	}
	if c.Kind == KindAuthorized {
		c.AppSecret = ""
	}
	if err := validate(c); err != nil {
		return err
	}
	if CloudSandbox() {
		return store(configDir).Save(ctx, c)
	}
	if err := writeSecret(configDir, c); err != nil {
		return errs.Internal(err.Error())
	}
	return store(configDir).Remove()
}

func Logout(configDir string) error {
	_ = DeletePending(configDir)
	if CloudSandbox() {
		return store(configDir).Remove()
	}
	account, err := secretAccount(configDir)
	if err != nil {
		return err
	}
	if err := secrets.Remove(keychain.ServiceName, account); err != nil && !errors.Is(err, keychain.ErrNotFound) {
		return errs.Internal(err.Error())
	}
	return store(configDir).Remove()
}

func loadFile(ctx context.Context, configDir string) (Credentials, error) {
	var c Credentials
	err := store(configDir).Load(ctx, &c)
	if errors.Is(err, os.ErrNotExist) {
		return Credentials{}, errs.Auth("未初始化", InitHint)
	}
	if err != nil {
		return Credentials{}, err
	}
	if err := validate(c); err != nil {
		return Credentials{}, err
	}
	return c, nil
}

func readSecret(configDir string) (string, error) {
	account, err := secretAccount(configDir)
	if err != nil {
		return "", err
	}
	return secrets.Get(keychain.ServiceName, account)
}

func writeSecret(configDir string, c Credentials) error {
	account, err := secretAccount(configDir)
	if err != nil {
		return err
	}
	raw, err := json.Marshal(c)
	if err != nil {
		return errors.New("编码凭据失败")
	}
	return secrets.Set(keychain.ServiceName, account, string(raw))
}

func decodeCredentials(raw string) (Credentials, error) {
	dec := json.NewDecoder(strings.NewReader(raw))
	dec.DisallowUnknownFields()
	var c Credentials
	if err := dec.Decode(&c); err != nil {
		return Credentials{}, errors.New("解析钥匙串凭据失败：格式错误或包含未知字段")
	}
	var trailing any
	if err := dec.Decode(&trailing); !errors.Is(err, io.EOF) {
		return Credentials{}, errors.New("解析钥匙串凭据失败：仅允许单个 JSON 对象")
	}
	return c, nil
}

func Expired(c Credentials, now time.Time) bool {
	if strings.TrimSpace(c.ExpiresAt) == "" {
		return false
	}
	ts, err := time.Parse(time.RFC3339, c.ExpiresAt)
	if err != nil {
		return true
	}
	return !ts.After(now)
}

func EnsureFresh(c Credentials, now time.Time) error {
	if Expired(c, now) {
		return errs.Auth("凭据已过期", InitHint)
	}
	return nil
}

func PublicIdentity(c Credentials) output.Identity {
	return output.Identity{
		Kind:      string(c.Kind),
		AppKey:    c.AppKey,
		ExpiresAt: c.ExpiresAt,
	}
}

func validate(c Credentials) error {
	if c.Kind != KindAuthorized && c.Kind != KindGeneric {
		return errs.Validation("凭据 kind 必须是 authorized 或 generic")
	}
	if strings.TrimSpace(c.AppKey) == "" || strings.TrimSpace(c.AccessToken) == "" {
		return errs.Validation("凭据缺少 app_key 或 access_token")
	}
	if c.Kind == KindGeneric && strings.TrimSpace(c.AppSecret) == "" {
		return errs.Validation("通用型凭据缺少 app_secret")
	}
	return nil
}
