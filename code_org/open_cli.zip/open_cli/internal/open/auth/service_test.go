package auth

import (
	"context"
	"errors"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"code.byted.org/temai/open_cli/internal/core/errs"
	"code.byted.org/temai/open_cli/internal/core/keychain"
)

var testSecrets *keychain.Memory

func TestMain(m *testing.M) {
	testSecrets = keychain.NewMemory()
	restore := SetKeychainForTest(testSecrets)
	code := m.Run()
	restore()
	os.Exit(code)
}

func TestSaveLoadGeneric(t *testing.T) {
	dir := t.TempDir()
	ctx := context.Background()
	in := Credentials{Kind: KindGeneric, AppKey: "abcdef", AppSecret: "sk-secret", ShopID: "shop-1", AccessToken: "tok-secret", ExpiresAt: "2099-01-01T00:00:00Z"}
	if err := Save(ctx, dir, in); err != nil {
		t.Fatal(err)
	}
	got, err := Load(ctx, dir)
	if err != nil {
		t.Fatal(err)
	}
	if got.Kind != KindGeneric || got.AppSecret != "sk-secret" || got.AccessToken != "tok-secret" {
		t.Fatalf("%+v", got)
	}
	if err := EnsureFresh(got, time.Date(2026, 9, 20, 0, 0, 0, 0, time.UTC)); err != nil {
		t.Fatal(err)
	}
}

func TestSaveAuthorizedDropsSecret(t *testing.T) {
	dir := t.TempDir()
	in := Credentials{Kind: KindAuthorized, AppKey: "abcdef", AppSecret: "must-drop", AccessToken: "fake-tok", ExpiresAt: "2099-01-01T00:00:00Z", ShopName: "店A"}
	if err := Save(context.Background(), dir, in); err != nil {
		t.Fatal(err)
	}
	if _, err := os.Stat(filepath.Join(Dir(dir), "credentials.json")); !os.IsNotExist(err) {
		t.Fatalf("plaintext credentials still present: %v", err)
	}
	account, err := secretAccount(dir)
	if err != nil {
		t.Fatal(err)
	}
	raw, err := testSecrets.Get(keychain.ServiceName, account)
	if err != nil {
		t.Fatal(err)
	}
	if strings.Contains(raw, "must-drop") || strings.Contains(raw, "app_secret") {
		t.Fatalf("authorized keychain leaked sk: %s", raw)
	}
	if strings.Contains(raw, "fake-tok") == false || strings.Contains(raw, "abcdef") == false {
		t.Fatalf("keychain missing token or app_key: %s", raw)
	}
	got, err := Load(context.Background(), dir)
	if err != nil {
		t.Fatal(err)
	}
	if got.Kind != KindAuthorized || got.AppSecret != "" || got.AccessToken != "fake-tok" {
		t.Fatalf("%+v", got)
	}
}

func TestEnsureFreshExpired(t *testing.T) {
	c := Credentials{Kind: KindGeneric, AppKey: "ab", AccessToken: "t", AppSecret: "s", ExpiresAt: "2020-01-01T00:00:00Z"}
	err := EnsureFresh(c, time.Date(2026, 1, 1, 0, 0, 0, 0, time.UTC))
	if errs.ExitCode(err) != errs.ExitAuth || !strings.Contains(err.Error(), "过期") {
		t.Fatalf("err=%v", err)
	}
	typed, ok := err.(*errs.Error)
	if !ok || typed.Hint != InitHint {
		t.Fatalf("hint=%v", err)
	}
}

func TestEnsureFreshNoExpiresAt(t *testing.T) {
	c := Credentials{Kind: KindGeneric, AppKey: "ab", AccessToken: "t", AppSecret: "s"}
	if err := EnsureFresh(c, time.Now()); err != nil {
		t.Fatal(err)
	}
}

func TestLoadMissingHintsInit(t *testing.T) {
	_, err := Load(context.Background(), t.TempDir())
	if errs.ExitCode(err) != errs.ExitAuth {
		t.Fatalf("err=%v", err)
	}
	typed, ok := err.(*errs.Error)
	if !ok || typed.Hint != InitHint {
		t.Fatalf("hint=%v", err)
	}
}

func TestValidateRejectsBadKind(t *testing.T) {
	err := Save(context.Background(), t.TempDir(), Credentials{Kind: "other", AppKey: "a", AccessToken: "t"})
	if errs.ExitCode(err) != errs.ExitValidation {
		t.Fatalf("err=%v", err)
	}
}

func TestSaveLoadLogoutPerm(t *testing.T) {
	dir := t.TempDir()
	in := Credentials{Kind: KindGeneric, AppKey: "abcdef", AppSecret: "sk", AccessToken: "tok"}
	if err := Save(context.Background(), dir, in); err != nil {
		t.Fatal(err)
	}
	if _, err := os.Stat(filepath.Join(Dir(dir), "credentials.json")); !os.IsNotExist(err) {
		t.Fatalf("plaintext file err=%v", err)
	}
	if !Exists(dir) {
		t.Fatal("Exists")
	}
	if err := Logout(dir); err != nil {
		t.Fatal(err)
	}
	if Exists(dir) {
		t.Fatal("still exists")
	}
}

func TestLoadUnknownField(t *testing.T) {
	dir := t.TempDir()
	openDir := Dir(dir)
	if err := os.MkdirAll(openDir, 0o700); err != nil {
		t.Fatal(err)
	}
	path := filepath.Join(openDir, "credentials.json")
	if err := os.WriteFile(path, []byte(`{"kind":"generic","app_key":"a","access_token":"t","app_secret":"s","extra":1}`), 0o600); err != nil {
		t.Fatal(err)
	}
	if _, err := Load(context.Background(), dir); err == nil {
		t.Fatal("expected unknown field")
	}
	if _, err := os.Stat(path); err != nil {
		t.Fatal("invalid plaintext must stay until it can be parsed")
	}
}

func TestMigratePlaintextFileIntoKeychain(t *testing.T) {
	dir := t.TempDir()
	openDir := Dir(dir)
	if err := os.MkdirAll(openDir, 0o700); err != nil {
		t.Fatal(err)
	}
	path := filepath.Join(openDir, "credentials.json")
	body := `{"kind":"generic","app_key":"abcdef","app_secret":"sk-secret","access_token":"tok-secret"}`
	if err := os.WriteFile(path, []byte(body), 0o600); err != nil {
		t.Fatal(err)
	}
	got, err := Load(context.Background(), dir)
	if err != nil {
		t.Fatal(err)
	}
	if got.AccessToken != "tok-secret" || got.AppSecret != "sk-secret" {
		t.Fatalf("%+v", got)
	}
	if _, err := os.Stat(path); !os.IsNotExist(err) {
		t.Fatalf("plaintext remains: %v", err)
	}
	again, err := Load(context.Background(), dir)
	if err != nil || again.AccessToken != "tok-secret" {
		t.Fatalf("again=%+v err=%v", again, err)
	}
}

func TestLoadRejectsTrailingKeychainJSON(t *testing.T) {
	dir := t.TempDir()
	account, err := secretAccount(dir)
	if err != nil {
		t.Fatal(err)
	}
	raw := `{"kind":"authorized","app_key":"abcdef","access_token":"tok"}{"x":1}`
	if err := testSecrets.Set(keychain.ServiceName, account, raw); err != nil {
		t.Fatal(err)
	}
	if _, err := Load(context.Background(), dir); err == nil {
		t.Fatal("expected trailing json rejection")
	}
}

func TestCloudSandboxKeepsFileCredential(t *testing.T) {
	t.Setenv(EnvDoubaoSandboxType, DoubaoSandboxTypeSaaS)
	t.Setenv(EnvDoubaoSandboxContextToken, "sandbox-context")
	if !CloudSandbox() || DeviceStartMode() != DeviceModeCloud {
		t.Fatal("expected cloud mode")
	}
	dir := t.TempDir()
	in := Credentials{Kind: KindAuthorized, AppKey: "abcdef", AppSecret: "must-drop", AccessToken: "fake-tok", ExpiresAt: "2099-01-01T00:00:00Z"}
	if err := Save(context.Background(), dir, in); err != nil {
		t.Fatal(err)
	}
	path := filepath.Join(Dir(dir), "credentials.json")
	raw, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	if strings.Contains(string(raw), "must-drop") || !strings.Contains(string(raw), "fake-tok") {
		t.Fatalf("file=%s", raw)
	}
	account, err := secretAccount(dir)
	if err != nil {
		t.Fatal(err)
	}
	if _, err := testSecrets.Get(keychain.ServiceName, account); !errors.Is(err, keychain.ErrNotFound) {
		t.Fatalf("keychain err=%v", err)
	}
	got, err := Load(context.Background(), dir)
	if err != nil || got.AccessToken != "fake-tok" || got.AppSecret != "" {
		t.Fatalf("got=%+v err=%v", got, err)
	}
	if _, err := os.Stat(path); err != nil {
		t.Fatal(err)
	}
	if err := Logout(dir); err != nil {
		t.Fatal(err)
	}
	if _, err := os.Stat(path); !os.IsNotExist(err) {
		t.Fatalf("logout file err=%v", err)
	}
}
