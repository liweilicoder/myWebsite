package auth

import (
	"context"
	"encoding/json"
	"errors"
	"io"
	"os"
	"path/filepath"
	"strings"
	"time"

	"code.byted.org/temai/open_cli/internal/core/credstore"
	"code.byted.org/temai/open_cli/internal/core/errs"
	"code.byted.org/temai/open_cli/internal/core/keychain"
)

type PendingSession struct {
	DeviceCode      string `json:"device_code"`
	UserCode        string `json:"user_code"`
	VerificationURL string `json:"verification_url"`
	ExpiresAt       string `json:"expires_at"`
	Interval        int    `json:"interval"`
}

func pendingStore(configDir string) credstore.Store {
	return credstore.Store{Path: filepath.Join(Dir(configDir), "login-session.json")}
}

func LoadPending(ctx context.Context, configDir string) (PendingSession, error) {
	if err := ctx.Err(); err != nil {
		return PendingSession{}, err
	}
	if CloudSandbox() {
		return loadPendingFile(ctx, configDir)
	}
	raw, err := readPending(configDir)
	if err == nil && strings.TrimSpace(raw) != "" {
		s, decErr := decodePending(raw)
		if decErr != nil {
			return PendingSession{}, decErr
		}
		if err := validatePending(s); err != nil {
			return PendingSession{}, err
		}
		_ = pendingStore(configDir).Remove()
		return s, nil
	}
	if err != nil && !errors.Is(err, keychain.ErrNotFound) {
		return PendingSession{}, errs.Internal(err.Error())
	}
	s, fileErr := loadPendingFile(ctx, configDir)
	if errors.Is(fileErr, os.ErrNotExist) {
		return PendingSession{}, os.ErrNotExist
	}
	if fileErr != nil {
		return PendingSession{}, fileErr
	}
	if err := writePending(configDir, s); err != nil {
		return PendingSession{}, errs.Internal(err.Error())
	}
	if err := pendingStore(configDir).Remove(); err != nil {
		return PendingSession{}, errs.Internal(err.Error())
	}
	return s, nil
}

func SavePending(ctx context.Context, configDir string, s PendingSession) error {
	if err := ctx.Err(); err != nil {
		return err
	}
	if err := validatePending(s); err != nil {
		return err
	}
	if CloudSandbox() {
		return pendingStore(configDir).Save(ctx, s)
	}
	if err := writePending(configDir, s); err != nil {
		return errs.Internal(err.Error())
	}
	return pendingStore(configDir).Remove()
}

func DeletePending(configDir string) error {
	if !CloudSandbox() {
		account, err := pendingAccount(configDir)
		if err != nil {
			return err
		}
		if err := secrets.Remove(keychain.ServiceName, account); err != nil && !errors.Is(err, keychain.ErrNotFound) {
			return errs.Internal(err.Error())
		}
	}
	return pendingStore(configDir).Remove()
}

func loadPendingFile(ctx context.Context, configDir string) (PendingSession, error) {
	var s PendingSession
	if err := pendingStore(configDir).Load(ctx, &s); err != nil {
		return PendingSession{}, err
	}
	if err := validatePending(s); err != nil {
		return PendingSession{}, err
	}
	return s, nil
}

func readPending(configDir string) (string, error) {
	account, err := pendingAccount(configDir)
	if err != nil {
		return "", err
	}
	return secrets.Get(keychain.ServiceName, account)
}

func writePending(configDir string, s PendingSession) error {
	account, err := pendingAccount(configDir)
	if err != nil {
		return err
	}
	raw, err := json.Marshal(s)
	if err != nil {
		return errors.New("编码登录会话失败")
	}
	return secrets.Set(keychain.ServiceName, account, string(raw))
}

func decodePending(raw string) (PendingSession, error) {
	dec := json.NewDecoder(strings.NewReader(raw))
	dec.DisallowUnknownFields()
	var s PendingSession
	if err := dec.Decode(&s); err != nil {
		return PendingSession{}, errors.New("解析登录会话失败：格式错误或包含未知字段")
	}
	var trailing any
	if err := dec.Decode(&trailing); !errors.Is(err, io.EOF) {
		return PendingSession{}, errors.New("解析登录会话失败：仅允许单个 JSON 对象")
	}
	return s, nil
}

func PendingExpired(s PendingSession, now time.Time) bool {
	if strings.TrimSpace(s.ExpiresAt) == "" {
		return true
	}
	ts, err := time.Parse(time.RFC3339, s.ExpiresAt)
	if err != nil {
		return true
	}
	return !ts.After(now)
}

func PendingExpiresIn(s PendingSession, now time.Time) int {
	ts, err := time.Parse(time.RFC3339, s.ExpiresAt)
	if err != nil {
		return 0
	}
	n := int(ts.Sub(now).Seconds())
	if n < 0 {
		return 0
	}
	return n
}

func validatePending(s PendingSession) error {
	if strings.TrimSpace(s.DeviceCode) == "" || strings.TrimSpace(s.UserCode) == "" || strings.TrimSpace(s.VerificationURL) == "" || strings.TrimSpace(s.ExpiresAt) == "" {
		return errs.Validation("登录会话缺少 device_code、user_code、verification_url 或 expires_at")
	}
	if s.Interval <= 0 || s.Interval > 300 {
		return errs.Validation("登录会话 interval 无效")
	}
	if _, err := time.Parse(time.RFC3339, s.ExpiresAt); err != nil {
		return errs.Validation("登录会话 expires_at 必须是 RFC3339")
	}
	return nil
}
