package auth

import (
	"context"
	"encoding/json"
	"errors"
	"net/http"
	"net/url"
	"strings"
	"testing"
	"time"

	"code.byted.org/temai/open_cli/internal/core/errs"
	"code.byted.org/temai/open_cli/internal/core/httpmock"
	"code.byted.org/temai/open_cli/internal/core/identity"
	"code.byted.org/temai/open_cli/internal/core/ppe"
	"code.byted.org/temai/open_cli/internal/open/config"
)

func testDeviceEP() config.Endpoints {
	return config.Endpoints{
		DeviceStart:     "https://open.test/device/start",
		DeviceToken:     "https://open.test/device/token",
		VerificationURI: "https://shop.auth.example/cli",
	}
}

func TestDeviceStartUsesCompleteURL(t *testing.T) {
	reg := &httpmock.Registry{}
	reg.Register(&httpmock.Stub{Method: "POST", URL: "/device/start", Body: map[string]any{
		"device_code": "dev-secret", "user_code": "ABCD-EFGH",
		"verification_uri":          "https://shop.auth.example/cli",
		"verification_uri_complete": "https://shop.auth.example/cli?user_code=ABCD-EFGH",
		"expires_in":                900, "interval": 5,
	}})
	c := DeviceClient{HTTP: httpmock.NewClient(reg), Endpoints: testDeviceEP()}
	start, err := c.Start(context.Background())
	if err != nil {
		t.Fatal(err)
	}
	if start.DeviceCode != "dev-secret" || start.UserCode != "ABCD-EFGH" {
		t.Fatalf("%+v", start)
	}
	if start.VerificationURIComplete != "https://shop.auth.example/cli?user_code=ABCD-EFGH" {
		t.Fatalf("complete=%s", start.VerificationURIComplete)
	}
	reg.Verify(t)
}

func TestDeviceStartFillsCompleteFromFallback(t *testing.T) {
	reg := &httpmock.Registry{}
	startStub := &httpmock.Stub{Method: "POST", URL: "/device/start", Body: map[string]any{
		"device_code": "dev-1", "user_code": "ABCD-EFGH", "expires_in": 60, "interval": 5,
	}}
	reg.Register(startStub)
	c := DeviceClient{HTTP: httpmock.NewClient(reg), Endpoints: testDeviceEP()}
	start, err := c.Start(context.Background())
	if err != nil {
		t.Fatal(err)
	}
	if start.VerificationURIComplete != "https://shop.auth.example/cli?user_code=ABCD-EFGH" {
		t.Fatalf("complete=%s", start.VerificationURIComplete)
	}
	if string(startStub.CapturedBody) != `{"mode":"local"}` {
		t.Fatalf("start body=%s", startStub.CapturedBody)
	}
	reg.Verify(t)
}

func TestDeviceStartTokenForwardsPPEHeaders(t *testing.T) {
	reg := &httpmock.Registry{}
	startStub := &httpmock.Stub{Method: "POST", URL: "/device/start", Body: map[string]any{
		"device_code": "d.secret", "user_code": "u.code", "expires_in": 60, "interval": 5,
	}}
	tokStub := &httpmock.Stub{Method: "POST", URL: "/device/token", Body: map[string]any{
		"access_token": "fake-tok", "app_key": "123", "expires_time": "2099-01-01T00:00:00Z",
	}}
	reg.Register(startStub)
	reg.Register(tokStub)
	c := DeviceClient{
		HTTP: httpmock.NewClient(reg), Endpoints: testDeviceEP(),
		PPE: ppe.Config{Enabled: true, Env: "ppe_cli"},
	}
	if _, err := c.Start(context.Background()); err != nil {
		t.Fatal(err)
	}
	if startStub.CapturedHeaders.Get("x-use-ppe") != "1" || startStub.CapturedHeaders.Get("x-tt-env") != "ppe_cli" {
		t.Fatalf("start headers=%v", startStub.CapturedHeaders)
	}
	if !strings.Contains(string(startStub.CapturedBody), `"mode":"local"`) {
		t.Fatalf("start body=%s", startStub.CapturedBody)
	}
	if _, _, err := c.Token(context.Background(), "d.secret"); err != nil {
		t.Fatal(err)
	}
	if tokStub.CapturedHeaders.Get("x-use-ppe") != "1" || tokStub.CapturedHeaders.Get("x-tt-env") != "ppe_cli" {
		t.Fatalf("token headers=%v", tokStub.CapturedHeaders)
	}
	reg.Verify(t)
}

func TestDeviceStartCloudMode(t *testing.T) {
	t.Setenv(EnvDoubaoSandboxType, DoubaoSandboxTypeSaaS)
	t.Setenv(EnvDoubaoSandboxContextToken, "ctx-raw")
	reg := &httpmock.Registry{}
	startStub := &httpmock.Stub{Method: "POST", URL: "/device/start", Body: map[string]any{
		"device_code": "d.secret", "user_code": "u.code", "expires_in": 60, "interval": 5,
	}}
	tokStub := &httpmock.Stub{Method: "POST", URL: "/device/token", Body: map[string]any{
		"access_token": "fake-tok", "app_key": "123", "expires_time": "2099-01-01T00:00:00Z",
	}}
	reg.Register(startStub)
	reg.Register(tokStub)
	c := DeviceClient{HTTP: httpmock.NewClient(reg), Endpoints: testDeviceEP()}
	if _, err := c.Start(context.Background()); err != nil {
		t.Fatal(err)
	}
	if !strings.Contains(string(startStub.CapturedBody), `"mode":"cloud"`) {
		t.Fatalf("body=%s", startStub.CapturedBody)
	}
	if got := startStub.CapturedHeaders.Get(HeaderSandboxContext); got != "ctx-raw" || strings.Contains(got, "Bearer") {
		t.Fatalf("start context=%q", got)
	}
	if got := startStub.CapturedHeaders.Get(config.HeaderSource); got != config.SourceValue {
		t.Fatalf("start source=%q", got)
	}
	if got := startStub.CapturedHeaders.Get(config.HeaderVersion); got != identity.Version() {
		t.Fatalf("start version=%q", got)
	}
	if _, _, err := c.Token(context.Background(), "d.secret"); err != nil {
		t.Fatal(err)
	}
	if got := tokStub.CapturedHeaders.Get(HeaderSandboxContext); got != "ctx-raw" {
		t.Fatalf("token context=%q", got)
	}
	if got := tokStub.CapturedHeaders.Get(config.HeaderSource); got != config.SourceValue {
		t.Fatalf("token source=%q", got)
	}
	if got := tokStub.CapturedHeaders.Get(config.HeaderVersion); got != identity.Version() {
		t.Fatalf("token version=%q", got)
	}
	reg.Verify(t)
}

func TestDeviceOutsideSaaSOmitsSandboxHeader(t *testing.T) {
	t.Setenv(EnvDoubaoSandboxType, "local")
	t.Setenv(EnvDoubaoSandboxContextToken, "ctx-raw")
	reg := &httpmock.Registry{}
	startStub := &httpmock.Stub{Method: "POST", URL: "/device/start", Body: map[string]any{
		"device_code": "d.secret", "user_code": "u.code", "expires_in": 60, "interval": 5,
	}}
	reg.Register(startStub)
	c := DeviceClient{HTTP: httpmock.NewClient(reg), Endpoints: testDeviceEP()}
	if _, err := c.Start(context.Background()); err != nil {
		t.Fatal(err)
	}
	if string(startStub.CapturedBody) != `{"mode":"local"}` {
		t.Fatalf("body=%s", startStub.CapturedBody)
	}
	if got := startStub.CapturedHeaders.Get(HeaderSandboxContext); got != "" {
		t.Fatalf("context=%q", got)
	}
	reg.Verify(t)
}

func TestDeviceStartEscapesOpaqueUserCode(t *testing.T) {
	userCode := "u.abc+def/ghi="
	deviceCode := "d." + strings.Repeat("x", 80)
	reg := &httpmock.Registry{}
	startStub := &httpmock.Stub{Method: "POST", URL: "/device/start", Body: map[string]any{
		"device_code": deviceCode, "user_code": userCode, "expires_in": 600, "interval": 5,
	}}
	reg.Register(startStub)
	c := DeviceClient{HTTP: httpmock.NewClient(reg), Endpoints: testDeviceEP()}
	start, err := c.Start(context.Background())
	if err != nil {
		t.Fatal(err)
	}
	want := "https://shop.auth.example/cli?user_code=" + url.QueryEscape(userCode)
	if start.VerificationURIComplete != want || start.UserCode != userCode || start.DeviceCode != deviceCode {
		t.Fatalf("complete=%s start=%+v", start.VerificationURIComplete, start)
	}
	if string(startStub.CapturedBody) != `{"mode":"local"}` {
		t.Fatalf("start body=%s", startStub.CapturedBody)
	}
	reg.Verify(t)
}

func TestDeviceStartRejectsHTTPRemoteURI(t *testing.T) {
	reg := &httpmock.Registry{}
	reg.Register(&httpmock.Stub{Method: "POST", URL: "/device/start", Body: map[string]any{
		"device_code": "d", "user_code": "U", "expires_in": 60, "interval": 5,
		"verification_uri_complete": "http://evil.example/x",
	}})
	c := DeviceClient{HTTP: httpmock.NewClient(reg), Endpoints: testDeviceEP()}
	if _, err := c.Start(context.Background()); errs.ExitCode(err) != errs.ExitAPI {
		t.Fatalf("err=%v", err)
	}
}

func TestDeviceTokenSuccessDropsSecret(t *testing.T) {
	reg := &httpmock.Registry{}
	tok := &httpmock.Stub{Method: "POST", URL: "/device/token", Body: map[string]any{
		"access_token": "fake-tok", "app_key": "123", "expires_time": "2099-01-01T00:00:00Z",
		"app_secret": "leak-sk", "shop_id": "s1", "shop_name": "店A",
	}}
	reg.Register(tok)
	c := DeviceClient{HTTP: httpmock.NewClient(reg), Endpoints: testDeviceEP()}
	creds, _, err := c.Token(context.Background(), "dev-secret")
	if err != nil {
		t.Fatal(err)
	}
	if creds.Kind != KindAuthorized || creds.AppSecret != "" || creds.AccessToken != "fake-tok" || creds.ExpiresAt != "2099-01-01T00:00:00Z" {
		t.Fatalf("%+v", creds)
	}
	var body map[string]string
	if err := json.Unmarshal(tok.CapturedBody, &body); err != nil {
		t.Fatal(err)
	}
	if body["device_code"] != "dev-secret" || body["deviceCode"] != "dev-secret" || body["code_verifier"] != "" {
		t.Fatalf("token body=%v", body)
	}
	reg.Verify(t)
}

func TestDevicePollPendingThenSuccess(t *testing.T) {
	reg := &httpmock.Registry{}
	reg.Register(&httpmock.Stub{Method: "POST", URL: "/device/token", Status: http.StatusBadRequest, Body: map[string]any{"error": "authorization_pending"}})
	reg.Register(&httpmock.Stub{Method: "POST", URL: "/device/token", Body: map[string]any{
		"access_token": "fake-tok", "app_key": "123", "expires_time": "2099-01-01T00:00:00Z",
	}})
	waits := 0
	c := DeviceClient{
		HTTP: httpmock.NewClient(reg), Endpoints: testDeviceEP(),
		Now:  func() time.Time { return time.Unix(1000, 0).UTC() },
		Wait: func(ctx context.Context, d time.Duration) error { waits++; return nil },
	}
	creds, _, err := c.Poll(context.Background(), PendingSession{
		DeviceCode: "dev-secret", UserCode: "U", VerificationURL: "https://shop.auth.example/cli?user_code=U",
		ExpiresAt: "2099-01-01T00:00:00Z", Interval: 1,
	})
	if err != nil || creds.AccessToken != "fake-tok" {
		t.Fatalf("%+v %v", creds, err)
	}
	if waits != 1 {
		t.Fatalf("waits=%d", waits)
	}
	reg.Verify(t)
}

func TestDevicePollAccessDenied(t *testing.T) {
	reg := &httpmock.Registry{}
	reg.Register(&httpmock.Stub{Method: "POST", URL: "/device/token", Status: http.StatusBadRequest, Body: map[string]any{"error": "access_denied"}})
	c := DeviceClient{HTTP: httpmock.NewClient(reg), Endpoints: testDeviceEP(), Now: func() time.Time { return time.Unix(1, 0) }}
	_, _, err := c.Poll(context.Background(), PendingSession{
		DeviceCode: "d", UserCode: "U", VerificationURL: "https://shop.auth.example/cli?user_code=U",
		ExpiresAt: "2099-01-01T00:00:00Z", Interval: 1,
	})
	if errs.ExitCode(err) != errs.ExitAuth {
		t.Fatalf("err=%v", err)
	}
	var pe *DeviceProtocolError
	if errors.As(err, &pe) {
		t.Fatal("should be mapped to errs.Auth")
	}
}

func TestDeviceTokenPendingError(t *testing.T) {
	reg := &httpmock.Registry{}
	reg.Register(&httpmock.Stub{Method: "POST", URL: "/device/token", Status: http.StatusBadRequest, Body: map[string]any{"error": "authorization_pending"}})
	c := DeviceClient{HTTP: httpmock.NewClient(reg), Endpoints: testDeviceEP()}
	_, _, err := c.Token(context.Background(), "d")
	var pe *DeviceProtocolError
	if !errors.As(err, &pe) || pe.Code != "authorization_pending" {
		t.Fatalf("err=%v", err)
	}
}

func TestDeviceStartAcceptsCamelCase(t *testing.T) {
	reg := &httpmock.Registry{}
	reg.Register(&httpmock.Stub{Method: "POST", URL: "/device/start", Body: map[string]any{
		"deviceCode": "dev-secret", "userCode": "ABCD-EFGH",
		"verificationUri":         "https://fuwu.jinritemai.com/auth/cli/shop/login",
		"verificationUriComplete": "https://fuwu.jinritemai.com/auth/cli/shop/login?user_code=ABCD-EFGH",
		"expiresIn":               600, "interval": 5,
		"BaseResp":    map[string]any{"StatusCode": 0},
		"CustomError": map[string]any{"ErrNo": 0, "ErrMsg": ""},
	}})
	c := DeviceClient{HTTP: httpmock.NewClient(reg), Endpoints: testDeviceEP()}
	start, err := c.Start(context.Background())
	if err != nil {
		t.Fatal(err)
	}
	if start.DeviceCode != "dev-secret" || start.UserCode != "ABCD-EFGH" || start.ExpiresIn != 600 || start.Interval != 5 {
		t.Fatalf("%+v", start)
	}
	if start.VerificationURIComplete != "https://fuwu.jinritemai.com/auth/cli/shop/login?user_code=ABCD-EFGH" {
		t.Fatalf("complete=%s", start.VerificationURIComplete)
	}
}

func TestDeviceTokenAcceptsOpenAuthPendingAndSuccess(t *testing.T) {
	reg := &httpmock.Registry{}
	reg.Register(&httpmock.Stub{Method: "POST", URL: "/device/token", Body: map[string]any{
		"CustomError": map[string]any{"ErrNo": 34003, "ErrMsg": "任意内部文案"},
		"fakeToken":   "", "appId": "", "expiresAt": 0,
	}})
	reg.Register(&httpmock.Stub{Method: "POST", URL: "/device/token", Body: map[string]any{
		"CustomError": map[string]any{"ErrNo": 0, "ErrMsg": ""},
		"fakeToken":   "fake-tok", "appId": "123", "authId": "shop-1", "expiresAt": 1893456000,
	}})
	waits := 0
	c := DeviceClient{
		HTTP: httpmock.NewClient(reg), Endpoints: testDeviceEP(),
		Now:  func() time.Time { return time.Unix(1000, 0).UTC() },
		Wait: func(ctx context.Context, d time.Duration) error { waits++; return nil },
	}
	creds, _, err := c.Poll(context.Background(), PendingSession{
		DeviceCode: "dev-secret", UserCode: "U", VerificationURL: "https://fuwu.jinritemai.com/auth/cli/shop/login?user_code=U",
		ExpiresAt: "2099-01-01T00:00:00Z", Interval: 1,
	})
	if err != nil || creds.AccessToken != "fake-tok" || creds.AppKey != "123" || creds.ShopID != "shop-1" {
		t.Fatalf("%+v %v", creds, err)
	}
	if creds.ExpiresAt != time.Unix(1893456000, 0).UTC().Format(time.RFC3339) {
		t.Fatalf("expires=%s", creds.ExpiresAt)
	}
	if waits != 1 {
		t.Fatalf("waits=%d", waits)
	}
}

func logidHeader(id string) http.Header {
	h := make(http.Header)
	h.Set("x-tt-logid", id)
	return h
}

func TestDeviceStartCapturesResponseLogID(t *testing.T) {
	reg := &httpmock.Registry{}
	reg.Register(&httpmock.Stub{
		Method:  "POST",
		URL:     "/device/start",
		Headers: logidHeader("start-log-1"),
		Body: map[string]any{
			"device_code": "dev-secret", "user_code": "ABCD-EFGH",
			"verification_uri":          "https://shop.auth.example/cli",
			"verification_uri_complete": "https://shop.auth.example/cli?user_code=ABCD-EFGH",
			"expires_in":                900, "interval": 5,
		},
	})
	c := DeviceClient{HTTP: httpmock.NewClient(reg), Endpoints: testDeviceEP()}
	start, err := c.Start(context.Background())
	if err != nil {
		t.Fatal(err)
	}
	if start.LogID != "start-log-1" {
		t.Fatalf("log_id=%q", start.LogID)
	}
}

func TestDeviceStartHTTPErrorIncludesLogID(t *testing.T) {
	reg := &httpmock.Registry{}
	reg.Register(&httpmock.Stub{
		Method: "POST", URL: "/device/start", Status: http.StatusInternalServerError,
		Headers: logidHeader("start-fail-log"), Body: map[string]any{"msg": "boom"},
	})
	c := DeviceClient{HTTP: httpmock.NewClient(reg), Endpoints: testDeviceEP()}
	_, err := c.Start(context.Background())
	var typed *errs.Error
	if !errors.As(err, &typed) || typed.LogID != "start-fail-log" {
		t.Fatalf("err=%v", err)
	}
}

func TestDeviceTokenCapturesResponseLogID(t *testing.T) {
	reg := &httpmock.Registry{}
	reg.Register(&httpmock.Stub{
		Method: "POST", URL: "/device/token", Headers: logidHeader("token-log-1"),
		Body: map[string]any{"access_token": "fake-tok", "app_key": "123", "expires_time": "2099-01-01T00:00:00Z"},
	})
	c := DeviceClient{HTTP: httpmock.NewClient(reg), Endpoints: testDeviceEP()}
	_, logID, err := c.Token(context.Background(), "dev-secret")
	if err != nil {
		t.Fatal(err)
	}
	if logID != "token-log-1" {
		t.Fatalf("log_id=%q", logID)
	}
}

func TestDeviceTokenHTTPErrorIncludesLogID(t *testing.T) {
	reg := &httpmock.Registry{}
	reg.Register(&httpmock.Stub{
		Method: "POST", URL: "/device/token", Status: http.StatusInternalServerError,
		Headers: logidHeader("token-fail-log"), Body: map[string]any{"msg": "boom"},
	})
	c := DeviceClient{HTTP: httpmock.NewClient(reg), Endpoints: testDeviceEP()}
	_, logID, err := c.Token(context.Background(), "d")
	var typed *errs.Error
	if !errors.As(err, &typed) || typed.LogID != "token-fail-log" || logID != "token-fail-log" {
		t.Fatalf("err=%v logID=%q", err, logID)
	}
}

func TestDevicePollSuccessReturnsLastTokenLogID(t *testing.T) {
	reg := &httpmock.Registry{}
	reg.Register(&httpmock.Stub{
		Method: "POST", URL: "/device/token", Status: http.StatusBadRequest,
		Headers: logidHeader("pending-log"), Body: map[string]any{"error": "authorization_pending"},
	})
	reg.Register(&httpmock.Stub{
		Method: "POST", URL: "/device/token", Headers: logidHeader("ok-log"),
		Body: map[string]any{"access_token": "fake-tok", "app_key": "123", "expires_time": "2099-01-01T00:00:00Z"},
	})
	c := DeviceClient{
		HTTP: httpmock.NewClient(reg), Endpoints: testDeviceEP(),
		Now:  func() time.Time { return time.Unix(1000, 0).UTC() },
		Wait: func(ctx context.Context, d time.Duration) error { return nil },
	}
	_, logID, err := c.Poll(context.Background(), PendingSession{
		DeviceCode: "dev-secret", UserCode: "U", VerificationURL: "https://shop.auth.example/cli?user_code=U",
		ExpiresAt: "2099-01-01T00:00:00Z", Interval: 1,
	})
	if err != nil {
		t.Fatal(err)
	}
	if logID != "ok-log" {
		t.Fatalf("log_id=%q", logID)
	}
}

func TestDevicePollAccessDeniedIncludesLogID(t *testing.T) {
	reg := &httpmock.Registry{}
	reg.Register(&httpmock.Stub{
		Method: "POST", URL: "/device/token", Status: http.StatusBadRequest,
		Headers: logidHeader("denied-log"), Body: map[string]any{"error": "access_denied"},
	})
	c := DeviceClient{HTTP: httpmock.NewClient(reg), Endpoints: testDeviceEP(), Now: func() time.Time { return time.Unix(1, 0) }}
	_, logID, err := c.Poll(context.Background(), PendingSession{
		DeviceCode: "d", UserCode: "U", VerificationURL: "https://shop.auth.example/cli?user_code=U",
		ExpiresAt: "2099-01-01T00:00:00Z", Interval: 1,
	})
	var typed *errs.Error
	if !errors.As(err, &typed) || typed.LogID != "denied-log" || logID != "denied-log" {
		t.Fatalf("err=%v logID=%q", err, logID)
	}
	if typed.Message != "商家已拒绝授权" {
		t.Fatalf("message=%q", typed.Message)
	}
}

func TestDeviceStartMapsCloudUIDCustomError(t *testing.T) {
	reg := &httpmock.Registry{}
	reg.Register(&httpmock.Stub{
		Method: "POST", URL: "/device/start",
		Headers: logidHeader("uid-log"),
		Body: map[string]any{
			"CustomError": map[string]any{
				"ErrNo":  34005,
				"ErrMsg": "doubao_uid 必须非空、合法UTF-8、不含首尾空白且不超过128字节",
			},
		},
	})
	c := DeviceClient{HTTP: httpmock.NewClient(reg), Endpoints: testDeviceEP()}
	_, err := c.Start(context.Background())
	assertPublicDeviceError(t, err, errs.TypeAuth, "云电脑授权缺少登录身份，请在豆包内重试或切换为本地电脑", "doubao_uid", "device_code", "user_code")
	var typed *errs.Error
	if !errors.As(err, &typed) || typed.LogID != "uid-log" {
		t.Fatalf("err=%v", err)
	}
}

func TestDeviceStartMapsInvalidModeCustomError(t *testing.T) {
	reg := &httpmock.Registry{}
	reg.Register(&httpmock.Stub{
		Method: "POST", URL: "/device/start",
		Body: map[string]any{
			"CustomError": map[string]any{"ErrNo": 100003, "ErrMsg": "mode 仅支持 local 或 cloud"},
		},
	})
	c := DeviceClient{HTTP: httpmock.NewClient(reg), Endpoints: testDeviceEP()}
	_, err := c.Start(context.Background())
	assertPublicDeviceError(t, err, errs.TypeAPI, "授权请求无效", "mode 仅支持")
}

func TestDeviceStartIncompleteSuccessHasOwnMessage(t *testing.T) {
	reg := &httpmock.Registry{}
	reg.Register(&httpmock.Stub{
		Method: "POST", URL: "/device/start",
		Body: map[string]any{"expires_in": 300, "interval": 5},
	})
	c := DeviceClient{HTTP: httpmock.NewClient(reg), Endpoints: testDeviceEP()}
	_, err := c.Start(context.Background())
	assertPublicDeviceError(t, err, errs.TypeAPI, "授权发起失败，服务未返回完整结果")
}

func TestDeviceTokenMapsCloudUIDCustomError(t *testing.T) {
	reg := &httpmock.Registry{}
	reg.Register(&httpmock.Stub{
		Method: "POST", URL: "/device/token",
		Body: map[string]any{
			"CustomError": map[string]any{
				"ErrNo":  34005,
				"ErrMsg": "doubao_uid 必须非空、合法UTF-8、不含首尾空白且不超过128字节",
			},
		},
	})
	c := DeviceClient{HTTP: httpmock.NewClient(reg), Endpoints: testDeviceEP()}
	_, _, err := c.Token(context.Background(), "d")
	assertPublicDeviceError(t, err, errs.TypeAuth, "云电脑授权缺少登录身份，请在豆包内重试或切换为本地电脑", "doubao_uid")
}

func TestDeviceTokenDoesNotLeakInternalCustomError(t *testing.T) {
	reg := &httpmock.Registry{}
	reg.Register(&httpmock.Stub{
		Method: "POST", URL: "/device/token",
		Body: map[string]any{
			"CustomError": map[string]any{"ErrNo": 100002, "ErrMsg": "KMS解密 fake_token 失败"},
		},
	})
	c := DeviceClient{HTTP: httpmock.NewClient(reg), Endpoints: testDeviceEP()}
	_, _, err := c.Token(context.Background(), "d")
	assertPublicDeviceError(t, err, errs.TypeAPI, "授权服务暂时不可用", "KMS", "fake_token")
}

func TestDeviceTokenCredentialExpiredIsAuth(t *testing.T) {
	reg := &httpmock.Registry{}
	reg.Register(&httpmock.Stub{
		Method: "POST", URL: "/device/token",
		Body: map[string]any{
			"CustomError": map[string]any{"ErrNo": 34002, "ErrMsg": "CLI凭证已过期，请重新授权"},
		},
	})
	c := DeviceClient{HTTP: httpmock.NewClient(reg), Endpoints: testDeviceEP()}
	_, _, err := c.Token(context.Background(), "d")
	assertPublicDeviceError(t, err, errs.TypeAuth, "授权已过期", "CLI凭证")
}

func TestDeviceTokenUnknownCustomErrorIsGeneric(t *testing.T) {
	reg := &httpmock.Registry{}
	reg.Register(&httpmock.Stub{
		Method: "POST", URL: "/device/token",
		Body: map[string]any{
			"CustomError": map[string]any{"ErrNo": 999999, "ErrMsg": "sid 在 Redis 不存在"},
		},
	})
	c := DeviceClient{HTTP: httpmock.NewClient(reg), Endpoints: testDeviceEP()}
	_, _, err := c.Token(context.Background(), "d")
	assertPublicDeviceError(t, err, errs.TypeAPI, "授权失败，请稍后重试", "Redis", "sid")
}

func TestDeviceTokenPendingUsesErrnoNotErrMsg(t *testing.T) {
	reg := &httpmock.Registry{}
	reg.Register(&httpmock.Stub{
		Method: "POST", URL: "/device/token",
		Body: map[string]any{"CustomError": map[string]any{"ErrNo": 34003, "ErrMsg": ""}},
	})
	c := DeviceClient{HTTP: httpmock.NewClient(reg), Endpoints: testDeviceEP()}
	_, _, err := c.Token(context.Background(), "d")
	var pe *DeviceProtocolError
	if !errors.As(err, &pe) || pe.Code != "authorization_pending" {
		t.Fatalf("err=%v", err)
	}
}

func TestDeviceTokenDeniedUsesErrnoNotErrMsg(t *testing.T) {
	reg := &httpmock.Registry{}
	reg.Register(&httpmock.Stub{
		Method: "POST", URL: "/device/token",
		Body: map[string]any{"CustomError": map[string]any{"ErrNo": 34004, "ErrMsg": "内部状态 denied"}},
	})
	c := DeviceClient{HTTP: httpmock.NewClient(reg), Endpoints: testDeviceEP()}
	_, _, err := c.Token(context.Background(), "d")
	assertPublicDeviceError(t, err, errs.TypeAuth, "商家已拒绝授权", "内部状态")
}

func TestDeviceTokenAuthExpiredUsesErrnoNotErrMsg(t *testing.T) {
	reg := &httpmock.Registry{}
	reg.Register(&httpmock.Stub{
		Method: "POST", URL: "/device/token",
		Body: map[string]any{"CustomError": map[string]any{"ErrNo": 200009, "ErrMsg": "KMS sid Redis 过期"}},
	})
	c := DeviceClient{HTTP: httpmock.NewClient(reg), Endpoints: testDeviceEP()}
	_, _, err := c.Token(context.Background(), "d")
	assertPublicDeviceError(t, err, errs.TypeAuth, "授权已过期，请重新登录", "KMS", "Redis", "sid")
}

func TestDeviceTokenStatusInvalidUsesErrnoNotErrMsg(t *testing.T) {
	reg := &httpmock.Registry{}
	reg.Register(&httpmock.Stub{
		Method: "POST", URL: "/device/token",
		Body: map[string]any{"CustomError": map[string]any{"ErrNo": 34006, "ErrMsg": "binding status invalid uid"}},
	})
	c := DeviceClient{HTTP: httpmock.NewClient(reg), Endpoints: testDeviceEP()}
	_, _, err := c.Token(context.Background(), "d")
	assertPublicDeviceError(t, err, errs.TypeAuth, "授权状态异常，请重新登录", "binding", "uid")
}

func TestDeviceTokenLegacyAuthStatusIllegalIsNotPending(t *testing.T) {
	reg := &httpmock.Registry{}
	reg.Register(&httpmock.Stub{
		Method: "POST", URL: "/device/token",
		Body: map[string]any{"CustomError": map[string]any{"ErrNo": 200008, "ErrMsg": "待登陆授权"}},
	})
	c := DeviceClient{HTTP: httpmock.NewClient(reg), Endpoints: testDeviceEP()}
	_, _, err := c.Token(context.Background(), "d")
	var pe *DeviceProtocolError
	if errors.As(err, &pe) {
		t.Fatal("must not poll on legacy 200008")
	}
	assertPublicDeviceError(t, err, errs.TypeAPI, "授权失败，请稍后重试", "待登陆授权")
}

func assertPublicDeviceError(t *testing.T, err error, wantType errs.Type, mustContain string, leaks ...string) {
	t.Helper()
	var typed *errs.Error
	if !errors.As(err, &typed) {
		t.Fatalf("err=%v", err)
	}
	if typed.Type != wantType {
		t.Fatalf("type=%s want=%s msg=%q", typed.Type, wantType, typed.Message)
	}
	if !strings.Contains(typed.Message, mustContain) {
		t.Fatalf("message=%q want contain %q", typed.Message, mustContain)
	}
	low := strings.ToLower(typed.Message + typed.Hint)
	for _, leak := range leaks {
		if leak != "" && strings.Contains(low, strings.ToLower(leak)) {
			t.Fatalf("leaked %q in %q", leak, typed.Message)
		}
	}
}
