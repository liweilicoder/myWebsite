package auth

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
	"time"

	"code.byted.org/temai/open_cli/internal/core/errs"
	"code.byted.org/temai/open_cli/internal/core/identity"
	"code.byted.org/temai/open_cli/internal/core/ppe"
	"code.byted.org/temai/open_cli/internal/core/urlpolicy"
	"code.byted.org/temai/open_cli/internal/open/config"
)

const maxDeviceResponseBody int64 = 1 << 20

type DeviceClient struct {
	HTTP      *http.Client
	Endpoints config.Endpoints
	Now       func() time.Time
	Wait      func(ctx context.Context, d time.Duration) error
	PPE       ppe.Config
}

type DeviceStart struct {
	DeviceCode              string
	UserCode                string
	VerificationURI         string
	VerificationURIComplete string
	ExpiresIn               int
	Interval                int
	LogID                   string
}

type DeviceProtocolError struct {
	Code  string
	LogID string
}

func (e *DeviceProtocolError) Error() string {
	return "设备授权失败: " + e.Code
}

const (
	msgDeviceCloudUID     = "云电脑授权缺少登录身份，请在豆包内重试或切换为本地电脑"
	msgDeviceInvalidReq   = "授权请求无效，请稍后重试"
	msgDeviceServiceDown  = "授权服务暂时不可用，请稍后重试"
	msgDeviceFailed       = "授权失败，请稍后重试"
	msgDeviceDenied       = "商家已拒绝授权"
	msgDeviceExpired      = "授权已过期，请重新登录"
	msgDeviceInvalidGrant = "授权无效，请重新登录"
	msgDeviceCredInvalid  = "授权凭证无效，请重新登录"
	msgDeviceStatusBad    = "授权状态异常，请重新登录"
	msgStartIncomplete    = "授权发起失败，服务未返回完整结果"
	msgTokenIncomplete    = "授权完成失败，服务未返回完整结果"
)

const (
	errNoParamIllegal     int64 = 100003
	errNoInternal         int64 = 100001
	errNoDynamic          int64 = 100002
	errNoRedis            int64 = 100005
	errNoMQ               int64 = 100006
	errNoDB               int64 = 100007
	errNoAuthExpired      int64 = 200009
	errNoCliCredInvalid   int64 = 34001
	errNoCliCredExpired   int64 = 34002
	errNoCliDevicePending int64 = 34003
	errNoCliDeviceDenied  int64 = 34004
	errNoCliCloudUID      int64 = 34005
	errNoCliDeviceStatus  int64 = 34006
)

type startResp struct {
	DeviceCode              string
	UserCode                string
	VerificationURI         string
	VerificationURIComplete string
	ExpiresIn               int
	Interval                int
}

type tokenSuccessResp struct {
	AccessToken string
	ExpiresTime string
	AppKey      string
	ShopID      string
	ShopName    string
}

func (c DeviceClient) client() *http.Client {
	if c.HTTP != nil {
		return c.HTTP
	}
	return http.DefaultClient
}

func (c DeviceClient) now() time.Time {
	if c.Now != nil {
		return c.Now()
	}
	return time.Now()
}

func (c DeviceClient) Start(ctx context.Context) (DeviceStart, error) {
	status, data, logID, err := c.postJSON(ctx, c.Endpoints.DeviceStart, map[string]any{"mode": DeviceStartMode()})
	if err != nil {
		return DeviceStart{}, err
	}
	if status < http.StatusOK || status >= http.StatusMultipleChoices {
		return DeviceStart{}, errs.API(fmt.Sprintf("授权 start 返回 HTTP %d", status), logID)
	}
	if ferr := interpretDeviceFailure(data, logID); ferr != nil {
		return DeviceStart{}, ferr
	}
	parsed, err := parseStartResp(data)
	if err != nil {
		return DeviceStart{}, errs.API("授权 start 响应不是 JSON", logID)
	}
	if parsed.DeviceCode == "" || parsed.UserCode == "" {
		return DeviceStart{}, errs.API(msgStartIncomplete, logID)
	}
	if parsed.ExpiresIn <= 0 || parsed.ExpiresIn > 3600 || parsed.Interval <= 0 || parsed.Interval > 300 {
		return DeviceStart{}, errs.API("授权 start 时长字段无效", logID)
	}
	uri := strings.TrimSpace(parsed.VerificationURI)
	if uri == "" {
		uri = strings.TrimSpace(c.Endpoints.VerificationURI)
	}
	if err := urlpolicy.ValidateVerificationURI(uri, false); err != nil {
		return DeviceStart{}, errs.API("verification_uri 不安全", logID)
	}
	complete := strings.TrimSpace(parsed.VerificationURIComplete)
	if complete == "" {
		complete = uri + "?user_code=" + url.QueryEscape(parsed.UserCode)
	}
	if err := urlpolicy.ValidateVerificationURI(complete, true); err != nil {
		return DeviceStart{}, errs.API("verification_uri_complete 不安全", logID)
	}
	same, err := urlpolicy.SameOrigin(uri, complete)
	if err != nil || !same {
		return DeviceStart{}, errs.API("verification_uri_complete 与 verification_uri 不同源", logID)
	}
	return DeviceStart{
		DeviceCode:              parsed.DeviceCode,
		UserCode:                parsed.UserCode,
		VerificationURI:         uri,
		VerificationURIComplete: complete,
		ExpiresIn:               parsed.ExpiresIn,
		Interval:                parsed.Interval,
		LogID:                   logID,
	}, nil
}

func (c DeviceClient) Token(ctx context.Context, deviceCode string) (Credentials, string, error) {
	status, data, logID, err := c.postJSON(ctx, c.Endpoints.DeviceToken, map[string]string{
		"device_code": deviceCode,
		"deviceCode":  deviceCode,
	})
	if err != nil {
		return Credentials{}, "", err
	}
	if status == http.StatusBadRequest {
		if ferr := interpretDeviceFailure(data, logID); ferr != nil {
			return Credentials{}, logID, ferr
		}
		return Credentials{}, logID, errs.API("授权 token 返回非法 HTTP 400", logID)
	}
	if status != http.StatusOK {
		return Credentials{}, logID, errs.API(fmt.Sprintf("授权 token 返回 HTTP %d", status), logID)
	}
	if ferr := interpretDeviceFailure(data, logID); ferr != nil {
		return Credentials{}, logID, ferr
	}
	parsed, err := parseTokenResp(data)
	if err != nil {
		return Credentials{}, logID, errs.API("授权 token 响应不是 JSON", logID)
	}
	if parsed.AccessToken == "" || parsed.AppKey == "" || strings.TrimSpace(parsed.ExpiresTime) == "" {
		return Credentials{}, logID, errs.API(msgTokenIncomplete, logID)
	}
	if _, err := time.Parse(time.RFC3339, parsed.ExpiresTime); err != nil {
		return Credentials{}, logID, errs.API("授权 token expires_time 必须是 RFC3339", logID)
	}
	return Credentials{
		Kind:        KindAuthorized,
		AppKey:      parsed.AppKey,
		AccessToken: parsed.AccessToken,
		ExpiresAt:   parsed.ExpiresTime,
		ShopID:      parsed.ShopID,
		ShopName:    parsed.ShopName,
	}, logID, nil
}

func (c DeviceClient) Poll(ctx context.Context, session PendingSession) (Credentials, string, error) {
	interval := time.Duration(session.Interval) * time.Second
	deadline, err := time.Parse(time.RFC3339, session.ExpiresAt)
	if err != nil {
		return Credentials{}, "", errs.Internal("登录会话 expires_at 无效")
	}
	var lastLogID string
	for {
		if err := ctx.Err(); err != nil {
			return Credentials{}, lastLogID, errs.Network(err.Error())
		}
		if !c.now().Before(deadline) {
			return Credentials{}, lastLogID, withLogID(errs.Auth("授权超时", InitHint), lastLogID)
		}
		creds, logID, err := c.Token(ctx, session.DeviceCode)
		if logID != "" {
			lastLogID = logID
		}
		if err == nil {
			return creds, lastLogID, nil
		}
		var pe *DeviceProtocolError
		if !errors.As(err, &pe) {
			return Credentials{}, lastLogID, err
		}
		switch pe.Code {
		case "authorization_pending":
		case "slow_down":
			interval += 5 * time.Second
		case "access_denied":
			return Credentials{}, lastLogID, withLogID(errs.Auth(msgDeviceDenied, InitHint), lastLogID)
		case "expired_token":
			return Credentials{}, lastLogID, withLogID(errs.Auth(msgDeviceExpired, InitHint), lastLogID)
		case "invalid_grant":
			return Credentials{}, lastLogID, withLogID(errs.Auth(msgDeviceInvalidGrant, InitHint), lastLogID)
		default:
			return Credentials{}, lastLogID, withLogID(errs.API(msgDeviceFailed, ""), lastLogID)
		}
		wait := interval
		if remaining := deadline.Sub(c.now()); wait > remaining {
			wait = remaining
		}
		if wait <= 0 {
			return Credentials{}, lastLogID, withLogID(errs.Auth("授权超时", InitHint), lastLogID)
		}
		if err := c.wait(ctx, wait); err != nil {
			return Credentials{}, lastLogID, err
		}
	}
}

func (c DeviceClient) wait(ctx context.Context, d time.Duration) error {
	if c.Wait != nil {
		if err := c.Wait(ctx, d); err != nil {
			return errs.Network(err.Error())
		}
		return ctx.Err()
	}
	timer := time.NewTimer(d)
	defer timer.Stop()
	select {
	case <-ctx.Done():
		return errs.Network(ctx.Err().Error())
	case <-timer.C:
		return nil
	}
}

func (c DeviceClient) postJSON(ctx context.Context, rawURL string, body any) (int, []byte, string, error) {
	payload, err := json.Marshal(body)
	if err != nil {
		return 0, nil, "", errs.Internal("编码授权请求失败")
	}
	httpReq, err := http.NewRequestWithContext(ctx, http.MethodPost, rawURL, bytes.NewReader(payload))
	if err != nil {
		return 0, nil, "", errs.Internal(err.Error())
	}
	httpReq.Header.Set("Content-Type", "application/json")
	httpReq.Header.Set("Accept", "application/json")
	ApplySandboxContext(httpReq.Header)
	identity.Apply(httpReq.Header)
	if err := c.PPE.Apply(httpReq.Header); err != nil {
		return 0, nil, "", errs.Validation(err.Error())
	}
	resp, err := c.client().Do(httpReq)
	if err != nil {
		if ctx.Err() != nil {
			return 0, nil, "", errs.Network(ctx.Err().Error())
		}
		return 0, nil, "", errs.Network(err.Error())
	}
	defer resp.Body.Close()
	logID := responseLogID(resp.Header)
	data, err := io.ReadAll(io.LimitReader(resp.Body, maxDeviceResponseBody+1))
	if err != nil {
		return 0, nil, logID, errs.Network(err.Error())
	}
	if int64(len(data)) > maxDeviceResponseBody {
		return 0, nil, logID, errs.API("授权响应过大", logID)
	}
	return resp.StatusCode, data, logID, nil
}

func responseLogID(h http.Header) string {
	if h == nil {
		return ""
	}
	return strings.TrimSpace(h.Get("x-tt-logid"))
}

func withLogID(err *errs.Error, logID string) error {
	if err == nil {
		return nil
	}
	if logID != "" && err.LogID == "" {
		err.LogID = logID
	}
	return err
}

func knownDeviceError(code string) bool {
	switch code {
	case "authorization_pending", "slow_down", "access_denied", "expired_token", "invalid_grant":
		return true
	default:
		return false
	}
}

func parseStartResp(data []byte) (startResp, error) {
	raw, err := decodeObject(data)
	if err != nil {
		return startResp{}, err
	}
	return startResp{
		DeviceCode:              stringField(raw, "device_code", "deviceCode"),
		UserCode:                stringField(raw, "user_code", "userCode"),
		VerificationURI:         stringField(raw, "verification_uri", "verificationUri"),
		VerificationURIComplete: stringField(raw, "verification_uri_complete", "verificationUriComplete"),
		ExpiresIn:               intField(raw, "expires_in", "expiresIn"),
		Interval:                intField(raw, "interval"),
	}, nil
}

func parseTokenResp(data []byte) (tokenSuccessResp, error) {
	raw, err := decodeObject(data)
	if err != nil {
		return tokenSuccessResp{}, err
	}
	expires := stringField(raw, "expires_time", "expiresTime")
	if expires == "" {
		if unix := intField(raw, "expires_at", "expiresAt"); unix > 0 {
			expires = time.Unix(int64(unix), 0).UTC().Format(time.RFC3339)
		}
	}
	return tokenSuccessResp{
		AccessToken: stringField(raw, "access_token", "fakeToken"),
		ExpiresTime: expires,
		AppKey:      stringField(raw, "app_key", "appId"),
		ShopID:      stringField(raw, "shop_id", "authId"),
		ShopName:    stringField(raw, "shop_name"),
	}, nil
}

func interpretDeviceFailure(data []byte, logID string) error {
	if code, ok := protocolErrorCode(data); ok {
		return mapDeviceProtocol(code, logID)
	}
	raw, err := decodeObject(data)
	if err != nil {
		return nil
	}
	errno, _ := customError(raw)
	if errno == 0 {
		return nil
	}
	return mapDeviceCustomError(errno, logID)
}

func mapDeviceProtocol(code, logID string) error {
	switch code {
	case "authorization_pending", "slow_down":
		return &DeviceProtocolError{Code: code, LogID: logID}
	case "access_denied":
		return withLogID(errs.Auth(msgDeviceDenied, InitHint), logID)
	case "expired_token":
		return withLogID(errs.Auth(msgDeviceExpired, InitHint), logID)
	case "invalid_grant":
		return withLogID(errs.Auth(msgDeviceInvalidGrant, InitHint), logID)
	default:
		return withLogID(errs.API(msgDeviceFailed, ""), logID)
	}
}

func mapDeviceCustomError(errno int64, logID string) error {
	switch errno {
	case errNoCliDevicePending:
		return &DeviceProtocolError{Code: "authorization_pending", LogID: logID}
	case errNoCliDeviceDenied:
		return withLogID(errs.Auth(msgDeviceDenied, InitHint), logID)
	case errNoCliCloudUID:
		return withLogID(errs.Auth(msgDeviceCloudUID, InitHint), logID)
	case errNoCliDeviceStatus:
		return withLogID(errs.Auth(msgDeviceStatusBad, InitHint), logID)
	case errNoParamIllegal:
		return withLogID(errs.API(msgDeviceInvalidReq, ""), logID)
	case errNoInternal, errNoDynamic, errNoRedis, errNoMQ, errNoDB:
		return withLogID(errs.API(msgDeviceServiceDown, ""), logID)
	case errNoAuthExpired, errNoCliCredExpired:
		return withLogID(errs.Auth(msgDeviceExpired, InitHint), logID)
	case errNoCliCredInvalid:
		return withLogID(errs.Auth(msgDeviceCredInvalid, InitHint), logID)
	default:
		return withLogID(errs.API(msgDeviceFailed, ""), logID)
	}
}

func protocolErrorCode(data []byte) (string, bool) {
	raw, err := decodeObject(data)
	if err != nil {
		return "", false
	}
	if code := stringField(raw, "error"); knownDeviceError(code) {
		return code, true
	}
	return "", false
}

func decodeObject(data []byte) (map[string]any, error) {
	dec := json.NewDecoder(bytes.NewReader(data))
	dec.UseNumber()
	var raw map[string]any
	if err := dec.Decode(&raw); err != nil {
		return nil, err
	}
	return raw, nil
}

func stringField(raw map[string]any, keys ...string) string {
	for _, key := range keys {
		value, ok := raw[key].(string)
		if ok && strings.TrimSpace(value) != "" {
			return strings.TrimSpace(value)
		}
	}
	return ""
}

func intField(raw map[string]any, keys ...string) int {
	for _, key := range keys {
		switch value := raw[key].(type) {
		case json.Number:
			n, err := value.Int64()
			if err == nil && n != 0 {
				return int(n)
			}
		case float64:
			if value != 0 {
				return int(value)
			}
		}
	}
	return 0
}

func customError(raw map[string]any) (int64, string) {
	nested, ok := raw["CustomError"].(map[string]any)
	if !ok {
		return 0, ""
	}
	msg := stringField(nested, "ErrMsg", "errMsg")
	var errno int64
	switch value := nested["ErrNo"].(type) {
	case json.Number:
		errno, _ = value.Int64()
	case float64:
		errno = int64(value)
	}
	if errno == 0 {
		switch value := nested["errNo"].(type) {
		case json.Number:
			errno, _ = value.Int64()
		case float64:
			errno = int64(value)
		}
	}
	return errno, msg
}
