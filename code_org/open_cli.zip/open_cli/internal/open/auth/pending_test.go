package auth

import (
	"context"
	"errors"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"testing"
	"time"

	"code.byted.org/temai/open_cli/internal/core/errs"
	"code.byted.org/temai/open_cli/internal/core/keychain"
)

func samplePending() PendingSession {
	return PendingSession{
		DeviceCode: "dev-secret", UserCode: "ABCD-EFGH",
		VerificationURL: "https://shop.auth.example/cli?user_code=ABCD-EFGH",
		ExpiresAt:       "2099-01-01T00:00:00Z", Interval: 5,
	}
}

func TestPendingSaveLoadDelete(t *testing.T) {
	t.Setenv(EnvDoubaoSandboxType, "")
	dir := t.TempDir()
	ctx := context.Background()
	in := samplePending()
	if err := SavePending(ctx, dir, in); err != nil {
		t.Fatal(err)
	}
	path := filepath.Join(Dir(dir), "login-session.json")
	if _, err := os.Stat(path); !os.IsNotExist(err) {
		t.Fatalf("plaintext session err=%v", err)
	}
	account, err := pendingAccount(dir)
	if err != nil {
		t.Fatal(err)
	}
	raw, err := testSecrets.Get(keychain.ServiceName, account)
	if err != nil || !strings.Contains(raw, "dev-secret") {
		t.Fatalf("keychain=%s err=%v", raw, err)
	}
	got, err := LoadPending(ctx, dir)
	if err != nil || got.DeviceCode != "dev-secret" || got.UserCode != "ABCD-EFGH" {
		t.Fatalf("%+v %v", got, err)
	}
	now := time.Date(2026, 9, 21, 0, 0, 0, 0, time.UTC)
	if PendingExpired(got, now) {
		t.Fatal("should not expire")
	}
	if PendingExpiresIn(got, now) <= 0 {
		t.Fatal("expires_in")
	}
	if err := DeletePending(dir); err != nil {
		t.Fatal(err)
	}
	if _, err := LoadPending(ctx, dir); !os.IsNotExist(err) {
		t.Fatalf("err=%v", err)
	}
	if _, err := testSecrets.Get(keychain.ServiceName, account); !errors.Is(err, keychain.ErrNotFound) {
		t.Fatalf("keychain after delete err=%v", err)
	}
}

func TestPendingMigratesPlaintextFile(t *testing.T) {
	t.Setenv(EnvDoubaoSandboxType, "")
	dir := t.TempDir()
	ctx := context.Background()
	if err := pendingStore(dir).Save(ctx, samplePending()); err != nil {
		t.Fatal(err)
	}
	got, err := LoadPending(ctx, dir)
	if err != nil || got.DeviceCode != "dev-secret" {
		t.Fatalf("%+v %v", got, err)
	}
	if _, err := os.Stat(filepath.Join(Dir(dir), "login-session.json")); !os.IsNotExist(err) {
		t.Fatalf("plaintext left err=%v", err)
	}
	account, err := pendingAccount(dir)
	if err != nil {
		t.Fatal(err)
	}
	raw, err := testSecrets.Get(keychain.ServiceName, account)
	if err != nil || !strings.Contains(raw, "dev-secret") {
		t.Fatalf("keychain=%s err=%v", raw, err)
	}
}

func TestPendingCloudKeepsPlaintextFile(t *testing.T) {
	t.Setenv(EnvDoubaoSandboxType, DoubaoSandboxTypeSaaS)
	dir := t.TempDir()
	ctx := context.Background()
	if err := SavePending(ctx, dir, samplePending()); err != nil {
		t.Fatal(err)
	}
	path := filepath.Join(Dir(dir), "login-session.json")
	raw, err := os.ReadFile(path)
	if err != nil || !strings.Contains(string(raw), "dev-secret") {
		t.Fatalf("file=%s err=%v", raw, err)
	}
	if runtime.GOOS != "windows" {
		info, err := os.Stat(path)
		if err != nil {
			t.Fatal(err)
		}
		if info.Mode().Perm() != 0o600 {
			t.Fatalf("perm=%o", info.Mode().Perm())
		}
	}
	account, err := pendingAccount(dir)
	if err != nil {
		t.Fatal(err)
	}
	if _, err := testSecrets.Get(keychain.ServiceName, account); !errors.Is(err, keychain.ErrNotFound) {
		t.Fatalf("cloud touched keychain err=%v", err)
	}
	got, err := LoadPending(ctx, dir)
	if err != nil || got.DeviceCode != "dev-secret" {
		t.Fatalf("%+v %v", got, err)
	}
}

func TestPendingExpired(t *testing.T) {
	now := time.Date(2026, 9, 21, 0, 0, 0, 0, time.UTC)
	if !PendingExpired(PendingSession{ExpiresAt: "2020-01-01T00:00:00Z"}, now) {
		t.Fatal("past")
	}
	if !PendingExpired(PendingSession{}, now) {
		t.Fatal("empty")
	}
}

func TestPendingRejectsZeroInterval(t *testing.T) {
	s := samplePending()
	s.Interval = 0
	if err := SavePending(context.Background(), t.TempDir(), s); errs.ExitCode(err) != errs.ExitValidation {
		t.Fatalf("err=%v", err)
	}
}

func TestLogoutRemovesPending(t *testing.T) {
	dir := t.TempDir()
	ctx := context.Background()
	if err := SavePending(ctx, dir, samplePending()); err != nil {
		t.Fatal(err)
	}
	if err := Save(ctx, dir, Credentials{Kind: KindAuthorized, AppKey: "123", AccessToken: "tok"}); err != nil {
		t.Fatal(err)
	}
	if err := Logout(dir); err != nil {
		t.Fatal(err)
	}
	if Exists(dir) {
		t.Fatal("credentials")
	}
	if _, err := LoadPending(ctx, dir); !os.IsNotExist(err) {
		t.Fatalf("pending=%v", err)
	}
}
