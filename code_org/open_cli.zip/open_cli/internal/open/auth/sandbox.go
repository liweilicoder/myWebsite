package auth

import (
	"net/http"
	"os"
	"strings"
)

const (
	EnvDoubaoSandboxType         = "DOUBAO_SANDBOX_TYPE"
	EnvDoubaoSandboxContextToken = "DOUBAO_SANDBOX_CONTEXT_TOKEN"
	DoubaoSandboxTypeSaaS        = "SaaS"
	HeaderSandboxContext         = "X-Sandbox-Context-Token"
)

const (
	DeviceModeCloud = "cloud"
	DeviceModeLocal = "local"
)

// CloudSandbox 只认豆包云电脑。其他取值，包括未设置，都按本地处理。
func CloudSandbox() bool {
	return os.Getenv(EnvDoubaoSandboxType) == DoubaoSandboxTypeSaaS
}

// SandboxContextToken 仅在云电脑内返回上下文原值。空值不带头，也不加 Bearer。
func SandboxContextToken() string {
	if !CloudSandbox() {
		return ""
	}
	raw := os.Getenv(EnvDoubaoSandboxContextToken)
	if strings.TrimSpace(raw) == "" {
		return ""
	}
	return raw
}

func DeviceStartMode() string {
	if CloudSandbox() {
		return DeviceModeCloud
	}
	return DeviceModeLocal
}

func ApplySandboxContext(h http.Header) {
	if h == nil {
		return
	}
	token := SandboxContextToken()
	if token == "" {
		return
	}
	h.Set(HeaderSandboxContext, token)
}
