package credstore

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"reflect"
	"runtime"
)

type Store struct {
	Path string
}

func (s Store) dir() string {
	return filepath.Dir(s.Path)
}

func requireStructPtr(v any) error {
	rv := reflect.ValueOf(v)
	if rv.Kind() != reflect.Ptr || rv.IsNil() || rv.Elem().Kind() != reflect.Struct {
		return errors.New("凭据必须是结构体指针")
	}
	return nil
}

func requireStruct(v any) error {
	rv := reflect.ValueOf(v)
	if rv.Kind() == reflect.Ptr {
		if rv.IsNil() {
			return errors.New("凭据必须是结构体")
		}
		rv = rv.Elem()
	}
	if rv.Kind() != reflect.Struct {
		return errors.New("凭据必须是结构体")
	}
	return nil
}

func (s Store) Load(ctx context.Context, dest any) error {
	if err := ctx.Err(); err != nil {
		return err
	}
	if err := requireStructPtr(dest); err != nil {
		return err
	}
	f, err := os.Open(s.Path)
	if err != nil {
		if errors.Is(err, os.ErrNotExist) {
			return os.ErrNotExist
		}
		return fmt.Errorf("打开凭据文件: %w", err)
	}
	defer f.Close()
	if runtime.GOOS != "windows" {
		info, statErr := f.Stat()
		if statErr != nil {
			return fmt.Errorf("检查凭据文件权限: %w", statErr)
		}
		if info.Mode().Perm() != 0o600 {
			return errors.New("凭据文件权限不安全，应为 0600")
		}
	}
	dec := json.NewDecoder(f)
	dec.DisallowUnknownFields()
	if err := dec.Decode(dest); err != nil {
		return errors.New("解析凭据文件失败：格式错误或包含未知字段")
	}
	var trailing any
	if err := dec.Decode(&trailing); !errors.Is(err, io.EOF) {
		return errors.New("解析凭据文件失败：仅允许单个 JSON 对象")
	}
	return ctx.Err()
}

func (s Store) Save(ctx context.Context, src any) (err error) {
	if err := ctx.Err(); err != nil {
		return err
	}
	if err := requireStruct(src); err != nil {
		return err
	}
	dir := s.dir()
	if err := os.MkdirAll(dir, 0o700); err != nil {
		return fmt.Errorf("创建配置目录: %w", err)
	}
	if runtime.GOOS != "windows" {
		if err := os.Chmod(dir, 0o700); err != nil {
			return fmt.Errorf("设置配置目录权限: %w", err)
		}
	}
	f, err := os.CreateTemp(dir, ".credentials-*")
	if err != nil {
		return fmt.Errorf("创建临时文件: %w", err)
	}
	tmpName := f.Name()
	defer func() {
		if err != nil {
			_ = f.Close()
			_ = os.Remove(tmpName)
		}
	}()
	if err = f.Chmod(0o600); err != nil {
		return fmt.Errorf("设置临时文件权限: %w", err)
	}
	if err = json.NewEncoder(f).Encode(src); err != nil {
		return errors.New("编码凭据失败")
	}
	if err = f.Sync(); err != nil {
		return fmt.Errorf("同步文件失败: %w", err)
	}
	if err = f.Close(); err != nil {
		return fmt.Errorf("关闭临时文件: %w", err)
	}
	if runtime.GOOS != "windows" {
		info, statErr := os.Stat(tmpName)
		if statErr != nil {
			return fmt.Errorf("检查临时文件权限: %w", statErr)
		}
		if info.Mode().Perm() != 0o600 {
			return errors.New("临时凭据文件权限不安全，应为 0600")
		}
	}
	if err = ctx.Err(); err != nil {
		return err
	}
	if err = os.Rename(tmpName, s.Path); err != nil {
		return fmt.Errorf("原子替换凭据文件失败: %w", err)
	}
	return nil
}

func (s Store) Remove() error {
	err := os.Remove(s.Path)
	if err != nil && !errors.Is(err, os.ErrNotExist) {
		return fmt.Errorf("删除凭据文件: %w", err)
	}
	return nil
}
