package credstore

import (
	"context"
	"os"
	"path/filepath"
	"runtime"
	"testing"
)

type sample struct {
	Name string `json:"name"`
}

func TestSaveLoadRoundTrip(t *testing.T) {
	path := filepath.Join(t.TempDir(), "credentials.json")
	s := Store{Path: path}
	if err := s.Save(context.Background(), sample{Name: "ok"}); err != nil {
		t.Fatal(err)
	}
	if runtime.GOOS != "windows" {
		info, err := os.Stat(path)
		if err != nil {
			t.Fatal(err)
		}
		if info.Mode().Perm() != 0o600 {
			t.Fatalf("perm=%o", info.Mode().Perm())
		}
	}
	var got sample
	if err := s.Load(context.Background(), &got); err != nil {
		t.Fatal(err)
	}
	if got.Name != "ok" {
		t.Fatalf("%+v", got)
	}
}

func TestLoadUnknownField(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "credentials.json")
	if err := os.WriteFile(path, []byte(`{"name":"a","extra":1}`), 0o600); err != nil {
		t.Fatal(err)
	}
	var got sample
	if err := (Store{Path: path}).Load(context.Background(), &got); err == nil {
		t.Fatal("expected unknown field error")
	}
}

func TestLoadMissing(t *testing.T) {
	err := (Store{Path: filepath.Join(t.TempDir(), "missing.json")}).Load(context.Background(), &sample{})
	if err == nil || !os.IsNotExist(err) {
		t.Fatalf("err=%v", err)
	}
}

func TestRemove(t *testing.T) {
	path := filepath.Join(t.TempDir(), "credentials.json")
	s := Store{Path: path}
	if err := s.Save(context.Background(), sample{Name: "x"}); err != nil {
		t.Fatal(err)
	}
	if err := s.Remove(); err != nil {
		t.Fatal(err)
	}
	if err := s.Load(context.Background(), &sample{}); !os.IsNotExist(err) {
		t.Fatalf("err=%v", err)
	}
}

func TestRejectsTrailingJSON(t *testing.T) {
	path := filepath.Join(t.TempDir(), "credentials.json")
	if err := os.WriteFile(path, []byte(`{"name":"a"}{"name":"b"}`), 0o600); err != nil {
		t.Fatal(err)
	}
	if err := (Store{Path: path}).Load(context.Background(), &sample{}); err == nil {
		t.Fatal("expected trailing json error")
	}
}

func TestSaveRejectsNonStruct(t *testing.T) {
	s := Store{Path: filepath.Join(t.TempDir(), "credentials.json")}
	if err := s.Save(context.Background(), map[string]string{"a": "b"}); err == nil {
		t.Fatal("expected error")
	}
}
