//go:build darwin

package keychain

import (
	"crypto/rand"
	"encoding/base64"
	"errors"
	"strings"
	"time"
)

const keychainTimeout = 5 * time.Second

// keyringGet / keyringSet 测试可替换。生产由 keyring_darwin.go 接到 go-keyring，后者调用 /usr/bin/security。
var keyringGet = func(service, account string) (string, error) {
	return "", errors.New("钥匙串访问被拒绝")
}
var keyringSet = func(service, account, secret string) error {
	return errors.New("钥匙串访问被拒绝")
}

func masterKeyForWrite(service string) ([]byte, error) {
	if key, err := readFileMasterKey(service, false); err == nil {
		return key, nil
	}
	key, err := systemMasterKey(service, true)
	if err == nil {
		return key, nil
	}
	return readFileMasterKey(service, true)
}

func decryptWithMasters(service string, data []byte) (string, error) {
	if key, err := readFileMasterKey(service, false); err == nil {
		if plain, derr := decryptData(data, key); derr == nil {
			return plain, nil
		}
	}
	key, err := systemMasterKey(service, false)
	if err != nil {
		return "", err
	}
	return decryptData(data, key)
}

func systemMasterKey(service string, allowCreate bool) ([]byte, error) {
	encoded, err := keyringGet(service, "master.key")
	if err == nil {
		key, decErr := base64.StdEncoding.DecodeString(strings.TrimSpace(encoded))
		if decErr == nil && len(key) == masterKeyBytes {
			return key, nil
		}
		return nil, errors.New("钥匙串主密钥已损坏")
	}
	if !errors.Is(err, ErrNotFound) {
		return nil, errors.New("钥匙串访问被拒绝")
	}
	if !allowCreate {
		return nil, errNotInitialized
	}
	key := make([]byte, masterKeyBytes)
	if _, err := rand.Read(key); err != nil {
		return nil, err
	}
	encodedKey := base64.StdEncoding.EncodeToString(key)
	if err := keyringSet(service, "master.key", encodedKey); err != nil {
		return nil, err
	}
	return key, nil
}
