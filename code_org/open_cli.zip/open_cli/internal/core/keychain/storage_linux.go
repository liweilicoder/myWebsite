//go:build linux

package keychain

import (
	"os"
	"path/filepath"
)

func defaultStorageRoot() string {
	home, err := os.UserHomeDir()
	if err != nil || home == "" {
		return filepath.Join(".doudian-open-cli", "keychain")
	}
	return filepath.Join(home, ".local", "share", "doudian-open-cli", "keychain")
}
