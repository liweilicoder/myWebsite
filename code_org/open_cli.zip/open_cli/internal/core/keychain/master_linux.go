//go:build linux

package keychain

func masterKeyForWrite(service string) ([]byte, error) {
	return readFileMasterKey(service, true)
}

func decryptWithMasters(service string, data []byte) (string, error) {
	key, err := readFileMasterKey(service, false)
	if err != nil {
		return "", err
	}
	return decryptData(data, key)
}
