package keychain

import (
	"encoding/base64"
	"regexp"
	"strings"
)

const windowsRegRoot = `Software\DoudianOpenCli\keychain`

var safeNameRe = regexp.MustCompile(`[^a-zA-Z0-9._-]`)

func safeFileName(account string) string {
	return safeNameRe.ReplaceAllString(account, "_") + ".enc"
}

func safeRegistryComponent(s string) string {
	s = strings.ReplaceAll(s, `\`, "_")
	return safeNameRe.ReplaceAllString(s, "_")
}

func registryPathForService(service string) string {
	return windowsRegRoot + `\` + safeRegistryComponent(service)
}

func valueNameForAccount(account string) string {
	return base64.RawURLEncoding.EncodeToString([]byte(account))
}
