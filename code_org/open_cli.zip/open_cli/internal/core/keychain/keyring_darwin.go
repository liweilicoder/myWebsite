//go:build darwin

package keychain

import (
	"context"
	"errors"

	"github.com/zalando/go-keyring"
)

func init() {
	keyringGet = keyringGetPlatform
	keyringSet = keyringSetPlatform
}

func keyringGetPlatform(service, account string) (string, error) {
	value, err := callKeyring(func() (string, error) {
		return keyring.Get(service, account)
	})
	if errors.Is(err, keyring.ErrNotFound) {
		return "", ErrNotFound
	}
	return value, err
}

func keyringSetPlatform(service, account, secret string) error {
	_, err := callKeyring(func() (string, error) {
		return "", keyring.Set(service, account, secret)
	})
	return err
}

func callKeyring(fn func() (string, error)) (string, error) {
	ctx, cancel := context.WithTimeout(context.Background(), keychainTimeout)
	defer cancel()
	type result struct {
		value string
		err   error
	}
	ch := make(chan result, 1)
	go func() {
		defer func() { recover() }()
		value, err := fn()
		ch <- result{value: value, err: err}
	}()
	select {
	case res := <-ch:
		if res.err != nil && !errors.Is(res.err, keyring.ErrNotFound) && !errors.Is(res.err, ErrNotFound) {
			return "", errors.New("钥匙串访问被拒绝")
		}
		return res.value, res.err
	case <-ctx.Done():
		return "", errors.New("钥匙串访问超时")
	}
}
