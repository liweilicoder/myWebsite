package keychain

import "sync"

// Memory 是进程内钥匙串，测试用，不触碰系统钥匙串。
type Memory struct {
	mu sync.Mutex
	m  map[string]string
}

func NewMemory() *Memory {
	return &Memory{m: map[string]string{}}
}

func (m *Memory) key(service, account string) string {
	return service + "\x00" + account
}

func (m *Memory) Get(service, account string) (string, error) {
	m.mu.Lock()
	defer m.mu.Unlock()
	v, ok := m.m[m.key(service, account)]
	if !ok {
		return "", ErrNotFound
	}
	return v, nil
}

func (m *Memory) Set(service, account, value string) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.m[m.key(service, account)] = value
	return nil
}

func (m *Memory) Remove(service, account string) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	delete(m.m, m.key(service, account))
	return nil
}
