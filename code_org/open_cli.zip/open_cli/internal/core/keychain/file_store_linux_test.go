//go:build linux

package keychain

import "testing"

func useFileMasterOnly(t *testing.T) func() {
	t.Helper()
	return func() {}
}
