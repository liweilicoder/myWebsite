//go:build darwin

package keychain

import (
	"errors"
	"os"
	"path/filepath"
	"testing"
)

func useFileMasterOnly(t *testing.T) func() {
	t.Helper()
	origGet, origSet := keyringGet, keyringSet
	keyringGet = func(service, account string) (string, error) {
		return "", ErrNotFound
	}
	keyringSet = func(service, account, secret string) error {
		return errors.New("blocked")
	}
	return func() {
		keyringGet = origGet
		keyringSet = origSet
	}
}

func TestSystemMasterKeyRoundTrip(t *testing.T) {
	dir := t.TempDir()
	t.Setenv("DOUDIAN_OPEN_CLI_KEYCHAIN_DIR", dir)
	store := map[string]string{}
	origGet, origSet := keyringGet, keyringSet
	keyringGet = func(service, account string) (string, error) {
		v, ok := store[service+"\x00"+account]
		if !ok {
			return "", ErrNotFound
		}
		return v, nil
	}
	keyringSet = func(service, account, secret string) error {
		store[service+"\x00"+account] = secret
		return nil
	}
	t.Cleanup(func() {
		keyringGet = origGet
		keyringSet = origSet
	})

	if err := Set(ServiceName, "acct", "from-keychain"); err != nil {
		t.Fatal(err)
	}
	if _, err := os.Stat(filepath.Join(StorageDir(ServiceName), fileMasterKeyName)); !os.IsNotExist(err) {
		t.Fatalf("file master should stay absent when system keychain works: %v", err)
	}
	got, err := Get(ServiceName, "acct")
	if err != nil || got != "from-keychain" {
		t.Fatalf("got=%q err=%v", got, err)
	}
}
