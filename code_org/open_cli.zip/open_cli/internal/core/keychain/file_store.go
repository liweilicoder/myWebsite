//go:build darwin || linux

package keychain

import (
	"crypto/rand"
	"encoding/hex"
	"errors"
	"os"
	"path/filepath"
	"strings"
)

const fileMasterKeyName = "master.key.file"

func StorageDir(service string) string {
	if dir := strings.TrimSpace(os.Getenv("DOUDIAN_OPEN_CLI_KEYCHAIN_DIR")); dir != "" {
		return filepath.Join(dir, safeRegistryComponent(service))
	}
	return filepath.Join(defaultStorageRoot(), safeRegistryComponent(service))
}

func platformGet(service, account string) (string, error) {
	path := filepath.Join(StorageDir(service), safeFileName(account))
	data, err := os.ReadFile(path)
	if errors.Is(err, os.ErrNotExist) {
		return "", nil
	}
	if err != nil {
		return "", err
	}
	return decryptWithMasters(service, data)
}

func platformSet(service, account, data string) error {
	key, err := masterKeyForWrite(service)
	if err != nil {
		return err
	}
	dir := StorageDir(service)
	if err := os.MkdirAll(dir, 0o700); err != nil {
		return err
	}
	encrypted, err := encryptData(data, key)
	if err != nil {
		return err
	}
	target := filepath.Join(dir, safeFileName(account))
	tmp, err := tempPath(dir, safeFileName(account))
	if err != nil {
		return err
	}
	defer os.Remove(tmp)
	if err := os.WriteFile(tmp, encrypted, 0o600); err != nil {
		return err
	}
	return os.Rename(tmp, target)
}

func platformRemove(service, account string) error {
	err := os.Remove(filepath.Join(StorageDir(service), safeFileName(account)))
	if err != nil && !errors.Is(err, os.ErrNotExist) {
		return err
	}
	return nil
}

func tempPath(dir, name string) (string, error) {
	buf := make([]byte, 8)
	if _, err := rand.Read(buf); err != nil {
		return "", err
	}
	return filepath.Join(dir, name+"."+hex.EncodeToString(buf)+".tmp"), nil
}

func readFileMasterKey(service string, allowCreate bool) ([]byte, error) {
	dir := StorageDir(service)
	path := filepath.Join(dir, fileMasterKeyName)
	key, err := os.ReadFile(path)
	if err == nil && len(key) == masterKeyBytes {
		return key, nil
	}
	if err == nil {
		return nil, errors.New("钥匙串主密钥已损坏")
	}
	if !errors.Is(err, os.ErrNotExist) {
		return nil, err
	}
	if !allowCreate {
		return nil, errNotInitialized
	}
	if err := os.MkdirAll(dir, 0o700); err != nil {
		return nil, err
	}
	key = make([]byte, masterKeyBytes)
	if _, err := rand.Read(key); err != nil {
		return nil, err
	}
	f, err := os.OpenFile(path, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0o600)
	if err != nil {
		if errors.Is(err, os.ErrExist) {
			existing, readErr := os.ReadFile(path)
			if readErr == nil && len(existing) == masterKeyBytes {
				return existing, nil
			}
		}
		return nil, err
	}
	if _, err := f.Write(key); err != nil {
		_ = f.Close()
		_ = os.Remove(path)
		return nil, err
	}
	if err := f.Close(); err != nil {
		_ = os.Remove(path)
		return nil, err
	}
	return key, nil
}
