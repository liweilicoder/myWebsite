//go:build darwin

package keychain

import (
	"os"
	"path/filepath"
)

func defaultStorageRoot() string {
	home, err := os.UserHomeDir()
	if err != nil || home == "" {
		return filepath.Join(".doudian-open-cli", "keychain")
	}
	return filepath.Join(home, "Library", "Application Support", "doudian-open-cli", "keychain")
}
