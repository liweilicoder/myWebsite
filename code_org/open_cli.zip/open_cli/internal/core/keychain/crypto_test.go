package keychain

import (
	"bytes"
	"testing"
)

func TestEncryptDecryptRoundTrip(t *testing.T) {
	key := bytes.Repeat([]byte{7}, masterKeyBytes)
	got, err := encryptData("tok-secret", key)
	if err != nil {
		t.Fatal(err)
	}
	if bytes.Contains(got, []byte("tok-secret")) {
		t.Fatal("ciphertext contains plaintext")
	}
	plain, err := decryptData(got, key)
	if err != nil {
		t.Fatal(err)
	}
	if plain != "tok-secret" {
		t.Fatalf("plain=%q", plain)
	}
}

func TestDecryptRejectsShortAndWrongKey(t *testing.T) {
	key := bytes.Repeat([]byte{3}, masterKeyBytes)
	if _, err := decryptData([]byte("short"), key); err == nil {
		t.Fatal("short ciphertext")
	}
	blob, err := encryptData("x", key)
	if err != nil {
		t.Fatal(err)
	}
	other := bytes.Repeat([]byte{9}, masterKeyBytes)
	if _, err := decryptData(blob, other); err == nil {
		t.Fatal("wrong key")
	}
}

func TestSafeNames(t *testing.T) {
	if got := safeFileName(`a/b c`); got != "a_b_c.enc" {
		t.Fatalf("file=%s", got)
	}
	if got := safeRegistryComponent(`a\b c`); got != "a_b_c" {
		t.Fatalf("reg=%s", got)
	}
	if got := registryPathForService("doudian-open-cli"); got != `Software\DoudianOpenCli\keychain\doudian-open-cli` {
		t.Fatalf("path=%s", got)
	}
	if valueNameForAccount("open") == "" {
		t.Fatal("empty value name")
	}
}

func TestMemoryIsolation(t *testing.T) {
	m := NewMemory()
	if _, err := m.Get(ServiceName, "a"); err != ErrNotFound {
		t.Fatal(err)
	}
	if err := m.Set(ServiceName, "a", "one"); err != nil {
		t.Fatal(err)
	}
	if err := m.Set(ServiceName, "b", "two"); err != nil {
		t.Fatal(err)
	}
	got, err := m.Get(ServiceName, "a")
	if err != nil || got != "one" {
		t.Fatalf("got=%q err=%v", got, err)
	}
	if err := m.Remove(ServiceName, "a"); err != nil {
		t.Fatal(err)
	}
	if _, err := m.Get(ServiceName, "a"); err != ErrNotFound {
		t.Fatal(err)
	}
	got, err = m.Get(ServiceName, "b")
	if err != nil || got != "two" {
		t.Fatalf("b=%q err=%v", got, err)
	}
}
