//go:build darwin || linux

package keychain

import (
	"bytes"
	"errors"
	"os"
	"path/filepath"
	"runtime"
	"testing"
)

func TestFileStoreRoundTripAndRemove(t *testing.T) {
	dir := t.TempDir()
	t.Setenv("DOUDIAN_OPEN_CLI_KEYCHAIN_DIR", dir)
	restore := useFileMasterOnly(t)
	defer restore()

	if err := Set(ServiceName, "acct/1", "token-value"); err != nil {
		t.Fatal(err)
	}
	encPath := filepath.Join(StorageDir(ServiceName), safeFileName("acct/1"))
	raw, err := os.ReadFile(encPath)
	if err != nil {
		t.Fatal(err)
	}
	if bytes.Contains(raw, []byte("token-value")) {
		t.Fatal("plaintext leaked into ciphertext file")
	}
	info, err := os.Stat(encPath)
	if err != nil {
		t.Fatal(err)
	}
	if info.Mode().Perm() != 0o600 {
		t.Fatalf("perm=%o", info.Mode().Perm())
	}
	got, err := Get(ServiceName, "acct/1")
	if err != nil || got != "token-value" {
		t.Fatalf("got=%q err=%v", got, err)
	}
	if _, err := Get(ServiceName, "missing"); !errors.Is(err, ErrNotFound) {
		t.Fatalf("missing err=%v", err)
	}
	if err := Remove(ServiceName, "acct/1"); err != nil {
		t.Fatal(err)
	}
	if _, err := Get(ServiceName, "acct/1"); !errors.Is(err, ErrNotFound) {
		t.Fatalf("after remove err=%v", err)
	}
}

func TestStorageDir(t *testing.T) {
	base := t.TempDir()
	t.Setenv("DOUDIAN_OPEN_CLI_KEYCHAIN_DIR", base)
	if got, want := StorageDir("svc"), filepath.Join(base, "svc"); got != want {
		t.Fatalf("override=%s want=%s", got, want)
	}
	t.Setenv("DOUDIAN_OPEN_CLI_KEYCHAIN_DIR", "")
	home := t.TempDir()
	t.Setenv("HOME", home)
	got := StorageDir("svc")
	var want string
	if runtime.GOOS == "darwin" {
		want = filepath.Join(home, "Library", "Application Support", "doudian-open-cli", "keychain", "svc")
	} else {
		want = filepath.Join(home, ".local", "share", "doudian-open-cli", "keychain", "svc")
	}
	if got != want {
		t.Fatalf("got=%s want=%s", got, want)
	}
}

func TestCorruptCiphertext(t *testing.T) {
	dir := t.TempDir()
	t.Setenv("DOUDIAN_OPEN_CLI_KEYCHAIN_DIR", dir)
	restore := useFileMasterOnly(t)
	defer restore()
	if err := Set(ServiceName, "a", "ok"); err != nil {
		t.Fatal(err)
	}
	path := filepath.Join(StorageDir(ServiceName), safeFileName("a"))
	if err := os.WriteFile(path, []byte("not-a-ciphertext-blob-padding!!"), 0o600); err != nil {
		t.Fatal(err)
	}
	if _, err := Get(ServiceName, "a"); err == nil {
		t.Fatal("expected decrypt error")
	}
}
