// Package keychain 按 Lark CLI 的跨平台方式保存密钥。
// macOS 主密钥经 github.com/zalando/go-keyring v0.2.8 调用 /usr/bin/security 放进登录钥匙串，业务密文落盘。
// Windows 用 DPAPI + 当前用户注册表。Linux 只用 AES-GCM 文件。
// 该钥匙串库不使用 cgo。npm 的 darwin 构建仍设 CGO_ENABLED=1，Linux 和 Windows 为 0。
package keychain

import (
	"errors"
	"fmt"
)

const ServiceName = "doudian-open-cli"

var ErrNotFound = errors.New("keychain: item not found")

var errNotInitialized = errors.New("keychain not initialized")

// KeychainAccess 供凭据层注入；测试用内存实现，生产用 Default。
type KeychainAccess interface {
	Get(service, account string) (string, error)
	Set(service, account, value string) error
	Remove(service, account string) error
}

type defaultKeychain struct{}

func (d defaultKeychain) Get(service, account string) (string, error) { return Get(service, account) }
func (d defaultKeychain) Set(service, account, value string) error {
	return Set(service, account, value)
}
func (d defaultKeychain) Remove(service, account string) error { return Remove(service, account) }

func Default() KeychainAccess { return defaultKeychain{} }

func Get(service, account string) (string, error) {
	val, err := platformGet(service, account)
	if err != nil {
		return "", wrapError("读取", err)
	}
	if val == "" {
		return "", ErrNotFound
	}
	return val, nil
}

func Set(service, account, data string) error {
	return wrapError("写入", platformSet(service, account, data))
}

func Remove(service, account string) error {
	return wrapError("删除", platformRemove(service, account))
}

func wrapError(op string, err error) error {
	if err == nil || errors.Is(err, ErrNotFound) {
		return err
	}
	return fmt.Errorf("钥匙串%s失败: %w", op, err)
}
