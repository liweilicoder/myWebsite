package keychain

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"errors"
)

const (
	masterKeyBytes = 32
	ivBytes        = 12
	tagBytes       = 16
)

func encryptData(plaintext string, key []byte) ([]byte, error) {
	block, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}
	aesGCM, err := cipher.NewGCM(block)
	if err != nil {
		return nil, err
	}
	iv := make([]byte, ivBytes)
	if _, err := rand.Read(iv); err != nil {
		return nil, err
	}
	sealed := aesGCM.Seal(nil, iv, []byte(plaintext), nil)
	out := make([]byte, 0, ivBytes+len(sealed))
	out = append(out, iv...)
	out = append(out, sealed...)
	return out, nil
}

func decryptData(data, key []byte) (string, error) {
	if len(data) < ivBytes+tagBytes {
		return "", errors.New("密文长度不足")
	}
	block, err := aes.NewCipher(key)
	if err != nil {
		return "", err
	}
	aesGCM, err := cipher.NewGCM(block)
	if err != nil {
		return "", err
	}
	plain, err := aesGCM.Open(nil, data[:ivBytes], data[ivBytes:], nil)
	if err != nil {
		return "", err
	}
	return string(plain), nil
}
