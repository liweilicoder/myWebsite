package urlpolicy

import (
	"errors"
	"net"
	"net/url"
	"strings"
)

func ValidateBaseURL(raw string) (string, error) {
	u, err := url.Parse(strings.TrimSpace(raw))
	if err != nil || u.Scheme == "" || u.Host == "" || u.User != nil || u.RawQuery != "" || u.Fragment != "" {
		return "", errors.New("base URL 必须是无 userinfo、query、fragment 的绝对 URL")
	}
	if err := checkSchemeAndHost(u); err != nil {
		return "", err
	}
	return strings.TrimRight(u.String(), "/"), nil
}

func ValidateVerificationURI(raw string, allowQuery bool) error {
	u, err := url.Parse(strings.TrimSpace(raw))
	if err != nil || u.Scheme == "" || u.Host == "" || u.User != nil || u.Fragment != "" {
		return errors.New("verification URI 必须是无 userinfo、fragment 的绝对 URL")
	}
	if !allowQuery && u.RawQuery != "" {
		return errors.New("verification URI 不允许携带 query")
	}
	return checkSchemeAndHost(u)
}

func SameOrigin(a, b string) (bool, error) {
	left, err := url.Parse(a)
	if err != nil {
		return false, err
	}
	right, err := url.Parse(b)
	if err != nil {
		return false, err
	}
	return origin(left) == origin(right), nil
}

func origin(u *url.URL) string {
	scheme := strings.ToLower(u.Scheme)
	port := u.Port()
	if port == "" {
		switch scheme {
		case "https":
			port = "443"
		case "http":
			port = "80"
		}
	}
	return scheme + "://" + strings.ToLower(u.Hostname()) + ":" + port
}

func checkSchemeAndHost(u *url.URL) error {
	host := u.Hostname()
	ip := net.ParseIP(host)
	loopback := strings.EqualFold(host, "localhost") || (ip != nil && ip.IsLoopback())
	if u.Scheme != "https" && !(u.Scheme == "http" && loopback) {
		return errors.New("仅允许 HTTPS 或 loopback HTTP")
	}
	return nil
}
