package urlpolicy

import (
	"testing"
)

func TestValidateBaseURL(t *testing.T) {
	tests := []struct {
		name    string
		raw     string
		wantErr bool
	}{
		{"valid https", "https://admin.example.com", false},
		{"valid localhost http", "http://localhost:8080", false},
		{"valid loopback ip", "http://127.0.0.1:8080", false},
		{"invalid scheme", "ftp://example.com", true},
		{"remote http", "http://example.com", true},
		{"has userinfo", "https://user:pass@example.com", true},
		{"has query", "https://example.com?q=1", true},
		{"has fragment", "https://example.com#frag", true},
		{"relative", "/path", true},
		{"empty", "", true},
		{"file scheme", "file:///etc/passwd", true},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			_, err := ValidateBaseURL(tt.raw)
			if (err != nil) != tt.wantErr {
				t.Errorf("ValidateBaseURL(%q) error = %v, wantErr %v", tt.raw, err, tt.wantErr)
			}
		})
	}
}

func TestSameOriginNormalizesHostCaseAndDefaultPort(t *testing.T) {
	tests := []struct {
		a, b string
		want bool
	}{
		{"https://EXAMPLE.com/path", "https://example.com:443/other", true},
		{"http://localhost/a", "http://localhost:80/b", true},
		{"https://example.com", "https://other.example.com", false},
		{"https://example.com", "http://example.com", false},
	}
	for _, tt := range tests {
		got, err := SameOrigin(tt.a, tt.b)
		if err != nil || got != tt.want {
			t.Errorf("SameOrigin(%q,%q)=(%v,%v), want %v", tt.a, tt.b, got, err, tt.want)
		}
	}
}

func TestValidateVerificationURI(t *testing.T) {
	tests := []struct {
		name       string
		raw        string
		allowQuery bool
		wantErr    bool
	}{
		{"valid https no query", "https://verify.example.com", false, false},
		{"valid https with query allowed", "https://verify.example.com?code=123", true, false},
		{"valid https with query forbidden", "https://verify.example.com?code=123", false, true},
		{"no scheme", "verify.example.com", false, true},
		{"file scheme", "file:///tmp/x", false, true},
		{"has userinfo", "https://u@v.com", false, true},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			err := ValidateVerificationURI(tt.raw, tt.allowQuery)
			if (err != nil) != tt.wantErr {
				t.Errorf("ValidateVerificationURI(%q, %v) error = %v, wantErr %v", tt.raw, tt.allowQuery, err, tt.wantErr)
			}
		})
	}
}
