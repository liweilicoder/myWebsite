package cli

import (
	"net/http"
	"testing"

	"code.byted.org/temai/open_cli/internal/core/factory"
	"github.com/spf13/cobra"
)

func TestBuildCallsRegisterWithoutHTTP(t *testing.T) {
	f, _, _, _ := factory.TestFactory(t)
	calls := 0
	orig := f.HttpClient
	f.HttpClient = func() (*http.Client, error) {
		calls++
		return orig()
	}
	registered := 0
	root, _ := Build(f, RootOptions{Version: "t", ShowPPE: false}, func(root *cobra.Command, got *factory.Factory) {
		registered++
		if got != f {
			t.Fatal("factory mismatch")
		}
		root.AddCommand(&cobra.Command{Use: "probe"})
	})
	if registered != 1 {
		t.Fatalf("registered=%d", registered)
	}
	if calls != 0 {
		t.Fatal("Build must not call HttpClient")
	}
	if root.Use != "doudian-open-cli" {
		t.Fatalf("use=%s", root.Use)
	}
	cmd, _, err := root.Find([]string{"probe"})
	if err != nil || cmd == nil || cmd.Use != "probe" {
		t.Fatalf("probe not registered: %v", err)
	}
}
