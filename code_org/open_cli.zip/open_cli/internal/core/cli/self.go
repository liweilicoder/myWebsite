package cli

import (
	"context"
	"fmt"

	"code.byted.org/temai/open_cli/internal/core/output"
	"code.byted.org/temai/open_cli/internal/core/skill"
	"github.com/spf13/cobra"
)

func newSelfCommand(opts RootOptions, format *OutputFormat) *cobra.Command {
	command := &cobra.Command{
		Use:   "self",
		Short: "管理 doudian-open-cli 自身资源",
	}
	command.AddCommand(newRootSelfSkillCommand(opts, format))
	return command
}

type skillsEnvelope struct {
	Skills []skill.Result `json:"skills"`
}

func newRootSelfSkillCommand(opts RootOptions, format *OutputFormat) *cobra.Command {
	command := &cobra.Command{
		Use:   "skill",
		Short: "管理当前二进制内嵌的 Agent Skill",
	}
	command.AddCommand(
		newMultiSkillAction("install", "安装或同步内置 Skill", opts, format, func(ctx context.Context, m *skill.Manager) (skill.Result, error) {
			return m.Install(ctx)
		}),
		newMultiSkillAction("status", "查看内置 Skill 状态", opts, format, func(ctx context.Context, m *skill.Manager) (skill.Result, error) {
			return m.Status(ctx)
		}),
		newMultiSkillAction("update", "更新已安装的内置 Skill", opts, format, func(ctx context.Context, m *skill.Manager) (skill.Result, error) {
			return m.Update(ctx)
		}),
	)
	return command
}

func newMultiSkillAction(use, short string, opts RootOptions, format *OutputFormat, action func(context.Context, *skill.Manager) (skill.Result, error)) *cobra.Command {
	return &cobra.Command{
		Use:   use,
		Short: short,
		Args:  cobra.NoArgs,
		RunE: func(command *cobra.Command, _ []string) error {
			envelope := skillsEnvelope{}
			var firstErr error
			for _, bundle := range opts.Bundles {
				manager := skill.NewManager(opts.HomeDir, bundle)
				result, err := action(command.Context(), manager)
				envelope.Skills = append(envelope.Skills, result)
				if err != nil && firstErr == nil {
					firstErr = err
				}
			}
			printer, err := output.New(opts.Stdout, string(*format))
			if err != nil {
				return err
			}
			if string(*format) == "json" {
				if err = printer.JSON(envelope); err != nil {
					return err
				}
			} else {
				for _, result := range envelope.Skills {
					for _, target := range result.Targets {
						line := fmt.Sprintf("%s\t%s\t%s\t%s", result.Skill, target.Agent, target.Status, target.Path)
						if target.Error != "" {
							line += "\t" + target.Error
						}
						if err = printer.Text("%s\n", line); err != nil {
							return err
						}
					}
				}
			}
			return firstErr
		},
	}
}

func NewSingleSkillCommand(opts RootOptions, format *OutputFormat, bundle skill.Bundle) *cobra.Command {
	manager := skill.NewManager(opts.HomeDir, bundle)
	command := &cobra.Command{
		Use:   "skill",
		Short: "管理内置 Agent Skill",
	}
	command.AddCommand(
		newSingleSkillAction("install", "安装或同步内置 Skill", opts, format, manager.Install),
		newSingleSkillAction("status", "查看内置 Skill 状态", opts, format, manager.Status),
		newSingleSkillAction("update", "更新已安装的内置 Skill", opts, format, manager.Update),
	)
	return command
}

func newSingleSkillAction(use, short string, opts RootOptions, format *OutputFormat, action func(context.Context) (skill.Result, error)) *cobra.Command {
	return &cobra.Command{
		Use:   use,
		Short: short,
		Args:  cobra.NoArgs,
		RunE: func(command *cobra.Command, _ []string) error {
			result, actionErr := action(command.Context())
			printer, err := output.New(opts.Stdout, string(*format))
			if err != nil {
				return err
			}
			if string(*format) == "json" {
				err = printer.JSON(result)
			} else {
				for _, target := range result.Targets {
					line := fmt.Sprintf("%s\t%s\t%s", target.Agent, target.Status, target.Path)
					if target.Error != "" {
						line += "\t" + target.Error
					}
					if err = printer.Text("%s\n", line); err != nil {
						break
					}
				}
			}
			if err != nil {
				return err
			}
			return actionErr
		},
	}
}
