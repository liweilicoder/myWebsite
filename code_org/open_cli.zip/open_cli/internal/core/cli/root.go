package cli

import (
	"io"

	"code.byted.org/temai/open_cli/internal/core/factory"
	"code.byted.org/temai/open_cli/internal/core/output"
	"code.byted.org/temai/open_cli/internal/core/ppe"
	"code.byted.org/temai/open_cli/internal/core/skill"
	"github.com/spf13/cobra"
)

// BuildVersion is replaced by npm cross-platform builds through -ldflags -X.
// Keep in sync with internal/core/identity.BuildVersion.
var BuildVersion = "dev"

type OutputFormat string

func (f *OutputFormat) Set(value string) error {
	if _, err := output.New(io.Discard, value); err != nil {
		return err
	}
	*f = OutputFormat(value)
	return nil
}

func (f *OutputFormat) String() string { return string(*f) }

func (*OutputFormat) Type() string { return "string" }

type RootOptions struct {
	Version string
	Stdout  io.Writer
	Stderr  io.Writer
	HomeDir string
	ShowPPE bool
	Bundles []skill.Bundle
}

type Register func(root *cobra.Command, f *factory.Factory)

func Build(f *factory.Factory, opts RootOptions, registers ...Register) (*cobra.Command, *OutputFormat) {
	if f != nil {
		if f.IOStreams != nil {
			if opts.Stdout == nil {
				opts.Stdout = f.IOStreams.Out
			}
			if opts.Stderr == nil {
				opts.Stderr = f.IOStreams.ErrOut
			}
		}
		if opts.HomeDir == "" {
			opts.HomeDir = f.HomeDir
		}
	}
	root, format := NewRoot(opts)
	for _, register := range registers {
		if register != nil {
			register(root, f)
		}
	}
	return root, format
}

func NewRoot(opts RootOptions) (*cobra.Command, *OutputFormat) {
	if opts.Version == "" {
		opts.Version = BuildVersion
	}
	format := OutputFormat("json")
	root := &cobra.Command{
		Use:           "doudian-open-cli",
		Version:       opts.Version,
		SilenceUsage:  true,
		SilenceErrors: true,
	}
	root.SetVersionTemplate("{{.Version}}\n")
	root.CompletionOptions.DisableDefaultCmd = true
	root.PersistentFlags().VarP(&format, "output", "o", "输出格式：json（默认）或 text")
	bindPPE(root, opts.ShowPPE)
	root.PersistentPreRunE = func(*cobra.Command, []string) error {
		_, err := output.New(opts.Stdout, string(format))
		return err
	}
	root.AddCommand(NewVersionCommand(opts.Stdout, opts.Version))
	if len(opts.Bundles) > 0 {
		root.AddCommand(newSelfCommand(opts, &format))
	}
	return root, &format
}

func bindPPE(root *cobra.Command, show bool) {
	var usePPE bool
	var ppeEnv string
	flags := root.PersistentFlags()
	flags.BoolVar(&usePPE, "use-ppe", false, "将请求打到 PPE 联调环境")
	flags.StringVar(&ppeEnv, "ppe-env", ppe.DefaultEnvironment, "PPE 环境名")
	if !show {
		_ = flags.MarkHidden("use-ppe")
		_ = flags.MarkHidden("ppe-env")
	}
}

func PPEInput(command *cobra.Command) ppe.Input {
	input := ppe.Input{}
	if use := command.Flag("use-ppe"); use != nil {
		input.UsePPESet = use.Changed
		input.UsePPE = use.Value.String() == "true"
	}
	if env := command.Flag("ppe-env"); env != nil {
		input.EnvSet = env.Changed
		input.Env = env.Value.String()
	}
	return input
}
