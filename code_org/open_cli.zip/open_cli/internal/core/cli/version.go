package cli

import (
	"fmt"
	"io"

	"github.com/spf13/cobra"
)

func NewVersionCommand(stdout io.Writer, version string) *cobra.Command {
	return &cobra.Command{
		Use:   "version",
		Short: "打印版本号",
		Args:  cobra.NoArgs,
		RunE: func(*cobra.Command, []string) error {
			_, err := fmt.Fprintln(stdout, version)
			return err
		},
	}
}
