package output

import (
	"bytes"
	"encoding/json"
	"io"
	"strings"
	"testing"

	"code.byted.org/temai/open_cli/internal/core/errs"
)

func TestSuccessJSONEnvelope(t *testing.T) {
	var stdout bytes.Buffer
	p, err := New(&stdout, "json")
	if err != nil {
		t.Fatal(err)
	}
	if err := p.Success(Envelope{
		OK:       true,
		DryRun:   true,
		Identity: &Identity{AppKey: "abcdef", ShopID: "1"},
		Data:     map[string]any{"path": "/x"},
	}); err != nil {
		t.Fatal(err)
	}
	var env Envelope
	if err := json.Unmarshal(stdout.Bytes(), &env); err != nil {
		t.Fatal(err)
	}
	if !env.OK || !env.DryRun || env.Identity.ShopID != "1" {
		t.Fatalf("%+v", env)
	}
	if env.Identity.AppKey != "abcdef" {
		t.Fatalf("app_key=%q", env.Identity.AppKey)
	}
}

func TestFailureLeavesStdoutEmpty(t *testing.T) {
	var stdout, stderr bytes.Buffer
	p, err := New(&stdout, "json")
	if err != nil {
		t.Fatal(err)
	}
	if err := p.Failure(&stderr, errs.Auth("未登录", "先运行 doudian-open-cli auth login")); err != nil {
		t.Fatal(err)
	}
	if stdout.Len() != 0 {
		t.Fatalf("stdout=%q", stdout.String())
	}
	if !strings.Contains(stderr.String(), `"type":"auth"`) {
		t.Fatalf("stderr=%s", stderr.String())
	}
	if strings.Contains(stderr.String(), "access_token") {
		t.Fatal(stderr.String())
	}
}

func TestFailureSanitizesGatewayBody(t *testing.T) {
	payload := json.RawMessage([]byte("{\"msg\":\"ok\x1b[31m\r\nsecret\x00\"}"))
	err := errs.API("网关失败", "L1")
	err.Body = payload

	var jsonErr bytes.Buffer
	jp, newErr := New(io.Discard, "json")
	if newErr != nil {
		t.Fatal(newErr)
	}
	if ferr := jp.Failure(&jsonErr, err); ferr != nil {
		t.Fatal(ferr)
	}
	if strings.Contains(jsonErr.String(), "\x1b") || strings.Contains(jsonErr.String(), "\x00") || strings.Contains(jsonErr.String(), "\r") {
		t.Fatalf("json stderr=%q", jsonErr.String())
	}
	if !strings.Contains(string(err.Body), "\x1b") {
		t.Fatal("original error body must stay unchanged")
	}

	var textErr bytes.Buffer
	tp, newErr := New(io.Discard, "text")
	if newErr != nil {
		t.Fatal(newErr)
	}
	if ferr := tp.Failure(&textErr, err); ferr != nil {
		t.Fatal(ferr)
	}
	got := textErr.String()
	if strings.Contains(got, "\x1b") || strings.Contains(got, "\x00") || strings.Contains(got, "\r") {
		t.Fatalf("text stderr=%q", got)
	}
	if !strings.Contains(got, "secret") {
		t.Fatalf("text stderr=%q", got)
	}
}
