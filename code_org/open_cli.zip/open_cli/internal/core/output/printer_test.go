package output

import (
	"bytes"
	"errors"
	"testing"
)

type errorWriter struct {
	err error
}

func (w errorWriter) Write([]byte) (int, error) {
	return 0, w.err
}

func TestNewAcceptsSupportedFormats(t *testing.T) {
	for _, format := range []string{"text", "json"} {
		printer, err := New(&bytes.Buffer{}, format)
		if err != nil {
			t.Fatalf("format=%q err=%v", format, err)
		}
		if got := printer.IsJSON(); got != (format == "json") {
			t.Fatalf("format=%q IsJSON=%v", format, got)
		}
	}
}

func TestNewRejectsUnsupportedFormat(t *testing.T) {
	if _, err := New(&bytes.Buffer{}, "yaml"); err == nil {
		t.Fatal("期望非法格式返回错误")
	}
}

func TestPrinterJSONWritesSingleLineWithNewline(t *testing.T) {
	var output bytes.Buffer
	printer, err := New(&output, "json")
	if err != nil {
		t.Fatal(err)
	}
	if err := printer.JSON(map[string]string{"status": "ok"}); err != nil {
		t.Fatal(err)
	}
	if got, want := output.String(), "{\"status\":\"ok\"}\n"; got != want {
		t.Fatalf("got %q want %q", got, want)
	}
}

func TestPrinterJSONKeepsAmpersandInURL(t *testing.T) {
	var output bytes.Buffer
	printer, err := New(&output, "json")
	if err != nil {
		t.Fatal(err)
	}
	url := "https://fuwu.jinritemai.com/open/auth/content?userCode=abc&from=open_cli"
	if err := printer.JSON(map[string]string{"verification_url": url}); err != nil {
		t.Fatal(err)
	}
	got := output.String()
	if !bytes.Contains(output.Bytes(), []byte(`"verification_url":"`+url+`"`)) {
		t.Fatalf("got %q", got)
	}
	if bytes.Contains(output.Bytes(), []byte(`\u0026`)) {
		t.Fatalf("HTML-escaped ampersand: %q", got)
	}
}

func TestPrinterTextFormatsOutput(t *testing.T) {
	var output bytes.Buffer
	printer, err := New(&output, "text")
	if err != nil {
		t.Fatal(err)
	}
	if err := printer.Text("状态：%s\n", "成功"); err != nil {
		t.Fatal(err)
	}
	if got, want := output.String(), "状态：成功\n"; got != want {
		t.Fatalf("got %q want %q", got, want)
	}
}

func TestPrinterTextRemovesTerminalControlCharacters(t *testing.T) {
	var output bytes.Buffer
	printer, err := New(&output, "text")
	if err != nil {
		t.Fatal(err)
	}
	if err := printer.Text("%s\n", "safe\x1b[31m\r\nunsafe\x00"); err != nil {
		t.Fatal(err)
	}
	if got, want := output.String(), "safe  unsafe\n"; got != want {
		t.Fatalf("got %q want %q", got, want)
	}
}

func TestPrinterPropagatesWriterErrors(t *testing.T) {
	wantErr := errors.New("write failed")
	printer, err := New(errorWriter{err: wantErr}, "json")
	if err != nil {
		t.Fatal(err)
	}
	if err := printer.JSON(struct{}{}); !errors.Is(err, wantErr) {
		t.Fatalf("JSON err=%v", err)
	}

	printer, err = New(errorWriter{err: wantErr}, "text")
	if err != nil {
		t.Fatal(err)
	}
	if err := printer.Text("text"); !errors.Is(err, wantErr) {
		t.Fatalf("Text err=%v", err)
	}
}
