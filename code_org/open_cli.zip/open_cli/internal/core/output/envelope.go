package output

import (
	"encoding/json"
	"errors"
	"fmt"
	"io"

	"code.byted.org/temai/open_cli/internal/core/errs"
	"code.byted.org/temai/open_cli/internal/core/sanitize"
)

type Identity struct {
	Kind      string `json:"kind,omitempty"`
	AppKey    string `json:"app_key,omitempty"`
	ShopID    string `json:"shop_id,omitempty"`
	ShopName  string `json:"shop_name,omitempty"`
	ExpiresAt string `json:"expires_at,omitempty"`
}

type Meta struct {
	LogID      string `json:"log_id,omitempty"`
	DurationMS int64  `json:"duration_ms,omitempty"`
}

type Envelope struct {
	OK       bool      `json:"ok"`
	DryRun   bool      `json:"dry_run"`
	Identity *Identity `json:"identity,omitempty"`
	Data     any       `json:"data,omitempty"`
	Meta     *Meta     `json:"meta,omitempty"`
}

func (p *Printer) Success(env Envelope) error {
	env.OK = true
	if p.IsJSON() {
		return p.JSON(env)
	}
	dry := "false"
	if env.DryRun {
		dry = "true"
	}
	return p.Text("ok dry_run=%s\n", dry)
}

func (p *Printer) Failure(stderr io.Writer, err error) error {
	var typed *errs.Error
	if !errors.As(err, &typed) {
		typed = errs.Internal(err.Error())
	}
	view := sanitizeFailure(typed)
	if p.IsJSON() {
		return encodeJSON(stderr, view)
	}
	line := string(view.Type) + ": " + sanitize.Terminal(view.Message)
	if view.Hint != "" {
		line += "\n" + sanitize.Terminal(view.Hint)
	}
	if len(view.Body) > 0 {
		line += "\n" + string(view.Body)
	}
	_, werr := fmt.Fprintln(stderr, line)
	return werr
}

func sanitizeFailure(err *errs.Error) *errs.Error {
	if err == nil {
		return nil
	}
	out := *err
	if len(out.Body) > 0 {
		out.Body = json.RawMessage(sanitize.Terminal(string(out.Body)))
	}
	return &out
}
