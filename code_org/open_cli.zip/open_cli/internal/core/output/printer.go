package output

import (
	"errors"
	"fmt"
	"io"

	"code.byted.org/temai/open_cli/internal/core/jsonenc"
	"code.byted.org/temai/open_cli/internal/core/sanitize"
)

type Printer struct {
	w      io.Writer
	format string
}

func New(w io.Writer, format string) (*Printer, error) {
	if format != "text" && format != "json" {
		return nil, errors.New("output 仅支持 text 或 json")
	}
	return &Printer{w: w, format: format}, nil
}

func (p *Printer) IsJSON() bool {
	return p.format == "json"
}

func (p *Printer) JSON(v any) error {
	return encodeJSON(p.w, v)
}

func encodeJSON(w io.Writer, v any) error {
	return jsonenc.Encode(w, v)
}

func (p *Printer) Text(format string, args ...any) error {
	for i, arg := range args {
		if value, ok := arg.(string); ok {
			args[i] = sanitize.Terminal(value)
		}
	}
	_, err := fmt.Fprintf(p.w, format, args...)
	return err
}
