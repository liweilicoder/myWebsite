package jsoninput

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"strings"
)

const MaxBytes = 8 << 20

type Loader struct {
	stdin     io.Reader
	stdinUsed bool
}

func NewLoader(stdin io.Reader) *Loader {
	if stdin == nil {
		stdin = strings.NewReader("")
	}
	return &Loader{stdin: stdin}
}

func (l *Loader) Object(source, flagName string) (json.RawMessage, error) {
	return l.load(source, flagName, func(value any) bool {
		_, ok := value.(map[string]any)
		return ok
	}, "JSON 对象")
}

func (l *Loader) Array(source, flagName string) (json.RawMessage, error) {
	return l.load(source, flagName, func(value any) bool {
		_, ok := value.([]any)
		return ok
	}, "JSON 数组")
}

func (l *Loader) load(source, flagName string, accepts func(any) bool, expected string) (json.RawMessage, error) {
	if source == "" {
		return nil, fmt.Errorf("%s 不能为空", flagName)
	}

	var r io.Reader = strings.NewReader(source)
	var closeFile *os.File
	if source == "@-" {
		if l.stdinUsed {
			return nil, errors.New("同一命令只能使用一次 @-")
		}
		l.stdinUsed, r = true, l.stdin
	} else if strings.HasPrefix(source, "@") {
		f, err := os.Open(strings.TrimPrefix(source, "@"))
		if err != nil {
			return nil, fmt.Errorf("读取 %s 文件失败: %w", flagName, err)
		}
		closeFile, r = f, f
		defer closeFile.Close()
	}

	data, err := io.ReadAll(io.LimitReader(r, MaxBytes+1))
	if err != nil {
		return nil, fmt.Errorf("读取 %s 失败: %w", flagName, err)
	}
	if len(data) > MaxBytes {
		return nil, fmt.Errorf("%s 超过 8 MiB", flagName)
	}

	dec := json.NewDecoder(bytes.NewReader(data))
	var value any
	if err := dec.Decode(&value); err != nil {
		return nil, fmt.Errorf("%s 是无效 JSON: %w", flagName, err)
	}
	if err := requireEOF(dec); err != nil {
		return nil, fmt.Errorf("%s 只能包含一个 JSON 文档", flagName)
	}
	if !accepts(value) {
		return nil, fmt.Errorf("%s 必须是%s", flagName, expected)
	}

	var compact bytes.Buffer
	if err := json.Compact(&compact, data); err != nil {
		return nil, fmt.Errorf("压缩 %s 失败: %w", flagName, err)
	}
	return json.RawMessage(compact.Bytes()), nil
}

func requireEOF(dec *json.Decoder) error {
	var extra any
	err := dec.Decode(&extra)
	if errors.Is(err, io.EOF) {
		return nil
	}
	if err == nil {
		return errors.New("存在额外 JSON")
	}
	return err
}
