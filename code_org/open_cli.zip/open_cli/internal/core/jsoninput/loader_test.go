package jsoninput

import (
	"bytes"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestLoaderArraySources(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "tree.json")
	if err := os.WriteFile(path, []byte("[ {\"path\":\"a\"} ]\n"), 0o600); err != nil {
		t.Fatal(err)
	}
	tests := []struct {
		name, source string
		stdin        string
	}{
		{"inline", `[{"path":"a"}]`, ""},
		{"file", "@" + path, ""},
		{"stdin", "@-", `[{"path":"a"}]`},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := NewLoader(strings.NewReader(tt.stdin)).Array(tt.source, "--request-info")
			if err != nil {
				t.Fatal(err)
			}
			if string(got) != `[{"path":"a"}]` {
				t.Fatalf("got=%s", got)
			}
		})
	}
}

func TestLoaderArrayRejectsInvalidInput(t *testing.T) {
	tests := []struct{ name, source, want string }{
		{"empty", "", "不能为空"}, {"null", "null", "JSON 数组"},
		{"object", `{}`, "JSON 数组"}, {"scalar", `1`, "JSON 数组"},
		{"two documents", `[] []`, "只能包含一个 JSON 文档"},
		{"invalid", `[`, "无效 JSON"},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			_, err := NewLoader(bytes.NewReader(nil)).Array(tt.source, "--request-info")
			if err == nil || !strings.Contains(err.Error(), tt.want) {
				t.Fatalf("err=%v", err)
			}
		})
	}
}

func TestLoaderArrayRejectsSecondStdinAndOversize(t *testing.T) {
	loader := NewLoader(strings.NewReader(`[]`))
	if _, err := loader.Array("@-", "--request-info"); err != nil {
		t.Fatal(err)
	}
	if _, err := loader.Array("@-", "--response-info"); err == nil || !strings.Contains(err.Error(), "只能使用一次 @-") {
		t.Fatalf("err=%v", err)
	}
	tooLarge := "[\"" + strings.Repeat("x", MaxBytes) + "\"]"
	if _, err := NewLoader(strings.NewReader(tooLarge)).Array("@-", "--request-info"); err == nil || !strings.Contains(err.Error(), "8 MiB") {
		t.Fatalf("err=%v", err)
	}
}
