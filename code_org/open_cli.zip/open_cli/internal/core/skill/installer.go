//go:build linux || darwin

package skill

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"os"
	"path"
	"path/filepath"
	"strings"
	"syscall"
)

type target struct {
	agent string
	root  string
	path  string
	err   error
	skill string
	files []BundledFile
}

func (m *Manager) Install(ctx context.Context) (Result, error) {
	return m.run(ctx, operationInstall)
}

func (m *Manager) Update(ctx context.Context) (Result, error) {
	return m.run(ctx, operationUpdate)
}

func (m *Manager) Status(ctx context.Context) (Result, error) {
	return m.run(ctx, operationStatus)
}

type operation int

const (
	operationInstall operation = iota
	operationUpdate
	operationStatus
)

func (m *Manager) run(ctx context.Context, op operation) (Result, error) {
	result := Result{Skill: m.bundle.Name, Targets: []TargetResult{}}
	targets := m.discover()
	var failures []error
	for _, item := range targets {
		entry := TargetResult{Agent: item.agent, Path: item.path}
		var err error
		if item.err != nil {
			err = item.err
		} else {
			switch op {
			case operationInstall:
				entry.Status, err = installTarget(ctx, item, true)
			case operationUpdate:
				entry.Status, err = installTarget(ctx, item, false)
			case operationStatus:
				entry.Status, err = statusTarget(ctx, item)
			}
		}
		if err != nil {
			entry.Status = StatusError
			entry.Error = err.Error()
			failures = append(failures, fmt.Errorf("%s: %w", item.agent, err))
		}
		result.Targets = append(result.Targets, entry)
	}
	return result, errors.Join(failures...)
}

func (m *Manager) discover() []target {
	home := filepath.Clean(m.home)
	canonicalRoot := filepath.Join(home, ".agents")
	targets := []target{m.newTarget("universal", canonicalRoot, nil)}
	if !filepath.IsAbs(home) || home == "." {
		targets[0].err = fmt.Errorf("用户主目录必须是绝对路径")
	}

	candidates := []struct {
		agent string
		root  string
	}{
		{agent: "claude", root: filepath.Join(home, ".claude")},
		{agent: "codex", root: filepath.Join(home, ".codex")},
	}
	seen := map[string]struct{}{canonicalRoot: {}}
	for _, candidate := range candidates {
		root := candidate.root
		if _, duplicate := seen[root]; duplicate {
			continue
		}
		seen[root] = struct{}{}
		info, err := os.Lstat(root)
		if errors.Is(err, os.ErrNotExist) {
			continue
		}
		if err != nil {
			targets = append(targets, m.newTarget(candidate.agent, root, fmt.Errorf("检查 Agent 根目录: %w", err)))
			continue
		}
		if info.Mode()&os.ModeSymlink != 0 {
			targets = append(targets, m.newTarget(candidate.agent, root, fmt.Errorf("Agent 根目录不能是符号链接")))
			continue
		}
		if !info.IsDir() {
			targets = append(targets, m.newTarget(candidate.agent, root, fmt.Errorf("Agent 根路径不是目录")))
			continue
		}
		targets = append(targets, m.newTarget(candidate.agent, root, nil))
	}
	return targets
}

func (m *Manager) newTarget(agent, root string, err error) target {
	targetPath := ""
	if root != "" {
		root = filepath.Clean(root)
		targetPath = filepath.Join(root, "skills", m.bundle.Name)
	}
	return target{agent: agent, root: root, path: targetPath, err: err, skill: m.bundle.Name, files: m.bundle.Files}
}

func statusTarget(ctx context.Context, item target) (string, error) {
	if err := ctx.Err(); err != nil {
		return "", err
	}
	directory, exists, modesCurrent, err := openTargetDir(item, false, false)
	if err != nil {
		return "", err
	}
	if !exists {
		return StatusMissing, nil
	}
	defer directory.Close()

	managedFiles := 0
	current := modesCurrent
	for _, file := range item.files {
		if err := validateManagedPath(file.Path); err != nil {
			return "", err
		}
		parent, parentExists, parentModesCurrent, err := openRelativeDir(directory, path.Dir(file.Path), false, false)
		if err != nil {
			return "", err
		}
		if !parentExists {
			current = false
			continue
		}
		if parent != directory {
			defer parent.Close()
		}
		if !parentModesCurrent {
			current = false
		}
		content, mode, fileExists, err := readRegularAt(parent, path.Base(file.Path))
		if err != nil {
			return "", err
		}
		if !fileExists {
			current = false
			continue
		}
		managedFiles++
		if !bytes.Equal(content, file.Content) || mode.Perm() != 0o644 {
			current = false
		}
	}
	if managedFiles == 0 {
		return StatusMissing, nil
	}
	if current && managedFiles == len(item.files) {
		return StatusCurrent, nil
	}
	return StatusOutdated, nil
}

func installTarget(ctx context.Context, item target, create bool) (string, error) {
	state, err := statusTarget(ctx, item)
	if err != nil {
		return "", err
	}
	if state == StatusCurrent {
		return StatusSkipped, nil
	}
	if state == StatusMissing && !create {
		return StatusMissing, nil
	}
	if err := writeTarget(ctx, item, create); err != nil {
		return "", err
	}
	if state == StatusMissing {
		return StatusInstalled, nil
	}
	return StatusUpdated, nil
}

func writeTarget(ctx context.Context, item target, create bool) error {
	if err := ctx.Err(); err != nil {
		return err
	}
	directory, exists, _, err := openTargetDir(item, create, true)
	if err != nil {
		return err
	}
	if !exists {
		return fmt.Errorf("Skill 目标目录不存在")
	}
	defer directory.Close()

	for _, file := range item.files {
		if err := ctx.Err(); err != nil {
			return err
		}
		if err := validateManagedPath(file.Path); err != nil {
			return err
		}
		parent, _, _, err := openRelativeDir(directory, path.Dir(file.Path), true, true)
		if err != nil {
			return fmt.Errorf("安全打开受管目录 %s: %w", path.Dir(file.Path), err)
		}
		if parent != directory {
			defer parent.Close()
		}
		name := path.Base(file.Path)
		content, mode, fileExists, err := readRegularAt(parent, name)
		if err != nil {
			return err
		}
		if fileExists && bytes.Equal(content, file.Content) && mode.Perm() == 0o644 {
			continue
		}
		if err := atomicWriteAt(ctx, parent, name, file.Content, defaultAtomicOps()); err != nil {
			return fmt.Errorf("安装受管文件 %s: %w", file.Path, err)
		}
	}
	return nil
}

func validateManagedPath(name string) error {
	if name == "" || path.IsAbs(name) || path.Clean(name) != name || name == "." || strings.HasPrefix(name, "../") {
		return fmt.Errorf("非法内嵌 Skill 路径 %q", name)
	}
	for _, part := range strings.Split(name, "/") {
		if part == "" || part == "." || part == ".." {
			return fmt.Errorf("非法内嵌 Skill 路径 %q", name)
		}
	}
	return nil
}

func openRelativeDir(base *pinnedDir, relative string, create, repairMode bool) (*pinnedDir, bool, bool, error) {
	if relative == "." || relative == "" {
		return base, true, true, nil
	}
	current := base
	modesCurrent := true
	for _, name := range strings.Split(relative, "/") {
		next, err := current.openChildDir(name)
		if errors.Is(err, os.ErrNotExist) || errors.Is(err, syscall.ENOENT) {
			if !create {
				if current != base {
					_ = current.Close()
				}
				return nil, false, false, nil
			}
			next, err = current.createChildDir(name, 0o755)
			modesCurrent = false
		}
		if err != nil {
			if current != base {
				_ = current.Close()
			}
			return nil, false, false, err
		}
		mode, err := next.mode()
		if err != nil {
			_ = next.Close()
			if current != base {
				_ = current.Close()
			}
			return nil, false, false, err
		}
		if mode.Perm() != 0o755 {
			modesCurrent = false
			if repairMode {
				if err := next.chmod(0o755); err != nil {
					_ = next.Close()
					if current != base {
						_ = current.Close()
					}
					return nil, false, false, err
				}
			}
		}
		if current != base {
			_ = current.Close()
		}
		current = next
	}
	return current, true, modesCurrent, nil
}

func openTargetDir(item target, create, repairMode bool) (*pinnedDir, bool, bool, error) {
	if !filepath.IsAbs(item.root) || filepath.Clean(item.root) != item.root {
		return nil, false, false, fmt.Errorf("目标路径必须是清理后的绝对路径")
	}
	root, err := openPinnedDir(item.root, create && item.agent == "universal")
	if errors.Is(err, os.ErrNotExist) || errors.Is(err, syscall.ENOENT) {
		return nil, false, false, nil
	}
	if err != nil {
		return nil, false, false, err
	}
	current := root
	modesCurrent := true
	for _, name := range []string{"skills", item.skill} {
		next, childErr := current.openChildDir(name)
		if errors.Is(childErr, os.ErrNotExist) || errors.Is(childErr, syscall.ENOENT) {
			if !create {
				_ = current.Close()
				return nil, false, false, nil
			}
			next, childErr = current.createChildDir(name, 0o755)
			modesCurrent = false
		}
		if childErr != nil {
			_ = current.Close()
			return nil, false, false, fmt.Errorf("安全打开 Skill 目录: %w", childErr)
		}
		mode, modeErr := next.mode()
		if modeErr != nil {
			_ = next.Close()
			_ = current.Close()
			return nil, false, false, fmt.Errorf("检查 Skill 目录权限: %w", modeErr)
		}
		if mode.Perm() != 0o755 {
			modesCurrent = false
			if repairMode {
				if chmodErr := next.chmod(0o755); chmodErr != nil {
					_ = next.Close()
					_ = current.Close()
					return nil, false, false, fmt.Errorf("修复 Skill 目录权限: %w", chmodErr)
				}
			}
		}
		_ = current.Close()
		current = next
	}
	return current, true, modesCurrent, nil
}
