//go:build linux || darwin

package skill

import (
	"context"
	"errors"
	"io"
	"os"
	"path/filepath"
	"runtime"
	"syscall"
	"testing"
)

func testBundle() Bundle {
	return Bundle{Name: "djt", Files: []BundledFile{
		{Path: "SKILL.md", Content: []byte("# test skill\n")},
		{Path: "scripts/helper.py", Content: []byte("print(1)\n")},
	}}
}

func testManager(home string) *Manager {
	return NewManager(home, testBundle())
}

func assertInstalledFiles(t *testing.T, root string) {
	t.Helper()
	for _, file := range testBundle().Files {
		path := filepath.Join(root, filepath.FromSlash(file.Path))
		content, err := os.ReadFile(path)
		if err != nil {
			t.Fatalf("读取受管文件 %s: %v", file.Path, err)
		}
		if string(content) != string(file.Content) {
			t.Fatalf("受管文件内容不一致: %s", file.Path)
		}
		info, err := os.Stat(path)
		if err != nil || info.Mode().Perm() != 0o644 {
			t.Fatalf("受管文件权限不正确: %s mode=%v err=%v", file.Path, info.Mode(), err)
		}
	}
}

func TestInstallManagesCompleteDirectoryAndPreservesUnknownFiles(t *testing.T) {
	home := t.TempDir()
	target := filepath.Join(home, ".agents", "skills", "djt")
	if err := os.MkdirAll(target, 0o755); err != nil {
		t.Fatal(err)
	}
	unknown := filepath.Join(target, "notes.txt")
	if err := os.WriteFile(unknown, []byte("user data"), 0o600); err != nil {
		t.Fatal(err)
	}
	result, err := testManager(home).Install(context.Background())
	if err != nil || result.Targets[0].Status != StatusInstalled {
		t.Fatalf("result=%+v err=%v", result, err)
	}
	assertInstalledFiles(t, target)
	content, err := os.ReadFile(unknown)
	if err != nil || string(content) != "user data" {
		t.Fatalf("未知文件不应被删除或覆盖: %q err=%v", content, err)
	}
}

func TestMissingManagedFileAndWrongModeAreOutdatedAndUpdateRepairs(t *testing.T) {
	home := t.TempDir()
	manager := testManager(home)
	target := filepath.Join(home, ".agents", "skills", "djt")
	if _, err := manager.Install(context.Background()); err != nil {
		t.Fatal(err)
	}
	missing := filepath.Join(target, "scripts", "helper.py")
	if err := os.Remove(missing); err != nil {
		t.Fatal(err)
	}
	status, err := manager.Status(context.Background())
	if err != nil || status.Targets[0].Status != StatusOutdated {
		t.Fatalf("缺少受管文件应为 outdated: status=%+v err=%v", status, err)
	}
	updated, err := manager.Update(context.Background())
	if err != nil || updated.Targets[0].Status != StatusUpdated {
		t.Fatalf("update 应补齐文件: result=%+v err=%v", updated, err)
	}
	if err := os.Chmod(filepath.Join(target, "scripts", "helper.py"), 0o600); err != nil {
		t.Fatal(err)
	}
	if err := os.Chmod(filepath.Join(target, "scripts"), 0o700); err != nil {
		t.Fatal(err)
	}
	if err := os.Chmod(target, 0o700); err != nil {
		t.Fatal(err)
	}
	status, err = manager.Status(context.Background())
	if err != nil || status.Targets[0].Status != StatusOutdated {
		t.Fatalf("受管权限错误应为 outdated: status=%+v err=%v", status, err)
	}
	if _, err := manager.Update(context.Background()); err != nil {
		t.Fatal(err)
	}
	assertInstalledFiles(t, target)
	for _, directory := range []string{target, filepath.Join(target, "scripts")} {
		info, err := os.Stat(directory)
		if err != nil || info.Mode().Perm() != 0o755 {
			t.Fatalf("受管目录权限未修复: path=%s mode=%v err=%v", directory, info.Mode(), err)
		}
	}
}

func TestInstallRejectsManagedSubdirectorySymlink(t *testing.T) {
	if runtime.GOOS == "windows" {
		t.Skip("Windows 不在支持范围")
	}
	home := t.TempDir()
	target := filepath.Join(home, ".agents", "skills", "djt")
	if err := os.MkdirAll(target, 0o755); err != nil {
		t.Fatal(err)
	}
	outside := t.TempDir()
	if err := os.Symlink(outside, filepath.Join(target, "scripts")); err != nil {
		t.Fatal(err)
	}
	result, err := testManager(home).Install(context.Background())
	if err == nil || result.Targets[0].Status != StatusError {
		t.Fatalf("result=%+v err=%v", result, err)
	}
	entries, err := os.ReadDir(outside)
	if err != nil || len(entries) != 0 {
		t.Fatalf("不得写入 symlink 外部: entries=%v err=%v", entries, err)
	}
}

func TestDiscoverTargetsCreatesOnlyCanonicalAndExistingAgentRoots(t *testing.T) {
	home := t.TempDir()
	claude := filepath.Join(home, ".claude")
	codex := filepath.Join(home, ".codex")
	if err := os.Mkdir(claude, 0o755); err != nil {
		t.Fatal(err)
	}
	m := testManager(home)
	results, err := m.Install(context.Background())
	if err != nil {
		t.Fatal(err)
	}
	if len(results.Targets) != 2 || results.Targets[0].Agent != "universal" || results.Targets[1].Agent != "claude" {
		t.Fatalf("targets=%+v", results.Targets)
	}
	if _, err := os.Stat(filepath.Join(home, ".agents", "skills", "djt", "SKILL.md")); err != nil {
		t.Fatal(err)
	}
	if _, err := os.Stat(filepath.Join(claude, "skills", "djt", "SKILL.md")); err != nil {
		t.Fatal(err)
	}
	if _, err := os.Stat(codex); !errors.Is(err, os.ErrNotExist) {
		t.Fatalf("不应创建不存在的 Codex 根: %v", err)
	}
}

func TestInstallUpdateAndStatusSemantics(t *testing.T) {
	home := t.TempDir()
	m := testManager(home)
	path := filepath.Join(home, ".agents", "skills", "djt", "SKILL.md")

	installed, err := m.Install(context.Background())
	if err != nil || installed.Targets[0].Status != StatusInstalled {
		t.Fatalf("install=%+v err=%v", installed, err)
	}
	info, err := os.Stat(path)
	if err != nil || info.Mode().Perm() != 0o644 {
		t.Fatalf("mode=%v err=%v", info.Mode(), err)
	}
	current, err := m.Status(context.Background())
	if err != nil || current.Targets[0].Status != StatusCurrent {
		t.Fatalf("status=%+v err=%v", current, err)
	}
	if err := os.Chmod(path, 0o600); err != nil {
		t.Fatal(err)
	}
	wrongMode, err := m.Status(context.Background())
	if err != nil || wrongMode.Targets[0].Status != StatusOutdated {
		t.Fatalf("内容相同但 mode 非 0644 应为 outdated: status=%+v err=%v", wrongMode, err)
	}
	modeUpdated, err := m.Install(context.Background())
	if err != nil || modeUpdated.Targets[0].Status != StatusUpdated {
		t.Fatalf("install 应修复 mode: result=%+v err=%v", modeUpdated, err)
	}
	if err := os.Chmod(path, 0o600); err != nil {
		t.Fatal(err)
	}
	modeUpdated, err = m.Update(context.Background())
	if err != nil || modeUpdated.Targets[0].Status != StatusUpdated {
		t.Fatalf("update 应修复 mode: result=%+v err=%v", modeUpdated, err)
	}
	skipped, err := m.Install(context.Background())
	if err != nil || skipped.Targets[0].Status != StatusSkipped {
		t.Fatalf("install again=%+v err=%v", skipped, err)
	}
	if err := os.WriteFile(path, []byte("old"), 0o600); err != nil {
		t.Fatal(err)
	}
	outdated, err := m.Status(context.Background())
	if err != nil || outdated.Targets[0].Status != StatusOutdated {
		t.Fatalf("outdated=%+v err=%v", outdated, err)
	}
	updated, err := m.Update(context.Background())
	if err != nil || updated.Targets[0].Status != StatusUpdated {
		t.Fatalf("update=%+v err=%v", updated, err)
	}
	info, _ = os.Stat(path)
	if info.Mode().Perm() != 0o644 {
		t.Fatalf("updated mode=%v", info.Mode())
	}
}

func TestUpdateDoesNotCreateMissingSkill(t *testing.T) {
	home := t.TempDir()
	m := testManager(home)
	result, err := m.Update(context.Background())
	if err != nil || result.Targets[0].Status != StatusMissing {
		t.Fatalf("result=%+v err=%v", result, err)
	}
	if _, err := os.Stat(filepath.Join(home, ".agents")); !errors.Is(err, os.ErrNotExist) {
		t.Fatalf("update 不应创建目录: %v", err)
	}
}

func TestTargetsRunIndependentlyAndRejectSymlinks(t *testing.T) {
	if runtime.GOOS == "windows" {
		t.Skip("Windows 不在支持范围")
	}
	home := t.TempDir()
	claude := filepath.Join(home, ".claude")
	if err := os.Mkdir(claude, 0o755); err != nil {
		t.Fatal(err)
	}
	outside := t.TempDir()
	if err := os.Symlink(outside, filepath.Join(home, ".agents")); err != nil {
		t.Fatal(err)
	}
	m := testManager(home)
	result, err := m.Install(context.Background())
	if err == nil {
		t.Fatal("符号链接目标应使命令失败")
	}
	if len(result.Targets) != 2 || result.Targets[0].Status != StatusError || result.Targets[1].Status != StatusInstalled {
		t.Fatalf("targets=%+v err=%v", result.Targets, err)
	}
	if _, statErr := os.Stat(filepath.Join(outside, "skills")); !errors.Is(statErr, os.ErrNotExist) {
		t.Fatalf("不得写入符号链接外部: %v", statErr)
	}
}

func TestInstallRejectsSymlinkSkillFileWithoutReplacingIt(t *testing.T) {
	if runtime.GOOS == "windows" {
		t.Skip("Windows 不在支持范围")
	}
	home := t.TempDir()
	targetDir := filepath.Join(home, ".agents", "skills", "djt")
	if err := os.MkdirAll(targetDir, 0o755); err != nil {
		t.Fatal(err)
	}
	outside := filepath.Join(t.TempDir(), "outside.md")
	if err := os.WriteFile(outside, []byte("outside"), 0o644); err != nil {
		t.Fatal(err)
	}
	if err := os.Symlink(outside, filepath.Join(targetDir, "SKILL.md")); err != nil {
		t.Fatal(err)
	}
	result, err := testManager(home).Install(context.Background())
	if err == nil || result.Targets[0].Status != StatusError {
		t.Fatalf("result=%+v err=%v", result, err)
	}
	got, _ := os.ReadFile(outside)
	if string(got) != "outside" {
		t.Fatalf("外部文件被修改: %q", got)
	}
}

func TestStatusAndUpdateRejectSymlinkInMissingSkillPath(t *testing.T) {
	if runtime.GOOS == "windows" {
		t.Skip("Windows 不在支持范围")
	}
	for _, operation := range []struct {
		name string
		run  func(*Manager) (Result, error)
	}{
		{name: "status", run: func(m *Manager) (Result, error) { return m.Status(context.Background()) }},
		{name: "update", run: func(m *Manager) (Result, error) { return m.Update(context.Background()) }},
	} {
		t.Run(operation.name, func(t *testing.T) {
			home := t.TempDir()
			root := filepath.Join(home, ".agents")
			if err := os.Mkdir(root, 0o755); err != nil {
				t.Fatal(err)
			}
			outside := t.TempDir()
			if err := os.Symlink(outside, filepath.Join(root, "skills")); err != nil {
				t.Fatal(err)
			}
			result, err := operation.run(testManager(home))
			if err == nil || result.Targets[0].Status != StatusError {
				t.Fatalf("result=%+v err=%v", result, err)
			}
		})
	}
}

func TestStatusKeepsExistingManagedDirectoryModesUnchanged(t *testing.T) {
	home := t.TempDir()
	root := filepath.Join(home, ".agents")
	skillsDir := filepath.Join(root, "skills")
	djtDir := filepath.Join(skillsDir, "djt")
	if err := os.MkdirAll(djtDir, 0o700); err != nil {
		t.Fatal(err)
	}
	if err := os.Chmod(skillsDir, 0o700); err != nil {
		t.Fatal(err)
	}

	result, err := testManager(home).Status(context.Background())
	if err != nil || result.Targets[0].Status != StatusMissing {
		t.Fatalf("status=%+v err=%v", result, err)
	}
	for _, dir := range []string{skillsDir, djtDir} {
		info, statErr := os.Stat(dir)
		if statErr != nil || info.Mode().Perm() != 0o700 {
			t.Fatalf("status 不得修改目录权限: dir=%s mode=%v err=%v", dir, info.Mode(), statErr)
		}
	}
}

func TestInstallSetsManagedDirectoriesTo0755WithoutChangingExistingAgentRoot(t *testing.T) {
	home := t.TempDir()
	root := filepath.Join(home, ".agents")
	djtDir := filepath.Join(root, "skills", "djt")
	if err := os.MkdirAll(djtDir, 0o700); err != nil {
		t.Fatal(err)
	}
	if err := os.Chmod(root, 0o700); err != nil {
		t.Fatal(err)
	}
	if _, err := testManager(home).Install(context.Background()); err != nil {
		t.Fatal(err)
	}
	rootInfo, _ := os.Stat(root)
	if rootInfo.Mode().Perm() != 0o700 {
		t.Fatalf("不应修改既有 Agent 根权限: %v", rootInfo.Mode())
	}
	for _, dir := range []string{filepath.Join(root, "skills"), djtDir} {
		info, err := os.Stat(dir)
		if err != nil || info.Mode().Perm() != 0o755 {
			t.Fatalf("managed dir=%s mode=%v err=%v", dir, info.Mode(), err)
		}
	}
}

func TestAtomicWriteUsesPinnedParentAfterPathReplacement(t *testing.T) {
	if runtime.GOOS == "windows" {
		t.Skip("Windows 不在支持范围")
	}
	home := t.TempDir()
	parentPath := filepath.Join(home, ".agents", "skills", "djt")
	if err := os.MkdirAll(parentPath, 0o755); err != nil {
		t.Fatal(err)
	}
	parent, err := openPinnedDir(parentPath, false)
	if err != nil {
		t.Fatal(err)
	}
	defer parent.Close()
	moved := parentPath + ".moved"
	outside := t.TempDir()
	if err := os.Rename(parentPath, moved); err != nil {
		t.Fatal(err)
	}
	if err := os.Symlink(outside, parentPath); err != nil {
		t.Fatal(err)
	}
	if err := atomicWriteAt(context.Background(), parent, "SKILL.md", []byte("safe"), defaultAtomicOps()); err != nil {
		t.Fatal(err)
	}
	got, err := os.ReadFile(filepath.Join(moved, "SKILL.md"))
	if err != nil || string(got) != "safe" {
		t.Fatalf("受信目录内容=%q err=%v", got, err)
	}
	if _, err := os.Stat(filepath.Join(outside, "SKILL.md")); !errors.Is(err, os.ErrNotExist) {
		t.Fatalf("不得经替换后的 symlink 逃逸: %v", err)
	}
}

func TestAtomicWriteFailuresKeepOldFileAndCleanTemporary(t *testing.T) {
	stages := []string{"create", "write", "short-write", "chmod", "sync", "close", "rename"}
	for _, stage := range stages {
		t.Run(stage, func(t *testing.T) {
			dir := t.TempDir()
			path := filepath.Join(dir, "SKILL.md")
			if err := os.WriteFile(path, []byte("old"), 0o644); err != nil {
				t.Fatal(err)
			}
			parent, err := openPinnedDir(dir, false)
			if err != nil {
				t.Fatal(err)
			}
			defer parent.Close()
			ops := defaultAtomicOps()
			injected := errors.New("injected " + stage)
			expected := injected
			switch stage {
			case "create":
				ops.open = func(int, string, int, uint32) (int, error) { return -1, injected }
			case "write":
				ops.write = func(*os.File, []byte) (int, error) { return 0, injected }
			case "short-write":
				ops.write = func(*os.File, []byte) (int, error) { return 1, nil }
				expected = io.ErrShortWrite
			case "chmod":
				ops.chmod = func(*os.File, os.FileMode) error { return injected }
			case "sync":
				ops.sync = func(*os.File) error { return injected }
			case "close":
				ops.close = func(*os.File) error { return injected }
			case "rename":
				ops.rename = func(int, string, int, string) error { return injected }
			}
			if err := atomicWriteAt(context.Background(), parent, "SKILL.md", []byte("new"), ops); !errors.Is(err, expected) {
				t.Fatalf("err=%v", err)
			}
			got, err := os.ReadFile(path)
			if err != nil || string(got) != "old" {
				t.Fatalf("旧文件=%q err=%v", got, err)
			}
			entries, err := os.ReadDir(dir)
			if err != nil {
				t.Fatal(err)
			}
			if len(entries) != 1 || entries[0].Name() != "SKILL.md" {
				t.Fatalf("临时文件未清理: %v", entries)
			}
		})
	}
}

func TestAtomicWriteDoesNotCleanTemporaryPathAfterRename(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "SKILL.md")
	if err := os.WriteFile(path, []byte("old"), 0o644); err != nil {
		t.Fatal(err)
	}
	parent, err := openPinnedDir(dir, false)
	if err != nil {
		t.Fatal(err)
	}
	defer parent.Close()

	ops := defaultAtomicOps()
	rename := ops.rename
	ops.rename = func(oldFD int, oldName string, newFD int, newName string) error {
		if err := rename(oldFD, oldName, newFD, newName); err != nil {
			return err
		}
		fd, err := openat(oldFD, oldName, os.O_WRONLY|os.O_CREATE|os.O_EXCL|syscall.O_NOFOLLOW|syscall.O_CLOEXEC, 0o600)
		if err != nil {
			return err
		}
		return os.NewFile(uintptr(fd), oldName).Close()
	}
	unlink := ops.unlink
	ops.unlink = func(fd int, name string) error {
		if err := unlink(fd, name); err != nil {
			return err
		}
		return errors.New("rename 成功后不应再清理临时路径")
	}

	if err := atomicWriteAt(context.Background(), parent, "SKILL.md", []byte("new"), ops); err != nil {
		t.Fatalf("rename 已提交后不应返回错误: %v", err)
	}
	entries, err := os.ReadDir(dir)
	if err != nil {
		t.Fatal(err)
	}
	if len(entries) != 2 {
		t.Fatalf("同名并发文件不应被 defer 误删: %v", entries)
	}
}
