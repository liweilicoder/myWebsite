//go:build linux || darwin

package skill

import (
	"context"
	"errors"
	"fmt"
	"io"
	"os"
	"syscall"
)

type atomicOps struct {
	open   func(int, string, int, uint32) (int, error)
	write  func(*os.File, []byte) (int, error)
	chmod  func(*os.File, os.FileMode) error
	sync   func(*os.File) error
	close  func(*os.File) error
	rename func(int, string, int, string) error
	unlink func(int, string) error
}

func defaultAtomicOps() atomicOps {
	return atomicOps{
		open:   openat,
		write:  func(file *os.File, content []byte) (int, error) { return file.Write(content) },
		chmod:  func(file *os.File, mode os.FileMode) error { return file.Chmod(mode) },
		sync:   func(file *os.File) error { return file.Sync() },
		close:  func(file *os.File) error { return file.Close() },
		rename: renameat,
		unlink: unlinkat,
	}
}

func atomicWriteAt(ctx context.Context, parent *pinnedDir, name string, content []byte, ops atomicOps) (returnErr error) {
	if err := ctx.Err(); err != nil {
		return err
	}
	temporaryName, err := randomTemporaryName()
	if err != nil {
		return fmt.Errorf("生成临时文件名: %w", err)
	}
	fd, err := ops.open(parent.FD(), temporaryName, syscall.O_WRONLY|syscall.O_CREAT|syscall.O_EXCL|syscall.O_NOFOLLOW|syscall.O_CLOEXEC, 0o600)
	if err != nil {
		return fmt.Errorf("创建临时文件: %w", err)
	}
	temporary := os.NewFile(uintptr(fd), temporaryName)
	closed := false
	cleanupTemporary := true
	defer func() {
		if !closed {
			_ = temporary.Close()
		}
		if cleanupTemporary {
			if removeErr := ops.unlink(parent.FD(), temporaryName); removeErr != nil && !errors.Is(removeErr, syscall.ENOENT) && returnErr == nil {
				returnErr = fmt.Errorf("清理临时文件: %w", removeErr)
			}
		}
	}()
	written, err := ops.write(temporary, content)
	if err != nil {
		return fmt.Errorf("写入临时文件: %w", err)
	}
	if written != len(content) {
		return fmt.Errorf("写入临时文件: %w", io.ErrShortWrite)
	}
	if err := ops.chmod(temporary, 0o644); err != nil {
		return fmt.Errorf("设置临时文件权限: %w", err)
	}
	if err := ops.sync(temporary); err != nil {
		return fmt.Errorf("同步临时文件: %w", err)
	}
	if err := ops.close(temporary); err != nil {
		return fmt.Errorf("关闭临时文件: %w", err)
	}
	closed = true
	if err := ctx.Err(); err != nil {
		return err
	}
	if _, _, _, err := readRegularAt(parent, name); err != nil {
		return err
	}
	if err := ops.rename(parent.FD(), temporaryName, parent.FD(), name); err != nil {
		return fmt.Errorf("原子替换 Skill 文件: %w", err)
	}
	cleanupTemporary = false
	return nil
}
