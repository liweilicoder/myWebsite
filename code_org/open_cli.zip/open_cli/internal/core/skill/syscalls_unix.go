//go:build linux || darwin

package skill

import "golang.org/x/sys/unix"

func openat(dirfd int, path string, flags int, mode uint32) (int, error) {
	return unix.Openat(dirfd, path, flags, mode)
}

func mkdirat(dirfd int, path string, mode uint32) error {
	return unix.Mkdirat(dirfd, path, mode)
}

func renameat(oldfd int, oldpath string, newfd int, newpath string) error {
	return unix.Renameat(oldfd, oldpath, newfd, newpath)
}

func unlinkat(dirfd int, path string) error {
	return unix.Unlinkat(dirfd, path, 0)
}
