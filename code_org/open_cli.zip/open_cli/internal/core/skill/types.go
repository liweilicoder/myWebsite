package skill

import "strings"

const (
	StatusInstalled = "installed"
	StatusUpdated   = "updated"
	StatusSkipped   = "skipped"
	StatusMissing   = "missing"
	StatusCurrent   = "current"
	StatusOutdated  = "outdated"
	StatusError     = "error"
)

type TargetResult struct {
	Agent  string `json:"agent"`
	Path   string `json:"path,omitempty"`
	Status string `json:"status"`
	Error  string `json:"error,omitempty"`
}

type Result struct {
	Skill   string         `json:"skill"`
	Targets []TargetResult `json:"targets"`
}

type BundledFile struct {
	Path    string
	Content []byte
}

type Bundle struct {
	Name  string
	Files []BundledFile
}

type Manager struct {
	home   string
	bundle Bundle
}

func NewManager(home string, bundle Bundle) *Manager {
	if strings.TrimSpace(bundle.Name) == "" || strings.Contains(bundle.Name, "/") || bundle.Name == "." || bundle.Name == ".." {
		panic("Skill bundle name 无效")
	}
	return &Manager{home: home, bundle: bundle}
}
