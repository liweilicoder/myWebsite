//go:build windows

package skill

import (
	"context"
	"fmt"
)

func (m *Manager) Install(context.Context) (Result, error) {
	return m.unsupportedInstall()
}

func (m *Manager) Update(context.Context) (Result, error) {
	return m.unsupportedInstall()
}

func (m *Manager) Status(context.Context) (Result, error) {
	return m.unsupportedInstall()
}

func (m *Manager) unsupportedInstall() (Result, error) {
	return Result{Skill: m.bundle.Name}, fmt.Errorf("Skill 安装仅支持 macOS 与 Linux")
}
