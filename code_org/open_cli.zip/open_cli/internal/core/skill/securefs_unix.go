//go:build linux || darwin

package skill

import (
	"crypto/rand"
	"encoding/hex"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"syscall"
)

type pinnedDir struct {
	file *os.File
}

func (directory *pinnedDir) FD() int      { return int(directory.file.Fd()) }
func (directory *pinnedDir) Close() error { return directory.file.Close() }

func openPinnedDir(path string, create bool) (*pinnedDir, error) {
	if !filepath.IsAbs(path) || filepath.Clean(path) != path {
		return nil, fmt.Errorf("目标路径必须是清理后的绝对路径")
	}
	existing := path
	var missing []string
	for {
		info, err := os.Lstat(existing)
		if err == nil {
			if info.Mode()&os.ModeSymlink != 0 || !info.IsDir() {
				return nil, fmt.Errorf("安全打开目录 %s: %w", path, syscall.ENOTDIR)
			}
			break
		}
		if !errors.Is(err, os.ErrNotExist) {
			return nil, fmt.Errorf("安全打开目录 %s: %w", path, err)
		}
		if !create && existing == path {
			return nil, fmt.Errorf("安全打开目录 %s: %w", path, err)
		}
		missing = append([]string{filepath.Base(existing)}, missing...)
		parent := filepath.Dir(existing)
		if parent == existing {
			return nil, fmt.Errorf("安全打开目录 %s: %w", path, err)
		}
		existing = parent
	}
	current, err := os.Open(existing)
	if err != nil {
		return nil, fmt.Errorf("安全打开目录 %s: %w", path, err)
	}
	info, err := current.Stat()
	if err != nil || !info.IsDir() {
		_ = current.Close()
		if err == nil {
			err = syscall.ENOTDIR
		}
		return nil, fmt.Errorf("安全打开目录 %s: %w", path, err)
	}
	for _, part := range missing {
		if part == "" || part == "." || part == ".." {
			_ = current.Close()
			return nil, fmt.Errorf("安全打开目录 %s: 非法路径分量", path)
		}
		fd, openErr := openat(int(current.Fd()), part, syscall.O_RDONLY|syscall.O_DIRECTORY|syscall.O_NOFOLLOW|syscall.O_CLOEXEC, 0)
		if errors.Is(openErr, syscall.ENOENT) && create {
			if mkdirErr := mkdirat(int(current.Fd()), part, 0o755); mkdirErr != nil && !errors.Is(mkdirErr, syscall.EEXIST) {
				_ = current.Close()
				return nil, fmt.Errorf("创建目录 %s: %w", path, mkdirErr)
			}
			fd, openErr = openat(int(current.Fd()), part, syscall.O_RDONLY|syscall.O_DIRECTORY|syscall.O_NOFOLLOW|syscall.O_CLOEXEC, 0)
		}
		if openErr != nil {
			_ = current.Close()
			return nil, fmt.Errorf("安全打开目录 %s: %w", path, openErr)
		}
		next := os.NewFile(uintptr(fd), part)
		_ = current.Close()
		current = next
	}
	return &pinnedDir{file: current}, nil
}

func (directory *pinnedDir) openChildDir(name string) (*pinnedDir, error) {
	fd, err := openat(directory.FD(), name, syscall.O_RDONLY|syscall.O_DIRECTORY|syscall.O_NOFOLLOW|syscall.O_CLOEXEC, 0)
	if err != nil {
		return nil, err
	}
	return &pinnedDir{file: os.NewFile(uintptr(fd), name)}, nil
}

func (directory *pinnedDir) createChildDir(name string, mode os.FileMode) (*pinnedDir, error) {
	if err := mkdirat(directory.FD(), name, uint32(mode.Perm())); err != nil && !errors.Is(err, syscall.EEXIST) {
		return nil, err
	}
	return directory.openChildDir(name)
}

func (directory *pinnedDir) chmod(mode os.FileMode) error {
	return directory.file.Chmod(mode)
}

func (directory *pinnedDir) mode() (os.FileMode, error) {
	info, err := directory.file.Stat()
	if err != nil {
		return 0, err
	}
	return info.Mode(), nil
}

func readRegularAt(directory *pinnedDir, name string) ([]byte, os.FileMode, bool, error) {
	fd, err := openat(directory.FD(), name, syscall.O_RDONLY|syscall.O_NOFOLLOW|syscall.O_CLOEXEC, 0)
	if errors.Is(err, syscall.ENOENT) {
		return nil, 0, false, nil
	}
	if err != nil {
		return nil, 0, false, fmt.Errorf("安全打开 Skill 文件: %w", err)
	}
	file := os.NewFile(uintptr(fd), name)
	defer file.Close()
	info, err := file.Stat()
	if err != nil {
		return nil, 0, false, err
	}
	if !info.Mode().IsRegular() {
		return nil, 0, false, fmt.Errorf("Skill 路径不是普通文件")
	}
	content, err := io.ReadAll(file)
	if err != nil {
		return nil, 0, false, fmt.Errorf("读取 Skill 文件: %w", err)
	}
	return content, info.Mode(), true, nil
}

func randomTemporaryName() (string, error) {
	var value [16]byte
	if _, err := rand.Read(value[:]); err != nil {
		return "", err
	}
	return ".SKILL.md.tmp-" + hex.EncodeToString(value[:]), nil
}
