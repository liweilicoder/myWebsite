package identity

import (
	"io"
	"net/http"
	"net/http/httptest"
	"testing"
)

func TestVersionFallsBackWhenEmpty(t *testing.T) {
	orig := BuildVersion
	t.Cleanup(func() { BuildVersion = orig })
	BuildVersion = "  1.0.0-alpha.1  "
	if got := Version(); got != "1.0.0-alpha.1" {
		t.Fatalf("got=%q", got)
	}
	BuildVersion = "  "
	if got := Version(); got != DefaultVersion {
		t.Fatalf("empty=%q", got)
	}
}

func TestResolveFallsBackToCLI(t *testing.T) {
	cases := []struct {
		name string
		env  string
		want string
	}{
		{name: "empty", env: "", want: DefaultFrom},
		{name: "spaces", env: "  ", want: DefaultFrom},
		{name: "invalid space", env: "doubao moa", want: DefaultFrom},
		{name: "invalid header chars", env: "doubao\nmoa", want: DefaultFrom},
		{name: "doubao", env: "doubao_moa", want: "doubao_moa"},
		{name: "trimmed", env: "  other-agent.1  ", want: "other-agent.1"},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			got := Resolve(func(string) string { return tc.env })
			if got != tc.want {
				t.Fatalf("got=%q want=%q", got, tc.want)
			}
		})
	}
}

func TestResolveNilLookupUsesGetenv(t *testing.T) {
	t.Setenv(EnvOfficeAgentName, "doubao_moa")
	if got := Resolve(nil); got != "doubao_moa" {
		t.Fatalf("got=%q", got)
	}
}

func TestApplySetsHeader(t *testing.T) {
	t.Setenv(EnvOfficeAgentName, "doubao_moa")
	h := make(http.Header)
	Apply(h)
	if got := h.Get(HeaderFrom); got != "doubao_moa" {
		t.Fatalf("got=%q", got)
	}
	if got := h.Get(HeaderSource); got != SourceValue {
		t.Fatalf("source=%q", got)
	}
	if got := h.Get(HeaderVersion); got != Version() {
		t.Fatalf("version=%q", got)
	}
	Apply(nil)
}

func TestWrapInjectsFromWithoutMutatingOriginal(t *testing.T) {
	t.Setenv(EnvOfficeAgentName, "doubao_moa")
	var seen http.Header
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		seen = r.Header.Clone()
		w.WriteHeader(http.StatusNoContent)
	}))
	t.Cleanup(srv.Close)

	client := &http.Client{Transport: Wrap(http.DefaultTransport)}
	req, err := http.NewRequest(http.MethodGet, srv.URL, nil)
	if err != nil {
		t.Fatal(err)
	}
	resp, err := client.Do(req)
	if err != nil {
		t.Fatal(err)
	}
	io.Copy(io.Discard, resp.Body)
	resp.Body.Close()
	if req.Header.Get(HeaderFrom) != "" || req.Header.Get(HeaderSource) != "" || req.Header.Get(HeaderVersion) != "" {
		t.Fatalf("original request mutated: %v", req.Header)
	}
	if got := seen.Get(HeaderFrom); got != "doubao_moa" {
		t.Fatalf("sent from=%q", got)
	}
	if got := seen.Get(HeaderSource); got != SourceValue {
		t.Fatalf("sent source=%q", got)
	}
	if got := seen.Get(HeaderVersion); got != Version() {
		t.Fatalf("sent version=%q", got)
	}
}
