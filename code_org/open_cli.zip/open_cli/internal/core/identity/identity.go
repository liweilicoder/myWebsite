package identity

import (
	"net/http"
	"os"
	"regexp"
	"strings"
)

const (
	EnvOfficeAgentName = "DOUBAO_OFFICE_AGENT_NAME"
	HeaderFrom         = "X-Doudian-Open-Cli-From"
	HeaderSource       = "X-Cli-Source"
	HeaderVersion      = "X-Doudian-Open-Cli-Version"
	DefaultFrom        = "cli"
	SourceValue        = "doudian-open-cli"
	DefaultVersion     = "dev"
)

// BuildVersion is replaced by npm cross-platform builds through -ldflags -X.
// Keep in sync with internal/core/cli.BuildVersion.
var BuildVersion = "dev"

func Version() string {
	v := strings.TrimSpace(BuildVersion)
	if v == "" {
		return DefaultVersion
	}
	return v
}

var agentNamePattern = regexp.MustCompile(`^[A-Za-z0-9._-]{1,128}$`)

type Lookup func(string) string

func Resolve(lookup Lookup) string {
	if lookup == nil {
		lookup = os.Getenv
	}
	raw := strings.TrimSpace(lookup(EnvOfficeAgentName))
	if raw == "" || !agentNamePattern.MatchString(raw) {
		return DefaultFrom
	}
	return raw
}

func From() string {
	return Resolve(os.Getenv)
}

func Apply(header http.Header) {
	if header == nil {
		return
	}
	header.Set(HeaderFrom, From())
	header.Set(HeaderSource, SourceValue)
	header.Set(HeaderVersion, Version())
}
