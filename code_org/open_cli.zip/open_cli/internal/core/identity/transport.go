package identity

import "net/http"

type roundTripper struct {
	base http.RoundTripper
}

func Wrap(base http.RoundTripper) http.RoundTripper {
	if base == nil {
		base = http.DefaultTransport
	}
	return roundTripper{base: base}
}

func (t roundTripper) RoundTrip(req *http.Request) (*http.Response, error) {
	if req == nil {
		return t.base.RoundTrip(req)
	}
	cloned := req.Clone(req.Context())
	if cloned.Header == nil {
		cloned.Header = make(http.Header)
	}
	Apply(cloned.Header)
	return t.base.RoundTrip(cloned)
}
