package factory

import (
	"io"
	"testing"

	"code.byted.org/temai/open_cli/internal/core/httpmock"
)

func TestNewDefaultDoesNotCreateHTTPUntilCalled(t *testing.T) {
	f := NewDefault(&IOStreams{Out: io.Discard, ErrOut: io.Discard}, t.TempDir(), t.TempDir())
	if f.HttpClient == nil {
		t.Fatal("HttpClient func required")
	}
}

func TestNewDefaultHttpClientCached(t *testing.T) {
	f := NewDefault(&IOStreams{Out: io.Discard, ErrOut: io.Discard}, t.TempDir(), t.TempDir())
	a, err := f.HttpClient()
	if err != nil {
		t.Fatal(err)
	}
	b, err := f.HttpClient()
	if err != nil {
		t.Fatal(err)
	}
	if a != b {
		t.Fatal("HttpClient must be cached")
	}
}

func TestTestFactoryWiresMockHTTP(t *testing.T) {
	f, stdout, stderr, reg := TestFactory(t)
	if stdout == nil || stderr == nil {
		t.Fatal("buffers required")
	}
	reg.Register(&httpmock.Stub{Method: "GET", URL: "/ok", Body: `{"ok":true}`})
	client, err := f.HttpClient()
	if err != nil {
		t.Fatal(err)
	}
	resp, err := client.Get("http://example.test/ok")
	if err != nil {
		t.Fatal(err)
	}
	resp.Body.Close()
	if f.ConfigDir == "" || f.HomeDir == "" {
		t.Fatal("temp dirs required")
	}
}
