package factory

import (
	"bytes"
	"io"
	"net/http"
	"testing"

	"code.byted.org/temai/open_cli/internal/core/httpmock"
)

func TestFactory(t *testing.T) (*Factory, *bytes.Buffer, *bytes.Buffer, *httpmock.Registry) {
	t.Helper()
	reg := &httpmock.Registry{}
	t.Cleanup(func() { reg.Verify(t) })
	stdout := &bytes.Buffer{}
	stderr := &bytes.Buffer{}
	client := httpmock.NewClient(reg)
	f := &Factory{
		IOStreams:  &IOStreams{In: io.NopCloser(bytes.NewReader(nil)), Out: stdout, ErrOut: stderr},
		HttpClient: func() (*http.Client, error) { return client, nil },
		ConfigDir:  t.TempDir(),
		HomeDir:    t.TempDir(),
	}
	return f, stdout, stderr, reg
}
