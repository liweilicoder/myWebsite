package factory

import (
	"io"
	"net/http"
	"os"
	"sync"

	"code.byted.org/temai/open_cli/internal/core/httpx"
)

type IOStreams struct {
	In     io.Reader
	Out    io.Writer
	ErrOut io.Writer
}

type Factory struct {
	IOStreams  *IOStreams
	HttpClient func() (*http.Client, error)
	ConfigDir  string
	HomeDir    string
}

func NewDefault(streams *IOStreams, configDir, homeDir string) *Factory {
	if streams == nil {
		streams = &IOStreams{In: os.Stdin, Out: os.Stdout, ErrOut: os.Stderr}
	}
	f := &Factory{IOStreams: streams, ConfigDir: configDir, HomeDir: homeDir}
	var once sync.Once
	var client *http.Client
	f.HttpClient = func() (*http.Client, error) {
		once.Do(func() { client = httpx.NewClient() })
		return client, nil
	}
	return f
}
