package ppe

import (
	"net/http"
	"strings"
	"testing"
)

func TestResolveUsesFlagsOnly(t *testing.T) {
	config, err := Resolve(Input{
		UsePPE:    true,
		UsePPESet: true,
		Env:       "ppe_flag",
		EnvSet:    true,
	})
	if err != nil {
		t.Fatal(err)
	}
	if !config.Enabled || config.Env != "ppe_flag" {
		t.Fatalf("config=%+v", config)
	}
}

func TestResolveDisabledByDefault(t *testing.T) {
	config, err := Resolve(Input{})
	if err != nil {
		t.Fatal(err)
	}
	if config.Enabled || config.Env != DefaultEnvironment {
		t.Fatalf("config=%+v", config)
	}
}

func TestResolveRejectsPPEEnvironmentWithoutUsePPE(t *testing.T) {
	_, err := Resolve(Input{Env: "ppe_flag", EnvSet: true})
	if err == nil || !strings.Contains(err.Error(), "--ppe-env 只能与 --use-ppe=true 一起使用") {
		t.Fatalf("err=%v", err)
	}
}

func TestResolveValidatesEnvironmentName(t *testing.T) {
	_, err := Resolve(Input{
		UsePPE:    true,
		UsePPESet: true,
		Env:       "ppe\r\ninjected",
		EnvSet:    true,
	})
	if err == nil || !strings.Contains(err.Error(), "PPE 环境名无效") {
		t.Fatalf("err=%v", err)
	}
}

func TestConfigApplySetsHeadersOnlyWhenEnabled(t *testing.T) {
	header := make(http.Header)
	if err := (Config{Enabled: true, Env: "ppe_djt_cli"}).Apply(header); err != nil {
		t.Fatal(err)
	}
	if header.Get(UsePPEHeader) != "1" || header.Get(EnvironmentHeader) != "ppe_djt_cli" {
		t.Fatalf("header=%v", header)
	}

	header = make(http.Header)
	if err := (Config{}).Apply(header); err != nil {
		t.Fatal(err)
	}
	if header.Get(UsePPEHeader) != "" || header.Get(EnvironmentHeader) != "" {
		t.Fatalf("production header=%v", header)
	}
}
