package ppe

import (
	"errors"
	"fmt"
	"net/http"
	"regexp"
)

const (
	DefaultEnvironment = "ppe_djt_cli"

	UsePPEHeader      = "x-use-ppe"
	EnvironmentHeader = "x-tt-env"
)

var environmentPattern = regexp.MustCompile(`^[A-Za-z0-9._-]{1,128}$`)

type Input struct {
	UsePPE    bool
	UsePPESet bool
	Env       string
	EnvSet    bool
}

type Config struct {
	Enabled bool
	Env     string
}

func Resolve(input Input) (Config, error) {
	usePPE := input.UsePPE
	ppeEnv := DefaultEnvironment
	envSource := ""
	if input.EnvSet {
		ppeEnv = input.Env
		envSource = "--ppe-env"
	}
	if !usePPE && envSource != "" {
		return Config{}, errors.New("--ppe-env 只能与 --use-ppe=true 一起使用")
	}
	if usePPE && !environmentPattern.MatchString(ppeEnv) {
		source := envSource
		if source == "" {
			source = "--ppe-env"
		}
		return Config{}, fmt.Errorf("PPE 环境名无效: %s 必须匹配 %s", source, environmentPattern.String())
	}
	return Config{Enabled: usePPE, Env: ppeEnv}, nil
}

func (c Config) Apply(header http.Header) error {
	if !c.Enabled {
		return nil
	}
	if !environmentPattern.MatchString(c.Env) {
		return errors.New("PPE 环境名无效")
	}
	header.Set(UsePPEHeader, "1")
	header.Set(EnvironmentHeader, c.Env)
	return nil
}
