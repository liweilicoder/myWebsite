package browser

import (
	"fmt"
	"os/exec"
	"runtime"
)

type SystemOpener struct{}

func (SystemOpener) Open(url string) error {
	name, args, err := browserCommand(runtime.GOOS, url)
	if err != nil {
		return err
	}
	if err := exec.Command(name, args...).Start(); err != nil {
		return fmt.Errorf("启动浏览器失败: %w", err)
	}
	return nil
}

func browserCommand(goos, url string) (string, []string, error) {
	switch goos {
	case "darwin":
		return "open", []string{url}, nil
	case "windows":
		return "rundll32", []string{"url.dll,FileProtocolHandler", url}, nil
	case "linux":
		return "xdg-open", []string{url}, nil
	default:
		return "", nil, fmt.Errorf("不支持在 %s 上打开浏览器", goos)
	}
}
