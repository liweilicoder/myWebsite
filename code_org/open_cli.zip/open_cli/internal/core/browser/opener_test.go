package browser

import (
	"reflect"
	"testing"
)

func TestBrowserCommandUsesArgumentsWithoutShell(t *testing.T) {
	url := "https://verify.example.com/?code=U;touch /tmp/never"
	for _, tt := range []struct {
		goos string
		want []string
	}{
		{goos: "darwin", want: []string{"open", url}},
		{goos: "windows", want: []string{"rundll32", "url.dll,FileProtocolHandler", url}},
		{goos: "linux", want: []string{"xdg-open", url}},
	} {
		t.Run(tt.goos, func(t *testing.T) {
			name, args, err := browserCommand(tt.goos, url)
			if err != nil {
				t.Fatal(err)
			}
			got := append([]string{name}, args...)
			if !reflect.DeepEqual(got, tt.want) {
				t.Fatalf("got=%q want=%q", got, tt.want)
			}
		})
	}
}

func TestBrowserCommandRejectsUnsupportedOS(t *testing.T) {
	if _, _, err := browserCommand("plan9", "https://example.com"); err == nil {
		t.Fatal("expected error")
	}
}
