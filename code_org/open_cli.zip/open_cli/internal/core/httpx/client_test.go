package httpx

import (
	"io"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"code.byted.org/temai/open_cli/internal/core/identity"
)

func TestNewClientTimeoutAndFromHeader(t *testing.T) {
	t.Setenv(identity.EnvOfficeAgentName, "doubao_moa")
	var seenFrom, seenSource, seenVersion string
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		seenFrom = r.Header.Get(identity.HeaderFrom)
		seenSource = r.Header.Get(identity.HeaderSource)
		seenVersion = r.Header.Get(identity.HeaderVersion)
		w.WriteHeader(http.StatusNoContent)
	}))
	t.Cleanup(srv.Close)

	client := NewClient()
	if client.Timeout != 30*time.Second {
		t.Fatalf("timeout=%v", client.Timeout)
	}
	resp, err := client.Get(srv.URL)
	if err != nil {
		t.Fatal(err)
	}
	io.Copy(io.Discard, resp.Body)
	resp.Body.Close()
	if seenFrom != "doubao_moa" {
		t.Fatalf("from=%q", seenFrom)
	}
	if seenSource != identity.SourceValue {
		t.Fatalf("source=%q", seenSource)
	}
	if seenVersion != identity.Version() {
		t.Fatalf("version=%q", seenVersion)
	}
}
