package httpx

import (
	"net/http"
	"time"

	"code.byted.org/temai/open_cli/internal/core/identity"
)

func NewClient() *http.Client {
	return &http.Client{
		Timeout:   30 * time.Second,
		Transport: identity.Wrap(http.DefaultTransport),
		CheckRedirect: func(*http.Request, []*http.Request) error {
			return http.ErrUseLastResponse
		},
	}
}
