package jsonenc

import (
	"bytes"
	"testing"
)

func TestMarshalKeepsAmpersandInURL(t *testing.T) {
	url := "https://djt.bytedance.net/auditManage/task?type=domainPerm&recordId=1"
	got, err := Marshal(map[string]string{"auditManageUrl": url})
	if err != nil {
		t.Fatal(err)
	}
	if bytes.Contains(got, []byte(`\u0026`)) {
		t.Fatalf("%s", got)
	}
	if !bytes.Contains(got, []byte(`"auditManageUrl":"`+url+`"`)) {
		t.Fatalf("%s", got)
	}
}

func TestEncodeKeepsAmpersandAndTrailingNewline(t *testing.T) {
	var buf bytes.Buffer
	if err := Encode(&buf, map[string]string{"u": "a&b"}); err != nil {
		t.Fatal(err)
	}
	got := buf.Bytes()
	if !bytes.HasSuffix(got, []byte("\n")) {
		t.Fatalf("%q", got)
	}
	if bytes.Contains(got, []byte(`\u0026`)) {
		t.Fatalf("%q", got)
	}
}
