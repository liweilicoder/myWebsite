package sanitize

import (
	"strings"
	"testing"
)

func TestTerminalRemovesC0AndANSIIntroducer(t *testing.T) {
	if got, want := Terminal("safe\x1b[31m\r\nnext\x00"), "safe  next"; got != want {
		t.Fatalf("got %q want %q", got, want)
	}
}

func TestRemoteMessageRedactsTokenBeforeTerminalCleaning(t *testing.T) {
	got := RemoteMessage("denied token-secret\x1b[31m", "token-secret")
	if want := "denied [REDACTED]"; got != want {
		t.Fatalf("got %q want %q", got, want)
	}
}

func TestRemoteMessageRedactsTokenReassembledByTerminalNormalization(t *testing.T) {
	tests := map[string]string{
		"ANSI":    "token-\x1b[31msecret",
		"newline": "token-\nsecret",
		"NUL":     "token-\x00secret",
	}
	for name, message := range tests {
		t.Run(name, func(t *testing.T) {
			got := RemoteMessage("denied "+message, "token-secret")
			if strings.Contains(got, "token-secret") {
				t.Fatalf("token remained after normalization: %q", got)
			}
			for _, r := range got {
				if r < 0x20 || r == 0x7f {
					t.Fatalf("control character %U remained: %q", r, got)
				}
			}
		})
	}
}
