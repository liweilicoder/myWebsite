package sanitize

import (
	"regexp"
	"strings"
)

var ansiSequence = regexp.MustCompile(`\x1b(?:\[[0-?]*[ -/]*[@-~]|\][^\x07]*(?:\x07|\x1b\\)?)`)

// Terminal removes ANSI sequences and C0 controls to prevent terminal control injection.
func Terminal(value string) string {
	value = ansiSequence.ReplaceAllString(value, "")
	return strings.Map(func(r rune) rune {
		if r == 0x1b {
			return -1
		}
		if r == '\r' || r == '\n' || r == '\t' {
			return ' '
		}
		if r >= 0 && r < 0x20 || r == 0x7f {
			return -1
		}
		return r
	}, value)
}

func RemoteMessage(message, token string) string {
	if token != "" {
		message = strings.ReplaceAll(message, token, "[REDACTED]")
	}
	message = Terminal(message)
	if token != "" {
		message = strings.ReplaceAll(message, token, "[REDACTED]")
	}
	return message
}
