package httpmock

import (
	"io"
	"net/http"
	"strings"
	"testing"
)

func TestRegistryMatchesAndVerify(t *testing.T) {
	reg := &Registry{}
	reg.Register(&Stub{Method: "POST", URL: "/gateway", Status: 200, Body: map[string]any{"ok": true}})
	client := NewClient(reg)
	resp, err := client.Post("http://example.test/gateway", "application/json", strings.NewReader(`{}`))
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		t.Fatalf("status=%d", resp.StatusCode)
	}
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		t.Fatal(err)
	}
	if !strings.Contains(string(body), `"ok":true`) {
		t.Fatalf("body=%s", body)
	}
	if len(reg.Unmatched()) != 0 {
		t.Fatalf("unmatched=%v", reg.Unmatched())
	}
	reg.Verify(t)
}

func TestRegistryNoStubFails(t *testing.T) {
	client := NewClient(&Registry{})
	_, err := client.Get("http://example.test/none")
	if err == nil {
		t.Fatal("expected error")
	}
}

func TestRegistryUnmatchedStub(t *testing.T) {
	reg := &Registry{}
	reg.Register(&Stub{Method: "GET", URL: "/unused"})
	if len(reg.Unmatched()) != 1 {
		t.Fatalf("want 1 unmatched, got %d", len(reg.Unmatched()))
	}
}

func TestRegistryCapturesRequest(t *testing.T) {
	reg := &Registry{}
	stub := &Stub{Method: "POST", URL: "/p", Status: 204, RawBody: []byte{}}
	reg.Register(stub)
	req, err := http.NewRequest(http.MethodPost, "http://example.test/p", strings.NewReader(`{"a":1}`))
	if err != nil {
		t.Fatal(err)
	}
	req.Header.Set("X-Use-Ppe", "1")
	resp, err := NewClient(reg).Do(req)
	if err != nil {
		t.Fatal(err)
	}
	resp.Body.Close()
	if stub.CapturedHeaders.Get("X-Use-Ppe") != "1" {
		t.Fatalf("headers=%v", stub.CapturedHeaders)
	}
	if string(stub.CapturedBody) != `{"a":1}` {
		t.Fatalf("body=%s", stub.CapturedBody)
	}
}

func TestRegistryCapturesURL(t *testing.T) {
	reg := &Registry{}
	stub := &Stub{Method: "POST", URL: "/product/detail", Status: 200, Body: map[string]any{"code": 10000}}
	reg.Register(stub)
	client := NewClient(reg)
	_, err := client.Post("https://openapi-fxg.jinritemai.com/product/detail?method=product.detail&app_key=123", "application/json", strings.NewReader(`{}`))
	if err != nil {
		t.Fatal(err)
	}
	if !strings.Contains(stub.CapturedURL, "method=product.detail") || !strings.Contains(stub.CapturedURL, "app_key=123") {
		t.Fatalf("CapturedURL=%s", stub.CapturedURL)
	}
	reg.Verify(t)
}
