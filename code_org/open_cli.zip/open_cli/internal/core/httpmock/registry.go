package httpmock

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"strings"
	"sync"
	"testing"
)

type Stub struct {
	Method          string
	URL             string
	Status          int
	Body            any
	RawBody         []byte
	ContentType     string
	Headers         http.Header
	matched         bool
	CapturedHeaders http.Header
	CapturedBody    []byte
	CapturedURL     string
}

type Registry struct {
	mu    sync.Mutex
	stubs []*Stub
}

func (r *Registry) Register(s *Stub) {
	r.mu.Lock()
	defer r.mu.Unlock()
	if s.Status == 0 {
		s.Status = http.StatusOK
	}
	r.stubs = append(r.stubs, s)
}

func (r *Registry) RoundTrip(req *http.Request) (*http.Response, error) {
	urlStr := req.URL.String()
	r.mu.Lock()
	var matched *Stub
	for _, s := range r.stubs {
		if s.matched {
			continue
		}
		if s.Method != "" && s.Method != req.Method {
			continue
		}
		if s.URL != "" && !strings.Contains(urlStr, s.URL) {
			continue
		}
		s.matched = true
		s.CapturedURL = urlStr
		s.CapturedHeaders = req.Header.Clone()
		if req.Body != nil {
			s.CapturedBody, _ = io.ReadAll(req.Body)
			req.Body = io.NopCloser(bytes.NewReader(s.CapturedBody))
		}
		matched = s
		break
	}
	r.mu.Unlock()
	if matched == nil {
		return nil, fmt.Errorf("httpmock: no stub for %s %s", req.Method, req.URL)
	}
	resp, err := stubResponse(matched)
	if err != nil {
		return nil, fmt.Errorf("httpmock: stub %s %s: %w", matched.Method, matched.URL, err)
	}
	return resp, nil
}

func (r *Registry) Unmatched() []*Stub {
	r.mu.Lock()
	defer r.mu.Unlock()
	var out []*Stub
	for _, s := range r.stubs {
		if !s.matched {
			out = append(out, s)
		}
	}
	return out
}

func (r *Registry) Verify(t testing.TB) {
	t.Helper()
	for _, s := range r.Unmatched() {
		t.Errorf("httpmock: unmatched stub: %s %s", s.Method, s.URL)
	}
}

func stubResponse(s *Stub) (*http.Response, error) {
	ct := s.ContentType
	if ct == "" {
		ct = "application/json"
	}
	var body io.ReadCloser
	if s.RawBody != nil {
		body = io.NopCloser(bytes.NewReader(s.RawBody))
	} else {
		switch v := s.Body.(type) {
		case string:
			body = io.NopCloser(strings.NewReader(v))
		case []byte:
			body = io.NopCloser(bytes.NewReader(v))
		default:
			b, err := json.Marshal(v)
			if err != nil {
				return nil, fmt.Errorf("marshal body: %w", err)
			}
			body = io.NopCloser(bytes.NewReader(b))
		}
	}
	header := http.Header{"Content-Type": []string{ct}}
	if s.Headers != nil {
		for k, vs := range s.Headers {
			header[k] = append([]string(nil), vs...)
		}
	}
	return &http.Response{StatusCode: s.Status, Header: header, Body: body}, nil
}

func NewClient(reg *Registry) *http.Client {
	return &http.Client{
		Transport: reg,
		CheckRedirect: func(*http.Request, []*http.Request) error {
			return http.ErrUseLastResponse
		},
	}
}
