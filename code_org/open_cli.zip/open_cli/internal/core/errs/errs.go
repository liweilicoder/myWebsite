package errs

import (
	"encoding/json"
	"errors"
)

const (
	ExitOK         = 0
	ExitAPI        = 1
	ExitValidation = 2
	ExitAuth       = 3
	ExitNetwork    = 4
	ExitInternal   = 5
)

type Type string

const (
	TypeAuth       Type = "auth"
	TypePermission Type = "permission"
	TypeValidation Type = "validation"
	TypeRateLimit  Type = "rate_limit"
	TypeNetwork    Type = "network"
	TypeAPI        Type = "api"
	TypeInternal   Type = "internal"
)

type Error struct {
	Type    Type            `json:"type"`
	Code    string          `json:"code,omitempty"`
	Message string          `json:"message"`
	Hint    string          `json:"hint,omitempty"`
	LogID   string          `json:"log_id,omitempty"`
	Body    json.RawMessage `json:"body,omitempty"`
	Exit    int             `json:"-"`
}

func (e *Error) Error() string {
	if e == nil {
		return ""
	}
	return e.Message
}

func (e *Error) ExitCode() int {
	if e == nil {
		return ExitOK
	}
	if e.Exit == 0 {
		return ExitAPI
	}
	return e.Exit
}

func Validation(msg string) *Error {
	return &Error{Type: TypeValidation, Message: msg, Exit: ExitValidation}
}

func Auth(msg, hint string) *Error {
	return &Error{Type: TypeAuth, Message: msg, Hint: hint, Exit: ExitAuth}
}

func Network(msg string) *Error {
	return &Error{Type: TypeNetwork, Message: msg, Exit: ExitNetwork}
}

func API(msg, logID string) *Error {
	return &Error{Type: TypeAPI, Message: msg, LogID: logID, Exit: ExitAPI}
}

func Internal(msg string) *Error {
	return &Error{Type: TypeInternal, Message: msg, Exit: ExitInternal}
}

func ExitCode(err error) int {
	if err == nil {
		return ExitOK
	}
	var typed *Error
	if errors.As(err, &typed) {
		return typed.ExitCode()
	}
	return ExitAPI
}
