package errs

import (
	"encoding/json"
	"errors"
	"strings"
	"testing"
)

func TestValidationExitCode(t *testing.T) {
	err := Validation("bad flag")
	if err.Type != TypeValidation || err.ExitCode() != ExitValidation {
		t.Fatalf("%+v", err)
	}
	if ExitCode(err) != ExitValidation {
		t.Fatalf("ExitCode=%d", ExitCode(err))
	}
}

func TestAuthHint(t *testing.T) {
	err := Auth("未登录", "先运行 doudian-open-cli auth login")
	if err.Type != TypeAuth || err.ExitCode() != ExitAuth {
		t.Fatalf("%+v", err)
	}
	if err.Hint == "" {
		t.Fatal("hint required")
	}
}

func TestExitCodeUnknownIsAPI(t *testing.T) {
	if ExitCode(errors.New("plain")) != ExitAPI {
		t.Fatal("plain error should map to 1")
	}
}

func TestExitCodeNilIsOK(t *testing.T) {
	if ExitCode(nil) != ExitOK {
		t.Fatal("nil error should map to 0")
	}
	var typed *Error
	if typed.ExitCode() != ExitOK {
		t.Fatal("nil *Error should map to 0")
	}
}

func TestJSONOmitsEmptyAndSecrets(t *testing.T) {
	err := API("remote", "log-1")
	b, marshalErr := json.Marshal(err)
	if marshalErr != nil {
		t.Fatal(marshalErr)
	}
	s := string(b)
	if !strings.Contains(s, `"type":"api"`) || !strings.Contains(s, `"log_id":"log-1"`) {
		t.Fatal(s)
	}
	if strings.Contains(s, "access_token") {
		t.Fatal("json must not invent token fields")
	}
}
