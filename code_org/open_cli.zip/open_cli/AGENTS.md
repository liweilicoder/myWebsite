# Repository Guidelines

## 项目定位

本仓库产出两套 `doudian-open-cli`：对外包 `@bytedance/doudian-open-cli`（`cmd/doudian-open-cli`，不得链接点将台）与对内超集 `@ecom-open-cli/opencli`（`cmd/doudian-open-cli-internal`）。对外提供 `init`、`auth status|logout` 与真实 `api` 调用（两种身份都带 HMAC `sign`；网关对授权型自行处理验签）。

对内命令域为 `doudian-open-cli djt`，通过 `open_admin_web` 的固定 HTTP 接口完成 Device Flow 登录、动态业务域查询与 Agent Interface 配置/文档/状态推进；点将台业务服务为 `cmp.ecom.open_admin`。CLI 只消费既定 BFF 契约，不在本仓库修改 `open_admin_web`、`open_admin` 或 `open_gw`。

`api init` 依赖 PSM、BAM 方法名和 BAM 版本，但 DJT CLI 不维护 PSM、BAM 方法或版本列表。Agent 应优先复用运行环境已有的 BAM Skill，否则使用 `bytedcli --json bam psm search`、`bytedcli --json bam method list`、`bytedcli --json bam version list` 完成只读元数据发现；存在多个服务、方法、分支或版本候选时必须让用户确认，不得猜测或跨分支机械选择最大版本。

面向 Agent 的运行手册位于 `skills/djt/`（对内，点将台 `SKILL.md` 为入口 Hub；`api.md` 与 `spi.md` 同级承载 OpenAPI / SPI 完整 SOP）、`skills/open_cli_skill/`（对外 CLI 用法，经 `doudian-open-cli skills open_cli_skill` 打印）以及 `skills/biz/<业务>/`（入口经 `doudian-open-cli skills <业务名>` 打印；章节用 `--ref <name>`，脚本用 `--script <name>`）。新增或调整点将台命令时，必须同步更新对应文件与 `npm/internal/README.md`。新增业务 Skill 时按 `skills/biz/README.md` 与 `docs/spec/skill-layout.md` 交目录、跑校验并 `sync-skill`，不必改打包名单。

## Spec Coding（设计规格驱动）

本仓库采用 **spec coding**：行为契约与架构决策写在 `docs/spec/`，代码与 `skills/` 是实现与 Agent 运行手册。文档索引是 [`docs/README.md`](docs/README.md)。迭代时**先读/改相关 spec，再改代码与测试**，最后同步 Skill、embed 镜像与对应 onepage（若涉及跨仓或全景变更）。

| 文档 | 用途 |
|---|---|
| `docs/README.md` | 文档目录。先看这里，再打开对应文件 |
| `docs/open_cli_open_onepage.md` | 对外 CLI 建设（auth、原始 API、core 地基、`skills`） |
| `docs/open_cli_djt_onepage.md` | 点将台全景 |
| `docs/spec/dual-flavor-cli.md` | 双产物隔离、打包、文档分层 |
| `docs/spec/skill-layout.md` | 对外 Skill 目录、`skills` catalog/read、业务约束 |
| `docs/spec/*.md` | 子域详细设计规格（目标、边界、契约、状态机、验收标准）；命名见 `docs/README.md` |
| `skills/djt/` / `skills/open_cli_skill/` / `skills/biz/` | Agent 实操 SOP（点将台 / 开放 CLI / 业务） |

**维护规则（含 Agent 迭代）：**

1. `docs/spec/` **只放设计规格**，不放任务分解、交付顺序、进度报告或实施计划。**不要**维护 `docs/plans/` 或把实现计划写进 spec。
2. **Spec 文件名（硬约束）：** `docs/spec/*.md` 使用 **kebab-case**，按主题命名；**禁止** `YYYY-MM-DD-` 日期前缀（例如不要 `2026-10-15-foo.md`）。新增 spec 时先按下表选前缀，再在 [`docs/README.md`](docs/README.md) 文档表里登记一行：

   | 前缀 / 模式 | 含义 | 示例 |
   |---|---|---|
   | `open-cli-*` | 对外 CLI（授权、钥匙串等） | `open-cli-auth-invoke.md` |
   | `djt-*` | 点将台命令与 BFF 契约 | `djt-cli-spi-agent.md` |
   | `skill-*` / `npm-*` | Skill 与 npm 分发 | `skill-layout.md` |
   | 其它 | 横切能力 | `dual-flavor-cli.md`、`cli-output.md` |

3. 新增命令、HTTP 端点、flags、状态门禁或 breaking 变更：先更新或新增 `docs/spec/<topic>.md`（遵守上表命名），再实现；合入时 spec、代码、测试、`skills/djt/` 须一致。增删改目录时同步根 `README.md` 目录树。
4. 修改已有能力时，同步更新对应 spec 的「状态」、命令表、验收标准；勿让 spec 落后于代码。
5. MR 应能说明：改了哪份 spec、实现如何满足 spec、测试覆盖了哪些 spec 断言。
6. 新增或拆分文档时，更新 `docs/README.md` 和根 README 的文档入口。主文档写概要和链接，细节放在被链接的文件里。
7. 不改变命令、接口或对外行为的改动，不必改文档。方案还在讨论时不新增长篇；方案确认并开始改行为时，再同步相关文档。

## 项目结构

目录树只维护在根 [`README.md`](README.md)。增删改目录、包或该树中的关键文件时，必须在同一变更里更新 README。

- `cmd/doudian-open-cli/main.go`：对外进程入口，只装配 `core` + `open`，**禁止 import `internal/djt`**。
- `cmd/doudian-open-cli-internal/main.go`：对内超集入口，装配 `core` + `open` + `djt`。
- `internal/core/`：两边共用的输出、JSON 输入（`internal/core/jsoninput`，每项最大 8 MiB、单文档、数组顶层）、脱敏、URL 策略、浏览器、PPE、HTTP 客户端、钥匙串（`internal/core/keychain`）、Skill 安装器、根命令。
- `internal/open/`：开放平台面（`init` / `auth` / `api` / `skills`）。
- `internal/djt/`：点将台 HTTP、AgentService、AgentInterfaceClient、Transport、AgentSPIService、AgentSPIClient；`internal/djt/auth` 为员工 Device Flow。
- `internal/djt/cli/`：`djt` 子树 Cobra 命令（含 `djt spi`）。
- `internal/djt/transport.go`：固定 origin、认证/PPE headers、HTTP、响应上限、envelope 与 `RemoteError`。
- `skills/djt/`、`skills/open_cli_skill/`、`skills/biz/<业务>/`：Skill 唯一手工源；embed 镜像分别在 `internal/djt/skill/assets/djt/` 与 `internal/open/skill/assets/<name>/`。
- `npm/open/`、`npm/internal/`：两套 npm 包根。仓库根 `package.json` 为 private，不能 publish。
- `bin/`、`scripts/`：共用 launcher、按 `--flavor` 交叉编译与发布。
- `docs/open_cli_open_onepage.md`、`docs/open_cli_djt_onepage.md`：对外 / 点将台全景。
- `docs/spec/`：子域详细设计规格；隔离以 `dual-flavor-cli.md` 为准。

依赖方向：`cmd/doudian-open-cli` → core + open；`cmd/doudian-open-cli-internal` → core + open + djt；`open` 与 `djt` 都只依赖 `core`。禁止 `open → djt`、`core → open`、`core → djt`、`djt → open`。接口 ID、`modifyVersionId`、`statusV2`、step 等控制字段使用强类型；`requestInfo`、`responseInfo`、`errConfigList` 等复杂树使用 `json.RawMessage` 保留未知字段，不能在 CLI 复制整套业务 schema。

## 开发与验证

最低 Go 版本为 1.21。修改前先阅读相关实现及测试，并按测试先行方式工作。只运行与改动相关的测试；提交前执行完整门禁：

```bash
gofmt -w <修改的.go文件>
go test ./...
node --test
node scripts/sync-skill.mjs --check
go test -race ./...
go vet ./...
go build ./cmd/doudian-open-cli
go build ./cmd/doudian-open-cli-internal
```

修改 Agent Interface 文档或 npm 契约时，先运行定向门禁，再跑完整门禁：

```bash
node --test scripts/npm-package.test.mjs
node scripts/sync-skill.mjs --check
```

两套 npm 包目前都用 `scripts/release-npm.mjs` 发到 `https://bnpm.byted.org` 做内部验收，Node.js >=18。对内包名 `@ecom-open-cli/opencli`。对外仓库包名 `@bytedance/doudian-open-cli`；BNPM 没有 `@bytedance` scope，发 BNPM 时打包改成 `@ecom-open-cli/doudian-open-cli`，不改 git。安装后都只暴露 `doudian-open-cli`。不得在文档、Skill 或脚本中把 `opencli` 写作命令。仓库根不能 `npm pack` / `npm publish`。`npm/*/binaries/` 和 `*.tgz` 是本地构建产物，验收后删除且不得提交。

**对外 tarball 公网表面：** `npm/open/` 仓库与 `--npmjs` 打包的 README、`package.json`、CHANGELOG、LICENSE、skills **不得**出现 BNPM、`byted.org`、PPE、对内包名、内网站点。内部怎么发 BNPM 只写在本文件和发布脚本里，不要写进对外 README。**对外 CHANGELOG 只写用户可感知的能力**（命令能做什么、平台要求），不写请求头、验签、网关实现、预发布内部条目，也不用 changelog 当改动清单。后续升版同样遵守。发 BNPM：`npm run release:publish -- --yes --flavor=open`（打包时改名）。发公网 npmjs：必须在 `open_cli` 根执行 `npm run release:npmjs`（固定 `--flavor=open --npmjs`，`npx npm@latest stage publish`，不改名）。可执行 SOP：`docs/spec/npmjs-open-publish.md`。门禁：`node --test scripts/npm-package.test.mjs`（含 `assertOpenPublicSurface`）。

## npm 发布 SOP（AI 维护者必读）

发布需要 Node.js >=18、Go >=1.21、`tar`、可访问 BNPM 的网络环境，以及对目标包的发布权限。正式发 `latest` 只允许从已合入、已同步远端的干净 `main` 分支执行；开发分支预发布见下文 `--allow-dev-branch`。必须显式传入 `--flavor=open` 或 `--flavor=internal`。对内发布仍会构建并扫描对外产物。

发 `latest` 的顺序固定为：

1. 在功能分支改 `npm/<flavor>/package.json` 版本，并同步 `scripts/npm-package.test.mjs` 的版本断言。版本提交和功能一起推到远端功能分支。
2. 等该分支合进远端 `main`。`git fetch origin main` 之后，`origin/main` 的 `package.json` 必须已经是要发布的版本。
3. `git switch main && git pull --ff-only`，确认 `HEAD` 等于 `origin/main`，再执行下面的 `release:publish`。

远端 `main` 受保护，不能直接推版本提交。禁止在本地 `main` 上单独改版本、先发 npm、再把版本提交补到功能分支。线上版本还没有对应的远端 `main` 提交时，停下来等合入，不要发 `latest`。

### BNPM 登录（SSO，不要用 npm 密码）

BNPM **不要**用 `npm login` 的 Username/Password（无 TTY 时会退化成密码提示，且不是公司标准方式）。使用 **bnpm CLI + Lark 扫码 SSO**：

```bash
npm install -g @bytedance-dev/bnpm
bnpm login --auth-type=sso
```

流程（本机可调起浏览器时）：

1. 命令行自动调起浏览器
2. 用 Lark 扫描浏览器中的二维码
3. 命令行显示登录成功

验证登录（用户名应为自己）：

```bash
npm whoami --registry=http://bnpm.byted.org
```

登录态写入本机 `~/.npmrc` 后，`scripts/release-npm.mjs` 里的 `npm whoami` / `npm publish` 才能通过。

#### Devbox / 无法调起浏览器的环境

若环境（如 Devbox、Cursor Agent 子进程、远程 SSH）**无法自动打开浏览器**，有两种方式：

**方式 A：打印 SSO URL，在别处打开**

命令行会输出 SSO 登录 URL；复制到本机或有浏览器的机器打开，用 Lark 扫码完成授权。

```bash
# 直接用 npm（auth-type 须为 sso，不是 web）
npm login --auth-type=sso --registry=http://bnpm.byted.org --browser=false

# 或用 bnpm（无需全局安装）
npx @bytedance-dev/bnpm@latest login --auth-type=sso --browser=false
```

授权成功后回到 Devbox，再执行 `npm whoami --registry=http://bnpm.byted.org` 确认。

**方式 B：本机登录后复制凭据**

在本机完成 `bnpm login --auth-type=sso` 后，将本机 `~/.npmrc` 中与 BNPM 相关的配置（如 `//bnpm.byted.org/:_authToken=...`）复制到 Devbox 的 `~/.npmrc`。勿把 token 提交到 Git 或写入仓库文档。

### 发布前检查

```bash
npm whoami --registry=https://bnpm.byted.org
npm view @ecom-open-cli/opencli version --registry=https://bnpm.byted.org
```

每次发布必须使用一个从未发布过、且严格大于线上版本的版本号：`x.y.z` 或 `x.y.z-alpha|beta|rc.N`。预发布号自动打对应 dist-tag（`alpha`/`beta`/`rc`），禁止打 `latest`。改对应 `npm/<flavor>/package.json` 版本，并同步 `scripts/npm-package.test.mjs` 中的版本断言。一般修复使用 patch（`npm version patch --no-git-tag-version` 只适用于单包目录，本仓库请直接改 `npm/<flavor>/package.json`）；新增向后兼容能力使用 minor；不兼容改动使用 major。若修改了 `skills/djt/`、`skills/open_cli_skill/` 或 `skills/biz/`，必须先生成并检查 Go embed 镜像：

```bash
node scripts/sync-skill.mjs
node scripts/sync-skill.mjs --check
```

完成代码、文档、Skill 和版本改动后，运行完整门禁，将版本改动一起提交；合入 `main` 后再发 `latest`。不要提交 `binaries/`、`*.tgz`、token、Cookie 或 `.test-config/`。

在干净工作区执行只读发布检查。该命令会校验分支、工作区、Node 版本、BNPM 登录和版本递增，运行 Go/Node 测试、race、vet、build，构建四平台二进制，生成 tarball，再用 allowlist、权限和 Skill 字节一致性规则校验包内容；它不会执行 `npm publish`，结束后会清理本地构建产物。

**对外发 npmjs：** 在本仓库根执行（`package.json` 的 `"name"` 为 `open_cli`），不要用根目录 `npm publish` / `npm stage publish`，也不要在上级目录跑 `npm run`。可执行步骤见 `docs/spec/npmjs-open-publish.md`。

```bash
git switch main && git pull --ff-only
npm login --auth-type=web --registry=https://registry.npmjs.org
npm run release:npmjs -- --check
npm run release:npmjs -- --publish --yes
```

脚本只把包交到 **Staged Packages**。你到 https://www.npmjs.com/settings/~/#staged-packages 等 Validating 结束，点 Approve 并过 2FA，之后才可安装。本机 npm 11 没有 `stage`，由脚本调用 `npx npm@latest`。占用过的版本会 E409，必须升号。预发布打 `alpha`/`beta`/`rc`，禁止 latest。Go 须 1.22+ 且 `GOROOT` 与 `go` 一致；刚发完对内 BNPM 时先还原被 stamp 的 `npm/open`。安装核对：正式版用 `@latest`，预发布用 `@alpha` 或精确版本。细则见 `docs/spec/npmjs-open-publish.md`。

**main 发 `latest`：**

```bash
git switch main
git pull --ff-only
npm run release:check -- --flavor=internal
npm run release:publish -- --yes --flavor=internal
```

**功能分支预发布（打 `beta` tag，不覆盖 `latest`）：**

```bash
git switch feat/your-branch
git pull --ff-only
npm run release:publish -- --yes --flavor=internal --allow-dev-branch
```

安装预发布包：`npm install --global @ecom-open-cli/opencli@beta --registry=https://bnpm.byted.org`

没有 `--yes` 时 `release:publish` 必须拒绝真实发布。仓库根 `prepack` 会拒绝 `npm pack`。

脚本等价的关键手工步骤如下，只用于排障；日常发布优先使用上面的统一脚本：

```bash
node scripts/sync-skill.mjs --check
go test ./...
node --test
go test -race ./...
go vet ./...
go build ./cmd/doudian-open-cli
go build ./cmd/doudian-open-cli-internal
node scripts/build-npm-binaries.mjs --flavor=internal
node scripts/verify-npm-package.mjs <生成的-tarball.tgz> --flavor=internal
```

发布后必须查询线上精确版本，并在隔离或可清理的环境中安装 `latest` 做验收：

```bash
npm view @ecom-open-cli/opencli version --registry=https://bnpm.byted.org
npm install --global @ecom-open-cli/opencli@latest --registry=https://bnpm.byted.org
doudian-open-cli --version
doudian-open-cli djt version
doudian-open-cli djt self skill status --output json
```

`postinstall` 会 best-effort 安装 Skill；如果用户安装时用了 `--ignore-scripts`、目标 Agent 当时不存在，或状态显示 Skill 不是最新，显式更新：

```bash
doudian-open-cli djt self skill update --output json
```

用户或 Agent 获取最新版本时，直接重复执行 `npm install --global ...@latest`；不要假设本地全局包会自动升级。npm 已发布版本不可覆盖或重复发布；如发布失败，修复后必须再升一个新版本，禁止尝试重发同一版本。发布脚本不创建 Git commit、tag 或 MR，这些仍按仓库协作流程完成。

安装到本机：

```bash
go install ./cmd/doudian-open-cli
doudian-open-cli --help
```

`go build ./cmd/doudian-open-cli` 只在当前目录生成可执行文件；要直接输入 `doudian-open-cli`，应使用 `go install` 并确保 `$(go env GOPATH)/bin`（或 `GOBIN`）在 `PATH` 中。

## 命令与输出契约

- 命令按 `doudian-open-cli <domain> <resource> <action>` 分层。对内当前业务域为 `djt`；根上另有 `skills`（列出或打印内嵌开放/业务 Skill）与 `version`。对外入口注册 `auth` 与 `api`，没有 `self skill`。
- `internal/jsoninput` 现位于 `internal/core/jsoninput`。点将台依赖方向为 `internal/djt/cli -> AgentService -> AgentInterfaceClient -> Transport -> auth.HTTPDoer`。
- Agent Interface canonical 命令固定为 `doudian-open-cli djt api get|init|save|doc|advance-step`；API 测试使用 `doudian-open-cli djt api test boe|ppe|prod`，授权主体添加使用 `doudian-open-cli djt api test auth add`；`api` 父命令不执行操作，leaf 不接受位置参数。
- SPI canonical 命令为 `doudian-open-cli djt spi scene list|get|save|sync-boe`、`scene access-app list|get|save|enable`、`interface list|get|save|submit-review|cancel-upgrade` 等；`spi` 父命令不执行操作。完整 SOP 见 `skills/djt/spi.md`（与 `api.md` 同级）。`interface list` 用 `--name-like`/`--scene-id`/`--biz-domain-id` 模糊搜索与过滤；`access-app get` 返回 `implList`（含 `interfaceImplUrl`）。新建接口 apply 必须 `--confirmed-by-user`；示例 JSON 转字段树只用 `skills/djt/scripts/json_to_spi_param_tree.py`（只做本地、不得联网），提审后到网页完成审核。最短路径：`scene save --apply` → `scripts/json_to_spi_param_tree.py` 补必填/加密/Map/Header → `interface save --dry-run` 看 preview/errors → `save --apply`（新建还要 `doudian-open-cli djt biz-domain list --output json` + `--confirmed-by-user`）→ get 记录 `modifyVersionId` → `submit-review --dry-run` → `--apply` → 网页审核（CLI 停止）。`access-app save` 后仍为未启用，需要可见时再 `enable --apply`。
- 业务域查询使用只读 `doudian-open-cli djt biz-domain list`，动态调用 `GET /api/domain/list`；JSON 保持 `{code,message,data}` envelope，text 标明 id/name/prefix/available。申请域权限使用 `doudian-open-cli djt biz-domain apply --domain-ids`（无 dry-run，调用即提交）。
- `doudian-open-cli djt self skill install|status|update` 分别负责安装同步、只读检查、仅更新已安装 Skill；目标结果互相独立。
- `save` / `advance-step` 默认 dry-run，`--dry-run` 与 `--apply` 互斥；`doc` 无 dry-run且必须显式 `--apply`。`init` 无 dry-run，必须先执行 `doudian-open-cli djt biz-domain list --output json`，向用户展示完整确认清单并等待明确答复，再同时传 `--confirmed-by-user --apply`。该语义门禁只约束 init。`doc` 后必须重新 get 最新 `modifyVersionId`。
- `init` 的 `bizDomainId` 必须由 CLI 显式传 `--biz-domain-id > 0`，不得静默默认 15 或其他测试域；禁止 Agent 自行选择默认测试域或伪造确认。后端默认保持不动，避免影响非 CLI。
- 自动化和 Agent 调用默认使用 `--output json`；成功时 stdout 只包含一个 `{code,message,data}` JSON 文档并以换行结束，原始 `data` 不丢未知字段。
- 过程提示和错误写 stderr；失败 stdout 为空、退出码为 1。命令层只返回 error，`cmd/doudian-open-cli/main.go` 统一打印一次；不得修改该输出边界或把失败 JSON 写入 stdout。调用方必须检查退出码，不能把 stderr 当 JSON 解析。
- `auth status` 和 `auth whoami` 只读取本地凭据，不验证远端会话。
- Agent 登录必须使用两段式命令：先执行 `doudian-open-cli djt auth login start --output json`，立即向用户展示 `verification_url` 和 `user_code`；用户确认授权完成后执行 `doudian-open-cli djt auth login complete --output json`。有效会话期间重复执行 `start` 必须复用原会话，不得重复创建授权；登录成功前不得查询业务域或接口配置。兼容的一步式 `auth login` 仅用于可持续前台运行的人工终端。
- 点将台短期登录会话保存到用户配置目录下权限为 `0600` 的 `login-session.json`，只允许包含恢复 Device Flow 所需字段；不得向 stdout、stderr 或日志输出 `device_code`、`code_verifier`。`complete` 成功或会话过期时必须清理该文件。
- 开放面待完成会话只允许恢复 Device Flow 所需字段（`device_code`、`user_code`、`verification_url`、`expires_at`、`interval`）。本地用钥匙串主密钥加密后落盘，不写明文 `login-session.json`；仅 `DOUBAO_SANDBOX_TYPE=SaaS` 使用该明文文件，且不得访问系统钥匙串。不得向 stdout、stderr 或对话输出 `device_code` / token / secret。`user_code` 可能是长密文，只展示 `verification_url`。`auth logout` 删除凭据密文和待完成会话，不删除登录钥匙串账号 `master.key`。macOS 与飞书一样使用 `go-keyring` v0.2.8（`/usr/bin/security`），登录钥匙串解锁时不弹确认框。结论见 `docs/spec/open-cli-keychain-sandbox.md`。
- PPE 人工终端登录命令为 `doudian-open-cli djt auth login --use-ppe --ppe-env ppe_djt_cli`。PPE 只通过根命令 persistent `--use-ppe` 与 `--ppe-env` 配置，二者必须同时显式传入，`--ppe-env` 不能单独设置，必须同时启用 PPE，环境名沿用共享严格校验；CLI 不读取任何环境变量。完整 Login 内的 Start、Token、GetLoginUser 三次 CLI 请求使用同一 `ppe.Config`，生产默认三次均不注入 PPE header；浏览器确认页不能由 CLI 注入，PPE 联调必须通过泳道浏览器/请求头环境打开 verification URL，生产部署后无需。独立 `auth whoami` 继续只读本地缓存身份，不发远端请求，也不扩展凭据 schema。PPE 只在根命令注册 persistent flag；对内 `--help` 可见，对外 Hidden。
- 不得在 stdout、stderr、日志、测试 fixture 或文档示例中暴露真实 token、Cookie 或线上敏感地址。

## 配置与安全

所有 DJT 请求固定使用 `https://djt.bytedance.net`，不得向其他 origin 发送认证信息，也不得增加 URL/path/method/header 覆盖入口。动态业务域只读批准 `GET /api/domain/list`；Agent Interface 只批准以下五个端点：

```text
GET  /api/djt-cli/agent/interface/get
POST /api/djt-cli/agent/interface/init
POST /api/djt-cli/agent/interface/save
POST /api/djt-cli/agent/interface/doc
POST /api/djt-cli/agent/interface/advanceStep
POST /api/djt-cli/agent/api-test/execute
POST /api/djt-cli/agent/api-test/auth/add
GET  /api/djt-cli/agent/spi/scene/list
GET  /api/djt-cli/agent/spi/scene/get
POST /api/djt-cli/agent/spi/scene/save
POST /api/djt-cli/agent/spi/scene/sync-boe
GET  /api/djt-cli/agent/spi/scene/access-app/list
GET  /api/djt-cli/agent/spi/scene/access-app/get
POST /api/djt-cli/agent/spi/scene/access-app/save
POST /api/djt-cli/agent/spi/scene/access-app/enable
GET  /api/djt-cli/agent/spi/interface/get
POST /api/djt-cli/agent/spi/interface/save
POST /api/djt-cli/agent/spi/interface/submit-review
```

PPE 只通过根命令 persistent `--use-ppe` 与 `--ppe-env` 配置；不得读取环境变量；环境名必须通过 allowlist 校验，且 ppe-env 不得脱离 use-ppe 单独生效。JSON source 每项最多 8 MiB；Agent Interface transport 响应上限为 8 MiB，业务域响应上限保持 1 MiB。`advance-step` 发 POST 前必须 get 预检版本和状态，`statusV2 >= 330` 时拒绝，审核通过后的发布只能走网页；不得增加 raw API、网页配置 API、动态 metadata/schema 或任意状态跳转。

当前 Demo 将点将台 token 保存到 `{UserConfigDir}/doudian-open-cli/djt/credentials.json`，文件权限 `0600`。旧路径 `{UserConfigDir}/opencli/` 在对内启动时只读迁移。不得放宽权限、允许重定向认证请求、跨 origin 复用 token，或绕过 URL 校验。正式版本接入系统安全存储前，不得把 Demo 文件存储描述为生产安全方案。

Skill 只允许写入 canonical、Claude 和 Codex 固定目标：canonical 可创建，Claude/Codex 仅在 `~/.claude`、`~/.codex` 已存在时写入；不得读取环境变量覆盖 Agent 根目录。必须拒绝路径中的符号链接和异常类型，逐文件使用同目录临时文件原子替换为 `0644`，受管子目录为 `0755`，并保留完整 Skill 目录中的未知用户文件。这只适用于对内 `djt self skill`。开放与业务 Skill 用 `doudian-open-cli skills` 打印，不写入这些目录。修改 `skills/djt/`、`skills/open_cli_skill/` 或 `skills/biz/` 后运行 `node scripts/sync-skill.mjs`，提交同步后的完整 embed 镜像；禁止直接手改镜像。

## 提交规范

保持改动小而聚焦，提交信息使用简洁中文。不要提交二进制、日志、临时凭据或构建产物。除非用户明确要求，不创建 MR 或修改其他仓库。
