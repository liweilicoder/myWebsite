package main

import (
	"bytes"
	"os"
	"os/exec"
	"path/filepath"
	"testing"
)

func TestPublicBinaryOmitsDJTSecrets(t *testing.T) {
	output := filepath.Join(t.TempDir(), "doudian-open-cli")
	cmd := exec.Command("go", "build", "-o", output, ".")
	if out, err := cmd.CombinedOutput(); err != nil {
		t.Fatalf("go build: %v\n%s", err, out)
	}
	data, err := os.ReadFile(output)
	if err != nil {
		t.Fatal(err)
	}
	for _, needle := range []string{
		"djt.bytedance.net",
		"skills/djt",
		"AgentSpi",
		"X-DJT-CLI-Authorization",
		"SaveSpiTemplateInterface",
	} {
		if bytes.Contains(data, []byte(needle)) {
			t.Errorf("public binary contains %q", needle)
		}
	}
}
