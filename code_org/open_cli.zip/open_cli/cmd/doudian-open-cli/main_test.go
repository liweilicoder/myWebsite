package main

import (
	"os"
	"path/filepath"
	"strings"
	"testing"

	corecli "code.byted.org/temai/open_cli/internal/core/cli"
	"code.byted.org/temai/open_cli/internal/core/errs"
	"code.byted.org/temai/open_cli/internal/core/factory"
	opencli "code.byted.org/temai/open_cli/internal/open/cli"
	openskill "code.byted.org/temai/open_cli/internal/open/skill"
)

func TestPublicHelpHidesDJTAndPPE(t *testing.T) {
	f, stdout, _, _ := factory.TestFactory(t)
	root, _ := corecli.Build(f, corecli.RootOptions{Version: "test", ShowPPE: false}, opencli.Register)
	root.SetOut(stdout)
	root.SetArgs([]string{"--help"})
	if err := root.Execute(); err != nil {
		t.Fatal(err)
	}
	out := stdout.String()
	for _, forbidden := range []string{"djt", "--use-ppe", "--ppe-env", "api invoke", "+product", "self skill"} {
		if strings.Contains(out, forbidden) {
			t.Fatalf("public help must not contain %q:\n%s", forbidden, out)
		}
	}
	for _, want := range []string{"auth", "api", "init", "skills", "doudian-open-cli skills"} {
		if !strings.Contains(out, want) {
			t.Fatalf("public help must contain %q:\n%s", want, out)
		}
	}
}

func TestPublicHelpDoesNotRegisterDJT(t *testing.T) {
	f, _, _, _ := factory.TestFactory(t)
	root, _ := corecli.Build(f, corecli.RootOptions{Version: "test", ShowPPE: false}, opencli.Register)
	cmd, _, err := root.Find([]string{"djt"})
	if err == nil && cmd != nil && cmd != root {
		t.Fatal("public root must not contain djt")
	}
	if cmd, _, err := root.Find([]string{"self"}); err == nil && cmd != nil && cmd != root {
		t.Fatal("public root must not contain self")
	}
}

func TestPublicSkillsListsCatalog(t *testing.T) {
	f, stdout, _, _ := factory.TestFactory(t)
	root, _ := corecli.Build(f, corecli.RootOptions{Version: "test", ShowPPE: false}, opencli.Register)
	root.SetArgs([]string{"skills"})
	if err := root.Execute(); err != nil {
		t.Fatal(err)
	}
	got := stdout.String()
	if !strings.HasPrefix(got, openskill.OpenCLIBundleName+"\t") {
		t.Fatalf("无参数时应先列出 %s：%q", openskill.OpenCLIBundleName, got)
	}
	if !strings.Contains(got, "打印全文：doudian-open-cli skills <name>\n") {
		t.Fatalf("catalog 应提示如何阅读全文：%q", got)
	}
	if strings.Contains(got, "# doudian-open-cli") {
		t.Fatal("无参数时不得打印 SKILL.md 正文")
	}
	if strings.Contains(got, "djt") {
		t.Fatal("对外 catalog 不得出现 djt")
	}
	for _, doc := range openskill.Documents() {
		want := doc.Name + "\t" + doc.Description
		if !strings.Contains(got, want+"\n") {
			t.Fatalf("catalog 缺少 %q", want)
		}
	}
	if _, err := os.Stat(filepath.Join(f.HomeDir, ".agents")); !os.IsNotExist(err) {
		t.Fatalf("skills 不得写入 ~/.agents: %v", err)
	}
}

func TestPublicSkillsPrintsNamedMarkdown(t *testing.T) {
	f, stdout, _, _ := factory.TestFactory(t)
	root, _ := corecli.Build(f, corecli.RootOptions{Version: "test", ShowPPE: false}, opencli.Register)
	root.SetArgs([]string{"skills", "open_cli_skill"})
	if err := root.Execute(); err != nil {
		t.Fatal(err)
	}
	if stdout.String() != string(openskill.Markdown()) {
		t.Fatal("skills open_cli_skill 必须与内嵌 SKILL.md 完全一致")
	}
}

func TestPublicSkillsUnknownName(t *testing.T) {
	f, stdout, _, _ := factory.TestFactory(t)
	root, _ := corecli.Build(f, corecli.RootOptions{Version: "test", ShowPPE: false}, opencli.Register)
	root.SetArgs([]string{"skills", "djt"})
	err := root.Execute()
	if errs.ExitCode(err) != errs.ExitValidation {
		t.Fatalf("err=%v", err)
	}
	if stdout.Len() != 0 {
		t.Fatalf("失败时 stdout 必须为空: %q", stdout.String())
	}
}

func TestPublicSkillsIgnoresJSONOutputFlag(t *testing.T) {
	f, stdout, _, _ := factory.TestFactory(t)
	root, _ := corecli.Build(f, corecli.RootOptions{Version: "test", ShowPPE: false}, opencli.Register)
	root.SetArgs([]string{"--output", "json", "skills", "open_cli_skill"})
	if err := root.Execute(); err != nil {
		t.Fatal(err)
	}
	got := stdout.String()
	if got != string(openskill.Markdown()) {
		t.Fatal("skills 不受 --output json 影响")
	}
	if strings.HasPrefix(strings.TrimSpace(got), "{") {
		t.Fatal("skills 不得包一层 JSON")
	}
}
