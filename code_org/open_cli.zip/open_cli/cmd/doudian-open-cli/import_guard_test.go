package main

import (
	"os/exec"
	"strings"
	"testing"
)

func TestPublicMainDoesNotDependOnDJT(t *testing.T) {
	cmd := exec.Command("go", "list", "-deps", ".")
	out, err := cmd.CombinedOutput()
	if err != nil {
		t.Fatalf("go list -deps: %v\n%s", err, out)
	}
	for _, line := range strings.Split(string(out), "\n") {
		line = strings.TrimSpace(line)
		if line == "" {
			continue
		}
		if strings.Contains(line, "/internal/djt") {
			t.Errorf("public main depends on %s", line)
		}
	}
}
