package main

import (
	"bytes"
	"errors"
	"strings"
	"testing"

	"code.byted.org/temai/open_cli/internal/djt"
	"github.com/spf13/cobra"
)

func TestRunAgentFailureWritesOnlyStderrAndExitOne(t *testing.T) {
	suggestedValue := "43"
	remote := &djt.RemoteError{
		Code:    8000037,
		Message: "版本冲突",
		Errors: []djt.AgentFieldError{{
			Field:          "modifyVersionId",
			Reason:         "当前版本已更新",
			Fix:            "重新查询后重试",
			SuggestedValue: &suggestedValue,
		}},
		Current: &djt.AgentCurrent{InterfaceID: 2846, ModifyVersionID: 43},
	}
	var stdout, stderr bytes.Buffer
	root := &cobra.Command{
		Use:           "doudian-open-cli",
		SilenceErrors: true,
		SilenceUsage:  true,
		RunE: func(*cobra.Command, []string) error {
			return remote
		},
	}
	root.SetOut(&stdout)

	if code := run(root, nil, &stderr); code != 1 {
		t.Fatalf("exit code=%d", code)
	}
	if stdout.Len() != 0 {
		t.Fatalf("stdout=%q", stdout.String())
	}
	if got, want := stderr.String(), remote.Error()+"\n"; got != want {
		t.Fatalf("stderr=%q want=%q", got, want)
	}
	for _, want := range []string{
		"field=modifyVersionId",
		"reason=当前版本已更新",
		"fix=重新查询后重试",
		"suggestedValue=43",
		"current.modifyVersionId=43",
	} {
		if !strings.Contains(stderr.String(), want) {
			t.Fatalf("stderr=%q missing=%q", stderr.String(), want)
		}
	}
	if strings.Count(stderr.String(), "版本冲突") != 1 {
		t.Fatalf("错误被重复输出: stderr=%q", stderr.String())
	}
}

func TestRunPrintsCommandErrorExactlyOnce(t *testing.T) {
	commandErr := errors.New("base URL 仅允许 HTTPS 或 loopback HTTP")
	command := &cobra.Command{
		Use:           "doudian-open-cli",
		SilenceErrors: true,
		SilenceUsage:  true,
		RunE: func(*cobra.Command, []string) error {
			return commandErr
		},
	}
	var stderr bytes.Buffer
	if code := run(command, nil, &stderr); code != 1 {
		t.Fatalf("exit code=%d", code)
	}
	if got := strings.Count(stderr.String(), commandErr.Error()); got != 1 {
		t.Fatalf("stderr=%q count=%d", stderr.String(), got)
	}
}

func TestRunPrintsConstructionErrorExactlyOnce(t *testing.T) {
	constructionErr := errors.New("获取用户配置目录失败")
	var stderr bytes.Buffer
	if code := run(nil, constructionErr, &stderr); code != 5 {
		t.Fatalf("exit code=%d", code)
	}
	if got := strings.Count(stderr.String(), constructionErr.Error()); got != 1 {
		t.Fatalf("stderr=%q count=%d", stderr.String(), got)
	}
}

func TestRunSuccessDoesNotPrintError(t *testing.T) {
	command := &cobra.Command{Use: "doudian-open-cli", Run: func(*cobra.Command, []string) {}}
	var stderr bytes.Buffer
	if code := run(command, nil, &stderr); code != 0 || stderr.Len() != 0 {
		t.Fatalf("exit code=%d stderr=%q", code, stderr.String())
	}
}
