package main

import (
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"

	corecli "code.byted.org/temai/open_cli/internal/core/cli"
	"code.byted.org/temai/open_cli/internal/core/errs"
	"code.byted.org/temai/open_cli/internal/core/factory"
	djtcli "code.byted.org/temai/open_cli/internal/djt/cli"
	opencli "code.byted.org/temai/open_cli/internal/open/cli"
	"github.com/spf13/cobra"
)

func run(command *cobra.Command, constructionErr error, stderr io.Writer) int {
	if constructionErr != nil {
		_, _ = fmt.Fprintln(stderr, constructionErr)
		return errs.ExitInternal
	}
	if err := command.Execute(); err != nil {
		var typed *errs.Error
		if !errors.As(err, &typed) {
			_, _ = fmt.Fprintln(stderr, err)
		}
		return errs.ExitCode(err)
	}
	return errs.ExitOK
}

func newInternalRoot() (*cobra.Command, error) {
	homeDir, err := os.UserHomeDir()
	if err != nil {
		return nil, fmt.Errorf("无法获取用户主目录: %w", err)
	}
	base, err := os.UserConfigDir()
	if err != nil {
		return nil, fmt.Errorf("无法获取用户配置目录: %w", err)
	}
	f := factory.NewDefault(&factory.IOStreams{In: os.Stdin, Out: os.Stdout, ErrOut: os.Stderr}, filepath.Join(base, "doudian-open-cli"), homeDir)
	root, format := corecli.Build(f, corecli.RootOptions{
		Version: corecli.BuildVersion,
		ShowPPE: true,
	}, opencli.Register)
	if err := djtcli.Attach(root, f, format, corecli.BuildVersion); err != nil {
		return nil, err
	}
	return root, nil
}

func main() {
	root, err := newInternalRoot()
	os.Exit(run(root, err, os.Stderr))
}
